package com.hookaddon.modules;

import com.hookaddon.HookAddon;
import com.hookaddon.nav.Navigator;
import com.hookaddon.persist.HookStore;
import com.hookaddon.spawner.RtpFallback;
import com.hookaddon.spawner.SpawnerSearcher;
import com.hookaddon.spawner.SpawnerTarget;
import com.hookaddon.task.Capability;
import com.hookaddon.task.ConflictPolicy;
import com.hookaddon.task.MiningController;
import com.hookaddon.task.TaskManager;
import com.hookaddon.util.HookStatus;
import com.hookaddon.util.SafetyChecks;
import java.util.EnumSet;
import java.util.List;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;

/**
 * Priority two module: find spawners in loaded chunks, walk to them, mine them, and fall back to
 * {@code /rtp} when a search area is exhausted.
 *
 * <p>Honest about what the client can see: only chunks the client has loaded are searched, a
 * spawner is only reported as confirmed once its block entity has synced and the mob type is known,
 * and a teleport is only treated as done when the player position actually changed.
 */
public class AutoSpawner extends Module {
    private enum Phase {
        SEARCHING,
        NAVIGATING,
        MINING,
        WAITING_FOR_TYPE,
        NO_TARGET,
        RTP_SENT,
        POST_RTP,
        PAUSED
    }

    private final SettingGroup sgSearch = settings.getDefaultGroup();
    private final SettingGroup sgRtp = settings.createGroup("RTP Fallback");
    private final SettingGroup sgMovement = settings.createGroup("Movement & Mining");
    private final SettingGroup sgSafety = settings.createGroup("Safety");
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgKeys = settings.createGroup("Keys");

    // Search --------------------------------------------------------------------------------

    private final Setting<java.util.Set<EntityType<?>>> spawnerTypes =
            sgSearch.add(new EntityTypeListSetting.Builder()
                    .name("spawner-types")
                    .description("Spawner types to search for; uncheck a type to ignore it")
                    .defaultValue(
                            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.CREEPER,
                            EntityType.CAVE_SPIDER, EntityType.BLAZE, EntityType.MAGMA_CUBE, EntityType.SLIME,
                            EntityType.WITCH, EntityType.SILVERFISH, EntityType.ENDERMAN, EntityType.PILLAGER,
                            EntityType.VINDICATOR, EntityType.EVOKER, EntityType.GUARDIAN, EntityType.DROWNED,
                            EntityType.STRAY, EntityType.HUSK, EntityType.PHANTOM, EntityType.GHAST)
                    .build());

    private final Setting<Boolean> onlySelected = sgSearch.add(new BoolSetting.Builder()
            .name("only-selected-types")
            .description("Ignore spawners whose mob is not in the list above")
            .defaultValue(true)
            .build());

    private final Setting<Integer> searchRadius = sgSearch.add(new IntSetting.Builder()
            .name("search-radius")
            .description("Horizontal search radius in blocks, loaded chunks only")
            .defaultValue(48)
            .sliderRange(8, 128)
            .build());

    private final Setting<Integer> searchHeight = sgSearch.add(new IntSetting.Builder()
            .name("search-height")
            .description("Blocks to scan above and below your position")
            .defaultValue(24)
            .sliderRange(8, 64)
            .build());

    private final Setting<Integer> budgetPerTick = sgSearch.add(new IntSetting.Builder()
            .name("budget-per-tick")
            .description("Maximum loaded chunks inspected each tick, higher is faster but laggier")
            .defaultValue(64)
            .sliderRange(1, 512)
            .build());

    private final Setting<Integer> searchTimeout = sgSearch.add(new IntSetting.Builder()
            .name("search-timeout")
            .description("Seconds before a search is considered exhausted")
            .defaultValue(90)
            .sliderRange(10, 600)
            .build());

    private final Setting<Integer> searchAttempts = sgSearch.add(new IntSetting.Builder()
            .name("max-search-attempts")
            .description("Searches in one place before the no-target action runs")
            .defaultValue(3)
            .range(1, 50)
            .build());

    private final Setting<Integer> searchCooldown = sgSearch.add(new IntSetting.Builder()
            .name("search-cooldown")
            .description("Seconds between two searches in the same area")
            .defaultValue(5)
            .sliderRange(0, 120)
            .build());

    private final Setting<Boolean> skipVisited = sgSearch.add(new BoolSetting.Builder()
            .name("skip-visited")
            .description("Do not report spawner positions that were already inspected in this session")
            .defaultValue(true)
            .build());

    public enum NoTargetAction {
        RTP("Run the RTP fallback"),
        RESTART("Restart the search here"),
        DISABLE("Disable the module"),
        PAUSE("Pause until toggled again");

        public final String title;

        NoTargetAction(String title) {
            this.title = title;
        }
    }

    private final Setting<NoTargetAction> onNoTarget = sgSearch.add(new EnumSetting.Builder<NoTargetAction>()
            .name("on-no-target")
            .description("What to do when the search area is exhausted")
            .defaultValue(NoTargetAction.RTP)
            .build());

    // RTP -----------------------------------------------------------------------------------

    private final Setting<Boolean> rtpEnabled = sgRtp.add(new BoolSetting.Builder()
            .name("rtp-enabled")
            .description("Allow the module to run a teleport command when nothing is found")
            .defaultValue(true)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP)
            .build());

    private final Setting<String> rtpCommand = sgRtp.add(new StringSetting.Builder()
            .name("rtp-command")
            .description("Command sent to teleport, must match what the server accepts")
            .defaultValue("/rtp")
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Integer> rtpRetryDelay = sgRtp.add(new IntSetting.Builder()
            .name("rtp-retry-delay")
            .description("Minimum seconds between two teleport attempts")
            .defaultValue(60)
            .sliderRange(5, 600)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Integer> rtpMaxAttempts = sgRtp.add(new IntSetting.Builder()
            .name("rtp-max-attempts")
            .description("Consecutive failed attempts before the fallback pauses")
            .defaultValue(3)
            .range(1, 20)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Integer> rtpTimeout = sgRtp.add(new IntSetting.Builder()
            .name("rtp-timeout")
            .description("Seconds to wait for the position to change after sending the command")
            .defaultValue(30)
            .sliderRange(5, 120)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Integer> rtpPostDelay = sgRtp.add(new IntSetting.Builder()
            .name("rtp-after-teleport-delay")
            .description("Seconds to wait after a confirmed teleport before searching again")
            .defaultValue(4)
            .sliderRange(0, 30)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Double> rtpMinDistance = sgRtp.add(new DoubleSetting.Builder()
            .name("rtp-min-distance")
            .description("Blocks you must move for the teleport to count as confirmed")
            .defaultValue(32)
            .range(4, 256)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<Boolean> rtpPauseAfterFailures = sgRtp.add(new BoolSetting.Builder()
            .name("rtp-pause-after-failures")
            .description("Stop trying once the attempt limit is reached instead of retrying forever")
            .defaultValue(true)
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    private final Setting<List<String>> rtpFailureKeywords = sgRtp.add(new StringListSetting.Builder()
            .name("rtp-failure-keywords")
            .description("Chat keywords that mark a teleport attempt as denied")
            .defaultValue("cooldown", "permission", "cannot", "can't", "not allowed", "must wait", "denied",
                    "insufficient", "not available")
            .visible(() -> onNoTarget.get() == NoTargetAction.RTP && rtpEnabled.get())
            .build());

    // Movement & mining ---------------------------------------------------------------------

    private final Setting<Boolean> navigate = sgMovement.add(new BoolSetting.Builder()
            .name("navigate")
            .description("Walk towards a confirmed spawner")
            .defaultValue(true)
            .build());

    private final Setting<Double> reach = sgMovement.add(new DoubleSetting.Builder()
            .name("reach")
            .description("Interaction distance in blocks")
            .defaultValue(4.5)
            .range(3.0, 6.0)
            .build());

    private final Setting<Boolean> rotate = sgMovement.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Look at the spawner while mining it")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> swing = sgMovement.add(new BoolSetting.Builder()
            .name("swing")
            .description("Swing the hand while mining")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> autoTool = sgMovement.add(new BoolSetting.Builder()
            .name("auto-tool")
            .description("Use the fastest pickaxe for the spawner")
            .defaultValue(true)
            .build());

    private final Setting<Integer> minToolDurability = sgMovement.add(new IntSetting.Builder()
            .name("min-tool-durability")
            .description("Do not use a tool with fewer durability points left")
            .defaultValue(10)
            .range(0, 500)
            .visible(autoTool::get)
            .build());

    private final Setting<Integer> mineTimeout = sgMovement.add(new IntSetting.Builder()
            .name("mine-timeout")
            .description("Ticks a single spawner may take before the attempt is abandoned")
            .defaultValue(300)
            .range(40, 2000)
            .build());

    private final Setting<Integer> maxNavigationRecoveries = sgMovement.add(new IntSetting.Builder()
            .name("max-recoveries")
            .description("Stuck recovery attempts before a target is abandoned")
            .defaultValue(3)
            .range(1, 10)
            .build());

    private final Setting<Integer> maxTargetFailures = sgMovement.add(new IntSetting.Builder()
            .name("max-target-failures")
            .description("Targets that may fail in a row before the search restarts")
            .defaultValue(3)
            .range(1, 20)
            .build());

    // Safety --------------------------------------------------------------------------------

    private final Setting<Boolean> avoidLava = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-lava")
            .description("Do not mine next to lava")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> avoidFalling = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-falling-blocks")
            .description("Do not mine with sand or gravel above")
            .defaultValue(true)
            .build());

    private final Setting<ConflictPolicy> conflictPolicy = sgSafety.add(new EnumSetting.Builder<ConflictPolicy>()
            .name("conflict-policy")
            .description("What to do when another Hook module already owns movement or mining")
            .defaultValue(ConflictPolicy.REJECT)
            .build());

    // Render --------------------------------------------------------------------------------

    private final Setting<Boolean> renderTarget = sgRender.add(new BoolSetting.Builder()
            .name("render-target")
            .description("Highlight the current spawner target")
            .defaultValue(true)
            .build());

    private final Setting<SettingColor> targetColor = sgRender.add(new ColorSetting.Builder()
            .name("target-color")
            .description("Colour of the highlighted spawner")
            .defaultValue(new SettingColor(255, 90, 90, 200))
            .visible(renderTarget::get)
            .build());

    // Keys ----------------------------------------------------------------------------------

    private final Setting<Keybind> stopKey = sgKeys.add(new KeybindSetting.Builder()
            .name("stop-key")
            .description("Stop searching and cancel any pending teleport")
            .defaultValue(Keybind.none())
            .action(this::manualStop)
            .build());

    // State ---------------------------------------------------------------------------------

    private final SpawnerSearcher searcher = new SpawnerSearcher();
    private final RtpFallback rtp = new RtpFallback();

    private Phase phase = Phase.SEARCHING;
    private SpawnerTarget target;
    private BlockPos mineTarget;

    private int attempts;
    private int consecutiveTargetFailures;
    private int searchTicks;
    private int candidateTicks;
    private long searchStartedAtMs;
    private long nextSearchAtMs;
    private int postRtpTicks;
    private int saveCounter;
    private String status = "starting";

    /** Whether this module currently holds the MOVE/MINE capabilities. */
    private boolean claimed;
    /** Set when the connection dropped mid-search, so the next tick can resume cleanly. */
    private boolean interrupted;

    public AutoSpawner() {
        super(HookAddon.CATEGORY, "auto-spawner",
                "Finds spawners in loaded chunks, mines them and falls back to a teleport command when the area is exhausted.");
    }

    // Lifecycle ------------------------------------------------------------------------------

    @Override
    public void onActivate() {
        HookStore.ensureDirectories();

        if (!ensureClaim()) return;

        HookStore.SpawnerState saved = HookStore.loadSpawnerState();
        if (saved != null && saved.visited != null) searcher.loadVisited(saved.visited);
        if (saved != null) rtp.restoreCounters(saved.rtpAttempts, saved.lastRtpAt);

        attempts = 0;
        consecutiveTargetFailures = 0;
        target = null;
        mineTarget = null;
        phase = Phase.SEARCHING;
        interrupted = false;
        startSearch(false);
        HookStatus.reset("spawner");
        info("Searching for spawners in loaded chunks (radius %d, %d types).",
                searchRadius.get(), spawnerTypes.get().size());
    }

    @Override
    public void onDeactivate() {
        finish();
    }

    private void finish() {
        Navigator.get().stop(name);
        MiningController.get().reset(name);
        searcher.stop();
        saveState();
        TaskManager.get().release(name);
        claimed = false;
        rtp.reset();
        HookStatus.reset("spawner");
    }

    private void forceStop() {
        if (isActive()) disable();
    }

    /**
     * Claims the movement and mining capabilities if they are not held yet. Used both when the
     * module starts and when it has to carry on after a disconnect, because the task registry is
     * wiped on every leave and a module that keeps ticking without its claims would silently get
     * refused by the navigator and mining controller.
     *
     * @return true when the module holds its capabilities and may keep working
     */
    private boolean ensureClaim() {
        if (claimed) return true;
        if (!isActive()) return false;

        TaskManager.ClaimResult claim = TaskManager.get().claim(
                name, title, EnumSet.of(Capability.MOVE, Capability.MINE), conflictPolicy.get(), this::forceStop);
        if (!claim.ok()) {
            error(claim.message());
            disable();
            return false;
        }

        claimed = true;
        return true;
    }

    /** Fresh search after the connection came back, keeping the positions already scanned. */
    private void resumeAfterReconnect() {
        interrupted = false;
        target = null;
        mineTarget = null;
        attempts = 0;
        consecutiveTargetFailures = 0;
        phase = Phase.SEARCHING;
        startSearch(false);
        HookStatus.info(this, "Reconnected, resuming the spawner search.");
    }

    private void manualStop() {
        if (!isActive()) return;

        if (phase == Phase.RTP_SENT) {
            rtp.stop(rtpOptions(), this::info);
        }

        target = null;
        mineTarget = null;
        phase = Phase.PAUSED;
        Navigator.get().stop(name);
        MiningController.get().reset(name);
        searcher.stop();
        info("Stopped. Toggle the module to start a new search.");
    }

    // Ticking --------------------------------------------------------------------------------

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (phase == Phase.PAUSED) {
            // Idle by choice: let go of the shared capabilities so another module can use them.
            interrupted = false;
            if (claimed) {
                Navigator.get().stop(name);
                MiningController.get().reset(name);
                TaskManager.get().release(name);
                claimed = false;
            }
            return;
        }

        if (!ensureClaim()) return;
        if (interrupted) resumeAfterReconnect();

        switch (phase) {
            case SEARCHING -> tickSearching();
            case WAITING_FOR_TYPE -> tickWaitingForType();
            case NAVIGATING -> tickNavigating();
            case MINING -> tickMining();
            case NO_TARGET -> tickNoTarget();
            case RTP_SENT -> tickRtp();
            case POST_RTP -> tickPostRtp();
            case PAUSED -> {
                // Nothing runs until the user restarts the module.
            }
        }

        if (++saveCounter >= 200) {
            saveCounter = 0;
            saveState();
        }
    }

    private void tickSearching() {
        searchTicks++;

        long elapsed = (System.currentTimeMillis() - searchStartedAtMs) / 1000;
        if (elapsed >= searchTimeout.get()) {
            handleNoTarget("search timeout after " + elapsed + "s");
            return;
        }

        SpawnerSearcher.Result result = searcher.tick(searchOptions());
        status = "scanning, " + searcher.scanned() + " chunks scanned";

        switch (result.outcome()) {
            case CONFIRMED -> {
                target = result.target();
                phase = Phase.NAVIGATING;
                consecutiveTargetFailures = 0;
                HookStatus.progressNow(this, "spawner", "Found a %s at %s",
                        describeType(target), format(target.pos()));
                saveState();
            }
            case CANDIDATE -> {
                candidateTicks = 0;
                phase = Phase.WAITING_FOR_TYPE;
                status = "candidate at " + format(result.target().pos()) + ", waiting for its type";
            }
            case NO_TARGET -> {
                if (searcher.lastCandidate() != null) {
                    target = searcher.lastCandidate();
                    candidateTicks = 0;
                    phase = Phase.WAITING_FOR_TYPE;
                } else {
                    handleNoTarget("area exhausted after " + searcher.scanned() + " chunk scans");
                }
            }
            case SCANNING -> {
                if (searchTicks % 100 == 0) {
                    HookStatus.progress(this, "spawner-search",
                            "Searching... %d chunk scans, %ds left", searcher.scanned(),
                            Math.max(0, searchTimeout.get() - elapsed));
                }
            }
        }
    }

    /** A spawner block is visible but its block entity has not synced yet: give it a moment. */
    private void tickWaitingForType() {
        if (target == null) {
            phase = Phase.SEARCHING;
            return;
        }

        if (!mc.world.getBlockState(target.pos()).isOf(net.minecraft.block.Blocks.SPAWNER)) {
            target = null;
            phase = Phase.SEARCHING;
            return;
        }

        if (++candidateTicks <= 100) {
            SpawnerSearcher.Result check = searcher.check(target.pos(), searchOptions());
            if (check.outcome() == SpawnerSearcher.Outcome.CONFIRMED) {
                target = check.target();
                phase = Phase.NAVIGATING;
                HookStatus.progressNow(this, "spawner", "Found a %s at %s",
                        describeType(target), format(target.pos()));
                return;
            }
            status = "waiting for the spawner type (" + candidateTicks + " ticks)";
            return;
        }

        if (onlySelected.get() && !spawnerTypes.get().isEmpty()) {
            HookStatus.warn(this, "Spawner at %s did not report its type, skipping it.", format(target.pos()));
        } else {
            // No filter: an unclassified spawner is still worth mining.
            phase = Phase.NAVIGATING;
            return;
        }

        target = null;
        candidateTicks = 0;
        phase = Phase.SEARCHING;
    }

    private void tickNavigating() {
        if (target == null) {
            phase = Phase.SEARCHING;
            return;
        }

        if (!mc.world.getBlockState(target.pos()).isOf(net.minecraft.block.Blocks.SPAWNER)) {
            HookStatus.info(this, "The spawner at %s disappeared before we got there.", format(target.pos()));
            target = null;
            phase = Phase.SEARCHING;
            startSearch(false);
            return;
        }

        if (!navigate.get()) {
            phase = Phase.MINING;
            return;
        }

        double within = Math.max(1.5, reach.get() - 0.5);
        Navigator.State state = Navigator.get().tick(name, target.pos(),
                new Navigator.Options(within, true, true, 80, maxNavigationRecoveries.get()));
        status = "walking to " + format(target.pos());

        switch (state) {
            case ARRIVED -> {
                Navigator.get().stop(name);
                phase = Phase.MINING;
            }
            case FAILED -> {
                if (++consecutiveTargetFailures >= maxTargetFailures.get()) {
                    giveUpTarget("cannot reach it repeatedly");
                } else {
                    HookStatus.warn(this, "Could not reach the spawner at %s, trying again.",
                            format(target.pos()));
                    Navigator.get().stop(name);
                    candidateTicks = 0;
                }
            }
            default -> {
                // Still walking.
            }
        }
    }

    private void tickMining() {
        if (target == null) {
            phase = Phase.SEARCHING;
            return;
        }

        mineTarget = target.pos();

        if (SafetyChecks.nearLava(mineTarget) && avoidLava.get()) {
            giveUpTarget("it is next to lava");
            return;
        }

        MiningController.Options options = new MiningController.Options(
                reach.get(), rotate.get(), swing.get(), autoTool.get(), minToolDurability.get(),
                avoidLava.get(), false, avoidFalling.get(), mineTimeout.get(), 2);

        MiningController.Result result = MiningController.get().tick(name, mineTarget, options);

        switch (result) {
            case WORKING -> status = "mining the spawner at " + format(mineTarget);
            case DONE -> {
                // Verified: the world reports air where the spawner was.
                HookStatus.progressNow(this, "spawner", "Mined the %s at %s.",
                        describeType(target), format(mineTarget));
                target = null;
                mineTarget = null;
                consecutiveTargetFailures = 0;
                attempts = 0;
                saveState();
                phase = Phase.SEARCHING;
                startSearch(false);
            }
            case OUT_OF_REACH -> phase = navigate.get() ? Phase.NAVIGATING : Phase.MINING;
            case UNSAFE -> giveUpTarget("it is unsafe to mine");
            case FAILED -> giveUpTarget("mining timed out or was rejected");
            case REJECTED -> status = "mining owned by another module";
        }
    }

    private void tickNoTarget() {
        long now = System.currentTimeMillis();
        if (now < nextSearchAtMs) {
            long seconds = (nextSearchAtMs - now) / 1000 + 1;
            status = "cooldown, next search in " + seconds + "s";
            return;
        }

        switch (onNoTarget.get()) {
            case RTP -> {
                phase = Phase.SEARCHING;
                startSearch(true);
            }
            case RESTART -> {
                phase = Phase.SEARCHING;
                startSearch(true);
            }
            case DISABLE -> disable();
            case PAUSE -> {
                phase = Phase.PAUSED;
                status = "paused after an exhausted search";
            }
        }
    }

    private void tickRtp() {
        RtpFallback.Event event = rtp.tick(rtpOptions(), this::info);

        switch (event) {
            case CONFIRMED -> {
                postRtpTicks = rtpPostDelay.get() * 20;
                phase = Phase.POST_RTP;
                status = "teleport confirmed, restarting the search";
                saveState();
            }
            case FAILED, PAUSED -> {
                phase = event == RtpFallback.Event.PAUSED ? Phase.PAUSED : Phase.NO_TARGET;
                nextSearchAtMs = rtp.nextAttemptAtMs();
                status = event == RtpFallback.Event.PAUSED ? "RTP paused" : "waiting for the RTP cooldown";
            }
            default -> status = "waiting for the teleport";
        }
    }

    private void tickPostRtp() {
        if (postRtpTicks-- > 0) {
            status = "settling after teleport";
            return;
        }

        // New area: location specific state must not carry over.
        searcher.clearVisited();
        attempts = 0;
        consecutiveTargetFailures = 0;
        target = null;
        phase = Phase.SEARCHING;
        startSearch(true);
        HookStatus.progressNow(this, "spawner", "New area reached, starting a fresh search.");
    }

    // Control --------------------------------------------------------------------------------

    private void startSearch(boolean resetVisited) {
        searcher.start(searchOptions(), mc.player.getBlockPos(), resetVisited);
        searchStartedAtMs = System.currentTimeMillis();
        searchTicks = 0;
        candidateTicks = 0;
        status = "scanning";
        if (resetVisited) HookStatus.reset("spawner-search");
    }

    private void handleNoTarget(String reason) {
        searcher.stop();
        attempts++;

        if (attempts < searchAttempts.get()) {
            nextSearchAtMs = System.currentTimeMillis() + searchCooldown.get() * 1000L;
            phase = Phase.NO_TARGET;
            HookStatus.progress(this, "spawner-none",
                    "Nothing found (%s). Attempt %d/%d, next search in %ds.",
                    reason, attempts, searchAttempts.get(), searchCooldown.get());
            return;
        }

        HookStatus.warn(this, "No target after %d attempts: %s.", attempts, reason);

        switch (onNoTarget.get()) {
            case RTP -> beginRtp(reason);
            case RESTART -> {
                attempts = 0;
                nextSearchAtMs = System.currentTimeMillis() + searchCooldown.get() * 1000L;
                phase = Phase.NO_TARGET;
                HookStatus.info(this, "Restarting the search in %ds.", searchCooldown.get());
            }
            case DISABLE -> disable();
            case PAUSE -> {
                phase = Phase.PAUSED;
                status = "paused, no target found";
            }
        }
    }

    private void beginRtp(String reason) {
        if (!rtpEnabled.get()) {
            phase = Phase.PAUSED;
            HookStatus.warn(this, "No target found (%s) and the RTP fallback is disabled, pausing.", reason);
            return;
        }

        if (rtp.request(reason, rtpOptions(), this::info)) {
            phase = Phase.RTP_SENT;
            status = "waiting for teleport";
            saveState();
        } else {
            if (rtp.isPaused()) {
                phase = Phase.PAUSED;
                return;
            }
            phase = Phase.NO_TARGET;
            nextSearchAtMs = Math.max(nextSearchAtMs, rtp.nextAttemptAtMs());
        }
    }

    private void giveUpTarget(String reason) {
        HookStatus.warn(this, "Giving up on the spawner at %s: %s.", format(target.pos()), reason);
        target = null;
        mineTarget = null;
        Navigator.get().stop(name);
        MiningController.get().reset(name);

        if (++consecutiveTargetFailures >= maxTargetFailures.get()) {
            consecutiveTargetFailures = 0;
            attempts = searchAttempts.get();
            handleNoTarget("repeated target failures");
            return;
        }

        phase = Phase.SEARCHING;
        startSearch(false);
    }

    private void saveState() {
        HookStore.SpawnerState state = new HookStore.SpawnerState();
        state.dimension = mc.world == null ? null : mc.world.getRegistryKey().getValue().toString();
        state.visited = new java.util.ArrayList<>(searcher.visited());
        state.rtpAttempts = rtp.consecutiveFailures();
        state.lastRtpAt = rtp.lastAttemptAtMs();
        state.lastStatus = status;
        HookStore.saveSpawnerState(state);
    }

    // Events ----------------------------------------------------------------------------------

    @EventHandler
    private void onReceiveMessage(ReceiveMessageEvent event) {
        if (phase != Phase.RTP_SENT) return;
        rtp.onChatMessage(event.getMessage().getString(), rtpOptions(), rtpFailureKeys(), this::info);
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        interrupted = true;
        finish();
    }

    @EventHandler
    private void onRender3d(Render3DEvent event) {
        if (!renderTarget.get() || target == null) return;
        event.renderer.box(target.pos(), targetColor.get(), targetColor.get(), ShapeMode.Lines, 0);
    }

    // Helpers ---------------------------------------------------------------------------------

    private SpawnerSearcher.Options searchOptions() {
        return new SpawnerSearcher.Options(
                searchRadius.get(), searchHeight.get(), budgetPerTick.get(),
                spawnerTypes.get(), onlySelected.get(), skipVisited.get(), 250000);
    }

    private RtpFallback.Options rtpOptions() {
        return new RtpFallback.Options(
                rtpEnabled.get(), rtpCommand.get(), rtpRetryDelay.get(), rtpMaxAttempts.get(),
                rtpTimeout.get(), rtpPostDelay.get(), rtpPauseAfterFailures.get(), rtpMinDistance.get());
    }

    private List<String> rtpFailureKeys() {
        List<String> value = rtpFailureKeywords.get();
        return value == null ? List.of() : value;
    }

    private static String format(BlockPos pos) {
        return "(" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ")";
    }

    private String describeType(SpawnerTarget target) {
        if (target == null || target.type() == null) return "spawner";
        return target.type().getName().getString() + " spawner";
    }

    @Override
    public String getInfoString() {
        return status;
    }

    /** Full status text for the {@code hook} command. */
    public String describeFull() {
        StringBuilder builder = new StringBuilder("phase=").append(phase).append(", ").append(status);
        if (target != null) builder.append(", target ").append(format(target.pos()));
        builder.append(", attempts=").append(attempts);
        builder.append(", scanned=").append(searcher.scanned());
        builder.append(", rtp=").append(rtp.state());
        return builder.toString();
    }

    public RtpFallback rtpFallback() {
        return rtp;
    }

    public SpawnerSearcher searcher() {
        return searcher;
    }
}
