package com.hookaddon.modules;

import com.hookaddon.HookAddon;
import com.hookaddon.finder.BlockFinder;
import com.hookaddon.mining.AreaGeometry;
import com.hookaddon.mining.AreaMinerEngine;
import com.hookaddon.mining.BorePlanner;
import com.hookaddon.mining.MiningMode;
import com.hookaddon.mining.MiningPattern;
import com.hookaddon.mining.PickaxeWidth;
import com.hookaddon.task.Capability;
import com.hookaddon.task.ConflictPolicy;
import com.hookaddon.task.MiningController;
import com.hookaddon.task.TaskManager;
import com.hookaddon.nav.Navigator;
import com.hookaddon.util.HookStatus;
import com.hookaddon.util.InvGuards;
import java.util.EnumSet;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BlockPosSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/**
 * Priority three module: mines a configurable rectangular volume.
 *
 * <p>The area, its traversal pattern and the block filters are plain settings; the run itself is
 * driven by {@link AreaMinerEngine}, which in turn uses the shared navigator and mining controller
 * so it can never fight the other two automation modules over movement or mining.
 */
public class AutoAreaMiner extends Module {
    private final SettingGroup sgArea = settings.getDefaultGroup();
    private final SettingGroup sgFilters = settings.createGroup("Filters");
    private final SettingGroup sgMining = settings.createGroup("Mining");
    private final SettingGroup sgSafety = settings.createGroup("Safety");
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgKeys = settings.createGroup("Keys");

    // Area ----------------------------------------------------------------------------------

    private final Setting<MiningMode> mode = sgArea.add(new EnumSetting.Builder<MiningMode>()
            .name("mode")
            .description("What to mine: a fixed area, blocks found around you, or a 3x3 bore forward")
            .defaultValue(MiningMode.AREA)
            .onChanged(value -> dirty = true)
            .build());

    // Bore (3x3 pickaxe) ---------------------------------------------------------------

    private final Setting<Integer> boreWidth = sgArea.add(new IntSetting.Builder()
            .name("bore-width")
            .description("Face size across the direction you travel")
            .defaultValue(3)
            .range(1, 7)
            .visible(this::isBore)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> boreHeight = sgArea.add(new IntSetting.Builder()
            .name("bore-height")
            .description("Face height along Y")
            .defaultValue(3)
            .range(1, 7)
            .visible(this::isBore)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> boreDepth = sgArea.add(new IntSetting.Builder()
            .name("bore-depth")
            .description("Slices to mine forward per segment")
            .defaultValue(8)
            .range(1, 32)
            .visible(this::isBore)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> boreYOffset = sgArea.add(new IntSetting.Builder()
            .name("bore-y-offset")
            .description("Vertical shift of the bore face relative to your feet")
            .defaultValue(0)
            .range(-8, 16)
            .visible(this::isBore)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Boolean> boreContinue = sgArea.add(new BoolSetting.Builder()
            .name("bore-continue")
            .description("Keep boring new segments forward as each one finishes")
            .defaultValue(true)
            .visible(this::isBore)
            .build());

    private final Setting<Integer> findRadius = sgArea.add(new IntSetting.Builder()
            .name("find-radius")
            .description("Horizontal search radius of the finder in blocks, loaded chunks only")
            .defaultValue(32)
            .sliderRange(8, 128)
            .visible(this::isFinder)
            .build());

    private final Setting<Integer> findHeight = sgArea.add(new IntSetting.Builder()
            .name("find-height")
            .description("Blocks above and below your position the finder looks at")
            .defaultValue(16)
            .sliderRange(4, 64)
            .visible(this::isFinder)
            .build());

    private final Setting<Integer> findBudget = sgArea.add(new IntSetting.Builder()
            .name("find-budget-per-tick")
            .description("Maximum positions the finder inspects each tick, higher is faster but laggier")
            .defaultValue(4000)
            .sliderRange(500, 16000)
            .visible(this::isFinder)
            .build());

    private final Setting<Integer> findCooldown = sgArea.add(new IntSetting.Builder()
            .name("find-cooldown")
            .description("Seconds between two finder scans")
            .defaultValue(5)
            .sliderRange(0, 120)
            .visible(this::isFinder)
            .build());

    private final Setting<Boolean> usePlayerPos = sgArea.add(new BoolSetting.Builder()
            .name("use-my-position")
            .description("Use your feet as the area origin, otherwise the origin setting")
            .defaultValue(true)
            .visible(this::isArea)
            .build());

    private final Setting<BlockPos> origin = sgArea.add(new BlockPosSetting.Builder()
            .name("origin")
            .description("Minimum corner of the area")
            .defaultValue(BlockPos.ORIGIN)
            .visible(() -> isArea() && !usePlayerPos.get())
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> width = sgArea.add(new IntSetting.Builder()
            .name("width")
            .description("Size along X")
            .defaultValue(8)
            .range(1, 64)
            .visible(this::isArea)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> height = sgArea.add(new IntSetting.Builder()
            .name("height")
            .description("Size along Y")
            .defaultValue(4)
            .range(1, 64)
            .visible(this::isArea)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> depth = sgArea.add(new IntSetting.Builder()
            .name("depth")
            .description("Size along Z")
            .defaultValue(8)
            .range(1, 64)
            .visible(this::isArea)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<MiningPattern> pattern = sgArea.add(new EnumSetting.Builder<MiningPattern>()
            .name("pattern")
            .description("Traversal order and which blocks are touched")
            .defaultValue(MiningPattern.LAYER_BY_LAYER)
            .visible(this::isArea)
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> stripWidth = sgArea.add(new IntSetting.Builder()
            .name("strip-width")
            .description("Blocks kept per strip")
            .defaultValue(3)
            .range(1, 16)
            .visible(() -> isArea() && (pattern.get() == MiningPattern.STRIP))
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> stripGap = sgArea.add(new IntSetting.Builder()
            .name("strip-gap")
            .description("Blocks left between two strips or corridors")
            .defaultValue(2)
            .range(0, 16)
            .visible(() -> isArea()
                    && (pattern.get() == MiningPattern.STRIP || pattern.get() == MiningPattern.TUNNEL))
            .onChanged(value -> dirty = true)
            .build());

    private final Setting<Integer> maxOperationSize = sgArea.add(new IntSetting.Builder()
            .name("max-operation-size")
            .description("Refuse to start an area larger than this many blocks")
            .defaultValue(32768)
            .sliderRange(64, 262144)
            .build());

    private final Setting<Boolean> autoStart = sgArea.add(new BoolSetting.Builder()
            .name("auto-start")
            .description("Start mining immediately when the module is enabled")
            .defaultValue(true)
            .build());

    private final Setting<ConflictPolicy> conflictPolicy = sgArea.add(new EnumSetting.Builder<ConflictPolicy>()
            .name("conflict-policy")
            .description("What to do when another Hook module already owns movement or mining")
            .defaultValue(ConflictPolicy.REJECT)
            .build());

    // Filters --------------------------------------------------------------------------------

    private final Setting<java.util.List<Block>> ignoreBlocks = sgFilters.add(new BlockListSetting.Builder()
            .name("ignore-blocks")
            .description("Blocks that are never mined")
            .defaultValue(net.minecraft.block.Blocks.CHEST, net.minecraft.block.Blocks.TRAPPED_CHEST,
                    net.minecraft.block.Blocks.BARREL, net.minecraft.block.Blocks.SPAWNER,
                    net.minecraft.block.Blocks.ENDER_CHEST)
            .build());

    private final Setting<java.util.List<Block>> mineBlocks = sgFilters.add(new BlockListSetting.Builder()
            .name("mine-blocks")
            .description("Blocks to mine, empty means every block that is not ignored")
            .defaultValue()
            .build());

    // Mining ---------------------------------------------------------------------------------

    private final Setting<Double> reach = sgMining.add(new DoubleSetting.Builder()
            .name("reach")
            .description("Interaction distance in blocks")
            .defaultValue(4.5)
            .range(3.0, 6.0)
            .build());

    private final Setting<Boolean> navigate = sgMining.add(new BoolSetting.Builder()
            .name("navigate")
            .description("Walk to blocks that are out of reach")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> rotate = sgMining.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Look at the block while mining")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> swing = sgMining.add(new BoolSetting.Builder()
            .name("swing")
            .description("Swing the hand while mining")
            .defaultValue(true)
            .build());

    private final Setting<PickaxeWidth> pickaxe = sgMining.add(new EnumSetting.Builder<PickaxeWidth>()
            .name("pickaxe")
            .description("1x1 mines only the current block; a 3x3 swing also clears the eight same-layer neighbours inside the area (mined one by one, vanilla cannot break several blocks at once)")
            .defaultValue(PickaxeWidth.ONE)
            .build());

    private final Setting<Boolean> autoTool = sgMining.add(new BoolSetting.Builder()
            .name("auto-tool")
            .description("Select the fastest tool for the block")
            .defaultValue(true)
            .build());

    private final Setting<Integer> minToolDurability = sgMining.add(new IntSetting.Builder()
            .name("min-tool-durability")
            .description("Do not use a tool with fewer durability points left")
            .defaultValue(10)
            .range(0, 500)
            .visible(autoTool::get)
            .build());

    private final Setting<Integer> delayBetweenBlocks = sgMining.add(new IntSetting.Builder()
            .name("delay-between-blocks")
            .description("Ticks to wait after each block")
            .defaultValue(1)
            .range(0, 40)
            .build());

    private final Setting<Integer> maxRetries = sgMining.add(new IntSetting.Builder()
            .name("max-retries")
            .description("Extra passes over blocks that failed")
            .defaultValue(1)
            .range(0, 5)
            .build());

    private final Setting<Boolean> stopWhenFull = sgMining.add(new BoolSetting.Builder()
            .name("stop-when-inventory-full")
            .description("Pause when no empty slot is left")
            .defaultValue(true)
            .build());

    // Safety ---------------------------------------------------------------------------------

    private final Setting<Boolean> avoidLava = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-lava")
            .description("Skip blocks touching lava")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> avoidFluids = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-fluids")
            .description("Skip blocks touching any fluid")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> avoidFalling = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-falling-blocks")
            .description("Skip blocks with sand or gravel above them")
            .defaultValue(true)
            .build());

    // Render ---------------------------------------------------------------------------------

    private final Setting<Boolean> preview = sgRender.add(new BoolSetting.Builder()
            .name("preview")
            .description("Render the area bounds and the remaining blocks")
            .defaultValue(true)
            .build());

    private final Setting<SettingColor> boundsColor = sgRender.add(new ColorSetting.Builder()
            .name("bounds-color")
            .description("Colour of the area outline")
            .defaultValue(new SettingColor(157, 89, 248, 200))
            .visible(preview::get)
            .build());

    private final Setting<SettingColor> targetColor = sgRender.add(new ColorSetting.Builder()
            .name("target-color")
            .description("Colour of the current target")
            .defaultValue(new SettingColor(64, 220, 255, 200))
            .visible(preview::get)
            .build());

    private final Setting<Integer> maxPreviewBlocks = sgRender.add(new IntSetting.Builder()
            .name("max-preview-blocks")
            .description("Upper bound on how many pending blocks are drawn")
            .defaultValue(256)
            .sliderRange(16, 2048)
            .visible(preview::get)
            .build());

    // Keys ------------------------------------------------------------------------------------

    private final Setting<Keybind> pauseKey = sgKeys.add(new KeybindSetting.Builder()
            .name("pause-key")
            .description("Pause and resume the current run")
            .defaultValue(Keybind.none())
            .action(this::togglePause)
            .build());

    private final Setting<Keybind> resetKey = sgKeys.add(new KeybindSetting.Builder()
            .name("reset-key")
            .description("Throw away the current run and rebuild the plan")
            .defaultValue(Keybind.none())
            .action(this::resetRun)
            .build());

    // State -----------------------------------------------------------------------------------

    private final AreaMinerEngine engine;
    private final BlockFinder finder = new BlockFinder();
    private long nextFindAtMs;
    private boolean findCooldownScheduled;
    /** When the next bore segment may be planned, so an all-air face cannot spin the CPU. */
    private long nextBoreAtMs;
    /** Player feet when the current bore segment was planned; the bore only steps forward from here. */
    private BlockPos lastBoreAnchor;
    private String autoStatus = "idle";
    /** Consecutive empty scans; only the first one announces itself in chat. */
    private int emptyScans;
    private boolean claimed;
    private boolean dirty;
    private boolean running;
    /** Set when the connection dropped mid-run, so the next tick can report the resume. */
    private boolean interrupted;

    public AutoAreaMiner() {
        super(HookAddon.CATEGORY, "auto-area-miner",
                "Mines a rectangular area layer by layer, in strips, tunnels or as a grid, with filters and safety checks.");
        this.engine = new AreaMinerEngine(name, this);
    }

    public AreaMinerEngine engine() {
        return engine;
    }

    private boolean isArea() {
        return mode.get() == MiningMode.AREA;
    }

    private boolean isFinder() {
        return mode.get() == MiningMode.FINDER;
    }

    private boolean isBore() {
        return mode.get() == MiningMode.BORE;
    }

    // Lifecycle -------------------------------------------------------------------------------

    @Override
    public void onActivate() {
        if (!ensureClaim()) return;

        dirty = false;
        interrupted = false;
        findCooldownScheduled = false;
        nextFindAtMs = 0;
        emptyScans = 0;

        if (!prepareArea()) {
            disable();
            return;
        }

        if (isFinder()) {
            finder.clearVisited();
            running = autoStart.get();
            if (running) {
                autoStatus = "finder: looking for blocks to mine";
            } else {
                autoStatus = "finder: waiting to start";
                info("Auto-target ready. Run '.hook area start' or press the module key to begin the scan.");
            }
            return;
        }

        if (isBore()) {
            running = autoStart.get();
            if (running) {
                autoStatus = "bore: ready";
                planBoreSegment();
            } else {
                autoStatus = "bore: waiting to start";
                info("Bore ready. Run '.hook area start' or press the module key to begin.");
            }
            return;
        }

        if (autoStart.get()) startRun();
        else info("Area ready. Press the module key again or run '.hook area start' to begin.");
    }

    @Override
    public void onDeactivate() {
        engine.shutdown();
        finder.stop();
        if (claimed) {
            TaskManager.get().release(name);
            claimed = false;
        }
        running = false;
        HookStatus.reset("area-miner");
    }

    private void forceStop() {
        if (isActive()) disable();
    }

    /**
     * Claims movement and mining when they are not held yet. Called on activate and again on every
     * tick after a disconnect, because the task registry is wiped when the player leaves a world
     * and a run that keeps ticking without its claims would be refused by the navigator and the
     * mining controller.
     *
     * @return true when the module holds its capabilities and may keep working
     */
    private boolean ensureClaim() {
        if (claimed) return true;
        if (!isActive()) return false;

        TaskManager.ClaimResult claim = TaskManager.get().claim(
                name, title, EnumSet.of(Capability.MOVE, Capability.MINE), conflictPolicy.get(), this::forceStop);
        if (!claim.ok()) {
            error(claim.message());
            disable();
            return false;
        }

        claimed = true;
        return true;
    }

    // Area control ----------------------------------------------------------------------------

    /** Rebuilds the traversal plan from the current settings. */
    public boolean prepareArea() {
        if (mc.player == null || mc.world == null) {
            error("Join a world before preparing an area.");
            return false;
        }

        if (isFinder() || isBore()) {
            // Neither has a fixed area: the finder or the bore planner supplies each plan.
            engine.setMaxRetries(maxRetries.get());
            engine.reset();
            return true;
        }

        BlockPos areaOrigin = usePlayerPos.get() ? mc.player.getBlockPos() : origin.get();
        int areaWidth = width.get();
        int areaHeight = height.get();
        int areaDepth = depth.get();

        int candidateCount = AreaGeometry.count(areaWidth, areaHeight, areaDepth, pattern.get(),
                stripWidth.get(), stripGap.get());

        if (candidateCount > maxOperationSize.get()) {
            error("That area touches %d blocks, above the max-operation-size of %d. Shrink the area or raise the limit.",
                    candidateCount, maxOperationSize.get());
            return false;
        }

        engine.setMaxRetries(maxRetries.get());
        engine.prepare(areaOrigin, areaWidth, areaHeight, areaDepth, pattern.get(), stripWidth.get(), stripGap.get());

        info("Area ready at (%d, %d, %d): %d x %d x %d, %s, %d candidate blocks.",
                areaOrigin.getX(), areaOrigin.getY(), areaOrigin.getZ(),
                areaWidth, areaHeight, areaDepth, pattern.get().title, candidateCount);
        return true;
    }

    /** Starts or resumes mining. */
    public boolean startRun() {
        if (isFinder()) {
            running = true;
            nextFindAtMs = 0;
            autoStatus = "finder: looking for blocks to mine";
            HookStatus.reset("area-miner");
            info("Finder scan requested within %d blocks.", findRadius.get());
            return true;
        }

        if (isBore()) {
            running = true;
            nextBoreAtMs = 0;
            autoStatus = "bore: ready";
            HookStatus.reset("area-miner");
            planBoreSegment();
            info("Bore started: %d x %d face, %d slices forward.",
                    boreWidth.get(), boreHeight.get(), boreDepth.get());
            return true;
        }

        if (engine.order() == null && !prepareArea()) return false;
        if (engine.phase() == AreaMinerEngine.Phase.COMPLETE) engine.reset();

        engine.setMaxRetries(maxRetries.get());
        engine.start();
        running = true;
        HookStatus.reset("area-miner");
        info("Mining started: %s.", engine.describe());
        return true;
    }

    public void togglePause() {
        if (!isActive()) return;

        if (engine.phase() == AreaMinerEngine.Phase.RUNNING) {
            engine.pause("paused by keybind");
            info("Area mining paused: %s.", engine.describe());
        } else if (engine.phase() == AreaMinerEngine.Phase.PAUSED) {
            engine.resume();
            running = true;
            info("Area mining resumed.");
        } else {
            startRun();
        }
    }

    public void stopRun() {
        if (!isActive()) return;

        if (isFinder()) {
            running = false;
            finder.stop();
            autoStatus = "finder: stopped";
        } else if (isBore()) {
            running = false;
            autoStatus = "bore: stopped";
        }

        engine.pause("stopped by user");
        info("Area mining stopped: %s.", engine.describe());
    }

    /** Discards all progress and rebuilds the plan from scratch. */
    public void resetRun() {
        if (!isActive()) return;

        engine.reset();

        if (isFinder()) {
            finder.clearVisited();
            finder.stop();
            nextFindAtMs = 0;
            findCooldownScheduled = false;
            running = true;
            autoStatus = "finder: looking for blocks to mine";
            info("Finder state cleared, starting a fresh scan.");
            return;
        }

        if (isBore()) {
            running = true;
            nextBoreAtMs = 0;
            autoStatus = "bore: ready";
            planBoreSegment();
            info("Bore plan rebuilt, no progress kept.");
            return;
        }

        if (prepareArea()) info("Plan rebuilt, no progress kept.");
    }

    // Ticking ----------------------------------------------------------------------------------

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (!ensureClaim()) return;

        if (interrupted) {
            interrupted = false;
            // A half-finished scan belongs to where we were before the disconnect.
            if (isFinder()) finder.stop();
            HookStatus.info(this, "Reconnected, resuming the area miner: %s.", engine.describe());
        }

        // An inventory pause is temporary: as soon as a slot frees up the run continues on its own.
        if (engine.phase() == AreaMinerEngine.Phase.PAUSED
                && engine.isInventoryPaused()
                && !InvGuards.inventoryFull()) {
            engine.resume();
            HookStatus.info(this, "Inventory has space again, resuming the area miner.");
        }

        // Rebuild when settings change and no run is in flight. Flipping auto-target on during a
        // box run rebuilds immediately too: the fixed-area plan is meaningless from then on.
        if (dirty && (engine.phase() != AreaMinerEngine.Phase.RUNNING || isFinder() || isBore())) {
            dirty = false;
            engine.reset();
            if (prepareArea()) info("Settings changed, plan rebuilt.");
            return;
        }

        if (isFinder()) tickAutoTarget();
        else if (isBore()) tickBore();

        engine.tick(engineOptions(), this::shouldMine, this::shouldIgnore);
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        // Release the inputs immediately so movement keys cannot stay held across the disconnect;
        // the plan itself survives, so rejoining resumes exactly where the run stopped.
        Navigator.get().stop(name);
        MiningController.get().reset(name);
        if (claimed) {
            TaskManager.get().release(name);
            claimed = false;
        }
        running = false;
        interrupted = true;
    }

    private AreaMinerEngine.Options engineOptions() {
        return new AreaMinerEngine.Options(
                reach.get(), navigate.get(), rotate.get(), swing.get(), autoTool.get(), minToolDurability.get(),
                delayBetweenBlocks.get(), maxRetries.get(), stopWhenFull.get(),
                avoidLava.get(), avoidFluids.get(), avoidFalling.get(), pickaxe.get());
    }

    private BlockFinder.Options finderOptions() {
        return new BlockFinder.Options(
                findRadius.get(), findHeight.get(), findBudget.get(),
                maxOperationSize.get(), true, 250000);
    }

    // Auto-target -----------------------------------------------------------------------------

    /**
     * Drives the finder half of auto-target mode: scan the loaded chunks for blocks that pass the
     * filters, hand the result to the engine as a plan, and schedule the next scan once the batch
     * is mined (or when the scan came back empty). Between batches the module simply waits, so
     * walking into new chunks is picked up by the cooldown-driven rescan.
     */
    private void tickAutoTarget() {
        long now = System.currentTimeMillis();

        if (finder.isRunning()) {
            BlockFinder.Result result = finder.tick(finderOptions(), this::shouldMine, this::shouldIgnore);

            switch (result.outcome()) {
                case SCANNING -> autoStatus = "finder: scanning, " + finder.scanned() + " positions checked";
                case TARGET -> {
                    finder.stop();
                    startBatch(finder.matches());
                }
                case NO_TARGET -> {
                    finder.stop();
                    autoStatus = "finder: nothing to mine nearby, retrying in " + findCooldown.get() + "s";
                    nextFindAtMs = now + findCooldown.get() * 1000L;
                    emptyScans++;
                    if (emptyScans == 1) {
                        HookStatus.progressNow(this, "area-finder",
                                "Finder checked %d positions and found nothing in the loaded chunks; it keeps retrying every %ds.",
                                finder.scanned(), findCooldown.get());
                    }
                }
            }
            return;
        }

        // A finished batch gets its rescan scheduled once, then the finder waits out the cooldown.
        if (engine.phase() == AreaMinerEngine.Phase.COMPLETE) {
            if (!findCooldownScheduled) {
                findCooldownScheduled = true;
                nextFindAtMs = now + findCooldown.get() * 1000L;
                autoStatus = "finder: batch finished, rescanning soon";
            }
        } else {
            findCooldownScheduled = false;
        }

        boolean idle = engine.phase() == AreaMinerEngine.Phase.IDLE
                || engine.phase() == AreaMinerEngine.Phase.COMPLETE;
        if ((autoStart.get() || running) && idle && now >= nextFindAtMs && mc.player != null) {
            finder.start(finderOptions(), mc.player.getBlockPos(), false);
            findCooldownScheduled = false;
            autoStatus = "finder: scanning, 0 positions checked";
        }
    }

    /** Turns a finished scan into a mining plan, bounded by max-operation-size. */
    private void startBatch(java.util.List<BlockPos> found) {
        if (found == null || found.isEmpty()) return;

        BlockPos min = found.get(0);
        BlockPos max = found.get(0);
        for (BlockPos pos : found) {
            min = new BlockPos(Math.min(min.getX(), pos.getX()),
                    Math.min(min.getY(), pos.getY()), Math.min(min.getZ(), pos.getZ()));
            max = new BlockPos(Math.max(max.getX(), pos.getX()),
                    Math.max(max.getY(), pos.getY()), Math.max(max.getZ(), pos.getZ()));
        }

        if (found.size() >= maxOperationSize.get()) {
            warning("The finder hit max-operation-size (%d blocks); mining the %d nearest ones.",
                    maxOperationSize.get(), found.size());
        }

        engine.setMaxRetries(maxRetries.get());
        engine.prepareFromPositions(min,
                max.getX() - min.getX() + 1,
                max.getY() - min.getY() + 1,
                max.getZ() - min.getZ() + 1,
                found);
        engine.start();

        running = true;
        findCooldownScheduled = false;
        emptyScans = 0;
        autoStatus = "mining " + found.size() + " found blocks";
        HookStatus.reset("area-miner");
        info("Finder located %d blocks to mine, starting the run.", found.size());
    }

    // Bore (3x3 pickaxe) ----------------------------------------------------------------------

    /**
     * Drives the directional face bore: when a segment is mined out, plan the next one ahead of
     * the player in the direction they are looking. The bore only steps forward once the player
     * has actually walked into the cleared tunnel (or been walked there by the navigator), so
     * standing still never re-mines air and never spins the planner.
     */
    private void tickBore() {
        if (engine.phase() != AreaMinerEngine.Phase.COMPLETE) return;
        if (!boreContinue.get() || !running) return;
        if (mc.player == null) return;

        // Give the world a moment to settle to air, then require real forward progress.
        if (System.currentTimeMillis() < nextBoreAtMs) return;
        if (lastBoreAnchor != null && lastBoreAnchor.equals(mc.player.getBlockPos())) return;

        autoStatus = "bore: extending the tunnel";
        planBoreSegment();
    }

    /**
     * Plans and starts one bore segment centred on the player, heading the way they look. This is
     * the AutoDao-style face bore: a fixed {@code bore-width x bore-height} cross-section
     * perpendicular to the travel axis, advanced {@code bore-depth} slices forward in
     * {@code travel -> layer -> row -> cell} order (see {@link BorePlanner}). The resulting block
     * list is handed to the shared engine exactly like a finder batch, so safety screens, tools,
     * reach and rotation all behave identically to the other two modes.
     */
    private void planBoreSegment() {
        if (mc.player == null || mc.world == null) return;

        // Horizontal look vector; its dominant axis is the travel axis, its sign the direction.
        double radians = Math.toRadians(mc.player.getYaw());
        double lookX = -Math.sin(radians);
        double lookZ = Math.cos(radians);

        boolean alongX = Math.abs(lookX) > Math.abs(lookZ);
        int sign = alongX ? (lookX >= 0 ? 1 : -1) : (lookZ >= 0 ? 1 : -1);

        int[] order = BorePlanner.plan(
                boreWidth.get(), boreHeight.get(), boreDepth.get(), sign, boreYOffset.get());

        BlockPos feet = mc.player.getBlockPos();
        lastBoreAnchor = feet;

        java.util.List<BlockPos> positions = new java.util.ArrayList<>(order.length / 3);
        BlockPos min = null;
        BlockPos max = null;

        for (int i = 0; i < order.length; i += 3) {
            int forward = order[i];
            int cross = order[i + 1];
            int up = order[i + 2];

            int x = feet.getX() + (alongX ? forward : cross);
            int z = feet.getZ() + (alongX ? cross : forward);
            int y = feet.getY() + up;
            BlockPos pos = new BlockPos(x, y, z);

            positions.add(pos);
            if (min == null) {
                min = pos;
                max = pos;
            } else {
                min = new BlockPos(Math.min(min.getX(), x), Math.min(min.getY(), y), Math.min(min.getZ(), z));
                max = new BlockPos(Math.max(max.getX(), x), Math.max(max.getY(), y), Math.max(max.getZ(), z));
            }
        }

        if (min == null || positions.isEmpty()) return;

        engine.setMaxRetries(maxRetries.get());
        engine.prepareFromPositions(min,
                max.getX() - min.getX() + 1,
                max.getY() - min.getY() + 1,
                max.getZ() - min.getZ() + 1,
                positions);
        engine.start();

        running = true;
        nextBoreAtMs = System.currentTimeMillis() + 250;
        autoStatus = "bore: mining " + positions.size() + " blocks ahead";
        HookStatus.reset("area-miner");
    }

    private boolean shouldMine(Block block) {
        java.util.List<Block> allowed = mineBlocks.get();
        if (allowed == null || allowed.isEmpty()) return true;
        return allowed.contains(block);
    }

    private boolean shouldIgnore(Block block) {
        java.util.List<Block> ignored = ignoreBlocks.get();
        return ignored != null && ignored.contains(block);
    }

    // Preview ----------------------------------------------------------------------------------

    @EventHandler
    private void onRender3d(Render3DEvent event) {
        if (!preview.get() || engine.origin() == null || engine.order() == null) return;

        if (isArea()) {
            BlockPos originPos = engine.origin();
            Box bounds = new Box(
                    originPos.getX(), originPos.getY(), originPos.getZ(),
                    originPos.getX() + engine.width(),
                    originPos.getY() + engine.height(),
                    originPos.getZ() + engine.depth());

            event.renderer.box(bounds, boundsColor.get(), boundsColor.get(), ShapeMode.Lines, 0);
        }

        java.util.List<BlockPos> pending = engine.pendingPositions();
        int limit = Math.min(pending.size(), maxPreviewBlocks.get());
        for (int i = 0; i < limit; i++) {
            event.renderer.box(pending.get(i), targetColor.get(), targetColor.get(), ShapeMode.Lines, 0);
        }

        BlockPos current = engine.currentTarget();
        if (current != null) {
            event.renderer.box(current, Color.WHITE, targetColor.get(), ShapeMode.Both, 0);
        }
    }

    // Reporting ----------------------------------------------------------------------------------

    @Override
    public String getInfoString() {
        if (isFinder() || isBore()) {
            return engine.phase() == AreaMinerEngine.Phase.RUNNING ? engine.describe() : autoStatus;
        }
        return engine.order() == null ? null : engine.describe();
    }

    /** Full status for the {@code hook} command. */
    public String describeFull() {
        if (isFinder()) {
            String scan = finder.isRunning()
                    ? "scanning, " + finder.scanned() + " positions checked"
                    : autoStatus;
            return "mode=auto-target, " + scan
                    + (engine.order() == null ? "" : ", " + engine.describe());
        }

        if (isBore()) {
            return "mode=3x3-bore, " + autoStatus
                    + (engine.order() == null ? "" : ", " + engine.describe());
        }

        if (engine.order() == null) return "no area prepared";
        AreaMinerEngine.Status status = engine.status();
        return "phase=" + status.phase()
                + ", " + engine.describe()
                + ", attempted=" + status.attempted()
                + ", retryPass=" + status.retryPass()
                + ", " + status.message();
    }

    /** Used by the command layer so one code path handles every module. */
    public void reportInfo(String message, Object... args) {
        info(message, args);
    }

    public void reportError(String message, Object... args) {
        error(message, args);
    }
}
