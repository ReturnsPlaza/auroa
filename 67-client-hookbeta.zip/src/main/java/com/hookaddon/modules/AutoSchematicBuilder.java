package com.hookaddon.modules;

import com.hookaddon.HookAddon;
import com.hookaddon.persist.HookStore;
import com.hookaddon.schematic.Blueprints;
import com.hookaddon.schematic.PlacementEngine;
import com.hookaddon.schematic.PlacementPlanner;
import com.hookaddon.schematic.Schematic;
import com.hookaddon.schematic.SchematicException;
import com.hookaddon.schematic.SchematicFormats;
import com.hookaddon.schematic.TransformMath;
import com.hookaddon.task.Capability;
import com.hookaddon.task.ConflictPolicy;
import com.hookaddon.task.TaskManager;
import com.hookaddon.util.HookStatus;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.List;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockPosSetting;
import meteordevelopment.meteorclient.settings.BlockSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/**
 * Priority one module: builds a schematic in the world, block by block, with real verification.
 *
 * <p>Responsibilities are split on purpose:
 *
 * <ul>
 *   <li>file formats are handled by {@link SchematicFormats},
 *   <li>transform and anchoring by {@link PlacementPlanner},
 *   <li>the placement loop by {@link PlacementEngine},
 *   <li>movement and breaking by the shared {@code Navigator} and {@code MiningController}.
 * </ul>
 *
 * This class only owns the settings, the lifecycle (claim, start, pause, resume, cancel), the chat
 * status and the preview rendering.
 */
public class AutoSchematicBuilder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPlacement = settings.createGroup("Placement");
    private final SettingGroup sgSafety = settings.createGroup("Safety");
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgKeys = settings.createGroup("Keys");

    // General -------------------------------------------------------------------------------

    private final Setting<Blueprints.Blueprint> blueprint = sgGeneral.add(new EnumSetting.Builder<Blueprints.Blueprint>()
            .name("blueprint")
            .description("Place a built-in shape instead of a schematic file; takes effect on the next start")
            .defaultValue(Blueprints.Blueprint.NONE)
            .onChanged(value -> {
                if (isActive() && value != Blueprints.Blueprint.NONE && mc.player != null) startBuild(null);
            })
            .build());

    private final Setting<net.minecraft.block.Block> blueprintMaterial = sgGeneral.add(new BlockSetting.Builder()
            .name("blueprint-material")
            .description("Block the selected blueprint is built from")
            .defaultValue(Blocks.COBBLESTONE)
            .visible(() -> blueprint.get() != Blueprints.Blueprint.NONE)
            .onChanged(value -> {
                if (isActive() && blueprint.get() != Blueprints.Blueprint.NONE && mc.player != null) startBuild(null);
            })
            .build());

    private final Setting<String> schematic = sgGeneral.add(new StringSetting.Builder()
            .name("schematic")
            .description("Schematic file name inside config/hook-addon/schematics")
            .defaultValue("")
            .placeholder("house.litematic")
            .visible(() -> blueprint.get() == Blueprints.Blueprint.NONE)
            .build());

    private final Setting<PlacementPlanner.Anchor> anchor = sgGeneral.add(new EnumSetting.Builder<PlacementPlanner.Anchor>()
            .name("anchor")
            .description("Where the schematic is placed in the world")
            .defaultValue(PlacementPlanner.Anchor.POSITION)
            .build());

    private final Setting<BlockPos> origin = sgGeneral.add(new BlockPosSetting.Builder()
            .name("origin")
            .description("World position the schematic corner is placed at")
            .defaultValue(BlockPos.ORIGIN)
            .visible(() -> anchor.get() == PlacementPlanner.Anchor.POSITION)
            .build());

    private final Setting<TransformMath.Mirror> mirror = sgGeneral.add(new EnumSetting.Builder<TransformMath.Mirror>()
            .name("mirror")
            .description("Mirrors the schematic before rotating it")
            .defaultValue(TransformMath.Mirror.NONE)
            .build());

    private final Setting<TransformMath.Rotation> rotation = sgGeneral.add(new EnumSetting.Builder<TransformMath.Rotation>()
            .name("rotation")
            .description("Rotates the schematic around its origin")
            .defaultValue(TransformMath.Rotation.NONE)
            .build());

    private final Setting<Boolean> autoResume = sgGeneral.add(new BoolSetting.Builder()
            .name("auto-resume")
            .description("Reopens the last build when the module is enabled again")
            .defaultValue(true)
            .build());

    private final Setting<Integer> maxOperationSize = sgGeneral.add(new IntSetting.Builder()
            .name("max-operation-size")
            .description("Refuse to plan a build larger than this many blocks")
            .defaultValue(200000)
            .sliderRange(256, 1000000)
            .build());

    private final Setting<ConflictPolicy> conflictPolicy = sgGeneral.add(new EnumSetting.Builder<ConflictPolicy>()
            .name("conflict-policy")
            .description("What to do when another Hook module already owns movement or mining")
            .defaultValue(ConflictPolicy.REJECT)
            .build());

    // Placement -----------------------------------------------------------------------------

    private final Setting<Integer> placeDelay = sgPlacement.add(new IntSetting.Builder()
            .name("place-delay")
            .description("Ticks between two placements")
            .defaultValue(2)
            .range(0, 40)
            .build());

    private final Setting<Double> reach = sgPlacement.add(new DoubleSetting.Builder()
            .name("reach")
            .description("Interaction distance in blocks")
            .defaultValue(4.5)
            .range(3.0, 6.0)
            .build());

    private final Setting<Boolean> autoNavigate = sgPlacement.add(new BoolSetting.Builder()
            .name("navigate")
            .description("Walk to blocks that are out of reach")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> rotateSetting = sgPlacement.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Look at a block before placing or breaking it")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> swing = sgPlacement.add(new BoolSetting.Builder()
            .name("swing")
            .description("Swing the hand while placing and breaking")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> skipMissing = sgPlacement.add(new BoolSetting.Builder()
            .name("skip-missing-materials")
            .description("Skip blocks whose material is not in the inventory instead of waiting")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> placeSupport = sgPlacement.add(new BoolSetting.Builder()
            .name("place-support")
            .description("Place a support block when a target has nothing to be placed against")
            .defaultValue(true)
            .build());

    private final Setting<net.minecraft.block.Block> supportBlock = sgPlacement.add(new BlockSetting.Builder()
            .name("support-block")
            .description("Block used for support placements")
            .defaultValue(Blocks.COBBLESTONE)
            .visible(placeSupport::get)
            .build());

    private final Setting<Boolean> autoMove = sgPlacement.add(new BoolSetting.Builder()
            .name("auto-move-to-hotbar")
            .description("Move building materials into an empty hotbar slot automatically")
            .defaultValue(true)
            .build());

    private final Setting<Integer> verifyBudget = sgPlacement.add(new IntSetting.Builder()
            .name("verify-per-tick")
            .description("Positions checked per tick while verifying a build")
            .defaultValue(1000)
            .sliderRange(50, 5000)
            .build());

    private final Setting<Integer> verifyTimeout = sgPlacement.add(new IntSetting.Builder()
            .name("confirm-timeout")
            .description("Ticks to wait for the server to confirm a placement")
            .defaultValue(60)
            .range(5, 400)
            .build());

    private final Setting<Integer> maxAttempts = sgPlacement.add(new IntSetting.Builder()
            .name("max-attempts")
            .description("Attempts per block before it is reported as failed")
            .defaultValue(3)
            .range(1, 10)
            .build());

    // Safety --------------------------------------------------------------------------------

    private final Setting<Boolean> autoTool = sgSafety.add(new BoolSetting.Builder()
            .name("auto-tool")
            .description("Select the fastest tool when breaking a wrong block")
            .defaultValue(true)
            .build());

    private final Setting<Integer> minToolDurability = sgSafety.add(new IntSetting.Builder()
            .name("min-tool-durability")
            .description("Do not use a tool that has fewer durability points left")
            .defaultValue(10)
            .range(0, 500)
            .visible(autoTool::get)
            .build());

    private final Setting<Boolean> avoidLava = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-lava")
            .description("Never break blocks touching lava")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> avoidFluids = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-fluids")
            .description("Never break blocks touching any fluid")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> avoidFalling = sgSafety.add(new BoolSetting.Builder()
            .name("avoid-falling-blocks")
            .description("Never break a block that has sand or gravel above it")
            .defaultValue(true)
            .build());

    // Render --------------------------------------------------------------------------------

    private final Setting<Boolean> preview = sgRender.add(new BoolSetting.Builder()
            .name("preview")
            .description("Render the schematic bounds and the blocks that are still pending")
            .defaultValue(true)
            .build());

    private final Setting<SettingColor> boundsColor = sgRender.add(new ColorSetting.Builder()
            .name("bounds-color")
            .description("Colour of the schematic outline")
            .defaultValue(new SettingColor(157, 89, 248, 200))
            .build());

    private final Setting<SettingColor> pendingColor = sgRender.add(new ColorSetting.Builder()
            .name("pending-color")
            .description("Colour of pending blocks and the current target")
            .defaultValue(new SettingColor(64, 220, 255, 160))
            .visible(preview::get)
            .build());

    private final Setting<Integer> maxPreviewBlocks = sgRender.add(new IntSetting.Builder()
            .name("max-preview-blocks")
            .description("Upper bound on how many pending blocks are drawn")
            .defaultValue(512)
            .sliderRange(16, 4096)
            .visible(preview::get)
            .build());

    // Keys ----------------------------------------------------------------------------------

    private final Setting<Keybind> pauseKey = sgKeys.add(new KeybindSetting.Builder()
            .name("pause-key")
            .description("Pause and resume the current build")
            .defaultValue(Keybind.none())
            .action(this::togglePause)
            .build());

    private final Setting<Keybind> stopKey = sgKeys.add(new KeybindSetting.Builder()
            .name("stop-key")
            .description("Cancel the current build without disabling the module")
            .defaultValue(Keybind.none())
            .action(this::stopBuild)
            .build());

    // State ---------------------------------------------------------------------------------

    private final PlacementEngine engine;
    private Schematic schematicFile;
    private PlacementPlanner.Plan plan;
    private boolean claimed;
    /** Set when the connection dropped mid-build, so the next tick can re-verify the plan. */
    private boolean interrupted;

    public AutoSchematicBuilder() {
        super(HookAddon.CATEGORY, "auto-schematic-builder",
                "Builds a schematic from config/hook-addon/schematics block by block, verifying every placement.");
        this.engine = new PlacementEngine(name, this);
    }

    public PlacementEngine engine() {
        return engine;
    }

    public Schematic loadedSchematic() {
        return schematicFile;
    }

    // Lifecycle ------------------------------------------------------------------------------

    @Override
    public void onActivate() {
        HookStore.ensureDirectories();
        TaskManager.setLogSink(message -> HookAddon.LOG.debug("[task] {}", message));

        if (!ensureClaim()) return;

        // Resume the previous build when asked to.
        String requested = schematic.get();
        HookStore.BuildState saved = HookStore.loadBuildState();
        if (autoResume.get() && saved != null && blueprint.get() == Blueprints.Blueprint.NONE
                && (requested == null || requested.isBlank())) {
            anchor.set(parseAnchor(saved.anchor));
            origin.set(new BlockPos(saved.originX, saved.originY, saved.originZ));
            mirror.set(parseMirror(saved.mirror));
            rotation.set(parseRotation(saved.rotation));

            Blueprints.Blueprint savedBlueprint = saved.blueprint == null
                    ? Blueprints.Blueprint.NONE : Blueprints.find(saved.blueprint);
            if (savedBlueprint != Blueprints.Blueprint.NONE) {
                net.minecraft.block.Block material = parseMaterial(saved.blueprintMaterial);
                blueprint.set(savedBlueprint);
                if (material != null) blueprintMaterial.set(material);
                info("Resuming blueprint %s", savedBlueprint.title);
            } else if (saved.schematicFile != null && !saved.schematicFile.isBlank()) {
                schematic.set(saved.schematicFile);
                info("Resuming build of %s", saved.schematicFile);
            }
        }

        if (!startBuildInternal(schematic.get())) {
            disable();
        }
    }

    @Override
    public void onDeactivate() {
        engine.shutdown();
        if (claimed) {
            TaskManager.get().release(name);
            claimed = false;
        }
        HookStatus.reset("schematic");
    }

    /** Called by the task layer when another module preempts this one. */
    private void forceStop() {
        engine.cancel();
        if (isActive()) disable();
    }

    /**
     * Claims movement, mining and interaction when they are not held yet. Called on activate and
     * again on every tick after a disconnect, because the task registry is wiped when the player
     * leaves a world and a build that keeps ticking without its claims would be refused by the
     * navigator and mining controller.
     *
     * @return true when the module holds its capabilities and may keep working
     */
    private boolean ensureClaim() {
        if (claimed) return true;
        if (!isActive()) return false;

        TaskManager.ClaimResult claim = TaskManager.get().claim(
                name,
                title,
                EnumSet.of(Capability.MOVE, Capability.MINE, Capability.INTERACT),
                conflictPolicy.get(),
                this::forceStop);
        if (!claim.ok()) {
            error(claim.message());
            disable();
            return false;
        }

        claimed = true;
        return true;
    }

    // Build control -------------------------------------------------------------------------

    /**
     * Loads a schematic and starts a fresh verification pass.
     *
     * @param fileName file name inside the schematics folder, may be {@code null}
     * @return true when the build started
     */
    public boolean startBuild(String fileName) {
        if (!ensureClaim()) return false;

        return startBuildInternal(fileName);
    }

    private boolean startBuildInternal(String fileName) {
        if (mc.player == null || mc.world == null) {
            error("Join a world before starting a build.");
            return false;
        }

        if (blueprint.get() != Blueprints.Blueprint.NONE) {
            Schematic shape;
            try {
                shape = Blueprints.build(blueprint.get(), blueprintMaterial.get());
            } catch (RuntimeException e) {
                error("Could not build the '%s' blueprint: %s", blueprint.get().title, e.getMessage());
                return false;
            }
            return startPlan(shape, blueprint.get().title);
        }

        if (fileName == null || fileName.isBlank()) {
            error("No schematic selected. Put a %s file in %s and set the 'schematic' setting.",
                    String.join("/", schematicExtensions()), HookStore.schematicsDir());
            return false;
        }

        Path file;
        try {
            file = resolveSchematicFile(fileName);
        } catch (SchematicException e) {
            error(e.getMessage());
            return false;
        }

        if (!Files.isRegularFile(file)) {
            error("Schematic '%s' was not found in %s", fileName, HookStore.schematicsDir());
            return false;
        }

        Schematic parsed;
        try {
            parsed = SchematicFormats.load(file);
        } catch (SchematicException e) {
            error("Could not load '%s': %s", fileName, e.getMessage());
            return false;
        } catch (Exception e) {
            error("Could not load '%s': %s", fileName, e);
            HookAddon.LOG.error("Schematic parsing failed for {}", file, e);
            return false;
        }

        return startPlan(parsed, fileName);
    }

    /** Plans the placement and starts the verification pass for a parsed schematic or blueprint. */
    private boolean startPlan(Schematic parsed, String sourceLabel) {
        PlacementPlanner.Plan newPlan = PlacementPlanner.build(
                parsed, mirror.get(), rotation.get(), anchor.get(), origin.get());

        if (newPlan.targets().isEmpty()) {
            error("'%s' contains no blocks to place.", sourceLabel);
            return false;
        }

        if (newPlan.targets().size() > maxOperationSize.get()) {
            error("'%s' has %d blocks, which is above the max-operation-size of %d.",
                    sourceLabel, newPlan.targets().size(), maxOperationSize.get());
            return false;
        }

        schematicFile = parsed;
        plan = newPlan;
        engine.setPlan(newPlan);
        HookStatus.reset("schematic");

        saveState(sourceLabel);

        info("Loaded %s (%s) - %d x %d x %d, %d blocks to place",
                sourceLabel, parsed.format, newPlan.sizeX(), newPlan.sizeY(), newPlan.sizeZ(),
                newPlan.targets().size());

        return true;
    }

    /** Pauses or resumes the current build. */
    public void togglePause() {
        if (!isActive()) return;

        if (engine.phase() == PlacementEngine.Phase.PAUSED) {
            engine.resume();
            info("Build resumed.");
        } else if (engine.phase() == PlacementEngine.Phase.BUILDING
                || engine.phase() == PlacementEngine.Phase.VERIFYING) {
            engine.pause();
            info("Build paused at %s.", describeProgress());
        } else {
            info("Nothing to pause.");
        }
    }

    /** Cancels the build but keeps the module enabled. */
    public void stopBuild() {
        if (!isActive()) return;
        engine.cancel();
        HookStore.clearBuildState();
        info("Build cancelled.");
    }

    /** Starts over from the current world state. */
    public void restartBuild() {
        if (plan == null) {
            error("No schematic loaded.");
            return;
        }
        engine.restart();
        HookStatus.reset("schematic");
        info("Re-verifying the build from scratch.");
    }

    // Ticking -------------------------------------------------------------------------------

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (plan == null) return;

        if (!ensureClaim()) return;

        if (interrupted) {
            interrupted = false;
            PlacementEngine.Phase phaseBefore = engine.phase();
            if (phaseBefore == PlacementEngine.Phase.VERIFYING
                    || phaseBefore == PlacementEngine.Phase.BUILDING
                    || phaseBefore == PlacementEngine.Phase.PAUSED) {
                // The queue was dropped on disconnect: rebuild the exact remaining work from the
                // world instead of reporting a build complete that never happened.
                engine.setPlan(plan);
                HookStatus.info(this, "Reconnected: re-verifying the build (%d blocks).", plan.targets().size());
            }
        }

        PlacementEngine.Phase before = engine.phase();
        engine.tick(engineOptions());

        if (before == PlacementEngine.Phase.VERIFYING
                && engine.phase() == PlacementEngine.Phase.BUILDING) {
            saveState(schematic.get());
        }
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        // The connection is gone: drop the claims so nothing is left dangling, and keep the saved
        // state so the build can be resumed after reconnecting.
        if (plan != null) saveState(schematic.get());
        engine.shutdown();
        if (claimed) {
            TaskManager.get().release(name);
            claimed = false;
        }
        interrupted = true;
    }

    private PlacementEngine.Options engineOptions() {
        return new PlacementEngine.Options(
                reach.get(),
                autoNavigate.get(),
                rotateSetting.get(),
                swing.get(),
                placeDelay.get(),
                verifyTimeout.get(),
                maxAttempts.get(),
                verifyBudget.get(),
                skipMissing.get(),
                placeSupport.get(),
                supportBlock.get(),
                autoMove.get(),
                autoTool.get(),
                minToolDurability.get(),
                avoidLava.get(),
                avoidFluids.get(),
                avoidFalling.get());
    }

    // Preview -------------------------------------------------------------------------------

    @EventHandler
    private void onRender3d(Render3DEvent event) {
        if (!preview.get() || plan == null) return;

        Box bounds = new Box(
                plan.origin().getX(), plan.origin().getY(), plan.origin().getZ(),
                plan.origin().getX() + plan.sizeX(),
                plan.origin().getY() + plan.sizeY(),
                plan.origin().getZ() + plan.sizeZ());

        event.renderer.box(bounds, boundsColor.get(), boundsColor.get(), ShapeMode.Lines, 0);

        List<BlockPos> pending = engine.pendingPositions();
        int limit = Math.min(pending.size(), maxPreviewBlocks.get());
        for (int i = 0; i < limit; i++) {
            event.renderer.box(pending.get(i), pendingColor.get(), pendingColor.get(), ShapeMode.Lines, 0);
        }

        BlockPos current = engine.currentTarget();
        if (current != null) {
            event.renderer.box(current, Color.WHITE, pendingColor.get(), ShapeMode.Both, 0);
        }
    }

    // Reporting -----------------------------------------------------------------------------

    @Override
    public String getInfoString() {
        return plan == null ? null : describeProgress();
    }

    /** Compact progress text, also used by the HUD and the {@code hook} command. */
    public String describeProgress() {
        if (plan == null) return "no schematic";
        PlacementEngine.Status status = engine.status();
        int total = status.total();
        int done = status.verified();
        int percent = total == 0 ? 0 : (int) Math.round(done * 100.0 / total);

        StringBuilder builder = new StringBuilder()
                .append(done).append('/').append(total).append(" (").append(percent).append("%)");

        if (status.skipped() > 0) builder.append(" skipped ").append(status.skipped());
        if (status.failed() > 0) builder.append(" failed ").append(status.failed());
        if (status.etaSeconds() >= 0) builder.append(", ETA ").append(formatSeconds(status.etaSeconds()));
        return builder.toString();
    }

    /** Full status text for the {@code hook status} command. */
    public String describeFull() {
        if (plan == null) return "no schematic loaded";
        PlacementEngine.Status status = engine.status();
        return "phase=" + status.phase()
                + ", " + describeProgress()
                + ", missing=" + status.missingBlocks()
                + ", incorrect=" + status.wrongBlocks()
                + ", " + status.message();
    }

    private static String formatSeconds(double seconds) {
        int total = (int) Math.round(seconds);
        if (total < 60) return total + "s";
        return (total / 60) + "m " + (total % 60) + "s";
    }

    // Helpers -------------------------------------------------------------------------------

    private void saveState(String fileName) {
        if (plan == null) return;

        boolean useBlueprint = blueprint.get() != Blueprints.Blueprint.NONE;
        if (!useBlueprint && (fileName == null || fileName.isBlank())) return;

        HookStore.BuildState state = new HookStore.BuildState();
        state.schematicFile = useBlueprint ? null : fileName;
        state.blueprint = useBlueprint ? blueprint.get().name() : null;
        state.blueprintMaterial = useBlueprint
                ? net.minecraft.registry.Registries.BLOCK.getId(blueprintMaterial.get()).toString()
                : null;
        state.anchor = anchor.get().name();
        state.originX = plan.origin().getX();
        state.originY = plan.origin().getY();
        state.originZ = plan.origin().getZ();
        state.mirror = mirror.get().name();
        state.rotation = rotation.get().name();
        state.dimension = mc.world == null ? null : mc.world.getRegistryKey().getValue().toString();
        state.savedAt = System.currentTimeMillis();
        HookStore.saveBuildState(state);
    }

    private Path resolveSchematicFile(String fileName) throws SchematicException {
        Path directory = HookStore.schematicsDir();
        Path resolved = directory.resolve(fileName.trim()).normalize();

        if (!resolved.startsWith(directory.normalize())) {
            throw new SchematicException("File name must point inside " + directory);
        }

        // Pick the format by extension so the user does not have to care which one it is.
        if (SchematicFormats.forFile(resolved.getFileName().toString()) == null) {
            throw new SchematicException("'" + fileName + "' has an unsupported extension ("
                    + String.join(", ", schematicExtensions()) + ")");
        }

        return resolved;
    }

    private static List<String> schematicExtensions() {
        return SchematicFormats.extensions();
    }

    private static PlacementPlanner.Anchor parseAnchor(String value) {
        if (value == null) return PlacementPlanner.Anchor.POSITION;
        try {
            return PlacementPlanner.Anchor.valueOf(value);
        } catch (IllegalArgumentException e) {
            return PlacementPlanner.Anchor.POSITION;
        }
    }

    private static TransformMath.Mirror parseMirror(String value) {
        if (value == null) return TransformMath.Mirror.NONE;
        try {
            return TransformMath.Mirror.valueOf(value);
        } catch (IllegalArgumentException e) {
            return TransformMath.Mirror.NONE;
        }
    }

    private static TransformMath.Rotation parseRotation(String value) {
        if (value == null) return TransformMath.Rotation.NONE;
        try {
            return TransformMath.Rotation.valueOf(value);
        } catch (IllegalArgumentException e) {
            return TransformMath.Rotation.NONE;
        }
    }

    /** Resolves a saved block id, tolerating unknown ids so a renamed block cannot break resuming. */
    private static net.minecraft.block.Block parseMaterial(String id) {
        if (id == null || id.isBlank()) return null;
        try {
            net.minecraft.util.Identifier identifier = net.minecraft.util.Identifier.tryParse(id);
            if (identifier == null || !net.minecraft.registry.Registries.BLOCK.containsId(identifier)) return null;
            return net.minecraft.registry.Registries.BLOCK.get(identifier);
        } catch (RuntimeException e) {
            return null;
        }
    }
}
