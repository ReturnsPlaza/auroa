package com.hookaddon.hud;

import com.hookaddon.HookAddon;
import com.hookaddon.modules.AutoAreaMiner;
import com.hookaddon.modules.AutoSchematicBuilder;
import com.hookaddon.modules.AutoSpawner;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;

/**
 * HUD element that shows what the three automation modules are doing.
 *
 * <p>Only active modules are listed, so the element stays small; when none is active it prints a
 * single muted line instead of an empty box.
 */
public class HookStatusHud extends HudElement {
    public static final HudElementInfo<HookStatusHud> INFO = new HudElementInfo<>(
            HookAddon.HUD_GROUP, "hook-status", "Shows the status of the Hook Addon modules.",
            HookStatusHud::new);

    private static final Color TITLE_COLOR = new Color(157, 89, 248);
    private static final Color INACTIVE_COLOR = new Color(120, 120, 130);

    public HookStatusHud() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {
        List<String[]> lines = collectLines();

        double width = 0;
        double lineHeight = renderer.textHeight(true);

        for (String[] line : lines) {
            width = Math.max(width, renderer.textWidth(line[0] + " " + line[1], true));
        }

        setSize(width, lines.size() * lineHeight);

        double rowY = y;
        for (String[] line : lines) {
            renderer.text(line[0], x, rowY, TITLE_COLOR, true);
            renderer.text(line[1], x + renderer.textWidth(line[0] + " ", true), rowY, INACTIVE_COLOR, true);
            rowY += lineHeight;
        }
    }

    private List<String[]> collectLines() {
        List<String[]> lines = new ArrayList<>();

        addLine(lines, Modules.get().getOptional(AutoSchematicBuilder.class)
                .filter(Module::isActive)
                .map(module -> new String[] {"Schematic:", module.getInfoString()}));
        addLine(lines, Modules.get().getOptional(AutoSpawner.class)
                .filter(Module::isActive)
                .map(module -> new String[] {"Spawner:", module.getInfoString()}));
        addLine(lines, Modules.get().getOptional(AutoAreaMiner.class)
                .filter(Module::isActive)
                .map(module -> new String[] {"Area:", module.getInfoString()}));

        if (lines.isEmpty()) lines.add(new String[] {"Hook Addon:", "idle"});
        return lines;
    }

    private static void addLine(List<String[]> lines, java.util.Optional<String[]> line) {
        line.ifPresent(lines::add);
    }
}
