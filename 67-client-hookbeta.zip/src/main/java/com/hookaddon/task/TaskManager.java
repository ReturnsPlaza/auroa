package com.hookaddon.task;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Central registry of task ownership.
 *
 * <p>Every automation module claims the capabilities it needs before it starts working and releases
 * them again when it stops. Because a capability can only be held by one owner, the schematic
 * builder, the spawner miner and the area miner can never move the player or break blocks at the
 * same time.
 *
 * <p>Deliberately free of Minecraft imports so the ownership rules can be unit tested on a plain
 * JVM. Logging goes through a pluggable sink that {@code HookAddon} installs at startup.
 */
public final class TaskManager {
    public record Claim(String owner, String title, Set<Capability> capabilities) {}

    public record ClaimResult(boolean ok, String message) {
        public static ClaimResult success() {
            return new ClaimResult(true, "ok");
        }
    }

    private static final int DEBUG_LOG_LIMIT = 250;
    private static final TaskManager INSTANCE = new TaskManager();

    private final Map<Capability, Claim> holders = new EnumMap<>(Capability.class);
    private final Map<String, Runnable> stopHandlers = new LinkedHashMap<>();
    private final Map<String, RetryTracker> retries = new LinkedHashMap<>();
    private final Deque<String> debugLog = new ArrayDeque<>();

    private static Consumer<String> logSink = message -> {};

    private TaskManager() {}

    public static TaskManager get() {
        return INSTANCE;
    }

    /** Replaces the debug sink, called once by the addon entry point. */
    public static void setLogSink(Consumer<String> sink) {
        logSink = sink == null ? message -> {} : sink;
    }

    /**
     * Tries to claim {@code capabilities} for {@code owner}.
     *
     * @param owner stable id of the caller, normally the module name
     * @param title human readable name used in conflict messages
     * @param stopHandler invoked when another module preempts this owner; must stop the task and
     *     release its claims (usually disables the module)
     */
    public synchronized ClaimResult claim(
            String owner,
            String title,
            Collection<Capability> capabilities,
            ConflictPolicy policy,
            Runnable stopHandler) {
        if (capabilities.isEmpty()) return ClaimResult.success();

        Set<Capability> wanted = EnumSet.noneOf(Capability.class);
        wanted.addAll(capabilities);

        Set<Capability> conflicting = conflicts(wanted, owner);
        if (!conflicting.isEmpty()) {
            if (policy == ConflictPolicy.PREEMPT) {
                Map<String, String> preempted = preempt(conflicting, owner);
                conflicting = conflicts(wanted, owner);
                if (conflicting.isEmpty()) {
                    log(owner + " took over from " + String.join(", ", preempted.values()));
                }
            }

            if (!conflicting.isEmpty()) {
                Claim holder = holders.get(conflicting.iterator().next());
                String holderTitle = holder == null ? "another task" : holder.title();
                return new ClaimResult(
                        false,
                        "Cannot start: "
                                + describe(conflicting)
                                + " is already used by "
                                + holderTitle
                                + ". Stop it first or set the module's conflict policy to '"
                                + ConflictPolicy.PREEMPT.title
                                + "'.");
            }
        }

        Claim claim = new Claim(owner, title, Set.copyOf(wanted));
        for (Capability capability : wanted) holders.put(capability, claim);

        if (stopHandler == null) stopHandlers.remove(owner);
        else stopHandlers.put(owner, stopHandler);

        log(owner + " claimed " + describe(wanted));
        return ClaimResult.success();
    }

    /** Releases every capability held by {@code owner}. Safe to call when nothing is held. */
    public synchronized void release(String owner) {
        Set<Capability> released = EnumSet.noneOf(Capability.class);
        holders.entrySet().removeIf(entry -> {
            if (entry.getValue().owner().equals(owner)) {
                released.add(entry.getKey());
                return true;
            }
            return false;
        });

        stopHandlers.remove(owner);
        RetryTracker tracker = retries.get(owner);
        if (tracker != null) tracker.reset();

        if (!released.isEmpty()) log(owner + " released " + describe(released));
    }

    public synchronized boolean owns(String owner, Capability capability) {
        Claim holder = holders.get(capability);
        return holder != null && holder.owner().equals(owner);
    }

    public synchronized Optional<String> holderOf(Capability capability) {
        Claim holder = holders.get(capability);
        return holder == null ? Optional.empty() : Optional.of(holder.owner());
    }

    public synchronized Optional<Claim> claimOf(String owner) {
        for (Claim claim : holders.values()) if (claim.owner().equals(owner)) return Optional.of(claim);
        return Optional.empty();
    }

    /** True when any module currently holds any capability. */
    public synchronized boolean anyHeld() {
        return !holders.isEmpty();
    }

    /** Drops everything, used on disconnect so a stale claim cannot block the next session. */
    public synchronized void releaseAll(String reason) {
        if (holders.isEmpty() && retries.isEmpty()) return;
        Set<String> owners = new LinkedHashSet<>();
        holders.values().forEach(claim -> owners.add(claim.owner()));
        holders.clear();
        stopHandlers.clear();
        retries.clear();
        log("released all claims (" + reason + "): " + String.join(", ", owners));
    }

    /** Shared retry/cooldown tracker for an owner, created on first use. */
    public synchronized RetryTracker retries(String owner) {
        return retries.computeIfAbsent(owner, key -> new RetryTracker());
    }

    /** Writes to the debug ring buffer and the pluggable sink. */
    public static void debug(String message) {
        logSink.accept(message);
    }

    /** Most recent debug messages, oldest first. */
    public synchronized List<String> debugLog() {
        return new ArrayList<>(debugLog);
    }

    public synchronized void clearDebugLog() {
        debugLog.clear();
    }

    private Set<Capability> conflicts(Set<Capability> wanted, String owner) {
        Set<Capability> conflicting = EnumSet.noneOf(Capability.class);
        for (Capability capability : wanted) {
            Claim holder = holders.get(capability);
            if (holder != null && !holder.owner().equals(owner)) conflicting.add(capability);
        }
        return conflicting;
    }

    private Map<String, String> preempt(Set<Capability> conflicting, String newOwner) {
        Map<String, String> owners = new LinkedHashMap<>();
        for (Capability capability : conflicting) {
            Claim holder = holders.get(capability);
            if (holder != null) owners.put(holder.owner(), holder.title());
        }

        for (Map.Entry<String, String> entry : owners.entrySet()) {
            if (entry.getKey().equals(newOwner)) continue;
            Runnable stopHandler = stopHandlers.get(entry.getKey());
            if (stopHandler != null) {
                try {
                    stopHandler.run();
                } catch (RuntimeException e) {
                    // A failing stop handler must not wedge the registry.
                    logSink.accept("stop handler of " + entry.getKey() + " failed: " + e.getMessage());
                }
            }
            release(entry.getKey());
        }
        return owners;
    }

    private static String describe(Collection<Capability> capabilities) {
        List<String> titles = new ArrayList<>();
        for (Capability capability : capabilities) titles.add(capability.title);
        return String.join(", ", titles);
    }

    private void log(String message) {
        debugLog.addLast(message);
        while (debugLog.size() > DEBUG_LOG_LIMIT) debugLog.removeFirst();
        logSink.accept(message);
    }
}
