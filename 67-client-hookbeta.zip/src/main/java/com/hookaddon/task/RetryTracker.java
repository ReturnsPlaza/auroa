package com.hookaddon.task;

/**
 * Per-task attempt counter with cooldown support.
 *
 * <p>Shared by all automation modules so retry limits and "do not spam this" cooldowns are applied
 * consistently. Pure Java on purpose so it can be unit tested without a Minecraft runtime.
 */
public final class RetryTracker {
    private int attempts;
    private long lastAttemptAt;

    /** Consecutive failures since the last success. */
    public synchronized int attempts() {
        return attempts;
    }

    /** Timestamp (ms) of the most recent failure, 0 if none. */
    public synchronized long lastAttemptAt() {
        return lastAttemptAt;
    }

    /**
     * @param nowMs current time in milliseconds
     * @param cooldownMs minimum time that must have passed since the last failure
     * @param maxAttempts maximum consecutive failures allowed before {@code forceBlock} applies
     */
    public synchronized boolean allow(long nowMs, long cooldownMs, int maxAttempts) {
        if (maxAttempts > 0 && attempts >= maxAttempts) return false;
        return attempts == 0 || nowMs - lastAttemptAt >= cooldownMs;
    }

    /** Records a failure and starts the cooldown window. */
    public synchronized void failure(long nowMs) {
        attempts++;
        lastAttemptAt = nowMs;
    }

    /** Clears the failure streak after a success. */
    public synchronized void success() {
        attempts = 0;
        lastAttemptAt = 0;
    }

    /** Full reset, used when a task is cancelled or the target changes. */
    public synchronized void reset() {
        attempts = 0;
        lastAttemptAt = 0;
    }

    @Override
    public synchronized String toString() {
        return "RetryTracker{attempts=" + attempts + '}';
    }
}
