package com.hookaddon.task;

import com.hookaddon.util.InvGuards;
import com.hookaddon.util.SafetyChecks;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * The single component allowed to break blocks.
 *
 * <p>Modules hand it a target every tick and it answers with a result that distinguishes the cases
 * the engines care about: still working, verified gone, out of reach, unsafe, unmineable or
 * rejected because another module holds mining ownership.
 *
 * <p>Completion is never assumed. The controller keeps breaking until the world actually reports
 * air at the target position, and it fails the target when the timeout elapses first.
 */
public final class MiningController {
    public enum Result {
        /** Another module owns mining right now. */
        REJECTED,
        /** Still working on the target. */
        WORKING,
        /** The block is gone, verified against the world. */
        DONE,
        /** The target is too far away or occluded; navigate closer first. */
        OUT_OF_REACH,
        /** Safety settings forbid breaking this block. */
        UNSAFE,
        /** The block cannot or should not be broken (unbreakable or timeout). */
        FAILED
    }

    /**
     * @param reach interaction distance in blocks
     * @param rotate aim at the block before breaking
     * @param swing swing the hand while breaking
     * @param autoTool move the best tool into the main hand
     * @param minToolDurability do not use a tool with fewer durability points left
     * @param avoidLava / @param avoidFluids / @param avoidFalling safety screens
     * @param timeoutTicks how long a single target may take before it is declared failed
     * @param maxAttempts how often a failing target may be retried before it is given up on
     */
    public record Options(
            double reach,
            boolean rotate,
            boolean swing,
            boolean autoTool,
            int minToolDurability,
            boolean avoidLava,
            boolean avoidFluids,
            boolean avoidFalling,
            int timeoutTicks,
            int maxAttempts) {
        public static final Options DEFAULT =
                new Options(4.5, true, true, true, 10, true, false, true, 200, 3);
    }

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private String owner;
    private BlockPos target;
    private Options options = Options.DEFAULT;
    private int ticksOnTarget;
    private int attempts;

    private MiningController() {}

    private static final MiningController INSTANCE = new MiningController();

    public static MiningController get() {
        return INSTANCE;
    }

    public synchronized String owner() {
        return owner;
    }

    public synchronized BlockPos target() {
        return target;
    }

    public synchronized boolean isWorking() {
        return owner != null;
    }

    /**
     * Breaks {@code requestedTarget} for one tick.
     *
     * <p>Must be called from a {@code TickEvent.Pre} handler.
     */
    public synchronized Result tick(String requestingOwner, BlockPos requestedTarget, Options requestedOptions) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            reset(requestingOwner);
            return Result.FAILED;
        }

        if (!TaskManager.get().owns(requestingOwner, Capability.MINE)) {
            if (owner != null) reset(requestingOwner);
            TaskManager.debug(requestingOwner + ": mining refused, mining capability not held");
            return Result.REJECTED;
        }

        if (owner == null || !owner.equals(requestingOwner)) {
            owner = requestingOwner;
            target = null;
            ticksOnTarget = 0;
            attempts = 0;
        }
        if (requestedOptions != null) options = requestedOptions;

        if (target == null || !target.equals(requestedTarget)) {
            target = requestedTarget;
            ticksOnTarget = 0;
        }

        BlockState state = mc.world.getBlockState(target);

        if (state.isAir()) {
            owner = null;
            target = null;
            ticksOnTarget = 0;
            return Result.DONE;
        }

        if (!BlockUtils.canBreak(target, state)) {
            forgetTarget();
            return Result.FAILED;
        }

        if (SafetyChecks.unsafeToMine(target, options.avoidLava(), options.avoidFluids(), options.avoidFalling())) {
            forgetTarget();
            return Result.UNSAFE;
        }

        if (!inReach(target)) {
            return Result.OUT_OF_REACH;
        }

        if (options.autoTool()) InvGuards.selectBestTool(state, options.minToolDurability());

        if (options.rotate()) {
            // Rotation goes through Meteor's rotation system so the server sees a normal look packet.
            Rotations.rotate(Rotations.getYaw(target.toCenterPos()), Rotations.getPitch(target.toCenterPos()));
        }

        if (BlockUtils.breakBlock(target, options.swing())) ticksOnTarget++;

        if (ticksOnTarget > options.timeoutTicks()) {
            attempts++;
            TaskManager.debug(owner + ": mining timeout on " + target.toShortString());
            if (attempts >= Math.max(1, options.maxAttempts())) {
                forgetTarget();
                return Result.FAILED;
            }
            ticksOnTarget = 0;
        }

        return Result.WORKING;
    }

    /** Drops the current target but keeps ownership, used when a target is switched out. */
    public synchronized void reset(String requestingOwner) {
        if (owner != null && !owner.equals(requestingOwner)) return;
        owner = null;
        target = null;
        ticksOnTarget = 0;
        attempts = 0;
    }

    public synchronized void forgetTarget() {
        target = null;
        ticksOnTarget = 0;
        attempts = 0;
        owner = null;
    }

    /** True when the block center is within reach and not occluded. */
    public static boolean inReach(BlockPos pos) {
        if (mc.player == null || mc.world == null) return false;
        return inReach(pos, Options.DEFAULT.reach());
    }

    public static boolean inReach(BlockPos pos, double reach) {
        if (mc.player == null || mc.world == null) return false;

        Vec3d center = pos.toCenterPos();
        if (mc.player.getEyePos().squaredDistanceTo(center) > reach * reach) return false;

        RaycastContext context = new RaycastContext(
                mc.player.getEyePos(), center, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE,
                mc.player);
        var result = mc.world.raycast(context);
        return result != null && result.getBlockPos().equals(pos);
    }

    /** Lowercase, human readable form used in status messages. */
    public static String describe(Result result) {
        return result.name().toLowerCase().replace('_', ' ');
    }
}
