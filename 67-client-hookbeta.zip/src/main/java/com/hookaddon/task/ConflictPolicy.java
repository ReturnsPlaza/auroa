package com.hookaddon.task;

/**
 * What happens when a module wants a capability that another module already holds.
 */
public enum ConflictPolicy {
    /** Refuse to start and tell the user which module is in the way. */
    REJECT("Reject activation"),

    /** Ask the other module to stop its task, then take over. */
    PREEMPT("Stop the other task");

    public final String title;

    ConflictPolicy(String title) {
        this.title = title;
    }
}
