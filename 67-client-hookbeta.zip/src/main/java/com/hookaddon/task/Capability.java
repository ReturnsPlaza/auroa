package com.hookaddon.task;

/**
 * Resources that only one automation module may drive at a time.
 *
 * <p>The task layer treats these as exclusive locks so the schematic builder, the spawner miner and
 * the area miner can never issue conflicting movement, mining or interaction actions in the same
 * tick.
 */
public enum Capability {
    /** Walking, pathing, jumping, i.e. anything that presses movement keys or drives a path manager. */
    MOVE("movement"),

    /** Breaking blocks, including tool selection while breaking. */
    MINE("mining"),

    /** Placing blocks and right-click interactions. */
    INTERACT("block interaction");

    public final String title;

    Capability(String title) {
        this.title = title;
    }
}
