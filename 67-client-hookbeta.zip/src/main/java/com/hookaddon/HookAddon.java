package com.hookaddon;

import com.hookaddon.command.HookCommand;
import com.hookaddon.compat.HookBridge;
import com.hookaddon.hud.HookStatusHud;
import com.hookaddon.modules.AutoAreaMiner;
import com.hookaddon.modules.AutoSchematicBuilder;
import com.hookaddon.modules.AutoSpawner;
import com.hookaddon.persist.HookStore;
import com.hookaddon.task.TaskManager;
import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.commands.Commands;
import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * Entry point of the Hook Addon.
 *
 * <p>Registered by Fabric under the {@code meteor} entrypoint (see {@code fabric.mod.json}). Meteor
 * calls {@link #onRegisterCategories()} before addons initialize, so {@link #CATEGORY} is valid to
 * use in module constructors.
 *
 * <p>The addon ships no mixins: every hook it needs (tick, render, chat, disconnect) is already
 * exposed by Meteor's event bus, so there is nothing to inject into Minecraft's internals.
 */
public class HookAddon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    public static final Category CATEGORY = new Category("Hook Client");
    public static final HudGroup HUD_GROUP = new HudGroup("Hook Client");

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public void onInitialize() {
        LOG.info("Initializing Hook Addon");

        // One debug sink for the shared task layer.
        TaskManager.setLogSink(message -> LOG.debug("[task] {}", message));

        // Local JSON store and the schematics folder.
        HookStore.ensureDirectories();

        // Modules
        Modules.get().add(new AutoSchematicBuilder());
        Modules.get().add(new AutoSpawner());
        Modules.get().add(new AutoAreaMiner());

        // Commands
        Commands.add(new HookCommand());

        // HUD
        Hud.get().register(HookStatusHud.INFO);

        // Hook Client glue: bridge the client events into the compatibility layer, then load persisted
        // settings now that the modules exist in the module manager.
        HookBridge.register();
        hook.Hook.INSTANCE.getSettingsManager().loadProfile();

        LOG.info("Hook Addon ready: 3 modules in the {} category", CATEGORY.name);
    }

    @Override
    public String getPackage() {
        return "com.hookaddon";
    }
}
