package com.hookaddon.compat;

import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.orbit.EventBus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;

/**
 * Forwards Hook Client's event bus into the Meteor compatibility layer: client tick, 3D/2D render,
 * system chat, disconnect, outgoing dot commands and keybind actions. One instance, registered
 * once by the Hook bootstrap; listeners on a plain object always run, regardless of module state.
 */
public final class HookBridge {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static HookBridge instance;

    private int lastTickAge = Integer.MIN_VALUE;

    private HookBridge() {
    }

    public static void register() {
        if (instance != null || hook.Hook.INSTANCE == null) return;
        instance = new HookBridge();
        hook.Hook.INSTANCE.getEventBus().register(instance);
    }

    @hook.event.EventListener
    public void onTick(hook.event.events.TickEvent event) {
        // Hook fires its tick event twice per client tick (MinecraftClient.tick and the player
        // tick); forward only the first sighting of each player age so modules tick exactly once.
        if (mc.player == null) return;
        if (mc.player.age == lastTickAge) return;
        lastTickAge = mc.player.age;

        EventBus.get().post(new meteordevelopment.meteorclient.events.world.TickEvent.Pre());
    }

    @hook.event.EventListener
    public void onRender3d(hook.event.events.Render3DEvent event) {
        EventBus.get().post(new meteordevelopment.meteorclient.events.render.Render3DEvent());
    }

    @hook.event.EventListener
    public void onRender2d(hook.event.events.Render2DEvent event) {
        meteordevelopment.meteorclient.systems.hud.Hud.get().render(event.context);
    }

    @hook.event.EventListener
    public void onPacketReceive(hook.event.events.PacketReceiveEvent event) {
        if (event.packet instanceof GameMessageS2CPacket message) {
            EventBus.get().post(new meteordevelopment.meteorclient.events.game.ReceiveMessageEvent(message.content()));
        }
    }

    @hook.event.EventListener
    public void onPacketSend(hook.event.events.PacketSendEvent event) {
        if (event.packet instanceof ChatMessageC2SPacket chat) {
            if (meteordevelopment.meteorclient.commands.Commands.dispatch(chat.chatMessage())) {
                event.cancel();
            }
        }
    }

    @hook.event.EventListener
    public void onSetScreen(hook.event.events.SetScreenEvent event) {
        if (event.screen instanceof DisconnectedScreen) {
            EventBus.get().post(new meteordevelopment.meteorclient.events.game.GameLeftEvent());
        }
    }

    @hook.event.EventListener
    public void onKey(hook.event.events.KeyEvent event) {
        if (event.mode != 1 || mc.currentScreen != null) return;
        KeybindSetting.handleKeyPress(event.key);
    }
}
