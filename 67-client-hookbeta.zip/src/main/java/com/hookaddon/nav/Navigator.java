package com.hookaddon.nav;

import com.hookaddon.task.Capability;
import com.hookaddon.task.TaskManager;
import meteordevelopment.meteorclient.pathing.IPathManager;
import meteordevelopment.meteorclient.pathing.PathManagers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * The single component allowed to move the player.
 *
 * <p>It refuses to act unless the calling module holds {@link Capability#MOVE}, which is what stops
 * two automation modules from fighting over the movement keys in the same tick.
 *
 * <p>Two back ends are used:
 *
 * <ul>
 *   <li>When a real path manager is installed (Baritone or Voyager, detected through {@link
 *       PathManagers#get()}), goals are handed to it.
 *   <li>Otherwise a built-in walker drives the movement keys directly: turn towards the target,
 *       hold forward, jump over single block steps, swim up in water and guard edges. This is plain
 *       client-side input, nothing more.
 * </ul>
 *
 * <p>Both back ends share the same stuck detection: if the player does not make progress for {@link
 * Options#stuckTicks()} the navigator tries a recovery (jump and a sideways hop), and after {@link
 * Options#maxRecoveries()} failed recoveries it gives up with {@link State#FAILED}.
 */
public final class Navigator {
    public enum State {
        /** No navigation requested. */
        IDLE,
        /** Walking towards the target. */
        MOVING,
        /** Within {@link Options#arriveDistance()} of the target. */
        ARRIVED,
        /** Navigation impossible, the caller should stop or retry later. */
        FAILED
    }

    /**
     * @param arriveDistance distance in blocks at which the target counts as reached
     * @param allowJump whether the walker may jump over obstacles
     * @param edgeGuard whether the walker sneaks at ledges it should not walk off
     * @param stuckTicks ticks without progress before a recovery attempt
     * @param maxRecoveries recoveries before the navigation fails
     */
    public record Options(
            double arriveDistance, boolean allowJump, boolean edgeGuard, int stuckTicks, int maxRecoveries) {
        public static final Options DEFAULT = new Options(3.0, true, true, 60, 3);
    }

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Navigator INSTANCE = new Navigator();

    private String owner;
    private BlockPos target;
    private Options options = Options.DEFAULT;

    private boolean usingPathManager;
    private boolean targetDirty;
    private Vec3d lastProgressPos;
    private int ticksSinceProgress;
    private int recoveries;
    private int recoveryTicks;
    private int recoveryDirection = 1;

    private Navigator() {}

    public static Navigator get() {
        return INSTANCE;
    }

    public synchronized String owner() {
        return owner;
    }

    public synchronized BlockPos target() {
        return target;
    }

    public synchronized boolean isNavigating() {
        return owner != null;
    }

    /**
     * Advances navigation by one tick. Must be called from a {@code TickEvent.Pre} handler by the
     * module that holds {@link Capability#MOVE}.
     */
    public synchronized State tick(String requestingOwner, BlockPos requestedTarget, Options requestedOptions) {
        ClientWorld world = mc.world;
        if (mc.player == null || world == null) {
            stop(requestingOwner);
            return State.FAILED;
        }

        if (!TaskManager.get().owns(requestingOwner, Capability.MOVE)) {
            if (owner != null) stopInternal();
            TaskManager.debug(requestingOwner + ": navigation refused, movement capability not held");
            return State.FAILED;
        }

        if (owner == null || !owner.equals(requestingOwner)) {
            stopInternal();
            owner = requestingOwner;
            lastProgressPos = null;
            ticksSinceProgress = 0;
            recoveries = 0;
            recoveryTicks = 0;
        }

        if (target == null || !target.equals(requestedTarget)) {
            target = requestedTarget;
            targetDirty = true;
            ticksSinceProgress = 0;
            recoveries = 0;
            recoveryTicks = 0;
        }
        if (requestedOptions != null) options = requestedOptions;

        if (mc.player.isDead() || mc.player.getHealth() <= 0) {
            stopInternal();
            return State.FAILED;
        }

        if (isArrived()) {
            releaseKeys();
            stopPathManager();
            lastProgressPos = null;
            return State.ARRIVED;
        }

        boolean progressed = trackProgress();

        if (pathManagerAvailable()) {
            if (!usingPathManager) {
                releaseKeys();
                usingPathManager = true;
                TaskManager.debug(owner + ": using path manager '" + PathManagers.get().getName() + "'");
            }
            if (targetDirty || !PathManagers.get().isPathing()) {
                PathManagers.get().moveTo(target);
                targetDirty = false;
            }
        } else {
            if (usingPathManager) {
                stopPathManager();
            }
            walkTowardTarget();
        }

        if (!progressed) {
            ticksSinceProgress++;
            if (ticksSinceProgress >= options.stuckTicks()) {
                if (!startRecovery()) {
                    TaskManager.debug(owner + ": navigation failed after " + recoveries + " recovery attempts");
                    stopInternal();
                    return State.FAILED;
                }
            }
        }

        if (recoveryTicks > 0) recoveryTicks--;

        return State.MOVING;
    }

    /** Stops navigation if {@code releasingOwner} is the current owner, otherwise does nothing. */
    public synchronized void stop(String releasingOwner) {
        if (owner == null || !owner.equals(releasingOwner)) return;
        stopInternal();
    }

    public synchronized void stopAny() {
        if (owner != null) stopInternal();
    }

    private void stopInternal() {
        releaseKeys();
        stopPathManager();
        owner = null;
        target = null;
        targetDirty = false;
        lastProgressPos = null;
        ticksSinceProgress = 0;
        recoveries = 0;
        recoveryTicks = 0;
    }

    private boolean isArrived() {
        if (target == null || mc.player == null) return true;

        double dx = mc.player.getX() - (target.getX() + 0.5);
        double dy = mc.player.getY() - (target.getY() + 0.5);
        double dz = mc.player.getZ() - (target.getZ() + 0.5);
        double distance = options.arriveDistance();
        return dx * dx + dy * dy + dz * dz <= distance * distance;
    }

    /**
     * @return true when the player moved since the last sample
     *
     * <p>The threshold is deliberately small: normal walking covers about 0.22 blocks per tick and
     * sneaking or soul sand considerably less, so anything above 0.05 blocks per tick counts as
     * progress. A larger threshold would classify every ordinary walk as "stuck".
     */
    private boolean trackProgress() {
        Vec3d position = new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        boolean progressed = lastProgressPos == null || position.squaredDistanceTo(lastProgressPos) > 0.0025;
        if (progressed) {
            lastProgressPos = position;
            ticksSinceProgress = 0;
        }
        return progressed;
    }

    /** @return false when no further recovery is allowed */
    private boolean startRecovery() {
        if (recoveries >= options.maxRecoveries()) return false;
        recoveries++;
        recoveryTicks = 20;
        recoveryDirection = -recoveryDirection;
        ticksSinceProgress = 0;
        TaskManager.debug(owner + ": stuck, recovery attempt " + recoveries + "/" + options.maxRecoveries());
        return true;
    }

    private static boolean pathManagerAvailable() {
        IPathManager manager = PathManagers.get();
        return manager != null && !"none".equals(manager.getName());
    }

    private void stopPathManager() {
        if (!usingPathManager) return;
        usingPathManager = false;
        if (mc.world != null) PathManagers.get().stop();
    }

    /** Fallback walker: pure client-side key input towards the target. */
    private void walkTowardTarget() {
        if (target == null || mc.player == null) return;

        double dx = target.getX() + 0.5 - mc.player.getX();
        double dz = target.getZ() + 0.5 - mc.player.getZ();
        double dy = target.getY() - mc.player.getY();

        float desiredYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        if (recoveryTicks > 0) desiredYaw += 90 * recoveryDirection;

        float delta = wrapDegrees(desiredYaw - mc.player.getYaw());
        float turn = Math.max(-30f, Math.min(30f, delta));
        mc.player.setYaw(mc.player.getYaw() + turn);

        boolean horizontalDistanceLeft = Math.hypot(dx, dz) > 1.0;

        if (horizontalDistanceLeft) {
            mc.options.forwardKey.setPressed(true);
        } else {
            mc.options.forwardKey.setPressed(false);
        }

        boolean water = mc.player.isTouchingWater();
        boolean blockedAhead = isBlockedAhead();
        boolean dropAhead = isDropAhead();

        boolean jump = false;
        if (options.allowJump()) {
            if (water && dy > 0.5) jump = true;
            else if (blockedAhead && canJumpOver()) jump = true;
            else if (recoveryTicks > 0 && mc.player.isOnGround()) jump = true;
        }

        mc.options.jumpKey.setPressed(jump);

        boolean sneak = options.edgeGuard()
                && dropAhead
                && dy > -1.5
                && !water
                && mc.player.isOnGround()
                && horizontalDistanceLeft;
        mc.options.sneakKey.setPressed(sneak);
    }

    private boolean isBlockedAhead() {
        ClientWorld world = mc.world;
        if (world == null) return false;
        return !world.getBlockState(aheadBlock()).isReplaceable();
    }

    private boolean canJumpOver() {
        ClientWorld world = mc.world;
        if (world == null) return false;
        BlockPos front = aheadBlock();
        return world.getBlockState(front.up()).isReplaceable();
    }

    private boolean isDropAhead() {
        ClientWorld world = mc.world;
        if (world == null) return false;
        BlockPos front = aheadBlock();
        BlockPos below = front.down();
        return world.getBlockState(below).isAir() && world.getBlockState(below.down()).isAir();
    }

    private BlockPos aheadBlock() {
        float radians = (float) Math.toRadians(mc.player.getYaw());
        int ox = (int) Math.round(-Math.sin(radians));
        int oz = (int) Math.round(Math.cos(radians));
        return mc.player.getBlockPos().add(ox, 0, oz);
    }

    /** Stops pressing movement keys; called whenever navigation ends so the player does not keep walking. */
    private void releaseKeys() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
    }

    private static float wrapDegrees(float degrees) {
        float value = degrees % 360f;
        if (value >= 180f) value -= 360f;
        if (value < -180f) value += 360f;
        return value;
    }
}
