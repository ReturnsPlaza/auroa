package com.hookaddon.finder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;

/**
 * Finder that locates blocks to mine inside the chunks the client actually has.
 *
 * <p>It is the same chunk based pass the spawner finder uses: chunks inside the radius are visited
 * nearest first, work is bounded by a per tick budget of positions inspected, and a search area
 * that is still streaming in gets a short settle window (another pass) instead of being reported
 * as empty on the first tick. Unloaded chunks are never guessed at: the client has no block data
 * there.
 *
 * <p>Only positions that pass both filters are collected, so the resulting list is ready to be
 * handed to the mining engine as a plan. Collected positions are remembered in a visited set, so
 * the next pass does not propose the same block again (blocks that were mined are simply air on
 * the next pass, while ones that failed stay excluded until the finder is reset).
 *
 * <p>The list is sorted nearest first when a scan finishes, which is the order the mining engine
 * then walks it in.
 */
public final class BlockFinder {
    public enum Outcome {
        /** Still scanning. */
        SCANNING,
        /** The scan finished (or hit its target cap) with at least one match. */
        TARGET,
        /** Everything in range was scanned without a match. */
        NO_TARGET
    }

    public record Result(Outcome outcome, BlockPos matched, int scanned) {}

    /**
     * @param radius horizontal search radius in blocks
     * @param height vertical range above and below the start position
     * @param budgetPerTick maximum positions inspected per tick
     * @param maxTargets stop scanning once this many matches were collected
     * @param skipVisited skip positions already collected in this session
     * @param maxVisited the visited set is cleared once it grows past this size
     */
    public record Options(
            int radius,
            int height,
            int budgetPerTick,
            int maxTargets,
            boolean skipVisited,
            int maxVisited) {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** Chunks that were not there yet get this long to stream in before a search reports empty. */
    private static final long SETTLE_MS = 4000;

    private final Set<Long> visited = new HashSet<>();
    private final List<BlockPos> matches = new ArrayList<>();

    private List<long[]> chunks;
    private int chunkIndex;
    private int localX;
    private int localY;
    private int localZ;
    /** Chunks that were not loaded during the last pass, re-polled until the settle window ends. */
    private List<long[]> pending = new ArrayList<>();

    private BlockPos center;
    private int radius;
    private int minY;
    private int maxY;
    private int sizeY;

    private boolean running;
    private long settleUntilMs;
    private int scannedThisRun;

    /** Matches collected by the last finished scan, sorted nearest first. */
    public List<BlockPos> matches() {
        return matches;
    }

    public Set<Long> visited() {
        return visited;
    }

    public void loadVisited(Collection<Long> positions) {
        visited.clear();
        if (positions != null) visited.addAll(positions);
    }

    public void clearVisited() {
        visited.clear();
    }

    public boolean isRunning() {
        return running;
    }

    /** Number of positions inspected during this run (multiple passes count once per pass). */
    public int scanned() {
        return scannedThisRun;
    }

    /** Starts a new scan around {@code start}. */
    public void start(Options options, BlockPos start, boolean resetVisited) {
        if (resetVisited) visited.clear();

        matches.clear();
        center = new BlockPos(start);
        radius = Math.max(4, options.radius());
        sizeY = options.height() * 2 + 1;
        minY = start.getY() - options.height();
        maxY = start.getY() + options.height();

        chunks = buildChunkOrder();
        chunkIndex = 0;
        localX = localY = localZ = 0;
        pending = new ArrayList<>();
        settleUntilMs = System.currentTimeMillis() + SETTLE_MS;
        running = true;
        scannedThisRun = 0;
    }

    public void stop() {
        running = false;
        chunks = null;
    }

    /**
     * Advances the scan; returns an outcome other than {@link Outcome#SCANNING} when finished.
     * Both final outcomes carry the full match list via {@link #matches()}.
     */
    public Result tick(Options options, Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        if (!running || chunks == null || mc.world == null || mc.player == null) {
            running = false;
            return result(matches.isEmpty() ? Outcome.NO_TARGET : Outcome.TARGET);
        }

        int budget = Math.max(1, options.budgetPerTick());

        while (budget > 0) {
            if (matches.size() >= options.maxTargets()) return finish(options);
            if (passComplete()) break;

            long[] chunk = chunks.get(chunkIndex);
            int chunkX = (int) chunk[0];
            int chunkZ = (int) chunk[1];

            if (!mc.world.isChunkLoaded(chunkX, chunkZ)) {
                // Not here yet: remember it and re-poll it until the settle window ends.
                pending.add(chunk);
                advanceChunk();
                continue;
            }

            int used = scanChunk(options, chunkX, chunkZ, budget, shouldMine, shouldIgnore);
            scannedThisRun += used;
            budget -= used;
        }

        if (!passComplete()) {
            // The tick budget ran out mid-pass.
            return new Result(Outcome.SCANNING, firstMatch(), scannedThisRun);
        }

        if (!pending.isEmpty() && System.currentTimeMillis() < settleUntilMs) {
            // The area was still streaming in: re-poll only the missing chunks instead of
            // walking (and re-reading) everything again.
            chunks = pending;
            pending = new ArrayList<>();
            chunkIndex = 0;
            localX = localY = localZ = 0;
            return new Result(Outcome.SCANNING, firstMatch(), scannedThisRun);
        }

        return finish(options);
    }

    private boolean passComplete() {
        return chunkIndex >= chunks.size();
    }

    /** Finds up to {@code budget} positions inside one chunk; advances the chunk when done. */
    private int scanChunk(Options options, int chunkX, int chunkZ, int budget,
            Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        ClientWorld world = mc.world;
        int baseX = chunkX << 4;
        int baseZ = chunkZ << 4;
        int processed = 0;

        while (processed < budget && localY < sizeY) {
            int x = baseX + localX;
            int y = minY + localY;
            int z = baseZ + localZ;

            step();
            processed++;

            if (outsideRadius(x, z)) continue;

            long key = pack(x, y, z);
            if (options.skipVisited() && visited.contains(key)) continue;

            BlockState state = world.getBlockState(new BlockPos(x, y, z));
            if (state.isAir()) continue;

            Block block = state.getBlock();
            if (shouldIgnore.test(block) || !shouldMine.test(block)) continue;

            visited.add(key);
            matches.add(new BlockPos(x, y, z));
            if (matches.size() >= options.maxTargets()) break;
        }

        if (localY >= sizeY) advanceChunk();
        return processed;
    }

    private Result finish(Options options) {
        running = false;
        matches.sort(Comparator.comparingDouble(p -> {
            long dx = p.getX() - center.getX();
            long dy = p.getY() - center.getY();
            long dz = p.getZ() - center.getZ();
            return (double) (dx * dx + dy * dy + dz * dz);
        }));
        trimVisited(options);
        return result(matches.isEmpty() ? Outcome.NO_TARGET : Outcome.TARGET);
    }

    private Result result(Outcome outcome) {
        return new Result(outcome, firstMatch(), scannedThisRun);
    }

    private BlockPos firstMatch() {
        return matches.isEmpty() ? null : matches.get(0);
    }

    private boolean outsideRadius(int x, int z) {
        int dx = x - center.getX();
        int dz = z - center.getZ();
        return (long) dx * dx + (long) dz * dz > (long) radius * radius;
    }

    private void step() {
        localX++;
        if (localX >= 16) {
            localX = 0;
            localZ++;
            if (localZ >= 16) {
                localZ = 0;
                localY++;
            }
        }
    }

    private void advanceChunk() {
        chunkIndex++;
        localX = localY = localZ = 0;
    }

    private void trimVisited(Options options) {
        if (visited.size() > options.maxVisited()) visited.clear();
    }

    /** Chunks inside the radius, nearest first. */
    private List<long[]> buildChunkOrder() {
        int chunkRadius = (radius + 15) / 16;
        List<long[]> list = new ArrayList<>((chunkRadius * 2 + 1) * (chunkRadius * 2 + 1));

        int centerX = center.getX() >> 4;
        int centerZ = center.getZ() >> 4;

        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                list.add(new long[] {centerX + cx, centerZ + cz});
            }
        }

        list.sort(Comparator.comparingLong(chunk -> {
            int dx = (int) chunk[0] - centerX;
            int dz = (int) chunk[1] - centerZ;
            return (long) dx * dx + (long) dz * dz;
        }));

        return list;
    }

    /** Packs a position into a long, keeping enough bits for any realistic world coordinate. */
    public static long pack(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }
}