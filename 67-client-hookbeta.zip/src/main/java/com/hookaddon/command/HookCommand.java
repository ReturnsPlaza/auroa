package com.hookaddon.command;

import com.hookaddon.persist.HookStore;
import com.hookaddon.schematic.SchematicFormats;
import com.hookaddon.task.TaskManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.nio.file.Path;
import java.util.List;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.command.CommandSource;

/**
 * The {@code hook} command.
 *
 * <p>It exists because the three modules already expose their state through chat and the ClickGUI,
 * but a single place to inspect them, control a running build and read the task log makes the addon
 * usable without hunting through screens.
 */
public class HookCommand extends Command {
    public HookCommand() {
        super("hook", "Hook Addon: status, build and area control, diagnostics.", "ha");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            printStatus();
            return SINGLE_SUCCESS;
        });

        builder.then(literal("schematics").executes(context -> {
            listSchematics();
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("path").executes(context -> {
            info("Config folder: %s", HookStore.configDir());
            info("Schematic folder: %s", HookStore.schematicsDir());
            return SINGLE_SUCCESS;
        }));

        // Schematic builder -----------------------------------------------------------------
        builder.then(literal("build")
                .then(literal("load").then(argument("file", StringArgumentType.string()).executes(context -> {
                    loadSchematic(StringArgumentType.getString(context, "file"));
                    return SINGLE_SUCCESS;
                })))
                .then(literal("blueprint").then(argument("name", StringArgumentType.string()).executes(context -> {
                    setBlueprint(StringArgumentType.getString(context, "name"));
                    return SINGLE_SUCCESS;
                })))
                .then(literal("pause").executes(context -> {
                    withSchematic(module -> {
                        module.togglePause();
                        return null;
                    });
                    return SINGLE_SUCCESS;
                }))
                .then(literal("resume").executes(context -> {
                    withSchematic(module -> {
                        module.togglePause();
                        return null;
                    });
                    return SINGLE_SUCCESS;
                }))
                .then(literal("restart").executes(context -> {
                    withSchematic(module -> {
                        module.restartBuild();
                        return null;
                    });
                    return SINGLE_SUCCESS;
                }))
                .then(literal("stop").executes(context -> {
                    withSchematic(module -> {
                        module.stopBuild();
                        return null;
                    });
                    return SINGLE_SUCCESS;
                })));

        // Area miner ------------------------------------------------------------------------
        builder.then(literal("area")
                .then(literal("prepare").executes(context -> {
                    withArea(module -> module.prepareArea(), "Area prepared.");
                    return SINGLE_SUCCESS;
                }))
                .then(literal("start").executes(context -> {
                    withArea(module -> module.startRun(), "Mining started.");
                    return SINGLE_SUCCESS;
                }))
                .then(literal("pause").executes(context -> {
                    withArea(module -> {
                        module.togglePause();
                        return true;
                    }, "Toggled pause.");
                    return SINGLE_SUCCESS;
                }))
                .then(literal("reset").executes(context -> {
                    withArea(module -> {
                        module.resetRun();
                        return true;
                    }, "Area plan rebuilt.");
                    return SINGLE_SUCCESS;
                })));

        // Spawner ----------------------------------------------------------------------------
        builder.then(literal("spawner")
                .then(literal("clear-visited").executes(context -> {
                    var module = Modules.get().get(com.hookaddon.modules.AutoSpawner.class);
                    module.searcher().clearVisited();
                    info("Cleared the list of already scanned positions.");
                    return SINGLE_SUCCESS;
                }))
                .then(literal("rtp").executes(context -> {
                    var module = Modules.get().get(com.hookaddon.modules.AutoSpawner.class);
                    info("RTP state: %s, consecutive failures: %d, attempts: %d",
                            module.rtpFallback().state(),
                            module.rtpFallback().consecutiveFailures(),
                            module.rtpFallback().totalAttempts());
                    return SINGLE_SUCCESS;
                })));

        // Diagnostics -------------------------------------------------------------------------
        builder.then(literal("log").executes(context -> {
            printLog();
            return SINGLE_SUCCESS;
        }));
    }

    private void printStatus() {
        var schematic = Modules.get().get(com.hookaddon.modules.AutoSchematicBuilder.class);
        var spawner = Modules.get().get(com.hookaddon.modules.AutoSpawner.class);
        var area = Modules.get().get(com.hookaddon.modules.AutoAreaMiner.class);

        info("Hook Addon - %d of 3 modules active", activeCount(schematic, spawner, area));
        info("Auto Schematic Builder: %s", schematic.isActive() ? schematic.describeFull() : "inactive");
        info("Auto Spawner: %s", spawner.isActive() ? spawner.describeFull() : "inactive");
        info("Auto Area Miner: %s", area.isActive() ? area.describeFull() : "inactive");
    }

    private static int activeCount(meteordevelopment.meteorclient.systems.modules.Module... modules) {
        int active = 0;
        for (var module : modules) if (module.isActive()) active++;
        return active;
    }

    private void listSchematics() {
        Path directory = HookStore.schematicsDir();
        List<Path> files = SchematicFormats.listFiles(directory);

        if (files.isEmpty()) {
            warning("No schematics in %s (supported: %s).", directory, String.join(", ", SchematicFormats.extensions()));
            return;
        }

        info("%d schematic file(s) in %s:", files.size(), directory);
        int shown = 0;
        for (Path file : files) {
            info("  %s", file.getFileName());
            if (++shown >= 20) {
                info("  ... and %d more", files.size() - shown);
                break;
            }
        }
    }

    /** Selects a built-in blueprint by name and restarts the plan when the module is already on. */
    private void setBlueprint(String name) {
        var module = Modules.get().get(com.hookaddon.modules.AutoSchematicBuilder.class);

        com.hookaddon.schematic.Blueprints.Blueprint blueprint =
                com.hookaddon.schematic.Blueprints.find(name);
        if (blueprint == com.hookaddon.schematic.Blueprints.Blueprint.NONE) {
            warning("Unknown blueprint '%s'. Available: %s", name, availableBlueprints());
            return;
        }

        Setting<com.hookaddon.schematic.Blueprints.Blueprint> setting =
                module.settings.get("blueprint", com.hookaddon.schematic.Blueprints.Blueprint.class);
        if (setting == null) {
            warning("The blueprint setting is unavailable.");
            return;
        }
        setting.set(blueprint);
        info("Blueprint set to %s.", blueprint.title);

        if (!module.isActive()) module.enable();
        else module.startBuild(null);
    }

    private static String availableBlueprints() {
        List<String> names = new java.util.ArrayList<>();
        for (var value : com.hookaddon.schematic.Blueprints.Blueprint.values()) {
            if (value != com.hookaddon.schematic.Blueprints.Blueprint.NONE) names.add(value.title);
        }
        return String.join(", ", names);
    }

    private void loadSchematic(String fileName) {
        var module = Modules.get().get(com.hookaddon.modules.AutoSchematicBuilder.class);

        // Loading a file means "not the blueprint": otherwise the file would be silently ignored.
        Setting<com.hookaddon.schematic.Blueprints.Blueprint> blueprint =
                module.settings.get("blueprint", com.hookaddon.schematic.Blueprints.Blueprint.class);
        if (blueprint != null) blueprint.set(com.hookaddon.schematic.Blueprints.Blueprint.NONE);

        Setting<String> setting = module.settings.get("schematic", String.class);
        if (setting != null) setting.set(fileName);

        if (!module.isActive()) {
            module.enable();
            return;
        }

        module.startBuild(fileName);
    }

    /** Runs an action on the schematic module, enabling it first when it is off. */
    private void withSchematic(java.util.function.Function<
            com.hookaddon.modules.AutoSchematicBuilder, Void> action) {
        var module = Modules.get().get(com.hookaddon.modules.AutoSchematicBuilder.class);
        if (!module.isActive()) {
            warning("Enable Auto Schematic Builder first.");
            return;
        }
        action.apply(module);
    }

    private void withArea(java.util.function.Predicate<com.hookaddon.modules.AutoAreaMiner> action, String okMessage) {
        var module = Modules.get().get(com.hookaddon.modules.AutoAreaMiner.class);
        if (!module.isActive()) {
            warning("Enable Auto Area Miner first.");
            return;
        }
        if (action.test(module)) info(okMessage);
    }

    private void printLog() {
        List<String> lines = TaskManager.get().debugLog();
        if (lines.isEmpty()) {
            info("The task log is empty.");
            return;
        }

        int from = Math.max(0, lines.size() - 10);
        info("Task log (last %d entries):", lines.size() - from);
        for (int i = from; i < lines.size(); i++) info("  %s", lines.get(i));
    }
}
