package com.hookaddon.spawner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Search engine that looks for spawners in the chunks the client actually has.
 *
 * <p>The scan is the block entity pass from the larp finder instead of a block-by-block walk of the
 * volume: each loaded chunk's block entity map is iterated, so a spawner qualifies as soon as its
 * block entity exists, its mob type comes from that very same object, and a radius of interest
 * costs a map iteration per chunk rather than {@code radius * height * radius} block reads.
 *
 * <p>What it does <em>not</em> do is scan unloaded chunks: the client has no block data there, so
 * pretending otherwise would report targets that cannot exist. A pass over a search area that was
 * still streaming in waits out a short settle window and takes another pass instead of reporting
 * the area as empty on the first tick, then falls through to {@link Outcome#NO_TARGET} honestly.
 *
 * <p>To keep the scan cheap:
 *
 * <ul>
 *   <li>work is bounded by a per tick budget of chunks inspected,
 *   <li>chunks are visited nearest first, so the closest spawner is found first,
 *   <li>every inspected spawner position is remembered in a visited set, so a repeated search does
 *       not report the same position again.
 * </ul>
 */
public final class SpawnerSearcher {
    public enum Outcome {
        /** Still scanning. */
        SCANNING,
        /** A spawner of an accepted type whose block entity the client has synced. */
        CONFIRMED,
        /** A spawner block the client cannot classify yet. */
        CANDIDATE,
        /** Everything in range was scanned without a match. */
        NO_TARGET
    }

    public record Result(Outcome outcome, SpawnerTarget target, int scanned) {}

    /**
     * @param radius horizontal search radius in blocks
     * @param height vertical range above and below the start position
     * @param budgetPerTick maximum chunks inspected per tick
     * @param types accepted spawner types, empty means "any type"
     * @param onlySelected restrict results to {@code types}
     * @param skipVisited skip positions already scanned in this session
     * @param maxVisited the visited set is cleared once it grows past this size
     */
    public record Options(
            int radius,
            int height,
            int budgetPerTick,
            Set<EntityType<?>> types,
            boolean onlySelected,
            boolean skipVisited,
            int maxVisited) {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** Chunks that were not there yet get this long to stream in before a search reports empty. */
    private static final long SETTLE_MS = 4000;

    private final Set<Long> visited = new HashSet<>();

    private List<long[]> chunks;
    private int chunkIndex;
    /** Chunks that were not loaded during the last pass, re-polled until the settle window ends. */
    private List<long[]> pending = new ArrayList<>();

    private BlockPos center;
    private int radius;
    private int minY;
    private int maxY;

    private boolean running;
    private long settleUntilMs;
    private int scannedThisRun;
    private SpawnerTarget lastCandidate;
    private SpawnerTarget confirmedTarget;

    public Set<Long> visited() {
        return visited;
    }

    public void loadVisited(Collection<Long> positions) {
        visited.clear();
        if (positions != null) visited.addAll(positions);
    }

    public void clearVisited() {
        visited.clear();
    }

    public boolean isRunning() {
        return running;
    }

    /** Number of chunks inspected during this run (multiple passes count once per pass). */
    public int scanned() {
        return scannedThisRun;
    }

    /** A spawner block that could not be classified during the last scan, if any. */
    public SpawnerTarget lastCandidate() {
        return lastCandidate;
    }

    /** Starts a new scan around {@code start}. */
    public void start(Options options, BlockPos start, boolean resetVisited) {
        if (resetVisited) visited.clear();

        center = new BlockPos(start);
        radius = Math.max(4, options.radius());
        minY = start.getY() - options.height();
        maxY = start.getY() + options.height();

        chunks = buildChunkOrder();
        chunkIndex = 0;
        pending = new ArrayList<>();
        settleUntilMs = System.currentTimeMillis() + SETTLE_MS;
        running = true;
        scannedThisRun = 0;
        lastCandidate = null;
    }

    public void stop() {
        running = false;
        chunks = null;
    }

    /** Advances the scan; returns an outcome other than {@link Outcome#SCANNING} when finished. */
    public Result tick(Options options) {
        if (!running || chunks == null || mc.world == null || mc.player == null) {
            running = false;
            return new Result(Outcome.NO_TARGET, lastCandidate, 0);
        }

        int budget = Math.max(1, options.budgetPerTick());

        while (budget > 0 && chunkIndex < chunks.size()) {
            long[] chunk = chunks.get(chunkIndex);
            int chunkX = (int) chunk[0];
            int chunkZ = (int) chunk[1];
            advanceChunk();

            if (!mc.world.isChunkLoaded(chunkX, chunkZ)) {
                // Not here yet: remember it and re-poll it until the settle window ends.
                pending.add(chunk);
                advanceChunk();
                continue;
            }

            scanChunk(options, chunkX, chunkZ);
            budget--;
            scannedThisRun++;

            SpawnerTarget found = confirmedTarget;
            if (found != null) {
                confirmedTarget = null;
                lastCandidate = null;
                running = false;
                trimVisited(options);
                return new Result(Outcome.CONFIRMED, found, scannedThisRun);
            }
        }

        if (chunkIndex < chunks.size()) return new Result(Outcome.SCANNING, lastCandidate, scannedThisRun);

        if (!pending.isEmpty()) {
            // Chunks were still streaming in: re-poll only the missing ones instead of walking
            // everything again, until the settle window ends (some may never load, e.g. because
            // they lie beyond the server's view distance).
            if (System.currentTimeMillis() < settleUntilMs) {
                chunks = pending;
                pending = new ArrayList<>();
                chunkIndex = 0;
                return new Result(Outcome.SCANNING, lastCandidate, scannedThisRun);
            }
        }

        running = false;
        return new Result(Outcome.NO_TARGET, lastCandidate, scannedThisRun);
    }

    /** Walks one chunk's block entity map; the chunk costs a single budget unit. */
    private void scanChunk(Options options, int chunkX, int chunkZ) {
        WorldChunk chunk = mc.world.getChunk(chunkX, chunkZ);
        if (chunk == null) return;

        for (BlockEntity entity : chunk.getBlockEntities().values()) {
            if (!(entity instanceof MobSpawnerBlockEntity)) continue;

            BlockPos pos = entity.getPos();
            if (pos.getY() < minY || pos.getY() > maxY) continue;
            if (outsideRadius(pos.getX(), pos.getZ())) continue;

            long key = pack(pos.getX(), pos.getY(), pos.getZ());
            if (options.skipVisited() && visited.contains(key)) continue;
            visited.add(key);

            SpawnerTarget target = inspect(pos, options);
            if (target == null) continue;

            if (target.confirmed()) {
                confirmedTarget = target;
                return;
            }

            lastCandidate = target;
        }

        trimVisited(options);
    }

    /** Re-checks a single position, used to upgrade a candidate to a confirmed target. */
    public Result check(BlockPos pos, Options options) {
        SpawnerTarget target = inspect(pos, options);
        if (target == null) return new Result(Outcome.SCANNING, null, 0);
        return new Result(target.confirmed() ? Outcome.CONFIRMED : Outcome.CANDIDATE, target, 0);
    }

    /** Classifies one spawner position. */
    private SpawnerTarget inspect(BlockPos pos, Options options) {
        ClientWorld world = mc.world;
        if (world == null || !world.getBlockState(pos).isOf(Blocks.SPAWNER)) return null;

        if (!(world.getBlockEntity(pos) instanceof MobSpawnerBlockEntity spawner)) {
            // Block entity not synced yet, the type is unknown.
            return new SpawnerTarget(pos, null, false);
        }

        EntityType<?> type = null;
        try {
            Entity rendered = spawner.getLogic().getRenderedEntity(world, pos);
            if (rendered != null) type = rendered.getType();
        } catch (RuntimeException e) {
            type = null;
        }

        if (type == null) return new SpawnerTarget(pos, null, false);

        if (options.types().isEmpty()) return new SpawnerTarget(pos, type, true);
        if (options.types().contains(type)) return new SpawnerTarget(pos, type, true);

        // Right block, wrong mob: only report it when the filter accepts everything.
        return options.onlySelected() ? null : new SpawnerTarget(pos, type, false);
    }

    private boolean outsideRadius(int x, int z) {
        int dx = x - center.getX();
        int dz = z - center.getZ();
        return (long) dx * dx + (long) dz * dz > (long) radius * radius;
    }

    private void advanceChunk() {
        chunkIndex++;
    }

    private void trimVisited(Options options) {
        if (visited.size() > options.maxVisited()) visited.clear();
    }

    /** Chunks inside the radius, nearest first. */
    private List<long[]> buildChunkOrder() {
        int chunkRadius = (radius + 15) / 16;
        List<long[]> list = new ArrayList<>((chunkRadius * 2 + 1) * (chunkRadius * 2 + 1));

        int centerX = center.getX() >> 4;
        int centerZ = center.getZ() >> 4;

        for (int cx = -chunkRadius; cx <= chunkRadius; cx++) {
            for (int cz = -chunkRadius; cz <= chunkRadius; cz++) {
                list.add(new long[] {centerX + cx, centerZ + cz});
            }
        }

        list.sort(Comparator.comparingLong(chunk -> {
            int dx = (int) chunk[0] - centerX;
            int dz = (int) chunk[1] - centerZ;
            return (long) dx * dx + (long) dz * dz;
        }));

        return list;
    }

    /** Packs a position into a long, keeping enough bits for any realistic world coordinate. */
    public static long pack(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }
}