package com.hookaddon.spawner;

import java.util.List;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.client.MinecraftClient;

/**
 * The automatic {@code /rtp} fallback.
 *
 * <p>The rules it follows are the ones that keep a command sequence from turning into spam:
 *
 * <ul>
 *   <li>one request at a time, gated by a cooldown between attempts,
 *   <li>a command is sent only after the cooldown has passed and only when the previous attempt
 *       finished,
 *   <li>a teleport is never assumed: the position (or the dimension) has to actually change within
 *       the timeout,
 *   <li>server replies that look like a permission or cooldown refusal fail the attempt immediately,
 *   <li>after the configured number of consecutive failures the fallback pauses instead of retrying
 *       forever.
 * </ul>
 *
 * The class has no Minecraft state of its own apart from reading the player position, and reports
 * through a {@link Consumer} so the module can phrase the messages.
 */
public final class RtpFallback {
    public enum State {
        /** Waiting for a search to request a teleport. */
        IDLE,
        /** Command sent, waiting for the world to move. */
        WAITING_CONFIRM,
        /** Teleport confirmed, waiting the configured delay before searching again. */
        POST_TELEPORT,
        /** Last attempt failed, waiting out the retry cooldown. */
        RETRY_WAIT,
        /** Too many failures, stopped until the user restarts it. */
        PAUSED
    }

    public enum Event {
        NONE,
        SENT,
        CONFIRMED,
        FAILED,
        PAUSED
    }

    /**
     * @param enabled master switch
     * @param command command to send, slash optional
     * @param retryDelaySeconds minimum gap between two attempts
     * @param maxConsecutive failures allowed before pausing
     * @param teleportTimeoutSeconds how long to wait for the position to change
     * @param postDelayTicks delay after a confirmed teleport before the next search
     * @param pauseAfterFailures pause instead of retrying when the limit is hit
     * @param minDistance blocks the player must move for the teleport to count as confirmed
     */
    public record Options(
            boolean enabled,
            String command,
            int retryDelaySeconds,
            int maxConsecutive,
            int teleportTimeoutSeconds,
            int postDelayTicks,
            boolean pauseAfterFailures,
            double minDistance) {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private State state = State.IDLE;

    private long sentAtMs;
    private long lastAttemptAtMs;
    private long cooldownUntilMs;
    private int postTeleportTicks;

    private double beforeX;
    private double beforeY;
    private double beforeZ;
    private String beforeDimension;

    private int consecutiveFailures;
    private int totalAttempts;
    private int totalSuccesses;

    public State state() {
        return state;
    }

    public int consecutiveFailures() {
        return consecutiveFailures;
    }

    public int totalAttempts() {
        return totalAttempts;
    }

    public int totalSuccesses() {
        return totalSuccesses;
    }

    /** Timestamp of the most recent attempt, persisted so the cooldown survives a restart. */
    public long lastAttemptAtMs() {
        return lastAttemptAtMs;
    }

    /** Earliest time another attempt may be sent, for the module's waiting state. */
    public long nextAttemptAtMs() {
        return Math.max(cooldownUntilMs, lastAttemptAtMs);
    }

    public boolean isPaused() {
        return state == State.PAUSED;
    }

    /**
     * Tries to start a teleport.
     *
     * @return true when the command was sent
     */
    public boolean request(String reason, Options options, Consumer<String> notify) {
        if (!options.enabled()) return false;

        if (state == State.PAUSED) {
            notify.accept("RTP fallback is paused after " + consecutiveFailures
                    + " failures. Toggle the module off and on to retry.");
            return false;
        }

        if (state != State.IDLE) return false;

        long now = System.currentTimeMillis();
        if (now < cooldownUntilMs) {
            notify.accept("RTP is on cooldown for " + remainingSeconds(now) + "s (" + reason + ").");
            return false;
        }

        if (options.pauseAfterFailures() && consecutiveFailures >= Math.max(1, options.maxConsecutive())) {
            state = State.PAUSED;
            notify.accept("RTP paused after " + consecutiveFailures + " consecutive failures.");
            return false;
        }

        String command = options.command() == null || options.command().isBlank()
                ? "/rtp"
                : options.command().trim();

        if (!command.startsWith("/")) command = "/" + command;

        ChatUtils.sendPlayerMsg(command);

        if (mc.player != null) {
            beforeX = mc.player.getX();
            beforeY = mc.player.getY();
            beforeZ = mc.player.getZ();
            beforeDimension = currentDimension();
        }

        sentAtMs = now;
        lastAttemptAtMs = now;
        totalAttempts++;
        state = State.WAITING_CONFIRM;

        notify.accept("Sent '" + command + "' (" + reason + "), waiting up to "
                + options.teleportTimeoutSeconds() + "s for the teleport...");
        return true;
    }

    /** Drives the state machine, returning the event that just happened. */
    public Event tick(Options options, Consumer<String> notify) {
        if (state == State.IDLE || state == State.PAUSED) return Event.NONE;

        if (mc.player == null || mc.world == null) {
            // Disconnected: forget the pending attempt, the module re-arms after rejoining.
            state = State.IDLE;
            return Event.NONE;
        }

        long now = System.currentTimeMillis();

        switch (state) {
            case WAITING_CONFIRM -> {
                if (teleported(options)) {
                    consecutiveFailures = 0;
                    totalSuccesses++;
                    cooldownUntilMs = now + options.retryDelaySeconds() * 1000L;
                    postTeleportTicks = Math.max(0, options.postDelayTicks());
                    state = State.POST_TELEPORT;
                    notify.accept("Teleport confirmed, waiting " + (postTeleportTicks / 20)
                            + "s before searching again.");
                    return Event.CONFIRMED;
                }

                if (now - sentAtMs > options.teleportTimeoutSeconds() * 1000L) {
                    fail(options, "no position change after " + options.teleportTimeoutSeconds()
                            + "s - the command may be denied, on cooldown or unavailable here", notify);
                    return Event.FAILED;
                }
            }

            case POST_TELEPORT -> {
                if (postTeleportTicks-- <= 0) {
                    state = State.IDLE;
                }
            }

            case RETRY_WAIT -> {
                if (now >= cooldownUntilMs) state = State.IDLE;
            }

            default -> {
                return Event.NONE;
            }
        }

        return Event.NONE;
    }

    /**
     * Feeds a chat message into the failure detection. Only messages received while a teleport is
     * pending are considered, and only the configured keywords.
     */
    public void onChatMessage(String message, Options options, List<String> keywords, Consumer<String> notify) {
        if (state != State.WAITING_CONFIRM || message == null || message.isBlank()) return;
        if (keywords == null || keywords.isEmpty()) return;

        String lower = message.toLowerCase(java.util.Locale.ROOT);
        for (String keyword : keywords) {
            if (keyword == null || keyword.isBlank()) continue;
            if (lower.contains(keyword.toLowerCase(java.util.Locale.ROOT))) {
                String snippet = message.length() > 120 ? message.substring(0, 120) + "..." : message;
                fail(options, "the server replied: \"" + snippet + "\"", notify);
                return;
            }
        }
    }

    /** Manual stop: drops any pending attempt and applies the cooldown. */
    public void stop(Options options, Consumer<String> notify) {
        if (state == State.WAITING_CONFIRM) {
            lastAttemptAtMs = System.currentTimeMillis();
            cooldownUntilMs = lastAttemptAtMs + options.retryDelaySeconds() * 1000L;
            notify.accept("RTP attempt cancelled, waiting " + options.retryDelaySeconds() + "s before retrying.");
        }
        state = State.IDLE;
    }

    /** Full reset, used when the module is toggled off. */
    public void reset() {
        state = State.IDLE;
        consecutiveFailures = 0;
    }

    public void clearCooldown() {
        cooldownUntilMs = 0;
        state = State.IDLE;
        consecutiveFailures = 0;
    }

    public void restoreCounters(int consecutiveFailures, long lastAttemptAtMs) {
        this.consecutiveFailures = Math.max(0, consecutiveFailures);
        this.lastAttemptAtMs = Math.max(0, lastAttemptAtMs);
        this.cooldownUntilMs = this.lastAttemptAtMs;
    }

    private void fail(Options options, String reason, Consumer<String> notify) {
        consecutiveFailures++;
        long now = System.currentTimeMillis();
        lastAttemptAtMs = now;
        cooldownUntilMs = now + options.retryDelaySeconds() * 1000L;
        state = State.RETRY_WAIT;

        notify.accept("RTP attempt " + totalAttempts + " failed: " + reason + " ("
                + consecutiveFailures + "/" + options.maxConsecutive() + ")");

        if (options.pauseAfterFailures() && consecutiveFailures >= Math.max(1, options.maxConsecutive())) {
            state = State.PAUSED;
            notify.accept("Too many failed RTP attempts, pausing. Enable it again to continue.");
        }
    }

    private boolean teleported(Options options) {
        String dimension = currentDimension();
        if (beforeDimension != null && !beforeDimension.equals(dimension)) return true;

        double dx = mc.player.getX() - beforeX;
        double dy = mc.player.getY() - beforeY;
        double dz = mc.player.getZ() - beforeZ;
        return dx * dx + dy * dy + dz * dz >= options.minDistance() * options.minDistance();
    }

    private String currentDimension() {
        if (mc.world == null) return "";
        return mc.world.getRegistryKey().getValue().toString();
    }

    private int remainingSeconds(long now) {
        long remaining = cooldownUntilMs - now;
        return remaining <= 0 ? 0 : (int) Math.ceil(remaining / 1000.0);
    }
}
