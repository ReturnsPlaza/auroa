package com.hookaddon.spawner;

import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;

/**
 * A spawner found by the search.
 *
 * <p>{@code confirmed} is the difference between "there is a spawner block here" and "the client
 * has the block entity and knows what it spawns". A candidate is never mined; the search upgrades
 * it to a confirmed target once the block entity has synced.
 */
public record SpawnerTarget(BlockPos pos, EntityType<?> type, boolean confirmed) {
    public String describe() {
        String where = "(" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ")";
        if (type == null) return "spawner at " + where;
        return "spawner at " + where;
    }
}
