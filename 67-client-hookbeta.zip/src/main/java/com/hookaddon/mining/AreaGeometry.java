package com.hookaddon.mining;

/**
 * Builds the traversal order of a rectangular volume for a given {@link MiningPattern}.
 *
 * <p>Pure arithmetic on ints so the order can be unit tested without a Minecraft runtime: the
 * returned array holds triples of {@code x, y, z} offsets relative to the area origin, in the exact
 * order the miner should visit them.
 *
 * <p>Every pattern walks bottom up so a corridor or layer never starts above material that still
 * has to be removed, and rows alternate direction (serpentine) so the miner does not walk back
 * across the whole area between rows.
 */
public final class AreaGeometry {
    private AreaGeometry() {}

    /**
     * @param width size along X
     * @param height size along Y
     * @param depth size along Z
     * @param pattern traversal pattern
     * @param stripWidth blocks kept per strip (STRIP) or corridor width (TUNNEL, forced to 1)
     * @param stripGap blocks left untouched between two strips or corridors
     * @return flat array of x,y,z triples
     * @throws IllegalArgumentException when a dimension is not positive
     */
    public static int[] order(int width, int height, int depth, MiningPattern pattern, int stripWidth, int stripGap) {
        if (width <= 0 || height <= 0 || depth <= 0) {
            throw new IllegalArgumentException("area dimensions must be positive");
        }

        int safeStripWidth = Math.max(1, stripWidth);
        int safeGap = Math.max(0, stripGap);

        return switch (pattern) {
            case LAYER_BY_LAYER -> fullOrder(width, height, depth, false);
            case GRID -> fullOrder(width, height, depth, true);
            case STRIP -> stripOrder(width, height, depth, safeStripWidth, safeGap, false);
            case TUNNEL -> stripOrder(width, height, depth, 1, safeGap, true);
        };
    }

    /** Number of blocks a pattern visits, without building the array. */
    public static int count(int width, int height, int depth, MiningPattern pattern, int stripWidth, int stripGap) {
        if (width <= 0 || height <= 0 || depth <= 0) return 0;

        int safeStripWidth = Math.max(1, stripWidth);
        int safeGap = Math.max(0, stripGap);

        return switch (pattern) {
            case LAYER_BY_LAYER, GRID -> width * height * depth;
            case STRIP -> countStrips(width, safeStripWidth, safeGap) * height * depth;
            case TUNNEL -> countStrips(width, 1, safeGap) * height * depth;
        };
    }

    private static int countStrips(int width, int stripWidth, int stripGap) {
        int period = stripWidth + stripGap;
        int complete = width / period;
        int remainder = width % period;
        return complete * stripWidth + Math.min(remainder, stripWidth);
    }

    /** Every block; {@code threeDimensional} alternates the row direction per layer as well. */
    private static int[] fullOrder(int width, int height, int depth, boolean threeDimensional) {
        int[] order = new int[width * height * depth * 3];
        int index = 0;

        for (int y = 0; y < height; y++) {
            boolean reverseRows = threeDimensional && (y & 1) == 1;

            for (int row = 0; row < width; row++) {
                int x = reverseRows ? width - 1 - row : row;
                boolean reverseCells = threeDimensional ? (row & 1) == 1 : ((row + y) & 1) == 1;

                for (int cell = 0; cell < depth; cell++) {
                    int z = reverseCells ? depth - 1 - cell : cell;
                    order[index++] = x;
                    order[index++] = y;
                    order[index++] = z;
                }
            }
        }

        return order;
    }

    /**
     * Strips of blocks along Z.
     *
     * @param width effective width to distribute strips over, 1 for a single corridor line
     * @param tunnel when true, two Y levels are advanced together so a corridor stays two high
     */
    private static int[] stripOrder(int width, int height, int depth, int stripWidth, int stripGap, boolean tunnel) {
        int[] xs = stripPositions(width, stripWidth, stripGap);
        int[] order = new int[Math.max(1, xs.length * height * depth) * 3];
        int index = 0;

        if (tunnel) {
            for (int pairStart = 0; pairStart < height; pairStart += 2) {
                int pairEnd = Math.min(height, pairStart + 2);

                for (int xi = 0; xi < xs.length; xi++) {
                    int x = xs[xi];
                    boolean reverse = (xi & 1) == 1;

                    for (int cell = 0; cell < depth; cell++) {
                        int z = reverse ? depth - 1 - cell : cell;

                        for (int y = pairStart; y < pairEnd; y++) {
                            order[index++] = x;
                            order[index++] = y;
                            order[index++] = z;
                        }
                    }
                }
            }

            return java.util.Arrays.copyOf(order, index);
        }

        for (int y = 0; y < height; y++) {
            for (int xi = 0; xi < xs.length; xi++) {
                int x = xs[xi];
                boolean reverse = ((xi + y) & 1) == 1;

                for (int cell = 0; cell < depth; cell++) {
                    int z = reverse ? depth - 1 - cell : cell;
                    order[index++] = x;
                    order[index++] = y;
                    order[index++] = z;
                }
            }
        }

        return java.util.Arrays.copyOf(order, index);
    }

    /** X offsets that belong to a strip. */
    private static int[] stripPositions(int width, int stripWidth, int stripGap) {
        int period = Math.max(1, stripWidth + stripGap);
        int[] positions = new int[width];
        int count = 0;

        for (int x = 0; x < width; x++) {
            if (x % period < stripWidth) positions[count++] = x;
        }

        return java.util.Arrays.copyOf(positions, count);
    }
}
