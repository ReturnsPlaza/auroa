package com.hookaddon.mining;

/**
 * Traversal patterns for the area miner.
 *
 * <p>All patterns walk the configured volume bottom up; they differ in which blocks they touch and
 * in the order they are visited.
 */
public enum MiningPattern {
    /** Every block, layer by layer, each layer traversed in a serpentine pattern. */
    LAYER_BY_LAYER("Layer by layer"),

    /** Strips of {@code stripWidth} blocks along Z, separated by {@code stripGap} blocks. */
    STRIP("Strip mining"),

    /** One-block-wide, two-block-high corridors along Z, spaced by {@code stripGap} blocks. */
    TUNNEL("Tunnel mining"),

    /** Every block, serpentine in three dimensions. */
    GRID("Grid traversal");

    public final String title;

    MiningPattern(String title) {
        this.title = title;
    }
}
