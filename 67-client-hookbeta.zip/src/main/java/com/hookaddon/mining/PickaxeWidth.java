package com.hookaddon.mining;

/**
 * Swing footprint of the area miner.
 *
 * <p>Vanilla servers only accumulate break progress for one block at a time, so a 3x3 swing still
 * mines block by block; the setting widens which blocks each swing clears, never the break speed.
 */
public enum PickaxeWidth {
    /** Mine only the block under the cursor. */
    ONE("1x1 pickaxe"),

    /** After each block, also clear the eight same-layer neighbours that are inside the area. */
    THREE("3x3 pickaxe");

    public final String title;

    PickaxeWidth(String title) {
        this.title = title;
    }
}
