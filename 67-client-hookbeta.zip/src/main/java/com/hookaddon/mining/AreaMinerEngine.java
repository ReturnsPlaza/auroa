package com.hookaddon.mining;

import com.hookaddon.nav.Navigator;
import com.hookaddon.task.MiningController;
import com.hookaddon.task.TaskManager;
import com.hookaddon.util.HookStatus;
import com.hookaddon.util.InvGuards;
import com.hookaddon.util.SafetyChecks;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Deque;
import java.util.List;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/**
 * The mining loop of the Auto Area Miner.
 *
 * <p>The engine walks a fixed traversal order built by {@link AreaGeometry} and, for each position:
 *
 * <ol>
 *   <li>applies the mine/ignore filters (a skipped position is counted, never attempted),
 *   <li>checks the world: already air counts as completed without touching it,
 *   <li>runs the safety screens (lava, fluids, falling blocks),
 *   <li>walks there when it is out of reach,
 *   <li>hands it to the shared {@link MiningController} and waits for a verified break.
 * </ol>
 *
 * Targets that fail are collected and retried up to a configurable number of passes instead of
 * being hammered in place, which is what keeps a single unbreakable or unreachable block from
 * looping forever. Counter values are always reported separately: attempted, completed, skipped
 * and failed are different outcomes.
 */
public final class AreaMinerEngine {
    public enum Phase {
        IDLE,
        RUNNING,
        PAUSED,
        COMPLETE
    }

    /**
     * @param reach interaction distance
     * @param autoNavigate walk to out of reach targets
     * @param rotate look at the block while mining
     * @param swing swing the hand while mining
     * @param autoTool pick the fastest tool
     * @param minToolDurability durability floor for the tool
     * @param delayBetweenBlocks ticks to wait between two targets
     * @param maxRetries extra passes over the blocks that failed
     * @param stopWhenFull pause when the inventory has no empty slot left
     * @param avoidLava / @param avoidFluids / @param avoidFalling safety screens
     * @param pickaxe swing footprint: only the current block, or a 3x3 swing that also clears the
     *     eight same-layer neighbours inside the area (still mined one by one; vanilla cannot
     *     break several blocks in parallel)
     */
    public record Options(
            double reach,
            boolean autoNavigate,
            boolean rotate,
            boolean swing,
            boolean autoTool,
            int minToolDurability,
            int delayBetweenBlocks,
            int maxRetries,
            boolean stopWhenFull,
            boolean avoidLava,
            boolean avoidFluids,
            boolean avoidFalling,
            PickaxeWidth pickaxe) {}

    public record Status(
            Phase phase,
            int total,
            int attempted,
            int completed,
            int skipped,
            int failed,
            int retryPass,
            double etaSeconds,
            String message) {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String owner;
    private final Module reporter;

    private int[] order;
    private BlockPos origin;
    private int width;
    private int height;
    private int depth;
    private MiningPattern pattern;

    private Phase phase = Phase.IDLE;
    private int cursor;
    private int attempted;
    private int completed;
    private int skipped;
    private int failed;

    private final Deque<Integer> failures = new ArrayDeque<>();
    private int retryPass;

    /** Last recorded outcome per position, so counters count unique positions, not events. */
    private static final byte OUT_NONE = 0;
    private static final byte OUT_DONE = 1;
    private static final byte OUT_SKIPPED = 2;
    private static final byte OUT_FAILED = 3;

    private byte[] outcomes = new byte[0];
    private final BitSet attemptedPositions = new BitSet();

    /** Neighbours queued by a 3x3 swing, mined one at a time before the traversal continues. */
    private final Deque<BlockPos> pendingSwing = new ArrayDeque<>();

    /** Positions where a swing-batch attempt already failed, so neighbours are not re-attempted per centre. */
    private final BitSet swingFailed = new BitSet();

    private int delayTicks;
    private String message = "idle";
    private long startedAtMs;
    private long completedAtStart;
    private boolean inventoryPaused;

    public AreaMinerEngine(String owner, Module reporter) {
        this.owner = owner;
        this.reporter = reporter;
    }

    public Phase phase() {
        return phase;
    }

    public int[] order() {
        return order;
    }

    public BlockPos origin() {
        return origin;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public int depth() {
        return depth;
    }

    /** Number of positions in the traversal order (the array holds x,y,z triples). */
    private int positionCount() {
        return order == null ? 0 : order.length / 3;
    }

    public BlockPos currentTarget() {
        if (cursor >= positionCount()) return null;
        int index = cursor * 3;
        return origin.add(order[index], order[index + 1], order[index + 2]);
    }

    /** Up to 512 outstanding positions, used by the preview. */
    public List<BlockPos> pendingPositions() {
        List<BlockPos> positions = new ArrayList<>();
        if (order == null) return positions;

        for (int i = cursor; i < positionCount() && positions.size() < 512; i++) {
            int index = i * 3;
            positions.add(origin.add(order[index], order[index + 1], order[index + 2]));
        }
        return positions;
    }

    public Status status() {
        return new Status(phase, positionCount(), attempted, completed, skipped, failed,
                retryPass, etaSeconds(), message);
    }

    /** Prepares a new run over the given volume. */
    public void prepare(
            BlockPos areaOrigin,
            int areaWidth,
            int areaHeight,
            int areaDepth,
            MiningPattern miningPattern,
            int stripWidth,
            int stripGap) {
        this.origin = areaOrigin;
        this.width = areaWidth;
        this.height = areaHeight;
        this.depth = areaDepth;
        this.pattern = miningPattern;
        this.order = AreaGeometry.order(areaWidth, areaHeight, areaDepth, miningPattern, stripWidth, stripGap);

        resetPlan();
    }

    /**
     * Prepares a new run over an explicit list of positions (the auto-target finder's result).
     * The bounding box of the positions becomes the area, so the preview and the 3x3 swing
     * footprint keep working exactly as they do for a rectangular plan.
     */
    public void prepareFromPositions(
            BlockPos areaOrigin,
            int areaWidth,
            int areaHeight,
            int areaDepth,
            List<BlockPos> positions) {
        this.origin = areaOrigin;
        this.width = areaWidth;
        this.height = areaHeight;
        this.depth = areaDepth;
        this.pattern = null;

        this.order = new int[positions.size() * 3];
        for (int i = 0; i < positions.size(); i++) {
            BlockPos pos = positions.get(i);
            int index = i * 3;
            order[index] = pos.getX() - areaOrigin.getX();
            order[index + 1] = pos.getY() - areaOrigin.getY();
            order[index + 2] = pos.getZ() - areaOrigin.getZ();
        }

        resetPlan();
    }

    /** Resets the per-run bookkeeping after a plan (rectangular or found) was put in place. */
    private void resetPlan() {
        this.cursor = 0;
        this.attempted = 0;
        this.completed = 0;
        this.skipped = 0;
        this.failed = 0;
        this.failures.clear();
        this.outcomes = new byte[positionCount()];
        this.attemptedPositions.clear();
        this.pendingSwing.clear();
        this.swingFailed.clear();
        this.retryPass = 0;
        this.delayTicks = 0;
        this.inventoryPaused = false;
        this.startedAtMs = 0;
        this.completedAtStart = 0;
        this.phase = Phase.IDLE;
        this.message = "ready: " + positionCount() + " candidate blocks";
    }

    public void start() {
        if (positionCount() == 0) return;
        phase = Phase.RUNNING;
        startedAtMs = System.currentTimeMillis();
        completedAtStart = completed;
        message = "mining";
        Navigator.get().stop(owner);
    }

    public void pause(String reason) {
        if (phase == Phase.RUNNING) {
            phase = Phase.PAUSED;
            message = "paused: " + reason;
            Navigator.get().stop(owner);
            MiningController.get().reset(owner);
        }
    }

    public void resume() {
        if (phase == Phase.PAUSED) {
            phase = Phase.RUNNING;
            inventoryPaused = false;
            message = "mining";
        }
    }

    /** Aborts the run and forgets all progress. */
    public void reset() {
        phase = Phase.IDLE;
        cursor = 0;
        attempted = 0;
        completed = 0;
        skipped = 0;
        failed = 0;
        failures.clear();
        Arrays.fill(outcomes, (byte) OUT_NONE);
        attemptedPositions.clear();
        pendingSwing.clear();
        swingFailed.clear();
        retryPass = 0;
        delayTicks = 0;
        inventoryPaused = false;
        Navigator.get().stop(owner);
        MiningController.get().reset(owner);
        message = "reset";
    }

    /** Advances one tick. Must be called from a {@code TickEvent.Pre} handler. */
    public Status tick(Options options, Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        if (phase != Phase.RUNNING || order == null) return status();
        if (mc.player == null || mc.world == null) return status();

        if (delayTicks > 0) {
            delayTicks--;
            return status();
        }

        if (options.stopWhenFull() && InvGuards.inventoryFull()) {
            if (!inventoryPaused) {
                inventoryPaused = true;
                pause("your inventory is full");
                if (reporter != null) HookStatus.warn(reporter, "Inventory is full, pausing the area miner.");
            }
            return status();
        }

        // A queued 3x3 swing drains fully before the traversal resumes, so a batch can never
        // overlap the next centre and no position can be queued twice.
        if (!pendingSwing.isEmpty()) {
            tickSwingNeighbor(options, shouldMine, shouldIgnore);
            return status();
        }

        while (cursor < positionCount()) {
            BlockPos pos = currentTarget();
            if (pos == null) break;

            BlockState state = mc.world.getBlockState(pos);
            Block block = state.getBlock();

            if (state.isAir()) {
                // Already gone: this is success, not an attempt.
                markDone(cursor);
                cursor++;
                delayTicks = 0;
                continue;
            }

            if (shouldIgnore.test(block) || !shouldMine.test(block)) {
                markSkipped(cursor);
                cursor++;
                continue;
            }

            if (SafetyChecks.unsafeToMine(pos, options.avoidLava(), options.avoidFluids(),
                    options.avoidFalling())) {
                markFailed(cursor);
                failures.add(cursor);
                cursor++;
                if (reporter != null && failed <= 3) {
                    HookStatus.warn(reporter, "Skipped %s at %s for safety reasons.",
                            block.getName().getString(), format(pos));
                }
                continue;
            }

            if (!MiningController.inReach(pos, options.reach())) {
                if (!options.autoNavigate()) {
                    message = "out of reach: " + format(pos);
                    return status();
                }

                Navigator.State nav = Navigator.get().tick(owner, pos,
                        new Navigator.Options(Math.max(1.5, options.reach() - 0.5), true, true, 80, 3));
                message = "walking to " + format(pos);

                if (nav == Navigator.State.FAILED) {
                    markFailed(cursor);
                    failures.add(cursor);
                    cursor++;
                    Navigator.get().stop(owner);
                    if (reporter != null) {
                        HookStatus.warn(reporter, "Cannot reach %s, skipping it.", format(pos));
                    }
                }
                return status();
            }

            Navigator.get().stop(owner);
            mineOne(pos, state, options, shouldMine, shouldIgnore);
            return status();
        }

        finishRun();
        return status();
    }

    private void mineOne(BlockPos pos, BlockState state, Options options,
            Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        // "attempted" counts positions we actually tried to break, not ticks spent on one block.
        markAttempted(pos);

        MiningController.Result result = MiningController.get().tick(owner, pos, miningControllerOptions(options));

        switch (result) {
            case WORKING -> message = "mining " + format(pos);
            case DONE -> {
                markDone(cursor);
                cursor++;
                delayTicks = Math.max(0, options.delayBetweenBlocks());
                enqueueSwing(pos, options, shouldMine, shouldIgnore);
                message = "mined " + format(pos);
            }
            case OUT_OF_REACH -> message = "reaching " + format(pos);
            case UNSAFE, FAILED, REJECTED -> {
                markFailed(cursor);
                failures.add(cursor);
                cursor++;
                delayTicks = Math.max(0, options.delayBetweenBlocks());
                if (reporter != null && failed <= 3) {
                    HookStatus.warn(reporter, "Could not mine %s (%s).",
                            format(pos), MiningController.describe(result));
                }
                if (result == MiningController.Result.REJECTED) {
                    pause("another module owns mining");
                }
            }
        }
    }

    private static MiningController.Options miningControllerOptions(Options options) {
        return new MiningController.Options(
                options.reach(), options.rotate(), options.swing(), options.autoTool(),
                options.minToolDurability(), options.avoidLava(), options.avoidFluids(),
                options.avoidFalling(), 200, 2);
    }

    /**
     * Queues the eight same-layer neighbours of a mined block for a 3x3 swing. Only blocks inside
     * the planned area are queued, and only when they pass the same filters and safety screens the
     * traversal uses, so the preview bounds stay exact.
     */
    private void enqueueSwing(BlockPos center, Options options,
            Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        if (options.pickaxe() != PickaxeWidth.THREE) return;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;

                BlockPos neighbour = center.add(dx, 0, dz);
                int index = volumeIndex(neighbour);
                if (index < 0 || swingFailed.get(index)) continue;

                BlockState state = mc.world.getBlockState(neighbour);
                if (state.isAir()) continue;

                Block block = state.getBlock();
                if (shouldIgnore.test(block) || !shouldMine.test(block)) continue;
                if (SafetyChecks.unsafeToMine(neighbour, options.avoidLava(), options.avoidFluids(),
                        options.avoidFalling())) continue;

                pendingSwing.addLast(neighbour);
            }
        }
    }

    /**
     * Drains one queued swing neighbour. Positions that are also part of the traversal are counted
     * when the cursor reaches them, so this method never touches the outcome counters; it attempts
     * the break and drops the position when it no longer qualifies.
     */
    private void tickSwingNeighbor(Options options, Predicate<Block> shouldMine, Predicate<Block> shouldIgnore) {
        BlockPos pos = pendingSwing.peekFirst();
        BlockState state = mc.world.getBlockState(pos);
        Block block = state.getBlock();

        if (state.isAir() || shouldIgnore.test(block) || !shouldMine.test(block)) {
            pendingSwing.pollFirst();
            return;
        }

        if (SafetyChecks.unsafeToMine(pos, options.avoidLava(), options.avoidFluids(),
                options.avoidFalling())) {
            int index = volumeIndex(pos);
            if (index >= 0) swingFailed.set(index);
            pendingSwing.pollFirst();
            return;
        }

        if (!MiningController.inReach(pos, options.reach())) {
            if (!options.autoNavigate()) {
                // The traversal itself will handle any position that is on the plan.
                pendingSwing.pollFirst();
                return;
            }

            Navigator.State nav = Navigator.get().tick(owner, pos,
                    new Navigator.Options(Math.max(1.5, options.reach() - 0.5), true, true, 80, 3));
            message = "walking to " + format(pos);

            if (nav == Navigator.State.FAILED) {
                pendingSwing.pollFirst();
                Navigator.get().stop(owner);
            }
            return;
        }

        Navigator.get().stop(owner);
        markAttempted(pos);

        MiningController.Result result = MiningController.get().tick(owner, pos, miningControllerOptions(options));
        switch (result) {
            case WORKING -> message = "mining " + format(pos);
            case DONE -> {
                pendingSwing.pollFirst();
                delayTicks = Math.max(0, options.delayBetweenBlocks());
                message = "mined " + format(pos);
            }
            case OUT_OF_REACH -> pendingSwing.pollFirst();
            case UNSAFE, FAILED, REJECTED -> {
                int index = volumeIndex(pos);
                if (index >= 0) swingFailed.set(index);
                pendingSwing.pollFirst();
                delayTicks = Math.max(0, options.delayBetweenBlocks());
                if (result == MiningController.Result.REJECTED) pause("another module owns mining");
            }
        }
    }

    /** Plan-relative index of a position, or {@code -1} when it lies outside the area. */
    private int volumeIndex(BlockPos pos) {
        int x = pos.getX() - origin.getX();
        int y = pos.getY() - origin.getY();
        int z = pos.getZ() - origin.getZ();
        if (x < 0 || x >= width || y < 0 || y >= height || z < 0 || z >= depth) return -1;
        return ((y * depth) + z) * width + x;
    }

    /**
     * "Attempted" counts positions we actually tried to break, not ticks spent on one block. The
     * key is the position itself, so a block reached by both a swing batch and the traversal is
     * only counted once.
     */
    private void markAttempted(BlockPos pos) {
        int index = volumeIndex(pos);
        if (index < 0 || attemptedPositions.get(index)) return;
        attemptedPositions.set(index);
        attempted++;
    }

    /** Called when the main pass is done; starts a retry pass when there are failures left. */
    private void finishRun() {
        if (!failures.isEmpty() && retryPass < maxRetries) {
            retryPass++;
            Integer first = failures.poll();
            failures.clear();
            cursor = first == null ? positionCount() : Math.max(0, first);
            message = "retry pass " + retryPass;
            if (reporter != null) {
                HookStatus.info(reporter, "Starting retry pass %d for blocks that failed before.", retryPass);
            }
            return;
        }

        phase = Phase.COMPLETE;
        Navigator.get().stop(owner);
        MiningController.get().reset(owner);

        String summary = "Area mining finished: " + completed + " mined, " + skipped + " skipped, "
                + failed + " failed out of " + positionCount();
        message = summary;
        if (reporter != null) HookStatus.progressNow(reporter, "area-miner", "%s", summary);
    }

    private int maxRetries = 1;

    // Outcome bookkeeping ---------------------------------------------------------------------

    /**
     * Records the outcome of one position. A retry pass revisits positions, so these helpers keep
     * the counters as a snapshot of unique positions instead of incrementing again on every pass.
     */
    private void markDone(int index) {
        byte previous = outcomes[index];
        if (previous == OUT_DONE) return;
        if (previous == OUT_FAILED) failed--;
        else if (previous == OUT_SKIPPED) skipped--;
        outcomes[index] = OUT_DONE;
        completed++;
    }

    private void markSkipped(int index) {
        byte previous = outcomes[index];
        if (previous == OUT_SKIPPED) return;
        if (previous == OUT_DONE) completed--;
        else if (previous == OUT_FAILED) failed--;
        outcomes[index] = OUT_SKIPPED;
        skipped++;
    }

    private void markFailed(int index) {
        byte previous = outcomes[index];
        if (previous == OUT_FAILED) return;
        if (previous == OUT_DONE) completed--;
        else if (previous == OUT_SKIPPED) skipped--;
        outcomes[index] = OUT_FAILED;
        failed++;
    }


    /** Set by the module before a run starts. */
    public void setMaxRetries(int retries) {
        this.maxRetries = Math.max(0, retries);
    }

    private double etaSeconds() {
        if (phase != Phase.RUNNING || startedAtMs == 0) return -1;

        long elapsed = System.currentTimeMillis() - startedAtMs;
        int doneNow = completed;
        int delta = doneNow - (int) completedAtStart;
        if (elapsed < 5000 || delta <= 0) return -1;

        double perSecond = delta / (elapsed / 1000.0);
        if (perSecond <= 0.001) return -1;

        int remaining = positionCount() - cursor;
        return remaining / perSecond;
    }

    private static String format(BlockPos pos) {
        return "(" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ")";
    }

    /** Releases everything the engine holds. */
    public void shutdown() {
        Navigator.get().stop(owner);
        MiningController.get().reset(owner);
        TaskManager.get().release(owner);
    }

    /** Compact status for the ClickGUI. */
    public String describe() {
        if (order == null) return "no area";
        return completed + "/" + positionCount() + " mined, " + skipped + " skipped, " + failed + " failed";
    }

    public boolean isInventoryPaused() {
        return inventoryPaused;
    }
}
