package com.hookaddon.mining;

/**
 * How the area miner picks what to mine.
 *
 * <p>The three modes are mutually exclusive and drive which settings are shown and which planning
 * path runs each tick.
 */
public enum MiningMode {
    /** Mine a fixed rectangular volume defined by the area settings. */
    AREA("Fixed area"),

    /** Use the block finder to locate targets in the loaded chunks around the player. */
    FINDER("Auto target"),

    /**
     * Directional face bore (the 3x3 pickaxe): mine a small cross-section that faces the player and
     * advance it straight ahead, so the miner eats a tunnel forward in the looked-at direction.
     */
    BORE("3x3 bore");

    public final String title;

    MiningMode(String title) {
        this.title = title;
    }
}
