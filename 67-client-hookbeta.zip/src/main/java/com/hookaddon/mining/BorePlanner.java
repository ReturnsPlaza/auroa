package com.hookaddon.mining;

/**
 * Builds the traversal order of a directional "face bore" — the 3x3 pickaxe behaviour.
 *
 * <p>Instead of a fixed rectangular volume, a bore mines a {@code width x height} cross-section
 * that faces the player and then advances one slice at a time straight ahead, so the miner eats a
 * tunnel forward in whatever direction the player looks. This mirrors the technique used by
 * dedicated auto-mine clients: a fixed face perpendicular to the travel axis, walked
 * {@code travel -> layer -> row -> cell}, with the rows of each layer serpentine so the sweep does
 * not jump side to side between layers.
 *
 * <p>Like {@link AreaGeometry} this is pure arithmetic on ints so it can be unit tested without a
 * Minecraft runtime. Positions are returned as {@code forward, cross, up} triples relative to the
 * player's feet:
 *
 * <ul>
 *   <li>{@code forward} — blocks along the travel direction, starting one block ahead of the
 *       player and increasing by one per slice ({@code sign * (1 + slice)});</li>
 *   <li>{@code cross} — offset along the horizontal axis perpendicular to travel, centred on the
 *       player;</li>
 *   <li>{@code up} — vertical offset from the player's feet, shifted by {@code yOffset}.</li>
 * </ul>
 *
 * <p>The caller maps {@code forward}/{@code cross} onto the concrete world axes using the resolved
 * travel axis, so this class stays free of world-axis knowledge and fully testable.
 */
public final class BorePlanner {
    private BorePlanner() {}

    /**
     * @param width face size across the horizontal axis perpendicular to travel
     * @param height face size along Y
     * @param depth number of slices to advance forward
     * @param sign direction of travel along its axis ({@code +1} or {@code -1})
     * @param yOffset vertical shift of the face relative to the player's feet
     * @return flat array of {@code forward, cross, up} triples, nearest slice first
     * @throws IllegalArgumentException when a dimension is not positive or the sign is zero
     */
    public static int[] plan(int width, int height, int depth, int sign, int yOffset) {
        if (width <= 0 || height <= 0 || depth <= 0) {
            throw new IllegalArgumentException("bore dimensions must be positive");
        }
        if (sign == 0) throw new IllegalArgumentException("travel sign must be non-zero");

        int[] order = new int[width * height * depth * 3];
        int index = 0;
        int half = (width - 1) / 2;

        for (int slice = 0; slice < depth; slice++) {
            int forward = sign * (1 + slice);

            for (int layer = 0; layer < height; layer++) {
                int up = yOffset + layer;
                boolean reverse = (layer & 1) == 1;

                for (int cell = 0; cell < width; cell++) {
                    int cross = reverse ? (width - 1 - cell) - half : cell - half;

                    order[index++] = forward;
                    order[index++] = cross;
                    order[index++] = up;
                }
            }
        }

        return order;
    }

    /** Number of blocks a bore visits, without building the array. */
    public static int count(int width, int height, int depth) {
        if (width <= 0 || height <= 0 || depth <= 0) return 0;
        return width * height * depth;
    }
}
