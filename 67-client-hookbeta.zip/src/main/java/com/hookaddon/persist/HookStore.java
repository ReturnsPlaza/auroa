package com.hookaddon.persist;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.hookaddon.HookAddon;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Local JSON configuration store for the data Meteor's settings system does not cover: schematic
 * build state (for resuming a build after a disconnect), mining presets and the spawner search
 * bookkeeping.
 *
 * <p>Everything lives under {@code config/hook-addon/}. A file that cannot be parsed is moved aside
 * as {@code *.corrupt} and replaced with defaults, so a broken file never stops the addon from
 * loading.
 */
public final class HookStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private HookStore() {}

    // Files ---------------------------------------------------------------------------------

    public static Path configDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("hook-addon");
    }

    public static Path schematicsDir() {
        return configDir().resolve("schematics");
    }

    private static Path buildStateFile() {
        return configDir().resolve("build-state.json");
    }

    private static Path presetsFile() {
        return configDir().resolve("mining-presets.json");
    }

    private static Path spawnerFile() {
        return configDir().resolve("spawner-state.json");
    }

    /** Creates the config and schematics folders if they do not exist yet. */
    public static void ensureDirectories() {
        try {
            Files.createDirectories(schematicsDir());
        } catch (IOException e) {
            HookAddon.LOG.warn("Could not create the Hook Addon config folder: {}", e.getMessage());
        }
    }

    // Build state ---------------------------------------------------------------------------

    /** State of an in-progress schematic build, enough to resume it after a restart. */
    public static final class BuildState {
        public String schematicFile;
        /** Built-in blueprint name; when set, {@link #schematicFile} is ignored. */
        public String blueprint;
        /** Block id the blueprint was built from. */
        public String blueprintMaterial;
        public String anchor;
        public int originX;
        public int originY;
        public int originZ;
        public String mirror;
        public String rotation;
        public long savedAt;
        public String dimension;
    }

    public static BuildState loadBuildState() {
        return read(buildStateFile(), BuildState.class, BuildState::new);
    }

    public static void saveBuildState(BuildState state) {
        write(buildStateFile(), state);
    }

    public static void clearBuildState() {
        delete(buildStateFile());
    }

    // Mining presets ------------------------------------------------------------------------

    /** A saved area miner configuration. */
    public static final class MiningPreset {
        public String name;
        public int originX;
        public int originY;
        public int originZ;
        public int width;
        public int height;
        public int depth;
        public String pattern;
        public List<String> mineBlocks = new ArrayList<>();
        public List<String> ignoreBlocks = new ArrayList<>();
        public long savedAt;
    }

    public static List<MiningPreset> loadPresets() {
        MiningPresetFile file = read(presetsFile(), MiningPresetFile.class, MiningPresetFile::new);
        return file.presets == null ? new ArrayList<>() : new ArrayList<>(file.presets);
    }

    public static void savePresets(List<MiningPreset> presets) {
        MiningPresetFile file = new MiningPresetFile();
        file.presets = presets;
        write(presetsFile(), file);
    }

    private static final class MiningPresetFile {
        List<MiningPreset> presets = new ArrayList<>();
    }

    // Spawner search ------------------------------------------------------------------------

    /** Bookkeeping of the spawner search so repeated searches skip positions already scanned. */
    public static final class SpawnerState {
        public String dimension;
        public List<Long> visited = new ArrayList<>();
        public int rtpAttempts;
        public long lastRtpAt;
        public String lastStatus;
    }

    public static SpawnerState loadSpawnerState() {
        return read(spawnerFile(), SpawnerState.class, SpawnerState::new);
    }

    public static void saveSpawnerState(SpawnerState state) {
        if (state.visited != null && state.visited.size() > 40000) {
            state.visited = new ArrayList<>(state.visited.subList(state.visited.size() - 40000, state.visited.size()));
        }
        write(spawnerFile(), state);
    }

    // Plumbing ------------------------------------------------------------------------------

    private static <T> T read(Path file, Class<T> type, java.util.function.Supplier<T> defaults) {
        if (!Files.isRegularFile(file)) return defaults.get();

        try {
            String json = Files.readString(file, StandardCharsets.UTF_8);
            T value = GSON.fromJson(json, type);
            return value == null ? defaults.get() : value;
        } catch (JsonParseException | IOException e) {
            HookAddon.LOG.warn("Could not read {}, starting from defaults: {}", file.getFileName(), e.getMessage());
            quarantine(file);
            return defaults.get();
        }
    }

    private static void write(Path file, Object value) {
        try {
            Files.createDirectories(file.getParent());
            Path temp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(value), StandardCharsets.UTF_8);
            Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            HookAddon.LOG.warn("Could not write {}: {}", file.getFileName(), e.getMessage());
        }
    }

    private static void delete(Path file) {
        try {
            Files.deleteIfExists(file);
        } catch (IOException e) {
            HookAddon.LOG.warn("Could not delete {}: {}", file.getFileName(), e.getMessage());
        }
    }

    /** Moves an unreadable file aside instead of overwriting it, so nothing is lost. */
    private static void quarantine(Path file) {
        try {
            Path target = file.resolveSibling(file.getFileName() + ".corrupt");
            Files.move(file, target, StandardCopyOption.REPLACE_EXISTING);
            HookAddon.LOG.warn("Kept the unreadable file as {}", target.getFileName());
        } catch (IOException e) {
            HookAddon.LOG.warn("Could not move the unreadable file aside: {}", e.getMessage());
        }
    }
}
