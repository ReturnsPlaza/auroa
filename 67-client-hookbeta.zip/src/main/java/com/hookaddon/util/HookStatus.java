package com.hookaddon.util;

import java.util.LinkedHashMap;
import java.util.Map;
import meteordevelopment.meteorclient.systems.modules.Module;

/**
 * One place for every status message the addon prints.
 *
 * <p>Meteor renders {@link Module#info}, {@link Module#warning} and {@link Module#error} as chat
 * messages prefixed with the module name in the addon colour, which is exactly the "clear errors
 * and status messages" behaviour the addon needs. Progress lines are rate limited so a fast
 * placement loop cannot flood the chat.
 */
public final class HookStatus {
    private static final long PROGRESS_INTERVAL_MS = 2000;
    private static final Map<String, Long> lastProgress = new LinkedHashMap<>();

    private HookStatus() {}

    public static void info(Module module, String message, Object... args) {
        module.info(message, args);
    }

    public static void warn(Module module, String message, Object... args) {
        module.warning(message, args);
    }

    public static void error(Module module, String message, Object... args) {
        module.error(message, args);
    }

    /** Prints a progress line at most once every {@link #PROGRESS_INTERVAL_MS} per key. */
    public static void progress(Module module, String key, String message, Object... args) {
        long now = System.currentTimeMillis();
        Long previous = lastProgress.get(key);
        if (previous != null && now - previous < PROGRESS_INTERVAL_MS) return;
        lastProgress.put(key, now);
        module.info(message, args);
    }

    /** Prints a progress line even if the interval has not elapsed yet. */
    public static void progressNow(Module module, String key, String message, Object... args) {
        lastProgress.put(key, System.currentTimeMillis());
        module.info(message, args);
    }

    /** Forgets rate-limit state, called when a task restarts. */
    public static void reset(String key) {
        lastProgress.remove(key);
    }

    public static void resetAll() {
        lastProgress.clear();
    }
}
