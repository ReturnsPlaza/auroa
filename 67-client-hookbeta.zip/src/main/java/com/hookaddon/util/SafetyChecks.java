package com.hookaddon.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * Safety checks used by the mining and placement engines before they touch a block.
 *
 * <p>They are deliberately conservative: every method answers "is this block risky to break or to
 * stand next to" from world data that is genuinely available on the client.
 */
public final class SafetyChecks {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private SafetyChecks() {}

    /** True when lava touches any of the six sides or the block below {@code pos}. */
    public static boolean nearLava(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;

        for (Direction direction : Direction.values()) {
            BlockState state = world.getBlockState(pos.offset(direction));
            if (state.getFluidState().isOf(Fluids.LAVA) || state.getFluidState().isOf(Fluids.FLOWING_LAVA)) {
                return true;
            }
        }
        return false;
    }

    /** True when any neighbouring block contains a fluid (water or lava). */
    public static boolean nearFluid(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;

        for (Direction direction : Direction.values()) {
            BlockState state = world.getBlockState(pos.offset(direction));
            if (!state.getFluidState().isEmpty()) return true;
        }
        return false;
    }

    /** True when breaking {@code pos} would release a gravity block such as sand or gravel. */
    public static boolean wouldReleaseFallingBlock(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;
        return world.getBlockState(pos.up()).getBlock() instanceof FallingBlock;
    }

    /** True when the player is standing in or next to lava. */
    public static boolean playerInDanger() {
        if (mc.player == null) return false;
        if (mc.player.isInLava()) return true;
        return nearLava(mc.player.getBlockPos());
    }

    /**
     * Combined "should we refuse to mine here" check driven by the module safety settings.
     *
     * @param avoidLava skip blocks touching lava
     * @param avoidFluids skip blocks touching any fluid
     * @param avoidFalling skip blocks with a gravity block above
     */
    public static boolean unsafeToMine(BlockPos pos, boolean avoidLava, boolean avoidFluids, boolean avoidFalling) {
        if (avoidLava && nearLava(pos)) return true;
        if (avoidFluids && nearFluid(pos)) return true;
        return avoidFalling && wouldReleaseFallingBlock(pos);
    }

    /** Cheap screen used before walking into an area: is the destination itself on fire/lava. */
    public static String describe(BlockPos pos) {
        if (nearLava(pos)) return "lava";
        if (wouldReleaseFallingBlock(pos)) return "falling block above";
        if (nearFluid(pos)) return "fluid";
        return null;
    }
}
