package com.hookaddon.util;

import java.util.function.Predicate;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.client.MinecraftClient;

/**
 * Inventory guards shared by the three automation modules.
 *
 * <p>All checks answer a question the engines need before they act: is there room for the drops,
 * do we have the material, and is there a usable tool left.
 */
public final class InvGuards {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private InvGuards() {}

    /** Number of empty slots in the main inventory (armor and offhand excluded). */
    public static int emptySlots() {
        if (mc.player == null) return 0;
        var inventory = mc.player.getInventory();
        int empty = 0;
        for (int i = 0; i < PlayerInventory.MAIN_SIZE; i++) {
            if (inventory.getStack(i).isEmpty()) empty++;
        }
        return empty;
    }

    public static boolean inventoryFull() {
        return emptySlots() == 0;
    }

    /** Total item count across the main inventory matching {@code filter}. */
    public static int count(Predicate<ItemStack> filter) {
        if (mc.player == null) return 0;
        var inventory = mc.player.getInventory();
        int total = 0;
        for (int i = 0; i < PlayerInventory.MAIN_SIZE; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && filter.test(stack)) total += stack.getCount();
        }
        return total;
    }

    /** Remaining durability of a stack, or {@link Integer#MAX_VALUE} for unbreakable items. */
    public static int durabilityLeft(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isDamageable()) return Integer.MAX_VALUE;
        return stack.getMaxDamage() - stack.getDamage();
    }

    /** True when the item can still be used without breaking: {@code minDurability} is the floor. */
    public static boolean durableEnough(ItemStack stack, int minDurability) {
        if (stack == null || stack.isEmpty()) return false;
        return durabilityLeft(stack) > Math.max(0, minDurability);
    }

    /**
     * Picks the fastest tool for {@code state} if it is in the hotbar and has durability left.
     *
     * @return empty result when no usable tool was found
     */
    public static FindItemResult bestTool(BlockState state, int minDurability) {
        FindItemResult result = InvUtils.findFastestTool(state);
        if (!result.found() || !result.isHotbar()) return result;
        if (!durableEnough(mc.player.getInventory().getStack(result.slot()), minDurability)) {
            return new FindItemResult(-1, 0);
        }
        return result;
    }

    /**
     * Swaps the best tool into the main hand when it is not already there.
     *
     * @return true when the main hand now holds a usable tool
     */
    public static boolean selectBestTool(BlockState state, int minDurability) {
        if (mc.player == null || mc.interactionManager == null) return false;

        FindItemResult best = bestTool(state, minDurability);
        if (!best.found() || !best.isHotbar()) {
            // Nothing better than what we already hold, keep the current item if it is usable.
            return durableEnough(mc.player.getMainHandStack(), minDurability);
        }

        ItemStack current = mc.player.getInventory().getStack(mc.player.getInventory().getSelectedSlot());
        if (InvUtils.findFastestTool(state).found()
                && !current.isEmpty()
                && current.getItem() == mc.player.getInventory().getStack(best.slot()).getItem()
                && best.slot() == mc.player.getInventory().getSelectedSlot()) {
            return true;
        }

        return InvUtils.swap(best.slot(), false);
    }

    /** True when the inventory holds an item that places {@code block}. */
    public static boolean hasBlockItem(net.minecraft.block.Block block) {
        return findBlockItem(block).found();
    }

    /** Hotbar/inventory lookup for the item that places {@code block}. */
    public static FindItemResult findBlockItem(net.minecraft.block.Block block) {
        net.minecraft.item.Item item = net.minecraft.item.Item.fromBlock(block);
        if (item == null) return new FindItemResult(-1, 0);
        return InvUtils.find(stack -> stack.isOf(item));
    }

    /** Count of the item placing {@code block} anywhere in the inventory. */
    public static int countForBlock(net.minecraft.block.Block block) {
        net.minecraft.item.Item item = net.minecraft.item.Item.fromBlock(block);
        if (item == null) return 0;
        return count(stack -> stack.isOf(item));
    }
}
