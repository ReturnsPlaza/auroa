package com.hookaddon.schematic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/**
 * Turns a parsed schematic into the concrete blocks the world should end up with.
 *
 * <p>Positions are transformed with {@link TransformMath} (mirror, then rotate) and then anchored,
 * which is the same order the Litematica reference implementation uses. The result is a sorted list
 * of world positions with their expected block state, ordered bottom up and outward from the
 * anchor so a build grows from where the player stands.
 */
public final class PlacementPlanner {
    /** Where the schematic is anchored in the world. */
    public enum Anchor {
        /** Exactly the configured origin position. */
        POSITION("At origin position"),
        /** The player's feet. */
        PLAYER("At my position"),
        /** Horizontally centred on the player, floor at the player's feet. */
        CENTER_ON_PLAYER("Centred on me");

        public final String title;

        Anchor(String title) {
            this.title = title;
        }
    }

    /** One block the finished build should contain. */
    public record Target(BlockPos pos, BlockState expected) {}

    /** The resolved build plan. */
    public record Plan(
            BlockPos origin,
            TransformMath.Mirror mirror,
            TransformMath.Rotation rotation,
            int sizeX,
            int sizeY,
            int sizeZ,
            List<Target> targets,
            Map<Block, Integer> required) {
        public int volume() {
            return sizeX * sizeY * sizeZ;
        }
    }

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private PlacementPlanner() {}

    /** Builds the plan for the current settings and player position. */
    public static Plan build(
            Schematic schematic,
            TransformMath.Mirror mirror,
            TransformMath.Rotation rotation,
            Anchor anchor,
            BlockPos originSetting) {
        List<Schematic.Entry> entries = schematic.entries();

        if (entries.isEmpty()) {
            return new Plan(originSetting, mirror, rotation, 0, 0, 0, List.of(), Map.of());
        }

        int[] transformedX = new int[entries.size()];
        int[] transformedY = new int[entries.size()];
        int[] transformedZ = new int[entries.size()];

        int minTieX = Integer.MAX_VALUE;
        int minTieY = Integer.MAX_VALUE;
        int minTieZ = Integer.MAX_VALUE;
        int maxTieX = Integer.MIN_VALUE;
        int maxTieY = Integer.MIN_VALUE;
        int maxTieZ = Integer.MIN_VALUE;

        for (int i = 0; i < entries.size(); i++) {
            Schematic.Entry entry = entries.get(i);
            int[] t = TransformMath.transform(entry.x(), entry.y(), entry.z(), mirror, rotation);
            transformedX[i] = t[0];
            transformedY[i] = t[1];
            transformedZ[i] = t[2];

            minTieX = Math.min(minTieX, t[0]);
            minTieY = Math.min(minTieY, t[1]);
            minTieZ = Math.min(minTieZ, t[2]);
            maxTieX = Math.max(maxTieX, t[0]);
            maxTieY = Math.max(maxTieY, t[1]);
            maxTieZ = Math.max(maxTieZ, t[2]);
        }

        int sizeX = maxTieX - minTieX + 1;
        int sizeY = maxTieY - minTieY + 1;
        int sizeZ = maxTieZ - minTieZ + 1;

        BlockPos anchorPoint = switch (anchor) {
            case POSITION -> originSetting;
            case PLAYER, CENTER_ON_PLAYER -> mc.player == null ? originSetting : mc.player.getBlockPos();
        };

        int offsetX = anchorPoint.getX() - minTieX;
        int offsetY = anchorPoint.getY() - minTieY;
        int offsetZ = anchorPoint.getZ() - minTieZ;

        if (anchor == Anchor.CENTER_ON_PLAYER) {
            offsetX -= sizeX / 2;
            offsetZ -= sizeZ / 2;
        }

        BlockPos origin = new BlockPos(offsetX, offsetY, offsetZ);

        Map<Block, Integer> required = new HashMap<>();
        List<Target> targets = new ArrayList<>(entries.size());

        for (int i = 0; i < entries.size(); i++) {
            Schematic.Entry entry = entries.get(i);
            BlockPos world = new BlockPos(
                    transformedX[i] + offsetX, transformedY[i] + offsetY, transformedZ[i] + offsetZ);
            targets.add(new Target(world, entry.state()));
            required.merge(entry.state().getBlock(), 1, Integer::sum);
        }

        // Bottom up first, then outward from the anchor: keeps blocks reachable and avoids building
        // a ceiling before the floor exists.
        int anchorX = anchorPoint.getX();
        int anchorZ = anchorPoint.getZ();
        targets.sort(Comparator
                .comparingInt((Target target) -> target.pos().getY())
                .thenComparingInt(target -> horizontalDistanceSq(target.pos(), anchorX, anchorZ)));

        return new Plan(origin, mirror, rotation, sizeX, sizeY, sizeZ, targets, required);
    }

    private static int horizontalDistanceSq(BlockPos pos, int anchorX, int anchorZ) {
        int dx = pos.getX() - anchorX;
        int dz = pos.getZ() - anchorZ;
        return dx * dx + dz * dz;
    }

    /** Blocks whose required count is not covered by the inventory counts. */
    public static Map<Block, Integer> missingMaterials(Plan plan, Map<Block, Integer> available) {
        Map<Block, Integer> missing = new HashMap<>();
        for (Map.Entry<Block, Integer> entry : plan.required().entrySet()) {
            int have = available.getOrDefault(entry.getKey(), 0);
            if (have < entry.getValue()) missing.put(entry.getKey(), entry.getValue() - have);
        }
        return missing;
    }
}
