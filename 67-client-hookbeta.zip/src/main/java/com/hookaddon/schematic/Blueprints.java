package com.hookaddon.schematic;

import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

/**
 * Built-in shapes the Auto Schematic Builder can place without a schematic file.
 *
 * <p>Each blueprint is produced as a regular in-memory {@link Schematic}, so planning, transforms,
 * anchoring, verification and the placement loop are exactly the same as for a parsed file: the
 * blueprint only decides which cells start out non-air.
 */
public final class Blueprints {
    /** Available shapes; {@code NONE} means "use the schematic file setting". */
    public enum Blueprint {
        NONE("None"),
        FLAT_PLATFORM_5X5("Flat Platform 5x5"),
        WALL_9X3("Wall 9x3"),
        TOWER_3X3X8("Tower 3x3x8"),
        STAIRCASE_7X3("Staircase 7x3");

        public final String title;

        Blueprint(String title) {
            this.title = title;
        }
    }

    /** Matches a user supplied name against a blueprint title or constant name. */
    public static Blueprint find(String name) {
        if (name == null || name.isBlank()) return Blueprint.NONE;

        String needle = name.trim().toLowerCase().replace(' ', '_').replace('-', '_');
        for (Blueprint blueprint : Blueprint.values()) {
            if (blueprint.name().toLowerCase().equals(needle)) return blueprint;
        }
        for (Blueprint blueprint : Blueprint.values()) {
            if (blueprint.title.toLowerCase().replace(' ', '_').equals(needle)) return blueprint;
        }
        return Blueprint.NONE;
    }

    /**
     * Builds the schematic for a blueprint.
     *
     * @param blueprint shape to build, {@link Blueprint#NONE} has no geometry
     * @param material block every non-air cell of the shape uses
     * @throws IllegalArgumentException when {@code blueprint} is {@link Blueprint#NONE}
     */
    public static Schematic build(Blueprint blueprint, Block material) {
        if (blueprint == null || blueprint == Blueprint.NONE) {
            throw new IllegalArgumentException("No blueprint selected");
        }

        BlockState state = (material == null ? Blocks.COBBLESTONE : material).getDefaultState();
        BlockState air = Blocks.AIR.getDefaultState();

        return switch (blueprint) {
            case FLAT_PLATFORM_5X5 -> of(blueprint.title, 5, 1, 5, (x, y, z) -> true, state, air);
            case WALL_9X3 -> of(blueprint.title, 9, 3, 1, (x, y, z) -> true, state, air);
            case TOWER_3X3X8 -> of(blueprint.title, 3, 8, 3, (x, y, z) -> true, state, air);
            // One block per step: seven steps climbing one block each, three blocks wide, which
            // gives the 7x7x3 outline with 21 blocks of work.
            case STAIRCASE_7X3 -> of(blueprint.title, 7, 7, 3, (x, y, z) -> y == x, state, air);
            default -> throw new IllegalArgumentException("No geometry for " + blueprint.title);
        };
    }

    @FunctionalInterface
    private interface CellFilter {
        boolean allows(int x, int y, int z);
    }

    private static Schematic of(String title, int sizeX, int sizeY, int sizeZ,
            CellFilter filter, BlockState state, BlockState air) {
        BlockState[] states = new BlockState[sizeX * sizeY * sizeZ];

        for (int y = 0; y < sizeY; y++) {
            for (int z = 0; z < sizeZ; z++) {
                for (int x = 0; x < sizeX; x++) {
                    // Same layout both supported file formats use: x fastest, then z, then y.
                    states[x + z * sizeX + y * sizeX * sizeZ] = filter.allows(x, y, z) ? state : air;
                }
            }
        }

        Schematic.Region region = new Schematic.Region(title, 0, 0, 0, sizeX, sizeY, sizeZ, states);
        return new Schematic(title, "blueprint", "", 0, Map.of(), List.of(region));
    }
}