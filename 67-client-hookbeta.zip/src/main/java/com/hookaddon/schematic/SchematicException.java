package com.hookaddon.schematic;

/**
 * Thrown when a schematic file cannot be parsed.
 *
 * <p>Every message is written for the end user: it names the file and says what was wrong instead
 * of surfacing a stack trace in chat.
 */
public class SchematicException extends Exception {
    public SchematicException(String message) {
        super(message);
    }

    public SchematicException(String message, Throwable cause) {
        super(message, cause);
    }
}
