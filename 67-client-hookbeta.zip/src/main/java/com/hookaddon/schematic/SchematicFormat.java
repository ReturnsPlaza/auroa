package com.hookaddon.schematic;

import java.io.IOException;
import java.nio.file.Path;

/**
 * A reader for one schematic file format.
 *
 * <p>The placement engine only ever sees the returned {@link Schematic}; adding another format
 * means implementing this interface and registering it in {@link SchematicFormats}, no placement
 * code has to change.
 */
public interface SchematicFormat {
    /** Stable id used in settings and status messages, e.g. {@code litematic}. */
    String id();

    /** Human readable name shown in the UI. */
    String title();

    /** True when this format can read the given file name (extension based). */
    boolean supports(String fileName);

    /** Parses the file, throwing {@link SchematicException} with a user readable message. */
    Schematic load(Path file) throws SchematicException, IOException;
}
