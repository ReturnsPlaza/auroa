package com.hookaddon.schematic;

/**
 * Coordinate transforms for mirror and rotation, kept free of Minecraft classes.
 *
 * <p>The arithmetic mirrors the reference implementation in Litematica
 * ({@code PositionUtils.getTransformedBlockPos}): a position is mirrored first and then rotated,
 * both around the schematic origin.
 *
 * <p>Own enums instead of Minecraft's {@code BlockRotation}/{@code BlockMirror} so the math can be
 * unit tested on a plain JVM; {@code PlacementPlanner} converts them at the Minecraft boundary.
 */
public final class TransformMath {
    public enum Rotation {
        NONE("None"),
        CLOCKWISE_90("90° right"),
        CLOCKWISE_180("180°"),
        COUNTERCLOCKWISE_90("90° left");

        public final String title;

        Rotation(String title) {
            this.title = title;
        }
    }

    public enum Mirror {
        NONE("None"),
        /** Mirrors along the north/south axis (z becomes -z). */
        LEFT_RIGHT("Front to back"),
        /** Mirrors along the east/west axis (x becomes -x). */
        FRONT_BACK("Left to right");

        public final String title;

        Mirror(String title) {
            this.title = title;
        }
    }

    private TransformMath() {}

    /** Mirrors then rotates a position that is relative to the schematic origin. */
    public static int[] transform(int x, int y, int z, Mirror mirror, Rotation rotation) {
        boolean mirrored = mirror != Mirror.NONE;
        switch (mirror) {
            case LEFT_RIGHT -> z = -z;
            case FRONT_BACK -> x = -x;
            default -> mirrored = false;
        }

        return switch (rotation) {
            case CLOCKWISE_90 -> new int[] {-z, y, x};
            case COUNTERCLOCKWISE_90 -> new int[] {z, y, -x};
            case CLOCKWISE_180 -> new int[] {-x, y, -z};
            default -> new int[] {x, y, z};
        };
    }

    /** True when the transform can change the sign of a coordinate, i.e. the bounds must shift. */
    public static boolean changesBounds(Mirror mirror, Rotation rotation) {
        return mirror != Mirror.NONE || rotation != Rotation.NONE;
    }

    /**
     * Transforms the inclusive bounding box and returns the axis aligned bounds of the result as
     * {@code {minX, minY, minZ, maxX, maxY, maxZ}} where max is exclusive.
     */
    public static int[] transformedBounds(int sizeX, int sizeY, int sizeZ, Mirror mirror, Rotation rotation) {
        if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0) return new int[] {0, 0, 0, 0, 0, 0};

        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;

        // Inclusive corners only: mirroring and rotation invert which side becomes the minimum.
        for (int corner = 0; corner < 8; corner++) {
            int x = (corner & 1) == 0 ? 0 : sizeX - 1;
            int y = (corner & 2) == 0 ? 0 : sizeY - 1;
            int z = (corner & 4) == 0 ? 0 : sizeZ - 1;

            int[] t = transform(x, y, z, mirror, rotation);
            minX = Math.min(minX, t[0]);
            minY = Math.min(minY, t[1]);
            minZ = Math.min(minZ, t[2]);
            maxX = Math.max(maxX, t[0]);
            maxY = Math.max(maxY, t[1]);
            maxZ = Math.max(maxZ, t[2]);
        }

        // The corner positions are inclusive; add one to make max exclusive.
        return new int[] {minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1};
    }

    /** Relative position of a world position inside a build area with the given origin. */
    public static int[] toWorldRelative(int x, int y, int z, int originX, int originY, int originZ) {
        return new int[] {x + originX, y + originY, z + originZ};
    }
}
