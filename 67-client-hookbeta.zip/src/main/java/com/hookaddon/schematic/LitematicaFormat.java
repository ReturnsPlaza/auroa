package com.hookaddon.schematic;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIntArray;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtLongArray;
import net.minecraft.nbt.NbtSizeTracker;

/**
 * Reader for the Litematica {@code .litematic} format.
 *
 * <p>Implemented from the published format (root {@code Regions} compound, per region a {@code
 * BlockStatePalette} list, a bit packed {@code BlockStates} long array, {@code Position} plus
 * signed {@code Size}) and cross checked against the Litematica mod's own reader,
 * {@code LitematicaBlockStateContainer}: {@code bits = max(2, ceil(log2(palette size)))}, entries
 * packed continuously so one entry may straddle two longs, and the flat array is ordered x fastest,
 * then z, then y.
 *
 * <p>Block entity contents (chest items, spawner types, ...) are not written back into the world;
 * that limitation is documented in the README.
 */
public final class LitematicaFormat implements SchematicFormat {
    private static final long MAX_FILE_BYTES = 256L * 1024L * 1024L;
    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    @Override
    public String id() {
        return "litematic";
    }

    @Override
    public String title() {
        return "Litematica (.litematic)";
    }

    @Override
    public boolean supports(String fileName) {
        return fileName.toLowerCase(Locale.ROOT).endsWith(".litematic");
    }

    @Override
    public Schematic load(Path file) throws SchematicException, IOException {
        if (Files.size(file) > MAX_FILE_BYTES) {
            throw new SchematicException("file is larger than 256 MiB, refusing to load it");
        }

        NbtCompound root = NbtFiles.read(file, "Litematica");
        if (root == null) throw new SchematicException("'" + file.getFileName() + "' contains no NBT data");

        if (!(root.get("Regions") instanceof NbtCompound regions)) {
            throw new SchematicException("not a Litematica schematic: missing the Regions tag");
        }

        int dataVersion = root.getInt("MinecraftDataVersion", -1);
        Map<String, String> metadata = readMetadata(root);

        List<Schematic.Region> parsedRegions = new ArrayList<>();
        List<String> problems = new ArrayList<>();

        for (String regionName : regions.getKeys()) {
            if (!(regions.get(regionName) instanceof NbtCompound regionTag)) continue;
            try {
                parsedRegions.add(readRegion(regionName, regionTag, problems));
            } catch (SchematicException e) {
                throw new SchematicException("region '" + regionName + "': " + e.getMessage(), e);
            }
        }

        if (parsedRegions.isEmpty()) throw new SchematicException("the schematic contains no regions");

        if (!problems.isEmpty()) {
            throw new SchematicException(join(problems));
        }

        return new Schematic(
                file.getFileName().toString(), id(), file.toAbsolutePath().toString(), dataVersion, metadata,
                parsedRegions);
    }

    private Schematic.Region readRegion(String name, NbtCompound tag, List<String> problems)
            throws SchematicException {
        int[] size = readBlockPos(tag, "Size");
        if (size == null) {
            throw new SchematicException("the region has no Size tag");
        }

        int[] position = readBlockPos(tag, "Position");
        if (position == null) position = new int[] {0, 0, 0};

        // Size is signed: a negative axis means the region extends towards negative coordinates from
        // Position. Normalise to a positive extent anchored at the true minimum corner.
        int minX = size[0] >= 0 ? position[0] : position[0] + size[0] + 1;
        int minY = size[1] >= 0 ? position[1] : position[1] + size[1] + 1;
        int minZ = size[2] >= 0 ? position[2] : position[2] + size[2] + 1;

        int sizeX = Math.abs(size[0]);
        int sizeY = Math.abs(size[1]);
        int sizeZ = Math.abs(size[2]);

        if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0) {
            throw new SchematicException("the region has an empty size");
        }

        long volumeLong = (long) sizeX * sizeY * sizeZ;
        if (volumeLong > Integer.MAX_VALUE) {
            throw new SchematicException("the region is too large (" + volumeLong + " blocks)");
        }
        int volume = (int) volumeLong;

        if (!(tag.get("BlockStatePalette") instanceof NbtList paletteTag) || paletteTag.isEmpty()) {
            throw new SchematicException("the region has no block palette");
        }

        BlockState[] palette = new BlockState[paletteTag.size()];
        for (int i = 0; i < palette.length; i++) {
            if (paletteTag.get(i) instanceof NbtCompound entry) {
                try {
                    palette[i] = BlockStateResolver.fromLitematic(entry);
                    continue;
                } catch (SchematicException e) {
                    problems.add(name + ": " + e.getMessage());
                }
            } else {
                problems.add(name + ": palette entry " + i + " is not a compound");
            }
            palette[i] = AIR;
        }

        int[] paletteIndices = readBlockStates(tag, volume, palette.length, problems);

        BlockState[] states = new BlockState[volume];
        for (int i = 0; i < volume; i++) states[i] = palette[paletteIndices[i]];

        return new Schematic.Region(name, minX, minY, minZ, sizeX, sizeY, sizeZ, states);
    }

    /**
     * Reads a region corner tag. Litematica writes {@code Position} and {@code Size} as BlockPos
     * compounds with named {@code x}/{@code y}/{@code z} int fields (see the mod's own
     * {@code NBTUtils.readBlockPos}); some third-party writers use a plain int array instead, so
     * both encodings are accepted.
     *
     * @return x,y,z in tag order, or {@code null} when the tag is missing or malformed
     */
    private static int[] readBlockPos(NbtCompound tag, String key) {
        if (tag.get(key) instanceof NbtCompound posTag) {
            return new int[] {posTag.getInt("x", 0), posTag.getInt("y", 0), posTag.getInt("z", 0)};
        }

        if (tag.get(key) instanceof NbtIntArray arrayTag) {
            int[] raw = arrayTag.getIntArray();
            return raw.length >= 3 ? raw : null;
        }

        return null;
    }

    /** Reads and decodes the packed {@code BlockStates} array. */
    private int[] readBlockStates(NbtCompound tag, int volume, int paletteSize, List<String> problems)
            throws SchematicException {
        int bits = BitPacking.bitsForPalette(paletteSize);

        long[] longs = null;
        if (tag.get("BlockStates") instanceof NbtLongArray array) {
            longs = array.getLongArray();
        } else if (tag.get("BlockStates") instanceof NbtIntArray array) {
            // Some writers fall back to an int array for small palettes.
            int[] raw = array.getIntArray();
            longs = new long[raw.length];
            for (int i = 0; i < raw.length; i++) longs[i] = raw[i] & 0xFFFFFFFFL;
        }

        if (longs == null) throw new SchematicException("the region has no BlockStates data");

        try {
            return BitPacking.unpack(longs, bits, volume);
        } catch (IllegalArgumentException e) {
            throw new SchematicException("cannot decode the block data: " + e.getMessage(), e);
        }
    }

    private static String join(List<String> problems) {
        int shown = Math.min(3, problems.size());
        return problems.size()
                + " block palette entries could not be resolved ("
                + String.join("; ", problems.subList(0, shown))
                + (problems.size() > shown ? "; ..." : "")
                + ")";
    }

    private Map<String, String> readMetadata(NbtCompound root) {
        Map<String, String> metadata = new LinkedHashMap<>();
        root.getCompound("Metadata").ifPresent(meta -> {
            for (String key : new String[] {"Name", "Author", "Description", "RegionCount", "TotalBlocks",
                    "TotalVolume", "TimeCreated", "TimeModified"}) {
                String value = meta.getString(key, "");
                if (!value.isEmpty()) metadata.put(key, value);
            }
        });

        return metadata;
    }

    /** Shared gzip/plain NBT loading with a readable error message. */
    static final class NbtFiles {
        private NbtFiles() {}

        /** @return the root tag, or {@code null} when the file held no compound */
        static NbtCompound read(Path file, String formatName) throws SchematicException, IOException {
            byte[] header = new byte[2];
            boolean gzip;
            try (InputStream in = Files.newInputStream(file)) {
                gzip = in.readNBytes(header, 0, 2) == 2
                        && (header[0] & 0xFF) == 0x1F
                        && (header[1] & 0xFF) == 0x8B;
            }

            try {
                if (gzip) return NbtIo.readCompressed(file, NbtSizeTracker.ofUnlimitedBytes());
                return NbtIo.read(file);
            } catch (IOException | RuntimeException e) {
                throw new SchematicException(
                        "cannot read the " + formatName + " file '" + file.getFileName() + "': " + e.getMessage(),
                        e);
            }
        }
    }
}
