package com.hookaddon.schematic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

/**
 * Parsed schematic held in memory.
 *
 * <p>A schematic is a list of regions, each with an offset relative to the schematic origin, an
 * extent and a flat block array ordered x fastest, then z, then y (the order both supported file
 * formats use).
 *
 * <p>Block states are resolved while parsing, so the placement engine never has to care which file
 * format a schematic came from. That keeps file parsing and placement strictly separated: a new
 * format only has to produce a {@code Schematic}.
 */
public final class Schematic {
    /** One region of the structure. Sizes are always positive. */
    public record Region(String name, int offsetX, int offsetY, int offsetZ, int sizeX, int sizeY, int sizeZ, BlockState[] states) {
        public int volume() {
            return sizeX * sizeY * sizeZ;
        }

        public BlockState stateAt(int localX, int localY, int localZ) {
            return states[localX + localZ * sizeX + localY * sizeX * sizeZ];
        }
    }

    public final String name;
    public final String format;
    public final String filePath;
    public final int dataVersion;
    public final Map<String, String> metadata;

    private final List<Region> regions;
    private int minX;
    private int minY;
    private int minZ;
    private int maxX;
    private int maxY;
    private int maxZ;
    private int solidBlocks = -1;

    public Schematic(String name, String format, String filePath, int dataVersion, Map<String, String> metadata,
                     List<Region> regions) {
        this.name = name;
        this.format = format;
        this.filePath = filePath;
        this.dataVersion = dataVersion;
        this.metadata = Collections.unmodifiableMap(new LinkedHashMap<>(metadata));
        this.regions = List.copyOf(regions);
        recomputeBounds();
    }

    private void recomputeBounds() {
        if (regions.isEmpty()) {
            minX = minY = minZ = maxX = maxY = maxZ = 0;
            return;
        }

        minX = minY = minZ = Integer.MAX_VALUE;
        maxX = maxY = maxZ = Integer.MIN_VALUE;

        for (Region region : regions) {
            minX = Math.min(minX, region.offsetX());
            minY = Math.min(minY, region.offsetY());
            minZ = Math.min(minZ, region.offsetZ());
            maxX = Math.max(maxX, region.offsetX() + region.sizeX());
            maxY = Math.max(maxY, region.offsetY() + region.sizeY());
            maxZ = Math.max(maxZ, region.offsetZ() + region.sizeZ());
        }
    }

    public List<Region> regions() {
        return regions;
    }

    /** Lowest corner of the structure relative to the schematic origin (can be negative). */
    public BlockPos minCorner() {
        return new BlockPos(minX, minY, minZ);
    }

    /** Size of the axis aligned bounds, always positive. */
    public int sizeX() {
        return Math.max(0, maxX - minX);
    }

    public int sizeY() {
        return Math.max(0, maxY - minY);
    }

    public int sizeZ() {
        return Math.max(0, maxZ - minZ);
    }

    public int volume() {
        return sizeX() * sizeY() * sizeZ();
    }

    /** Number of non-air blocks, i.e. the amount of work the build actually needs. */
    public int solidBlockCount() {
        if (solidBlocks >= 0) return solidBlocks;

        int total = 0;
        for (Region region : regions) {
            for (BlockState state : region.states()) {
                if (!state.isAir()) total++;
            }
        }
        solidBlocks = total;
        return total;
    }

    /** Every non-air block with its schematic-relative position. */
    public List<Entry> entries() {
        List<Entry> entries = new ArrayList<>(solidBlockCount());
        for (Region region : regions) {
            for (int y = 0; y < region.sizeY(); y++) {
                for (int z = 0; z < region.sizeZ(); z++) {
                    for (int x = 0; x < region.sizeX(); x++) {
                        BlockState state = region.stateAt(x, y, z);
                        if (state.isAir()) continue;
                        entries.add(new Entry(
                                region.offsetX() + x, region.offsetY() + y, region.offsetZ() + z, state));
                    }
                }
            }
        }
        return entries;
    }

    /** Distinct blocks with counts, ordered by descending quantity. */
    public Map<Block, Integer> requiredBlocks() {
        Map<Block, Integer> required = new LinkedHashMap<>();
        for (Region region : regions) {
            for (BlockState state : region.states()) {
                if (state.isAir()) continue;
                required.merge(state.getBlock(), 1, Integer::sum);
            }
        }
        return required;
    }

    /** A single block of the structure, positioned relative to the schematic origin. */
    public record Entry(int x, int y, int z, BlockState state) {
        public BlockPos relativePos() {
            return new BlockPos(x, y, z);
        }
    }
}
