package com.hookaddon.schematic;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;

/**
 * Reader for the Sponge Schematic Specification v2 ({@code .schem}).
 *
 * <p>Follows the published specification: gzip NBT root with {@code Version} (2), {@code Width},
 * {@code Height}, {@code Length} as unsigned shorts, an optional {@code Offset} int array, a {@code
 * Palette} compound mapping block state strings to indices, and {@code BlockData} holding one
 * VarInt palette index per block in {@code index = x + z * Width + y * Width * Length} order.
 *
 * <p>Version 1 and the older WorldEdit {@code .schematic} (MCEdit) format are intentionally not
 * supported; the parser says so instead of guessing.
 */
public final class SpongeSchematicFormat implements SchematicFormat {
    private static final long MAX_FILE_BYTES = 256L * 1024L * 1024L;
    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    @Override
    public String id() {
        return "sponge";
    }

    @Override
    public String title() {
        return "Sponge Schematic v2 (.schem)";
    }

    @Override
    public boolean supports(String fileName) {
        return fileName.toLowerCase(Locale.ROOT).endsWith(".schem");
    }

    @Override
    public Schematic load(Path file) throws SchematicException, IOException {
        if (Files.size(file) > MAX_FILE_BYTES) {
            throw new SchematicException("file is larger than 256 MiB, refusing to load it");
        }

        NbtCompound root = LitematicaFormat.NbtFiles.read(file, "Sponge");
        if (root == null) throw new SchematicException("'" + file.getFileName() + "' contains no NBT data");

        int version = root.getInt("Version", -1);
        if (version == -1) {
            throw new SchematicException(
                    "missing Version tag; this looks like a WorldEdit .schematic (MCEdit) file, which is not supported");
        }
        if (version != 2) {
            throw new SchematicException("schematic version " + version + " is not supported, only version 2");
        }

        int width = root.getShort("Width", (short) 0) & 0xFFFF;
        int height = root.getShort("Height", (short) 0) & 0xFFFF;
        int length = root.getShort("Length", (short) 0) & 0xFFFF;

        if (width <= 0 || height <= 0 || length <= 0) {
            throw new SchematicException("the schematic has an empty size (" + width + "x" + height + "x" + length + ")");
        }

        long volumeLong = (long) width * height * length;
        if (volumeLong > Integer.MAX_VALUE) {
            throw new SchematicException("the schematic is too large (" + volumeLong + " blocks)");
        }
        int volume = (int) volumeLong;

        NbtCompound paletteTag = root.getCompound("Palette").orElse(null);
        if (paletteTag == null || paletteTag.isEmpty()) {
            throw new SchematicException("the schematic has no palette");
        }

        int paletteMax = root.getInt("PaletteMax", 0);
        BlockState[] palette = readPalette(paletteTag, paletteMax);

        byte[] blockData = root.getByteArray("BlockData").orElse(null);
        if (blockData == null) throw new SchematicException("the schematic has no BlockData array");

        int[] indices;
        try {
            indices = BitPacking.readVarInts(blockData, volume);
        } catch (IllegalArgumentException e) {
            throw new SchematicException("cannot decode the block data: " + e.getMessage(), e);
        }

        BlockState[] states = new BlockState[volume];
        for (int i = 0; i < volume; i++) {
            int paletteIndex = indices[i];
            states[i] = paletteIndex >= 0 && paletteIndex < palette.length ? palette[paletteIndex] : AIR;
        }

        int[] offset = root.getIntArray("Offset").orElse(new int[] {0, 0, 0});
        int offsetX = offset.length > 0 ? offset[0] : 0;
        int offsetY = offset.length > 1 ? offset[1] : 0;
        int offsetZ = offset.length > 2 ? offset[2] : 0;

        Map<String, String> metadata = new LinkedHashMap<>();
        root.getCompound("Metadata").ifPresent(meta -> {
            for (String key : meta.getKeys()) {
                String value = meta.getString(key, "");
                if (!value.isEmpty()) metadata.put(key, value);
            }
        });
        metadata.put("DataVersion", Integer.toString(root.getInt("DataVersion", -1)));

        List<Schematic.Region> regions = List.of(
                new Schematic.Region("root", offsetX, offsetY, offsetZ, width, height, length, states));

        return new Schematic(
                file.getFileName().toString(), id(), file.toAbsolutePath().toString(),
                root.getInt("DataVersion", -1), metadata, regions);
    }

    private BlockState[] readPalette(NbtCompound paletteTag, int paletteMax) throws SchematicException {
        int highest = Math.max(paletteMax, 0);
        for (String key : paletteTag.getKeys()) {
            highest = Math.max(highest, paletteTag.getInt(key, -1) + 1);
        }

        if (highest <= 0) throw new SchematicException("the palette is empty");

        BlockState[] palette = new BlockState[highest];
        List<String> problems = new ArrayList<>();

        for (String key : paletteTag.getKeys()) {
            int index = paletteTag.getInt(key, -1);
            if (index < 0 || index >= palette.length) {
                problems.add("'" + key + "' maps to the out of range index " + index);
                continue;
            }

            try {
                palette[index] = BlockStateResolver.fromPaletteKey(key);
            } catch (SchematicException e) {
                problems.add(e.getMessage());
                palette[index] = AIR;
            }
        }

        if (!problems.isEmpty()) {
            int shown = Math.min(3, problems.size());
            throw new SchematicException(
                    problems.size()
                            + " palette entries could not be resolved ("
                            + String.join("; ", problems.subList(0, shown))
                            + (problems.size() > shown ? "; ..." : "")
                            + ")");
        }

        return palette;
    }
}
