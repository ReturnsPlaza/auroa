package com.hookaddon.schematic;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

/**
 * Resolves palette entries into runtime {@link BlockState}s.
 *
 * <p>Used by both parsers: Litematica stores a {@code Name} plus a {@code Properties} compound,
 * Sponge stores a single {@code namespace:block[prop=value,...]} key. Unknown blocks or properties
 * raise a readable error instead of silently turning into air, so a schematic that needs a mod the
 * player does not have fails loudly.
 */
public final class BlockStateResolver {
    private BlockStateResolver() {}

    /** Reads a Litematica palette entry. */
    public static BlockState fromLitematic(NbtCompound entry) throws SchematicException {
        String name = entry.getString("Name", "");
        if (name.isEmpty()) throw new SchematicException("palette entry without a block name");

        Map<String, String> properties = new LinkedHashMap<>();
        entry.getCompound("Properties").ifPresent(props -> {
            for (String key : props.getKeys()) properties.put(key, props.getString(key, ""));
        });

        return resolve(name, properties);
    }

    /** Reads a Sponge palette key such as {@code minecraft:oak_stairs[facing=east,half=bottom]}. */
    public static BlockState fromPaletteKey(String key) throws SchematicException {
        int bracket = key.indexOf('[');
        String id = bracket >= 0 ? key.substring(0, bracket) : key;

        Map<String, String> properties = new LinkedHashMap<>();
        if (bracket >= 0 && key.endsWith("]")) {
            String body = key.substring(bracket + 1, key.length() - 1);
            for (String pair : body.split(",")) {
                if (pair.isEmpty()) continue;
                int equals = pair.indexOf('=');
                if (equals <= 0) throw new SchematicException("malformed property '" + pair + "' in '" + key + "'");
                properties.put(pair.substring(0, equals).trim(), pair.substring(equals + 1).trim());
            }
        }

        return resolve(id, properties);
    }

    /** Resolves a block id plus its property values. */
    public static BlockState resolve(String id, Map<String, String> properties) throws SchematicException {
        Identifier identifier = Identifier.tryParse(id);
        if (identifier == null) throw new SchematicException("'" + id + "' is not a valid block id");

        Block block = Registries.BLOCK.get(identifier);
        if (block == null) {
            throw new SchematicException("block '" + id + "' is not registered (is the mod that adds it installed?)");
        }

        BlockState state = block.getDefaultState();

        for (Map.Entry<String, String> property : properties.entrySet()) {
            BlockState updated = apply(state, property.getKey(), property.getValue());
            if (updated == null) {
                throw new SchematicException("'" + id + "' does not accept "
                        + property.getKey() + "=" + property.getValue());
            }
            state = updated;
        }

        return state;
    }

    /** @return the updated state, or {@code null} when the property or value does not exist */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static BlockState apply(BlockState state, String propertyName, String propertyValue) {
        for (Property<?> property : state.getProperties()) {
            if (!property.getName().equals(propertyName)) continue;

            Optional<?> parsed = property.parse(propertyValue);
            if (parsed.isEmpty()) return null;

            return state.with((Property) property, (Comparable) parsed.get());
        }

        return null;
    }
}
