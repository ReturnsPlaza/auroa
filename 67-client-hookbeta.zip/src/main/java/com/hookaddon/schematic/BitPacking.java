package com.hookaddon.schematic;

/**
 * Pure bit/byte decoding helpers for the schematic formats.
 *
 * <p>No Minecraft classes on purpose: this is the part of the parsers that is worth unit testing
 * on a plain JVM, since a wrong shift silently scrambles a whole build.
 *
 * <p>The Litematica layout matches the reference implementation ({@code LitematicaBitArray} from
 * the Litematica mod): entries are packed continuously with {@code bits = max(2, ceil(log2(palette
 * size)))} and a single entry may straddle two longs. Sponge v2 stores one VarInt palette index per
 * block.
 */
public final class BitPacking {
    private BitPacking() {}

    /** Bit width Litematica uses for a palette of {@code paletteSize} entries. */
    public static int bitsForPalette(int paletteSize) {
        if (paletteSize <= 1) return 2;
        return Math.max(2, Integer.SIZE - Integer.numberOfLeadingZeros(paletteSize - 1));
    }

    /**
     * Decodes {@code count} palette indices from a Litematica {@code BlockStates} long array.
     *
     * @param data packed longs as stored in the file
     * @param bits entry width in bits, see {@link #bitsForPalette(int)}
     * @param count number of entries to read (the region volume)
     * @throws IllegalArgumentException when the array is too short for the requested count
     */
    public static int[] unpack(long[] data, int bits, int count) {
        if (bits < 1 || bits > 32) throw new IllegalArgumentException("invalid bit width: " + bits);
        if (count < 0) throw new IllegalArgumentException("invalid count: " + count);

        int[] values = new int[count];
        if (count == 0) return values;
        if (data == null || data.length == 0) throw new IllegalArgumentException("missing block state data");

        long mask = (1L << bits) - 1L;

        for (int i = 0; i < count; i++) {
            long startOffset = (long) i * (long) bits;
            int startIndex = (int) (startOffset >> 6);
            int endIndex = (int) (((long) i + 1L) * (long) bits - 1L >> 6);
            int startBit = (int) (startOffset & 0x3F);

            if (startIndex >= data.length) {
                throw new IllegalArgumentException(
                        "block state data too short: need index " + startIndex + " of " + data.length);
            }

            if (startIndex == endIndex) {
                values[i] = (int) (data[startIndex] >>> startBit & mask);
            } else {
                if (endIndex >= data.length) {
                    throw new IllegalArgumentException(
                            "block state data too short: need index " + endIndex + " of " + data.length);
                }
                int endOffset = 64 - startBit;
                values[i] = (int) ((data[startIndex] >>> startBit | data[endIndex] << endOffset) & mask);
            }
        }

        return values;
    }

    /**
     * Decodes {@code count} VarInt palette indices from Sponge {@code BlockData} bytes.
     *
     * @throws IllegalArgumentException when the data is truncated
     */
    public static int[] readVarInts(byte[] data, int count) {
        if (count < 0) throw new IllegalArgumentException("invalid count: " + count);
        int[] values = new int[count];
        if (count == 0) return values;
        if (data == null) throw new IllegalArgumentException("missing block data");

        int index = 0;
        int pos = 0;

        while (index < count) {
            int value = 0;
            int shift = 0;

            while (true) {
                if (pos >= data.length) {
                    throw new IllegalArgumentException(
                            "block data truncated: expected " + count + " entries, decoded " + index);
                }

                byte next = data[pos++];
                value |= (next & 0x7F) << shift;
                if ((next & 0x80) == 0) break;

                shift += 7;
                if (shift > 35) throw new IllegalArgumentException("malformed varint in block data");
            }

            values[index++] = value;
        }

        return values;
    }

    /** Packs values the same way Litematica writes them, used by the tests to round-trip data. */
    public static long[] pack(int[] values, int bits) {
        if (bits < 1 || bits > 32) throw new IllegalArgumentException("invalid bit width: " + bits);
        if (values.length == 0) return new long[0];

        long mask = (1L << bits) - 1L;
        long[] data = new long[(int) Math.ceil(values.length * (double) bits / 64.0)];

        for (int i = 0; i < values.length; i++) {
            long startOffset = (long) i * (long) bits;
            int startIndex = (int) (startOffset >> 6);
            int endIndex = (int) (((long) i + 1L) * (long) bits - 1L >> 6);
            int startBit = (int) (startOffset & 0x3F);
            long value = values[i] & mask;

            data[startIndex] = data[startIndex] & ~(mask << startBit) | value << startBit;

            if (startIndex != endIndex) {
                int endOffset = 64 - startBit;
                data[endIndex] = data[endIndex] >>> (bits - endOffset) << (bits - endOffset) | value >>> endOffset;
            }
        }

        return data;
    }
}
