package com.hookaddon.schematic;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Registry of the schematic formats the addon can read.
 *
 * <p>Adding a format means adding an implementation of {@link SchematicFormat} to this list; the
 * module, the placement engine and the UI pick it up automatically.
 */
public final class SchematicFormats {
    private static final List<SchematicFormat> FORMATS = List.of(new LitematicaFormat(), new SpongeSchematicFormat());

    private SchematicFormats() {}

    public static List<SchematicFormat> all() {
        return FORMATS;
    }

    public static SchematicFormat byId(String id) {
        for (SchematicFormat format : FORMATS) {
            if (format.id().equalsIgnoreCase(id)) return format;
        }
        return null;
    }

    /** @return the format that reads {@code fileName}, or {@code null} when it is unsupported */
    public static SchematicFormat forFile(String fileName) {
        for (SchematicFormat format : FORMATS) {
            if (format.supports(fileName)) return format;
        }
        return null;
    }

    public static boolean isSupported(String fileName) {
        return forFile(fileName) != null;
    }

    /** Picks the format by extension and parses the file. */
    public static Schematic load(Path file) throws SchematicException, IOException {
        SchematicFormat format = forFile(file.getFileName().toString());
        if (format == null) {
            throw new SchematicException(
                    "'" + file.getFileName() + "' is not a supported schematic file ("
                            + String.join(", ", extensions()) + ")");
        }
        return format.load(file);
    }

    public static List<String> extensions() {
        List<String> extensions = new ArrayList<>();
        for (SchematicFormat format : FORMATS) {
            switch (format.id()) {
                case "litematic" -> extensions.add("*.litematic");
                case "sponge" -> extensions.add("*.schem");
                default -> extensions.add("*." + format.id());
            }
        }
        return extensions;
    }

    /** Sorted list of supported schematic files inside a directory, empty when it does not exist. */
    public static List<Path> listFiles(Path directory) {
        if (directory == null || !Files.isDirectory(directory)) return List.of();

        try (Stream<Path> stream = Files.list(directory)) {
            return stream.filter(Files::isRegularFile)
                    .filter(path -> isSupported(path.getFileName().toString()))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }
}
