package com.hookaddon.schematic;

import com.hookaddon.nav.Navigator;
import com.hookaddon.task.MiningController;
import com.hookaddon.task.RetryTracker;
import com.hookaddon.task.TaskManager;
import com.hookaddon.util.HookStatus;
import com.hookaddon.util.InvGuards;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * The placement engine of the Auto Schematic Builder.
 *
 * <p>It runs in two phases:
 *
 * <ol>
 *   <li><b>Verify</b> - walk the plan with a per tick budget and compare every position against the
 *       world. Positions that already match count as done, air positions become placement work, and
 *       anything else becomes "wrong block" work that has to be broken first. This same pass is what
 *       lets a build resume after a disconnect: re-running it rebuilds the exact remaining work.
 *   <li><b>Build</b> - take work from the queue, resolve the material, make sure the target is in
 *       reach (walking there when allowed), make sure there is a side to place against (putting a
 *       support block down when allowed), place, then <em>wait for the world to confirm</em>. A
 *       placement only counts once the block state matches, and a placement that is never confirmed
 *       is retried up to a limit and then reported as failed.
 * </ol>
 *
 * <p>Nothing here moves the player or breaks blocks by itself: it goes through the shared
 * {@link Navigator} and {@link MiningController}, so ownership rules stay in one place.
 */
public final class PlacementEngine {
    public enum Phase {
        IDLE,
        VERIFYING,
        BUILDING,
        PAUSED,
        COMPLETE,
        FAILED
    }

    /**
     * @param reach interaction distance
     * @param autoNavigate walk to out of reach targets
     * @param rotate aim at the position before interacting
     * @param swing swing the hand while placing
     * @param placeDelayTicks ticks between two placements
     * @param verifyTimeoutTicks ticks to wait for server confirmation before retrying
     * @param maxAttempts attempts per block before it is marked failed
     * @param verifyBudgetPerTick positions inspected per tick during verification
     * @param skipMissingMaterials skip blocks whose material is not in the inventory
     * @param placeSupportBlocks place a support block when a target has no neighbour to place against
     * @param supportBlock block used for support placements
     * @param autoMoveToHotbar move materials into an empty hotbar slot automatically
     * @param autoTool pick the fastest tool when breaking wrong blocks
     * @param minToolDurability durability floor for the tool
     * @param avoidLava / @param avoidFluids / @param avoidFalling safety screens for breaking
     */
    public record Options(
            double reach,
            boolean autoNavigate,
            boolean rotate,
            boolean swing,
            int placeDelayTicks,
            int verifyTimeoutTicks,
            int maxAttempts,
            int verifyBudgetPerTick,
            boolean skipMissingMaterials,
            boolean placeSupportBlocks,
            Block supportBlock,
            boolean autoMoveToHotbar,
            boolean autoTool,
            int minToolDurability,
            boolean avoidLava,
            boolean avoidFluids,
            boolean avoidFalling) {}

    /** Snapshot of the engine state for status lines and the HUD. */
    public record Status(
            Phase phase,
            int total,
            int verified,
            int pending,
            int skipped,
            int failed,
            int wrongBlocks,
            int missingBlocks,
            double etaSeconds,
            String message) {}

    /** One unit of remaining work. */
    private record Work(BlockPos pos, BlockState expected) {}

    /** Outcome of one support-placement attempt: progressed, stalled on material, or impossible. */
    private enum SupportOutcome { PLACED, WAITING, FAILED }

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String owner;
    private final Module reporter;

    private PlacementPlanner.Plan plan;
    private Phase phase = Phase.IDLE;

    private final Deque<Work> queue = new ArrayDeque<>();
    private int verifyIndex;
    private int verified;
    private int skipped;
    private int failed;
    private int placed;
    private int wrongBlocks;
    private int missingBlocks;

    private Work pending;
    private int confirmTicksLeft;
    private int attemptsOnCurrent;
    private int placeCooldown;
    private int supportAttempts;
    private BlockPos lastWorkPos;

    private long buildStartedAt;
    private int placedAtBuildStart;
    private String lastMessage = "idle";

    private final RetryTracker materialTracker = new RetryTracker();

    public PlacementEngine(String owner, Module reporter) {
        this.owner = owner;
        this.reporter = reporter;
    }

    public PlacementPlanner.Plan plan() {
        return plan;
    }

    public Phase phase() {
        return phase;
    }

    public BlockPos currentTarget() {
        if (pending != null) return pending.pos();
        Work head = queue.peek();
        return head == null ? null : head.pos();
    }

    public List<BlockPos> pendingPositions() {
        List<BlockPos> positions = new ArrayList<>(Math.min(queue.size(), 512));
        int index = 0;
        for (Work work : queue) {
            if (index++ >= 512) break;
            positions.add(work.pos());
        }
        if (pending != null) positions.add(pending.pos());
        return positions;
    }

    /** Accepts a new plan and starts a fresh verification pass. */
    public void setPlan(PlacementPlanner.Plan newPlan) {
        this.plan = newPlan;
        this.phase = Phase.VERIFYING;
        this.queue.clear();
        this.verifyIndex = 0;
        this.verified = 0;
        this.skipped = 0;
        this.failed = 0;
        this.placed = 0;
        this.wrongBlocks = 0;
        this.missingBlocks = 0;
        this.pending = null;
        this.confirmTicksLeft = 0;
        this.attemptsOnCurrent = 0;
        this.placeCooldown = 0;
        this.lastWorkPos = null;
        this.buildStartedAt = 0;
        this.placedAtBuildStart = 0;
        this.lastMessage = "verifying " + newPlan.targets().size() + " positions";
    }

    public void pause() {
        if (phase == Phase.BUILDING || phase == Phase.VERIFYING) {
            phase = Phase.PAUSED;
            lastMessage = "paused";
            Navigator.get().stop(owner);
        }
    }

    public void resume() {
        if (phase == Phase.PAUSED) {
            phase = verifyIndex < totalTargets() ? Phase.VERIFYING : Phase.BUILDING;
            lastMessage = "resumed";
        }
    }

    /** Aborts the build and keeps the plan, so it can be started again. */
    public void cancel() {
        phase = Phase.IDLE;
        queue.clear();
        pending = null;
        attemptsOnCurrent = 0;
        supportAttempts = 0;
        lastWorkPos = null;
        Navigator.get().stop(owner);
        MiningController.get().reset(owner);
        lastMessage = "cancelled";
    }

    /** Re-verifies everything from scratch. */
    public void restart() {
        if (plan != null) setPlan(plan);
    }

    public Status status() {
        return new Status(
                phase,
                totalTargets(),
                verified,
                remaining(),
                skipped,
                failed,
                wrongBlocks,
                missingBlocks,
                etaSeconds(),
                lastMessage);
    }

    /** Blocks still to place: queued plus the one waiting for its confirmation. */
    private int remaining() {
        return queue.size() + (pending != null ? 1 : 0);
    }

    public Map<Block, Integer> missingMaterials(Options options) {
        if (plan == null) return Map.of();

        Map<Block, Integer> available = new java.util.HashMap<>();
        for (Map.Entry<Block, Integer> entry : plan.required().entrySet()) {
            Item item = Item.fromBlock(entry.getKey());
            if (item == null) continue;
            available.put(entry.getKey(), InvGuards.count(stack -> stack.isOf(item)));
        }

        return PlacementPlanner.missingMaterials(plan, available);
    }

    /** Advances the build by one tick. Must be called from a {@code TickEvent.Pre} handler. */
    public Status tick(Options options) {
        if (mc.player == null || mc.world == null) {
            lastMessage = "no world";
            return status();
        }

        if (phase == Phase.IDLE || phase == Phase.PAUSED || phase == Phase.COMPLETE || phase == Phase.FAILED) {
            return status();
        }

        if (placeCooldown > 0) placeCooldown--;

        if (phase == Phase.VERIFYING) {
            verifyStep(options);
        }

        if (phase == Phase.BUILDING) {
            buildStep(options);
        }

        return status();
    }

    private int totalTargets() {
        return plan == null ? 0 : plan.targets().size();
    }

    // Phase 1: verification ---------------------------------------------------------------

    private void verifyStep(Options options) {
        int budget = Math.max(1, options.verifyBudgetPerTick());
        List<PlacementPlanner.Target> targets = plan.targets();

        while (budget-- > 0 && verifyIndex < targets.size()) {
            PlacementPlanner.Target target = targets.get(verifyIndex++);
            BlockState world = mc.world.getBlockState(target.pos());

            if (matches(world, target.expected())) {
                verified++;
                continue;
            }

            if (world.isAir()) missingBlocks++;
            else wrongBlocks++;

            queue.add(new Work(target.pos(), target.expected()));
        }

        if (verifyIndex >= targets.size()) {
            phase = queue.isEmpty() ? Phase.COMPLETE : Phase.BUILDING;
            buildStartedAt = System.currentTimeMillis();
            placedAtBuildStart = placed;

            if (phase == Phase.COMPLETE) {
                lastMessage = "already complete, " + verified + " blocks verified";
                if (reporter != null) {
                    HookStatus.progressNow(reporter, "schematic", "Schematic %s is already complete (%d blocks verified)",
                            plan.targets().size(), verified);
                }
            } else {
                lastMessage = "verifying finished: " + queue.size() + " blocks to place";
                if (reporter != null) {
                    HookStatus.progressNow(reporter, "schematic",
                            "Verified %d blocks: %d correct, %d missing, %d incorrect. Placing %d blocks.",
                            targets.size(), verified, missingBlocks, wrongBlocks, queue.size());
                }
            }
        }
    }

    // Phase 2: placement -----------------------------------------------------------------

    private void buildStep(Options options) {
        if (queue.isEmpty() && pending == null) {
            phase = Phase.COMPLETE;
            Navigator.get().stop(owner);
            MiningController.get().reset(owner);
            lastMessage = "complete";
            if (reporter != null) {
                HookStatus.progressNow(reporter, "schematic", "Build complete: %d blocks verified, %d skipped, %d failed",
                        verified, skipped, failed);
            }
            return;
        }

        // Wait for the server to confirm the previous placement before doing anything else.
        if (pending != null) {
            if (confirmPlacement(options)) return;
        }

        Work work = queue.peek();
        if (work == null) return;

        // Every work item starts with a fresh attempt budget; retries of the same item keep theirs
        // (lastWorkPos stays set while an item cycles through pending -> requeued -> peeked again).
        if (lastWorkPos == null || !lastWorkPos.equals(work.pos())) {
            lastWorkPos = work.pos();
            attemptsOnCurrent = 0;
            supportAttempts = 0;
        }

        BlockState world = mc.world.getBlockState(work.pos());

        if (matches(world, work.expected())) {
            queue.poll();
            verified++;
            // It was queued because the world did not match: something (usually a late server
            // confirmation of our own placement) put it there, so count it as placed for the ETA.
            placed++;
            attemptsOnCurrent = 0;
            materialTracker.reset();
            return;
        }

        if (!world.isAir()) {
            breakWrongBlock(work, world, options);
            return;
        }

        placeBlock(work, options);
    }

    /** @return true when the engine is still waiting for a server confirmation */
    private boolean confirmPlacement(Options options) {
        BlockState world = mc.world.getBlockState(pending.pos());

        if (matches(world, pending.expected())) {
            verified++;
            placed++;
            pending = null;
            attemptsOnCurrent = 0;
            materialTracker.reset();
            return false;
        }

        if (confirmTicksLeft-- > 0) return true;

        // Timed out: the placement did not happen (out of range, no support, server rejected it).
        attemptsOnCurrent++;
        Work timedOut = pending;
        pending = null;

        if (attemptsOnCurrent >= Math.max(1, options.maxAttempts())) {
            failed++;
            attemptsOnCurrent = 0;
            report("warn", "Could not place %s at %s after %d attempts, skipping",
                    name(timedOut.expected()), timedOut.pos().toShortString(), options.maxAttempts());
        } else {
            // The work left the queue when it was placed: put it back so the retry actually happens.
            // Without this the block silently disappears from the build and never gets counted.
            queue.addFirst(timedOut);
            report("info", "Placement at %s not confirmed, retrying (%d/%d)",
                    timedOut.pos().toShortString(), attemptsOnCurrent, options.maxAttempts());
        }

        return false;
    }

    private void breakWrongBlock(Work work, BlockState world, Options options) {
        Navigator.get().stop(owner);

        MiningController.Options miningOptions = new MiningController.Options(
                options.reach(),
                options.rotate(),
                options.swing(),
                options.autoTool(),
                options.minToolDurability(),
                options.avoidLava(),
                options.avoidFluids(),
                options.avoidFalling(),
                200,
                options.maxAttempts());

        MiningController.Result result = MiningController.get().tick(owner, work.pos(), miningOptions);

        switch (result) {
            case DONE -> attemptsOnCurrent = 0;
            case WORKING -> lastMessage = "breaking " + name(work.expected());
            case OUT_OF_REACH -> navigateTo(work.pos(), options, "breaking");
            case UNSAFE -> {
                queue.poll();
                failed++;
                report("warn", "Refusing to break %s at %s for safety reasons, skipping",
                        name(mc.world.getBlockState(work.pos())), work.pos().toShortString());
            }
            case FAILED -> {
                queue.poll();
                failed++;
                attemptsOnCurrent = 0;
                report("warn", "Could not break %s at %s, skipping",
                        name(mc.world.getBlockState(work.pos())), work.pos().toShortString());
            }
            case REJECTED -> lastMessage = "mining owned by another module";
        }
    }

    private void placeBlock(Work work, Options options) {
        BlockState expected = work.expected();
        Block block = expected.getBlock();

        // Material lookup, including the hotbar.
        Item item = Item.fromBlock(block);
        if (item == null) {
            queue.poll();
            failed++;
            report("error", "No item exists for block %s, skipping", name(expected));
            return;
        }

        FindItemResult hotbar = InvUtils.findInHotbar(stack -> stack.isOf(item));
        if (!hotbar.found()) {
            FindItemResult anywhere = InvUtils.find(stack -> stack.isOf(item));

            if (!anywhere.found()) {
                handleMissingMaterial(work, block, options);
                return;
            }

            if (!options.autoMoveToHotbar()) {
                lastMessage = "waiting for " + name(expected) + " in the hotbar";
                return;
            }

            int emptyHotbar = findEmptyHotbarSlot();
            if (emptyHotbar < 0) {
                lastMessage = "free a hotbar slot for " + name(expected);
                return;
            }

            InvUtils.move().from(anywhere.slot()).toHotbar(emptyHotbar);
            return;
        }

        // Reach and navigation.
        if (!MiningController.inReach(work.pos(), options.reach())) {
            navigateTo(work.pos(), options, "placing");
            return;
        }

        Navigator.get().stop(owner);
        lastMessage = "placing " + name(expected);

        // Something has to be placed against.
        if (BlockUtils.getPlaceSide(work.pos()) == null) {
            if (!options.placeSupportBlocks()) {
                queue.poll();
                failed++;
                report("warn", "No surface to place against at %s, skipping", work.pos().toShortString());
                return;
            }

            switch (placeSupport(work, options)) {
                    // A support block went down (or we are walking closer): retry next tick.
                case PLACED -> {}
                    // Material for the support block is not ready yet: keep the work queued.
                case WAITING -> {}
                case FAILED -> {
                    queue.poll();
                    failed++;
                    supportAttempts = 0;
                    report("warn", "Could not build support for %s at %s, skipping",
                            name(expected), work.pos().toShortString());
                }
            }
            return;
        }

        if (placeCooldown > 0) return;

        boolean placedOk = BlockUtils.place(work.pos(), hotbar, options.rotate(), 50, options.swing(), true, true);
        if (!placedOk) {
            attemptsOnCurrent++;
            if (attemptsOnCurrent >= Math.max(1, options.maxAttempts())) {
                queue.poll();
                failed++;
                attemptsOnCurrent = 0;
                report("warn", "Placement at %s was rejected, skipping", work.pos().toShortString());
            }
            return;
        }

        queue.poll();
        pending = work;
        confirmTicksLeft = Math.max(5, options.verifyTimeoutTicks());
        placeCooldown = Math.max(0, options.placeDelayTicks());
        supportAttempts = 0;
    }

    private void handleMissingMaterial(Work work, Block block, Options options) {
        if (options.skipMissingMaterials()) {
            queue.poll();
            skipped++;
            materialTracker.failure(System.currentTimeMillis());

            if (materialTracker.attempts() == 1 || materialTracker.attempts() % 16 == 0) {
                report("warn", "Missing materials for %s, skipping (total skipped: %d)",
                        name(block.getDefaultState()), skipped);
            }
            return;
        }

        lastMessage = "waiting for " + name(block.getDefaultState());
        if (materialTracker.attempts() == 0 || materialTracker.attempts() % 32 == 0) {
            report("warn", "Missing materials for %s, waiting. Enable skip-missing to continue without them.",
                    name(block.getDefaultState()));
        }
        materialTracker.failure(System.currentTimeMillis());
    }

    /** Places one support block next to the current target so the next placement has a side. */
    private SupportOutcome placeSupport(Work work, Options options) {
        BlockPos target = work.pos();

        Block supportBlock = options.supportBlock();
        if (supportBlock == null || supportBlock == Blocks.AIR) return SupportOutcome.FAILED;

        Item supportItem = Item.fromBlock(supportBlock);
        if (supportItem == null) return SupportOutcome.FAILED;

        FindItemResult hotbar = InvUtils.findInHotbar(stack -> stack.isOf(supportItem));
        if (!hotbar.found()) {
            FindItemResult anywhere = InvUtils.find(stack -> stack.isOf(supportItem));

            if (!anywhere.found()) {
                // Nothing to build with: skip the block when missing materials are skipped,
                // otherwise wait like the main material does.
                if (options.skipMissingMaterials()) {
                    supportAttempts = 0;
                    return SupportOutcome.FAILED;
                }
                lastMessage = "waiting for " + supportBlock.getName().getString() + " to build support";
                return SupportOutcome.WAITING;
            }

            if (options.autoMoveToHotbar()) {
                int emptyHotbar = findEmptyHotbarSlot();
                if (emptyHotbar >= 0) {
                    InvUtils.move().from(anywhere.slot()).toHotbar(emptyHotbar);
                } else {
                    lastMessage = "free a hotbar slot for " + supportBlock.getName().getString();
                }
            } else {
                lastMessage = "waiting for " + supportBlock.getName().getString() + " to build support";
            }
            return SupportOutcome.WAITING;
        }

        if (!MiningController.inReach(target, options.reach())) {
            navigateTo(target, options, "support");
            return SupportOutcome.PLACED;
        }

        // Only actual placement tries consume the attempt budget; waiting and walking do not.
        if (++supportAttempts > 8) {
            supportAttempts = 0;
            return SupportOutcome.FAILED;
        }

        for (Direction direction : Direction.values()) {
            BlockPos neighbour = target.offset(direction);
            if (!mc.world.getBlockState(neighbour).isReplaceable()) continue;
            if (!BlockUtils.canPlace(neighbour)) continue;
            if (BlockUtils.getPlaceSide(neighbour) == null) continue;

            if (BlockUtils.place(neighbour, hotbar, options.rotate(), 40, options.swing(), true, true)) {
                lastMessage = "placing support block";
                return SupportOutcome.PLACED;
            }
        }

        return SupportOutcome.FAILED;
    }

    private void navigateTo(BlockPos pos, Options options, String activity) {
        if (!options.autoNavigate()) {
            lastMessage = "out of reach while " + activity;
            return;
        }

        Navigator.Options navOptions = new Navigator.Options(
                Math.max(1.5, options.reach() - 0.5), true, true, 60, 3);
        Navigator.State state = Navigator.get().tick(owner, pos, navOptions);

        lastMessage = switch (state) {
            case MOVING -> "walking to " + pos.toShortString();
            case ARRIVED -> "in position at " + pos.toShortString();
            case FAILED -> "cannot reach " + pos.toShortString();
            case IDLE -> "idle";
        };

        if (state == Navigator.State.FAILED) {
            queue.poll();
            failed++;
            report("warn", "Cannot reach %s, skipping", pos.toShortString());
        }
    }

    private static int findEmptyHotbarSlot() {
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isEmpty()) return i;
        }
        return -1;
    }

    /** Compares the world against the plan, tolerating forced waterlogging. */
    public static boolean matches(BlockState world, BlockState expected) {
        if (world == expected) return true;
        if (world.getBlock() != expected.getBlock()) return false;

        // Placing into water always yields a waterlogged state; treat that as a match so the engine
        // cannot loop on a block it can never place exactly.
        if (world.contains(net.minecraft.state.property.Properties.WATERLOGGED)
                && expected.contains(net.minecraft.state.property.Properties.WATERLOGGED)) {
            return world.with(net.minecraft.state.property.Properties.WATERLOGGED, false)
                    == expected.with(net.minecraft.state.property.Properties.WATERLOGGED, false);
        }

        return false;
    }

    private double etaSeconds() {
        if (phase != Phase.BUILDING || buildStartedAt == 0) return -1;

        long elapsedMs = System.currentTimeMillis() - buildStartedAt;
        int placedNow = placed;
        int delta = placedNow - placedAtBuildStart;
        if (elapsedMs < 4000 || delta <= 0) return -1;

        double blocksPerSecond = delta / (elapsedMs / 1000.0);
        if (blocksPerSecond <= 0.001) return -1;

        return remaining() / blocksPerSecond;
    }

    private static String name(BlockState state) {
        return state.getBlock().getName().getString();
    }

    private static String name(Block block) {
        return block.getName().getString();
    }

    private void report(String level, String message, Object... args) {
        lastMessage = message.formatted(args);
        if (reporter == null) return;

        switch (level) {
            case "error" -> HookStatus.error(reporter, message, args);
            case "warn" -> HookStatus.warn(reporter, message, args);
            default -> HookStatus.info(reporter, message, args);
        }
    }

    /** Used by the module to know whether it must hold the movement capability. */
    public boolean needsMovement() {
        return phase == Phase.BUILDING || phase == Phase.VERIFYING;
    }

    /** Debug helper used by the module's status command. */
    public String describe() {
        return phase + " " + verified + "/" + totalTargets() + " verified, " + queue.size() + " queued, "
                + skipped + " skipped, " + failed + " failed";
    }

    /** Releases everything the engine holds; called from the module's deactivate handler. */
    public void shutdown() {
        Navigator.get().stop(owner);
        MiningController.get().reset(owner);
        pending = null;
        queue.clear();
        TaskManager.get().release(owner);
    }
}
