package hook.imixin;

public interface IKeybinding {
   boolean hook$isActuallyPressed();

   void hook$resetPressed();
}
