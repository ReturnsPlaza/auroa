package hook.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
