package hook.event.events;

import hook.event.CancellableEvent;

public class AttackEvent extends CancellableEvent {
}
