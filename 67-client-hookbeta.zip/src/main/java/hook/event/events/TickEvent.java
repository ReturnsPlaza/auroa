package hook.event.events;

import hook.event.CancellableEvent;

public class TickEvent extends CancellableEvent {
}
