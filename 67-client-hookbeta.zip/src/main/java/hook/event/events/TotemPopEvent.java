package hook.event.events;

import hook.event.Event;

public final class TotemPopEvent implements Event {
}
