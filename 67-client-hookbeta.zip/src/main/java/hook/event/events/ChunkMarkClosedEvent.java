package hook.event.events;

import hook.event.CancellableEvent;

public class ChunkMarkClosedEvent extends CancellableEvent {
}
