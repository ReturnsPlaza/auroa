package hook.event.events;

import hook.event.CancellableEvent;

public class BlockBreakingEvent extends CancellableEvent {
}
