package hook.event.events;

import hook.event.CancellableEvent;

public class SendMovementPacketsEvent extends CancellableEvent {
}
