package hook.module.ext.event;

import net.minecraft.network.packet.Packet;

public final class PacketReceiveNettyEvent extends CancellableEvent {
   public static final EventType<PacketReceiveNettyEvent> TYPE = new EventType<>(PacketReceiveNettyEvent.class);
   public Packet<?> packet;

   public PacketReceiveNettyEvent(Packet<?> var1) {
      this.packet = var1;
   }
}
