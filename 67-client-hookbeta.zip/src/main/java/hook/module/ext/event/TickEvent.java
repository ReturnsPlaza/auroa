package hook.module.ext.event;

public final class TickEvent {
   public static final EventType<TickEvent> TYPE = new EventType<>(TickEvent.class);
}
