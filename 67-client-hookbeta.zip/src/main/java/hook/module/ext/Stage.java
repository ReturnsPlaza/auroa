package hook.module.ext;

public enum Stage {
   PRE,
   POST;
}
