package hook.module.modules.client;

import hook.event.EventListener;
import hook.event.events.PacketReceiveEvent;
import hook.event.events.TickEvent;
import hook.halloween.Halloween;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.utils.EncryptedString;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import hook.feature.HookClickGuiScreen;
import hook.feature.UiPalette;

public final class Hook extends Module {
   public static final ModeSetting<UiPalette> theme = new ModeSetting<>(EncryptedString.of("Theme"), UiPalette.Hook, UiPalette.class)
      .setDescription(EncryptedString.of("Accent, gradient and lighting colors of the client"));
   public static final BooleanSetting uiSounds = new BooleanSetting(EncryptedString.of("UI Sounds"), true)
      .setDescription(EncryptedString.of("Soft sounds for clicks, toggles and menus"));
   public static final NumberSetting uiVolume = new NumberSetting(EncryptedString.of("UI Volume"), 0.0, 100.0, 70.0, 1.0)
      .getValue(EncryptedString.of("Volume of the interface sounds in percent"));
   public static final BooleanSetting halloweenMusic = new BooleanSetting(EncryptedString.of("Halloween Music"), true)
      .setDescription(EncryptedString.of("Halloween song in the menu (Halloween theme)"));
   public static final NumberSetting halloweenVolume = new NumberSetting(EncryptedString.of("Halloween Music Volume"), 0.0, 100.0, 35.0, 1.0)
      .getValue(EncryptedString.of("How loud the Halloween menu music is"));
   public static final BooleanSetting beatShake = new BooleanSetting(EncryptedString.of("Beat Shake"), true)
      .setDescription(EncryptedString.of("The backdrop moves gently with the beat"));
   public static final NumberSetting shakeStrength = new NumberSetting(EncryptedString.of("Beat Shake Strength"), 0.0, 100.0, 50.0, 5.0)
      .getValue(EncryptedString.of("How strongly the background reacts to the beat"));
   public static final NumberSetting guiSize = new NumberSetting(EncryptedString.of("GUI Size"), 70.0, 140.0, 100.0, 5.0)
      .getValue(EncryptedString.of("Scale of the 67 Client menu in percent"));
   public static final BooleanSetting renderBackground = new BooleanSetting(EncryptedString.of("Background"), true)
      .setDescription(EncryptedString.of("Dims the world behind Hook editor screens"));
   private final BooleanSetting preventClose = new BooleanSetting(EncryptedString.of("Prevent Close"), true)
      .setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final ModeSetting<Hook.AnimationMode> animationMode = new ModeSetting<>(
      EncryptedString.of("Animations"), Hook.AnimationMode.NORMAL, Hook.AnimationMode.class
   );
   public boolean shouldPreventClose;

   public Hook() {
      super(EncryptedString.of("67 Client"), EncryptedString.of("Settings for the client"), 344, Category.CLIENT);
      this.addSettings(
         new Setting[]{
            theme, uiSounds, uiVolume, halloweenMusic, halloweenVolume, beatShake, shakeStrength, guiSize, renderBackground, this.preventClose, animationMode
         }
      );
   }

   @Override
   public void onEnable() {
      if (Halloween.guiLocked()) {
         this.setEnabled(false);
         Halloween.lockedNotice();
      } else {
         if (!(this.mc.currentScreen instanceof HookClickGuiScreen)) {
            hook.Hook.INSTANCE.screen = this.mc.currentScreen;
         }

         if (hook.Hook.INSTANCE.GUI != null) {
            hook.Hook.INSTANCE.GUI.prepareOpen();
            this.mc.setScreenAndRender(hook.Hook.INSTANCE.GUI);
         } else if (this.mc.player != null && this.mc.currentScreen instanceof InventoryScreen) {
            this.shouldPreventClose = true;
         }

         super.onEnable();
      }
   }

   @Override
   public void onDisable() {
      if (this.mc.currentScreen instanceof HookClickGuiScreen) {
         hook.Hook.INSTANCE.GUI.requestClose();
      } else if (this.mc.currentScreen instanceof InventoryScreen) {
         this.shouldPreventClose = false;
      }

      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (hook.Hook.INSTANCE.GUI != null) {
         hook.Hook.INSTANCE.GUI.syncAmbience();
      }
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent var1) {
      if (this.shouldPreventClose && var1.packet instanceof OpenScreenS2CPacket && this.preventClose.getValue()) {
         var1.cancel();
      }
   }

   public static enum AnimationMode {
      NORMAL("Normal", 0),
      POSITIVE("Positive", 1),
      OFF("Off", 2);

      private AnimationMode(final String nullxx, final int nullxxx) {
      }

      private static Hook.AnimationMode[] $values() {
         return new Hook.AnimationMode[]{NORMAL, POSITIVE, OFF};
      }
   }
}
