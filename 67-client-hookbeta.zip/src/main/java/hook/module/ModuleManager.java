package hook.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import hook.event.EventListener;
import hook.event.events.KeyEvent;
import hook.event.events.MouseButtonEvent;
import hook.module.modules.client.Hook;
import hook.module.setting.BindSetting;
import hook.utils.EncryptedString;
import net.minecraft.client.gui.screen.ChatScreen;
import hook.feature.HookClickGuiScreen;
import hook.feature.AnchorMacroModule;
import hook.feature.AutoCrystalModule;
import hook.feature.AutoInvTotemModule;
import hook.feature.AutoTotemModule;
import hook.feature.DoubleAnchorModule;
import hook.feature.ElytraSwapModule;
import hook.feature.HitboxModule;
import hook.feature.HoverTotemModule;
import hook.feature.MaceSwapModule;
import hook.feature.StaticHitboxesModule;
import hook.feature.AntiTrapModule;
import hook.feature.AntiVanishModule;
import hook.feature.AuctionSniperModule;
import hook.feature.AutoRtpModule;
import hook.feature.AutoSellModule;
import hook.feature.AutoSpawnerSellModule;
import hook.feature.SpawnerDropperModule;
import hook.feature.ChunkFinderModule;
import hook.feature.ChunkFinderBetterModule;
import hook.feature.FakeScoreboardModule;
import hook.feature.LuckyFinderModule;
import hook.feature.NetheriteFinderModule;
import hook.feature.OgScoreboardModule;
import hook.feature.PlayerBypassModule;
import hook.feature.PrimeChunkFinderModule;
import hook.feature.RegionMapModule;
import hook.feature.RtpBaseFinderModule;
import hook.feature.ShulkerDropperModule;
import hook.feature.SpawnerOrderModule;
import hook.feature.StaffListModule;
import hook.feature.SusChunkFinderModule;
import hook.feature.SusChunkV2Module;
import hook.feature.TunnelBaseFinderModule;
import hook.feature.SpawnerProtectModule;
import hook.feature.AutoEatModule;
import hook.feature.AutoFireworkModule;
import hook.feature.AutoMineModule;
import hook.feature.AutoTpaModule;
import hook.feature.AutoToolModule;
import hook.feature.CordSnapperModule;
import hook.feature.ElytraGlideModule;
import hook.feature.FakePayModule;
import hook.feature.FastPlaceModule;
import hook.feature.FreecamModule;
import hook.feature.FullbrightModule;
import hook.feature.FreelookModule;
import hook.feature.NameProtectModule;
import hook.feature.PlayerDetectionModule;
import hook.feature.SkinProtectModule;
import hook.feature.SwingSpeedModule;
import hook.feature.BedrockEspModule;
import hook.feature.BlockEspModule;
import hook.feature.BlockNotifierModule;
import hook.feature.BlockOverlayModule;
import hook.feature.CustomSkysModule;
import hook.feature.CustomToolsModule;
import hook.feature.CustomTotemModule;
import hook.feature.HudModule;
import hook.feature.HalloweenModule;
import hook.feature.HandAuraModule;
import hook.feature.ItemOutlineModule;
import hook.feature.PlayerEspModule;
import hook.feature.SpawnerNotifyModule;
import hook.feature.StorageEspModule;
import hook.feature.TargetHudModule;
import hook.feature.Character3dModule;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<?>, Module> modulesByClass = new HashMap<>();
   private final Map<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.a(new ElytraSwapModule());
      this.a(new MaceSwapModule());
      this.a(new HitboxModule());
      this.a(new StaticHitboxesModule());
      this.a(new AutoTotemModule());
      this.a(new HoverTotemModule());
      this.a(new AutoInvTotemModule());
      this.a(new AnchorMacroModule());
      this.a(new AutoCrystalModule());
      this.a(new DoubleAnchorModule());
      this.a(new FastPlaceModule());
      this.a(new FreecamModule());
      this.a(new FreelookModule());
      this.a(new AutoFireworkModule());
      this.a(new ElytraGlideModule());
      this.a(new AutoToolModule());
      this.a(new SwingSpeedModule());
      this.a(new AutoEatModule());
      this.a(new AutoMineModule());
      this.a(new CordSnapperModule());
      this.a(new NameProtectModule());
      this.a(new SkinProtectModule());
      this.a(new PlayerDetectionModule());
      this.a(new FakePayModule());
      this.macro(new AutoTpaModule());
      this.macro(new AutoRtpModule());
      this.macro(new SpawnerProtectModule());
      this.a(new ChunkFinderModule());
      this.a(new SpawnerOrderModule());
      this.a(new RtpBaseFinderModule());
      this.a(new TunnelBaseFinderModule());
      this.a(new NetheriteFinderModule());
      this.macro(new SpawnerDropperModule());
      this.macro(new AutoSellModule());
      this.macro(new ShulkerDropperModule());
      this.a(new AntiTrapModule());

      try {
         this.macro(new AuctionSniperModule());
      } catch (RuntimeException var3) {
         System.err.println("Hook: Auction Sniper unavailable: " + var3.getMessage());
      }

      this.macro(new AutoSpawnerSellModule());
      this.a(new FakeScoreboardModule());
      this.a(new OgScoreboardModule());
      this.a(new RegionMapModule());
      this.a(new PlayerBypassModule());
      this.a(new SusChunkFinderModule());
      this.a(new SusChunkV2Module());
      this.a(new ChunkFinderBetterModule());
      this.safe("Prime Chunk Finder", PrimeChunkFinderModule::new);
      this.safe("Anti Vanish", AntiVanishModule::new);
      this.safe("Halloween", HalloweenModule::new);
      this.safe("Custom Totem", CustomTotemModule::new);
      this.safe("Custom Tools", CustomToolsModule::new);
      this.a(new PlayerEspModule());
      this.a(new StorageEspModule());
      this.a(new BlockEspModule());
      this.a(new BlockNotifierModule());
      this.a(new BedrockEspModule());
      this.a(new SpawnerNotifyModule());
      this.a(new TargetHudModule());
      this.safe("3D Character", Character3dModule::new);
      this.safe("Custom Skys", CustomSkysModule::new);
      this.safe("Block Overlay", BlockOverlayModule::new);
      this.safe("Fullbright", FullbrightModule::new);
      this.safe("Hand Aura", HandAuraModule::new);
      this.a(new Hook());
      this.a(new HudModule());

      try {
         this.a(new ItemOutlineModule());
      } catch (Throwable var2) {
         System.err.println("Hook: Item Outline unavailable: " + var2.getClass().getSimpleName());
      }

      this.a(new LuckyFinderModule());
      this.a(new StaffListModule());
   }

   public List<Module> b() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      hook.Hook.INSTANCE.getEventBus().register(this);

      for (Module var2 : this.modules) {
         var2.addSetting(
            new BindSetting(EncryptedString.of("Keybind"), var2.getKeybind(), true).setDescription(EncryptedString.of("Key to enabled the module"))
         );
      }
   }

   public List<Module> a(Category var1) {
      return this.modulesByCategory.getOrDefault(var1, List.of());
   }

   public Module getModuleByClass(Class<? extends Module> var1) {
      Module var2 = this.modulesByClass.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         for (Module var4 : this.modules) {
            if (var1.isInstance(var4)) {
               return var4;
            }
         }

         return null;
      }
   }

   private void safe(String var1, Supplier<? extends Module> var2) {
      try {
         this.a((Module)var2.get());
      } catch (Throwable var4) {
         System.err.println("Hook: " + var1 + " unavailable: " + var4);
         var4.printStackTrace(System.err);
      }
   }

   private void macro(Module var1) {
      var1.setCategory(Category.MACROS);
      this.a(var1);
   }

   public void a(Module var1) {
      hook.Hook.INSTANCE.getEventBus().register(var1);
      this.modules.add(var1);
      this.modulesByClass.put(var1.getClass(), var1);
      this.modulesByCategory.computeIfAbsent(var1.getCategory(), var0 -> new ArrayList<>()).add(var1);
   }

   @EventListener
   public void a(KeyEvent var1) {
      if (var1.mode == 1 && (hook.Hook.mc == null || !(hook.Hook.mc.currentScreen instanceof HookClickGuiScreen var2) || !var2.isTyping())) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2x;
                  if (var1x.getKeybind() == var1.key
                     && (
                        (var2x = var1x instanceof Hook)
                           || hook.Hook.mc.player != null && hook.Hook.mc.options != null && !(hook.Hook.mc.currentScreen instanceof ChatScreen)
                     )) {
                     var1x.toggle();
                  }
               }
            );
      }
   }

   @EventListener
   public void onMouseButton(MouseButtonEvent var1) {
      if (var1.actions == 1
         && var1.button >= 0
         && var1.button <= 7
         && !(hook.Hook.mc.currentScreen instanceof HookClickGuiScreen)
         && !(hook.Hook.mc.currentScreen instanceof ChatScreen)) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2;
                  if (var1x.getKeybind() == var1.button
                     && ((var2 = var1x instanceof Hook) || hook.Hook.mc.player != null && hook.Hook.mc.options != null)) {
                     var1x.toggle();
                  }
               }
            );
      }
   }
}
