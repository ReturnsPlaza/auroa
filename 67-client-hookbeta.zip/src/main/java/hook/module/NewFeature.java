package hook.module;

public interface NewFeature {
}
