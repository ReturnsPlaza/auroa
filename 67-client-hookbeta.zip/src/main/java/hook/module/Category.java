package hook.module;

import hook.utils.EncryptedString;

public enum Category {
   COMBAT(EncryptedString.of("Combat")),
   MISC(EncryptedString.of("Misc")),
   MACROS(EncryptedString.of("Macros")),
   DONUT(EncryptedString.of("Donut")),
   RENDER(EncryptedString.of("Render")),
   AUTOMATION(EncryptedString.of("Automation")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(final CharSequence nullxx) {
      this.name = nullxx;
   }
}
