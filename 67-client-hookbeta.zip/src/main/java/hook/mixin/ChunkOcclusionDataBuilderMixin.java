package hook.mixin;

import hook.event.events.ChunkMarkClosedEvent;
import hook.manager.EventManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.render.chunk.ChunkOcclusionDataBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ChunkOcclusionDataBuilder.class})
public abstract class ChunkOcclusionDataBuilderMixin {
   @Inject(
      method = {"markClosed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMarkClosed(BlockPos var1, CallbackInfo var2) {
      if (EventManager.hasActiveListener(ChunkMarkClosedEvent.class)) {
         ChunkMarkClosedEvent var3 = new ChunkMarkClosedEvent();
         EventManager.b(var3);
         if (var3.isCancelled()) {
            var2.cancel();
         }
      }
   }
}
