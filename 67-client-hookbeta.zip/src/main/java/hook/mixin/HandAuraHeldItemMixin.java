package hook.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.command.RenderDispatcher;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.HeldItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import hook.feature.HandAuraModule;

@Environment(EnvType.CLIENT)
@Mixin({HeldItemRenderer.class})
public abstract class HandAuraHeldItemMixin {
   @WrapOperation(
      method = {"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/command/RenderDispatcher;render()V"
      )}
   )
   private void hook$handAura(RenderDispatcher var1, Operation<Void> var2) {
      if (HandAuraModule.active != null && HandAuraModule.beginCapture()) {
         boolean var3 = false;

         try {
            var2.call(new Object[]{var1});
            MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers().draw();
            var3 = true;
         } finally {
            HandAuraModule.endCapture(var3);
         }
      } else {
         var2.call(new Object[]{var1});
      }
   }
}
