package hook.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import hook.feature.CharacterRenderStateAccess;
import hook.feature.WornCharacterModel;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderState.class})
public abstract class CharacterRenderStateMixin implements CharacterRenderStateAccess {
   @Unique
   private WornCharacterModel hook$character;
   @Unique
   private float hook$seat;

   @Override
   public WornCharacterModel hook$character() {
      return this.hook$character;
   }

   @Override
   public void hook$setCharacter(WornCharacterModel var1) {
      this.hook$character = var1;
   }

   @Override
   public float hook$seat() {
      return this.hook$seat;
   }

   @Override
   public void hook$setSeat(float var1) {
      this.hook$seat = var1;
   }
}
