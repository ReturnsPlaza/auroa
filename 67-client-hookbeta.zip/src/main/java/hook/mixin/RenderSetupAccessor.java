package hook.mixin;

import java.util.Map;
import net.minecraft.client.render.RenderSetup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(
   value = {RenderSetup.class},
   remap = true
)
public interface RenderSetupAccessor {
   @Accessor(
      value = "textures",
      remap = true
   )
   Map<?, ?> hook$getTextures();
}
