package hook.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import hook.feature.HookClickGuiScreen;

@Mixin({GameRenderer.class})
public abstract class GuiBlurMixin {
   @ModifyArg(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gl/GlobalSettings;set(IIDJLnet/minecraft/client/render/RenderTickCounter;ILnet/minecraft/client/render/Camera;Z)V"
      ),
      index = 5
   )
   private int hook$fadeMenuBlur(int var1) {
      return HookClickGuiScreen.blurRadius(var1);
   }
}
