package hook.mixin;

import hook.module.ext.ExtBridge;
import hook.module.ext.Stage;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public abstract class ExtTickMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void hook$extTickStart(CallbackInfo var1) {
      ExtBridge.tick(Stage.PRE);
   }

   @Inject(
      method = {"tick"},
      at = {@At("RETURN")}
   )
   private void hook$extTickEnd(CallbackInfo var1) {
      ExtBridge.tick(Stage.POST);
   }
}
