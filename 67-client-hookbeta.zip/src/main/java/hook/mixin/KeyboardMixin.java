package hook.mixin;

import hook.event.events.KeyEvent;
import hook.manager.EventManager;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Keyboard.class})
public class KeyboardMixin {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPress(long window, int action, KeyInput input, CallbackInfo ci) {
      int key = input.key();
      if (key != -1) {
         KeyEvent event = new KeyEvent(key, window, action);
         EventManager.b(event);
         if (event.isCancelled()) {
            ci.cancel();
         }
      }
   }
}
