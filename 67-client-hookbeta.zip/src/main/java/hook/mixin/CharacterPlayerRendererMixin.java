package hook.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.client.network.ClientPlayerLikeEntity;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import hook.feature.CharacterFeatureRenderer;
import hook.feature.Character3dModule;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderer.class})
public abstract class CharacterPlayerRendererMixin<T extends PlayerLikeEntity & ClientPlayerLikeEntity> extends LivingEntityRenderer<T, PlayerEntityRenderState, PlayerEntityModel> {
   protected CharacterPlayerRendererMixin(Context var1, PlayerEntityModel var2, float var3) {
      super(var1, var2, var3);
   }

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   private void hook$addCharacterLayer(Context var1, boolean var2, CallbackInfo var3) {
      this.addFeature(new CharacterFeatureRenderer(this));
   }

   @Inject(
      method = {"updateRenderState"},
      at = {@At("TAIL")}
   )
   private void hook$extractCharacter(PlayerLikeEntity var1, PlayerEntityRenderState var2, float var3, CallbackInfo var4) {
      Character3dModule.extract(var1, var2);
   }

   @Inject(
      method = {"renderArm"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hook$characterFirstPersonHand(MatrixStack var1, OrderedRenderCommandQueue var2, int var3, Identifier var4, ModelPart var5, boolean var6, CallbackInfo var7) {
      if (CharacterFeatureRenderer.firstPersonHand((PlayerEntityModel)(Object)this.getModel(), var1, var2, var3, var5)) {
         var7.cancel();
      }
   }
}
