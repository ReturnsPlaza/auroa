package hook.mixin;

import hook.module.ext.ExtBridge;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientWorld.class})
public abstract class ExtWorldMixin {
   @Inject(
      method = {"updateListeners"},
      at = {@At("HEAD")}
   )
   private void hook$extBlockUpdated(BlockPos var1, BlockState var2, BlockState var3, int var4, CallbackInfo var5) {
      ExtBridge.blockUpdate(var1, var2, var3);
   }
}
