package hook.mixin;

import hook.Hook;
import hook.imixin.IKeybinding;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({KeyBinding.class})
public abstract class KeyBindingMixin implements IKeybinding {
   @Shadow
   private Key boundKey;

   @Shadow
   public abstract void setPressed(boolean var1);

   @Override
   public boolean hook$isActuallyPressed() {
      return InputUtil.isKeyPressed(Hook.mc.getWindow(), this.boundKey.getCode());
   }

   @Override
   public void hook$resetPressed() {
      this.setPressed(this.hook$isActuallyPressed());
   }
}
