package hook.mixin;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import hook.module.ext.ExtBridge;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.NetworkSide;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientConnection.class})
public abstract class ExtConnectionMixin {
   @Shadow
   public abstract NetworkSide getSide();

   @Inject(
      method = {"channelRead0"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hook$extPacketReceive(ChannelHandlerContext var1, Packet<?> var2, CallbackInfo var3) {
      if (this.getSide() == NetworkSide.CLIENTBOUND && ExtBridge.packetReceive(var2)) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hook$extPacketSend(Packet<?> var1, ChannelFutureListener var2, boolean var3, CallbackInfo var4) {
      if (this.getSide() == NetworkSide.CLIENTBOUND && ExtBridge.packetSend(var1)) {
         var4.cancel();
      }
   }
}
