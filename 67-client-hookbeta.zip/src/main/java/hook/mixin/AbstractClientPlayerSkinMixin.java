package hook.mixin;

import com.mojang.authlib.GameProfile;
import hook.Hook;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import hook.feature.SkinProtectModule;

@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerSkinMixin {
   @Inject(
      method = {"method_52814"},
      at = {@At("RETURN")},
      cancellable = true,
      remap = false
   )
   private void hook$replacePlayerSkin(CallbackInfoReturnable<SkinTextures> var1) {
      if (Hook.INSTANCE != null && Hook.INSTANCE.MODULE_MANAGER != null) {
         SkinProtectModule var2 = (SkinProtectModule)Hook.INSTANCE.MODULE_MANAGER.getModuleByClass(SkinProtectModule.class);
         if (var2 != null && var2.isEnabled()) {
            AbstractClientPlayerEntity var3 = (AbstractClientPlayerEntity)(Object)this;
            GameProfile var4 = var3.getGameProfile();
            var1.setReturnValue(var2.replacementFor(var4.id(), var4.name(), (SkinTextures)var1.getReturnValue()));
         }
      }
   }
}
