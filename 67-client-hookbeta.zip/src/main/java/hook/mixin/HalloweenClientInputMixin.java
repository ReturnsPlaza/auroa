package hook.mixin;

import hook.halloween.CinematicCamera;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public abstract class HalloweenClientInputMixin {
   @Inject(
      method = {"handleInputEvents"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hook$swallowInput(CallbackInfo var1) {
      if (CinematicCamera.inputLocked()) {
         MinecraftClient var2 = (MinecraftClient)(Object)this;
         if (var2.options != null) {
            for (KeyBinding var6 : var2.options.allKeys) {
               while (var6.wasPressed()) {
               }
            }
         }

         var1.cancel();
      }
   }
}
