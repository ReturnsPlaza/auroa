package hook.mixin;

import hook.feature.FullbrightModule;
import net.minecraft.client.render.LightmapTextureManager;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Fullbright: bends the two lightmap uniforms the Halloween mixin does not touch.
 *
 * <p>{@code LightmapTextureManager.update} writes the shader block in declaration order:
 * seven floats (ambient factor, sky factor, block factor, night vision, darkness, darkened world,
 * brightness) then two vec3s (sky light colour, ambient colour). Only ordinals 1, 2, 3, 5 and 6 of
 * the floats plus vec3 ordinal 0 are taken by {@link HalloweenLightmapMixin}, so ambient factor
 * (float ordinal 0) and ambient colour (vec3 ordinal 1) are free and cannot conflict.
 *
 * <p>With the ambient factor at 1 the shader replaces its computed colour with the ambient colour
 * before the darkness, darkened-world and night-vision branches run (all gated on the factor being
 * exactly 0), so the lightmap ends up white regardless of light level, gamma slider or potion
 * effects.
 */
@Mixin({LightmapTextureManager.class})
public abstract class FullbrightLightmapMixin {
   private static final Vector3fc HOOK_WHITE = new Vector3f(1.0F, 1.0F, 1.0F);

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putFloat(F)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 0
      )
   )
   private float hook$fullbrightAmbientFactor(float ambient) {
      float strength = FullbrightModule.strength();
      if (strength <= 0.0F) {
         return ambient;
      }

      // Blend the dimension's ambient light toward 1 so Strength below 100 keeps some shading.
      return ambient + (1.0F - ambient) * strength;
   }

   @ModifyArg(
      method = {"update"},
      at = @At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/buffers/Std140Builder;putVec3(Lorg/joml/Vector3fc;)Lcom/mojang/blaze3d/buffers/Std140Builder;",
         ordinal = 1
      )
   )
   private Vector3fc hook$fullbrightAmbientColor(Vector3fc ambientColor) {
      return FullbrightModule.strength() > 0.0F ? HOOK_WHITE : ambientColor;
   }
}