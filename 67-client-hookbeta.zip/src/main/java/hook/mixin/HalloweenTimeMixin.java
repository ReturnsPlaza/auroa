package hook.mixin;

import hook.halloween.HalloweenAtmosphere;
import net.minecraft.world.World;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({World.class})
public abstract class HalloweenTimeMixin {
   @Inject(
      method = {"getTimeOfDay"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void hook$halloweenTime(CallbackInfoReturnable<Long> var1) {
      if ((Object)this instanceof ClientWorld && HalloweenAtmosphere.overridingTime()) {
         var1.setReturnValue(HalloweenAtmosphere.timeOfDay((World)(Object)this, var1.getReturnValueJ()));
      }
   }
}
