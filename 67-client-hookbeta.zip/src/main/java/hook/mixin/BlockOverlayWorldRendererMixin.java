package hook.mixin;

import hook.module.ext.ModuleRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import hook.feature.BlockOverlayModule;

@Environment(EnvType.CLIENT)
@Mixin({WorldRenderer.class})
public abstract class BlockOverlayWorldRendererMixin {
   @Inject(
      method = {"renderTargetBlockOutline"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hook$hideVanillaOutline(CallbackInfo var1) {
      BlockOverlayModule var2 = ModuleRegistry.get(BlockOverlayModule.class);
      if (var2 != null && var2.isEnabled()) {
         var1.cancel();
      }
   }
}
