package hook.mixin;

import hook.event.events.MouseButtonEvent;
import hook.event.events.MouseScrolledEvent;
import hook.manager.EventManager;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public abstract class MouseMixin {
   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseButton(long window, MouseInput input, int action, CallbackInfo ci) {
      int button = input.button();
      if (button != -1) {
         MouseButtonEvent event = new MouseButtonEvent(button, window, action);
         EventManager.b(event);
         if (event.isCancelled()) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      MouseScrolledEvent event = new MouseScrolledEvent(vertical);
      EventManager.b(event);
      if (event.isCancelled()) {
         ci.cancel();
      }
   }
}
