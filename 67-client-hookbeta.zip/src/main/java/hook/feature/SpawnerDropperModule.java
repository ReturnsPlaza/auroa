package hook.feature;

import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.module.setting.BooleanSetting;
import hook.utils.EncryptedString;
import net.minecraft.util.Hand;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos.Mutable;

public final class SpawnerDropperModule extends Module {
   private static final int CHECK_DELAY = 3;
   private final BooleanSetting notifications = new BooleanSetting(
      EncryptedString.of("Notifications"), true
   );
   private final NumberSetting delay = new NumberSetting(
      EncryptedString.of("Delay"),
      1.0,
      20.0,
      5.0,
      1.0
   );
   private final BooleanSetting boneOnly = new BooleanSetting(
      EncryptedString.of("Bone Only"), true
   );
   private final NumberSetting autoReopenInterval = new NumberSetting(
      EncryptedString.of("Auto Reopen Interval"),
      1.0,
      600.0,
      10.0,
      1.0
   );
   private int tickCounter;
   private int currentStep;
   private int checkDelayCounter;
   private int reopenTimer;
   private BlockPos spawnerPos;
   private boolean waitingForInterval;

   public SpawnerDropperModule() {
      super(
         EncryptedString.of("Spawner Dropper"),
         EncryptedString.of("Drops all items from nearby spawners"),
         -1,
         Category.MISC
      );
      Setting[] var10001 = new Setting[4];
      var10001[0] = this.notifications;
      var10001[1] = this.delay;
      var10001[2] = this.boneOnly;
      var10001[3] = this.autoReopenInterval;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.reset();
      this.message(
         "Spawner Dropper activated - looking for a nearby spawner."
      );
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.reset();
      if (this.mc.player != null && this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
         this.mc.player.closeHandledScreen();
      }

      super.onDisable();
   }

   private void reset() {
      this.tickCounter = 0;
      this.currentStep = 0;
      this.checkDelayCounter = 0;
      this.reopenTimer = 0;
      this.spawnerPos = null;
      this.waitingForInterval = false;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null) {
         if (this.spawnerPos == null || !this.mc.world.getBlockState(this.spawnerPos).isOf(Blocks.SPAWNER)) {
            this.spawnerPos = this.findNearbySpawner();
            if (this.spawnerPos != null) {
               this.message("Spawner detected nearby.");
            }
         }

         this.reopenTimer += 1;
         int var2 = this.autoReopenInterval.getIntValue() * (60) * (20);
         if (this.waitingForInterval) {
            if (this.reopenTimer >= var2) {
               this.openSpawner();
            }
         } else if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var3) {
            if (var3.slots.size() > (53)) {
               if (this.boneOnly.getValue() && this.hasArrows(var3)) {
                  this.message(
                     "Arrows detected - waiting for the next interval."
                  );
                  this.mc.player.closeHandledScreen();
                  this.waitingForInterval = true;
                  this.reopenTimer = 0;
               } else if (this.currentStep != (2) && this.currentStep != (5)) {
                  if ((this.tickCounter += 1) >= this.delay.getIntValue()) {
                     this.tickCounter = 0;
                     switch (this.currentStep) {
                        case 0:
                           this.click(var3, 50);
                           this.currentStep = 1;
                           break;
                        case 1:
                           this.click(var3, 53);
                           this.currentStep = 2;
                           this.checkDelayCounter = 0;
                        case 2:
                        default:
                           break;
                        case 3:
                           this.click(var3, 50);
                           this.currentStep = 4;
                           break;
                        case 4:
                           this.click(var3, 53);
                           this.currentStep = 5;
                           this.checkDelayCounter = 0;
                     }
                  }
               } else {
                  if ((this.checkDelayCounter += 1) >= (3)) {
                     if (var3.getSlot(0).getStack().isEmpty()) {
                        this.message(
                           "Spawner emptied - waiting for the next interval."
                        );
                        this.mc.player.closeHandledScreen();
                        this.waitingForInterval = true;
                        this.reopenTimer = 0;
                     } else {
                        this.currentStep = this.currentStep == (2)
                           ? 3
                           : 0;
                        this.checkDelayCounter = 0;
                     }
                  }
               }
            }
         } else {
            if (this.spawnerPos != null && (this.reopenTimer >= var2 || this.reopenTimer == (20))) {
               this.openSpawner();
            }
         }
      }
   }

   private boolean hasArrows(GenericContainerScreenHandler var1) {
      for (int var2 = 0; var2 <= (44) && var2 < var1.slots.size(); var2++) {
         if (var1.getSlot(var2).getStack().isOf(Items.ARROW)) {
            return true;
         }
      }

      return false;
   }

   private BlockPos findNearbySpawner() {
      BlockPos var1 = this.mc.player.getBlockPos();
      Mutable var2 = new Mutable();

      for (int var3 = -6; var3 <= (6); var3++) {
         for (int var4 = -6; var4 <= (6); var4++) {
            for (int var5 = -6; var5 <= (6); var5++) {
               var2.set(var1.getX() + var3, var1.getY() + var4, var1.getZ() + var5);
               if (this.mc.world.getBlockState(var2).isOf(Blocks.SPAWNER)) {
                  return var2.toImmutable();
               }
            }
         }
      }

      return null;
   }

   private void openSpawner() {
      if (this.spawnerPos != null) {
         BlockHitResult var1 = new BlockHitResult(
            Vec3d.ofCenter(this.spawnerPos), Direction.UP, this.spawnerPos, false
         );
         this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, var1);
         this.currentStep = 0;
         this.checkDelayCounter = 0;
         this.tickCounter = 0;
         this.waitingForInterval = false;
         this.reopenTimer = 0;
      }
   }

   private void click(GenericContainerScreenHandler var1, int var2) {
      this.mc.interactionManager.clickSlot(var1.syncId, var2, 0, SlotActionType.PICKUP, this.mc.player);
   }

   private void message(String var1) {
      if (this.notifications.getValue() && this.mc.player != null) {
         this.mc.player.sendMessage(Text.literal("§b[Spawner Dropper] §f" + var1), false);
      }
   }
}
