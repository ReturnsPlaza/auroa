package hook.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.command.RenderCommandQueue;
import net.minecraft.client.render.command.OrderedRenderCommandQueue.Custom;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.model.BipedEntityModel.ArmPose;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@Environment(EnvType.CLIENT)
final class CharacterMeshRenderer {
   private static final int GHOST_ALPHA = 38;
   private static final CharacterBone[] BONES = CharacterBone.values();
   private static final Quaternionf ROTATION = new Quaternionf();
   private static final float[] LEVELS = new float[153];
   private static final float[] PITCH = new float[BONES.length];
   private static final float[] JOINT = new float[BONES.length];
   private static final float[] JOINT_LEVELS = new float[153];
   private static float[] scratch = new float[24576];

   private CharacterMeshRenderer() {
   }

   static void submit(WornCharacterModel var0, PlayerEntityModel var1, MatrixStack var2, OrderedRenderCommandQueue var3, int var4, PlayerEntityRenderState var5) {
      BakedCharacterData var6 = var0.model;
      BakedCharacterPart[] var7 = var6.parts;
      boolean var8 = var5.invisible;
      int var9 = LivingEntityRenderer.getOverlay(var5, 0.0F);
      float[] var10 = pitches(var5, var6, var1);
      float[] var11 = joints(var5, var6);
      float var12 = var1.head.pitch;
      float var13 = -var1.head.yaw;
      float[] var14 = CharacterMotionAnimator.update(var5, var6, var1, var10);
      var2.push();
      var1.getRootPart().applyTransform(var2);
      lift(var2, var5, var6);

      for (int var15 = 0; var15 < var7.length; var15++) {
         BakedCharacterPart var16 = var7[var15];
         if (var16.base != null || var16.outline != null || var16.decals != null) {
            int var17 = var16.bends() && var14 != null ? 1 : 0;
            float var18 = var17 != 0 ? var14[var16.motionSlot * (3)] : 0.0F;
            float var19 = var17 != 0
               ? var14[var16.motionSlot * (3) + (1)]
               : 0.0F;
            float var20 = var17 != 0
               ? var14[var16.motionSlot * (3) + (2)]
               : 0.0F;
            float var21 = 0.0F;
            float var22 = 0.0F;
            if (var16.neck) {
               var21 = look(var16.lookPitch * var12, var16.lookLimit);
               var22 = look(var16.lookYaw * var13, var16.lookLimit);
            } else if (var16.jointed) {
               var21 = var11[var16.bone.ordinal()];
            }

            var2.push();
            chain(var2, var1, var6, var15, var14, ((var17 == 0)), null, var10);
            submitPart(var0, var16, var2, var3, var4, var9, var8, (var17 != 0), var18, var19, var20, var21, var22);
            var2.pop();
         }
      }

      var2.pop();
   }

   static boolean firstPersonHand(PlayerEntityModel var0, MatrixStack var1, OrderedRenderCommandQueue var2, int var3, ModelPart var4) {
      WornCharacterModel var5 = Character3dModule.firstPerson();
      if (var5 == null) {
         return false;
      } else {
         CharacterBone var6 = var4 == var0.rightArm ? CharacterBone.RIGHT_ARM : CharacterBone.LEFT_ARM;
         BakedCharacterData var7 = var5.model;
         BakedCharacterPart var8 = var7.part(var6);
         if (var8 != null && var8.base != null) {
            var4.resetTransform();
            var4.roll = var6 == CharacterBone.RIGHT_ARM
               ? 0.10000000149011612F
               : -0.10000000149011612F;
            BakedCharacterPart[] var9 = var7.parts;

            for (int var10 = 0; var10 < var9.length; var10++) {
               BakedCharacterPart var11 = var9[var10];
               if (var11.bone == var6 && (var11.base != null || var11.outline != null || var11.decals != null)) {
                  var1.push();
                  chain(var1, var0, var7, var10, null, true, var4, null);
                  submitPart(
                     var5,
                     var11,
                     var1,
                     var2,
                     var3,
                     OverlayTexture.DEFAULT_UV,
                     false,
                     false,
                     0.0F,
                     0.0F,
                     0.0F,
                     0.0F,
                     0.0F
                  );
                  var1.pop();
               }
            }

            return true;
         } else {
            return false;
         }
      }
   }

   private static void submitPart(
      WornCharacterModel var0,
      BakedCharacterPart var1,
      MatrixStack var2,
      OrderedRenderCommandQueue var3,
      int var4,
      int var5,
      boolean var6,
      boolean var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12
   ) {
      if (var6) {
         if (var1.base != null) {
            var3.getBatchingQueue(1)
               .submitCustom(
                  var2,
                  var0.ghost,
                  (var9x, var10x) -> emit(
                        var9x, var10x, var1.base, var4, var5, 38, var7, var8, var9, var10, var1, var11, var12
                     )
               );
         }
      } else {
         if (var1.base != null || var1.outline != null) {
            var3.submitCustom(var2, var0.solid, (var9x, var10x) -> {
               if (var1.base != null) {
                  emit(var9x, var10x, var1.base, var4, var5, 255, var7, var8, var9, var10, var1, var11, var12);
               }

               if (var1.outline != null) {
                  emit(var9x, var10x, var1.outline, var4, var5, 255, var7, var8, var9, var10, var1, var11, var12);
               }
            });
         }

         if (var1.decals != null) {
            var3.getBatchingQueue(1)
               .submitCustom(
                  var2,
                  var0.decal,
                  (var9x, var10x) -> emit(
                        var9x, var10x, var1.decals, var4, var5, 255, var7, var8, var9, var10, var1, var11, var12
                     )
               );
         }
      }
   }

   static boolean translateToHand(PlayerEntityModel var0, PlayerEntityRenderState var1, Arm var2, MatrixStack var3) {
      WornCharacterModel var4 = Character3dModule.worn(var1);
      if (var4 == null) {
         return false;
      } else {
         BakedCharacterData var5 = var4.model;
         CharacterBone var6 = var2 == Arm.RIGHT ? CharacterBone.RIGHT_ARM : CharacterBone.LEFT_ARM;
         BakedCharacterPart var7 = var5.part(var6);
         if (var7 == null) {
            return false;
         } else {
            float var8 = var5.scale;
            ModelPart var9 = vanilla(var0, var6);
            var0.getRootPart().applyTransform(var3);
            lift(var3, var1, var5);
            pivot(var3, var9, var7, var8, pitch(var1, var7, var9.pitch));
            float var10 = var7.jointed
               ? CharacterJointAngles.angle(var1, var6, walk(var1, var6) * weight(var1, var6))
               : 0.0F;
            if (var10 != 0.0F) {
               float var11 = var7.jointY * var8 / 16.0F;
               float var12 = var7.jointZ * var8 / 16.0F;
               var3.translate(0.0F, -var11, -var12);
               var3.multiply(ROTATION.rotationX(var10));
               var3.translate(0.0F, var11, var12);
            }

            var3.translate(
               (var7.gripX - var7.pivotX) * var8 / 16.0F,
               -(var7.gripY - var7.pivotY) * var8 / 16.0F,
               -(var7.gripZ - var7.pivotZ) * var8 / 16.0F
            );
            var3.scale(var8, var8, var8);
            var3.translate(
               (var2 == Arm.RIGHT ? 1.0F : -1.0F)
                  / 16.0F,
               -0.625F,
               0.125F
            );
            return true;
         }
      }
   }

   private static float[] pitches(PlayerEntityRenderState var0, BakedCharacterData var1, PlayerEntityModel var2) {
      float[] var3 = PITCH;
      CharacterBone[] var4 = BONES;
      int var5 = var4.length;

      for (int var6 = 0; var6 < var5; var6++) {
         CharacterBone var7 = var4[var6];
         float var8 = vanilla(var2, var7).pitch;
         BakedCharacterPart var9 = !var7.arm() && !var7.leg() ? null : var1.part(var7);
         var3[var7.ordinal()] = var9 == null ? var8 : pitch(var0, var9, var8);
      }

      return var3;
   }

   private static float pitch(PlayerEntityRenderState var0, BakedCharacterPart var1, float var2) {
      float var3 = var1.swingPitch(var2, walk(var0, var1.bone), weight(var0, var1.bone));
      if (var1.jointed && var1.bone.leg() && var0.isInSneakingPose && !var0.hasVehicle) {
         var3 -= 0.5F * (1.0F - var0.leaningPitch);
      }

      return var3;
   }

   private static float[] joints(PlayerEntityRenderState var0, BakedCharacterData var1) {
      float[] var2 = JOINT;
      CharacterBone[] var3 = BONES;
      int var4 = var3.length;

      for (int var5 = 0; var5 < var4; var5++) {
         CharacterBone var6 = var3[var5];
         BakedCharacterPart var7 = !var6.arm() && !var6.leg() ? null : var1.part(var6);
         var2[var6.ordinal()] = var7 != null && var7.jointed
            ? CharacterJointAngles.angle(var0, var6, walk(var0, var6) * weight(var0, var6))
            : 0.0F;
      }

      return var2;
   }

   private static float look(float var0, float var1) {
      float var2 = var1 * 0.01745329238474369F;
      return MathHelper.clamp(var0, -var2, var2);
   }

   private static float walk(PlayerEntityRenderState var0, CharacterBone var1) {
      float var2 = var0.limbSwingAnimationProgress * 0.6661999821662903F;
      float var3 = var0.limbSwingAmplitude / var0.limbAmplitudeInverse;

      return switch (var1) {
         case RIGHT_LEG-> MathHelper.cos((double)var2) * 1.399999976158142F * var3;
         case LEFT_LEG-> MathHelper.cos((double)(var2 + 3.1415927410125732F)) * 1.399999976158142F * var3;
         case RIGHT_ARM-> MathHelper.cos((double)(var2 + 3.1415927410125732F)) * var3;
         case LEFT_ARM-> MathHelper.cos((double)var2) * var3;
         default -> 0.0F;
      };
   }

   private static float weight(PlayerEntityRenderState var0, CharacterBone var1) {
      if (var1.leg()) {
         return var0.hasVehicle ? 0.0F : 1.0F - var0.leaningPitch;
      } else if (!var1.arm()) {
         return 0.0F;
      } else {
         ArmPose var2 = var1 == CharacterBone.RIGHT_ARM ? var0.rightArmPose : var0.leftArmPose;
         ArmPose var3 = var1 == CharacterBone.RIGHT_ARM ? var0.leftArmPose : var0.rightArmPose;
         if (var3.isTwoHanded()) {
            return 0.0F;
         } else {
            float var4 = switch (var2) {
               case EMPTY-> 1.0F;
               case ITEM, BLOCK, BRUSH, THROW_TRIDENT-> 0.5F;
               default -> 0.0F;
            };
            return var0.isUsingItem ? var4 : var4 * (1.0F - var0.leaningPitch);
         }
      }
   }

   private static void lift(MatrixStack var0, PlayerEntityRenderState var1, BakedCharacterData var2) {
      if (var1.hasVehicle) {
         float var3 = 12.0F - var2.scale * var2.hipY;
         if (var3 != 0.0F) {
            var0.translate(
               0.0F,
               -var3 / 16.0F,
               0.0F
            );
         }
      }
   }

   private static void chain(
      MatrixStack var0, PlayerEntityModel var1, BakedCharacterData var2, int var3, float[] var4, boolean var5, ModelPart var6, float[] var7
   ) {
      BakedCharacterPart var8 = var2.parts[var3];
      float var9 = var2.scale;
      if (!var8.extra) {
         if (var6 == null) {
            ModelPart var10 = vanilla(var1, var8.bone);
            pivot(var0, var10, var8, var9, var7 == null ? var10.pitch : var7[var8.bone.ordinal()]);
         } else {
            var0.translate(
               var6.originX / 16.0F,
               var6.originY / 16.0F,
               var6.originZ / 16.0F
            );
            var0.multiply(ROTATION.rotationZYX(var6.roll, var6.yaw, var6.pitch));
            float var12 = var8.bone == CharacterBone.RIGHT_ARM
               ? -1.0F
               : 1.0F;
            var0.translate(
               (var12 - (var8.gripX - var8.pivotX) * var9) / 16.0F,
               (10.0F + (var8.gripY - var8.pivotY) * var9) / 16.0F,
               (-2.0F + (var8.gripZ - var8.pivotZ) * var9) / 16.0F
            );
         }

         float var13 = var9 / 16.0F;
         var0.scale(var13, -var13, -var13);
      } else {
         chain(var0, var1, var2, var8.parent, var4, true, var6, var7);
         BakedCharacterPart var14 = var2.parts[var8.parent];
         var0.translate(var8.pivotX - var14.pivotX, var8.pivotY - var14.pivotY, var8.pivotZ - var14.pivotZ);
         if (var5 && var4 != null && var8.motionSlot >= 0) {
            int var11 = var8.motionSlot * (3);
            if (var4[var11] != 0.0F
               || var4[var11 + (1)] != 0.0F
               || var4[var11 + (2)] != 0.0F) {
               var0.multiply(
                  ROTATION.rotationZYX(var4[var11 + (2)], var4[var11 + (1)], var4[var11])
               );
            }
         }
      }
   }

   private static void pivot(MatrixStack var0, ModelPart var1, BakedCharacterPart var2, float var3, float var4) {
      ModelTransform var5 = var1.getDefaultTransform();
      var0.translate(
         (var3 * var2.pivotX + (var1.originX - var5.x()) * var3) / 16.0F,
         (24.0F - var3 * var2.pivotY + (var1.originY - var5.y()) * var3)
            / 16.0F,
         (-var3 * var2.pivotZ + (var1.originZ - var5.z()) * var3) / 16.0F
      );
      if (var4 != 0.0F
         || var1.yaw != 0.0F
         || var1.roll != 0.0F) {
         var0.multiply(ROTATION.rotationZYX(var1.roll, var1.yaw, var4));
      }

      if (var1.xScale != 1.0F
         || var1.yScale != 1.0F
         || var1.zScale != 1.0F) {
         var0.scale(var1.xScale, var1.yScale, var1.zScale);
      }
   }

   private static ModelPart vanilla(PlayerEntityModel var0, CharacterBone var1) {
      return switch (var1) {
         case RIGHT_LEG-> var0.rightLeg;
         case LEFT_LEG-> var0.leftLeg;
         case RIGHT_ARM-> var0.rightArm;
         case LEFT_ARM-> var0.leftArm;
         case HEAD-> var0.head;
         case BODY-> var0.body;
         default -> throw new MatchException(null, null);
      };
   }

   private static void emit(
      Entry var0,
      VertexConsumer var1,
      MeshBufferBuilder var2,
      int var3,
      int var4,
      int var5,
      boolean var6,
      float var7,
      float var8,
      float var9,
      BakedCharacterPart var10,
      float var11,
      float var12
   ) {
      int var13 = var2.vertexCount();
      if (scratch.length < var13 * (6)) {
         scratch = new float[Math.max(var13 * (6), scratch.length * (2))];
      }

      float[] var14 = scratch;
      Matrix4f var15 = var0.getPositionMatrix();
      Matrix3f var16 = var0.getNormalMatrix();
      float var17 = var15.m00();
      float var18 = var15.m10();
      float var19 = var15.m20();
      float var20 = var15.m30();
      float var21 = var15.m01();
      float var22 = var15.m11();
      float var23 = var15.m21();
      float var24 = var15.m31();
      float var25 = var15.m02();
      float var26 = var15.m12();
      float var27 = var15.m22();
      float var28 = var15.m32();
      float var29 = var16.m00();
      float var30 = var16.m10();
      float var31 = var16.m20();
      float var32 = var16.m01();
      float var33 = var16.m11();
      float var34 = var16.m21();
      float var35 = var16.m02();
      float var36 = var16.m12();
      float var37 = var16.m22();
      float[] var38 = var2.pos;
      float[] var39 = var2.nrm;
      float[] var40 = var6 ? var2.weight : null;
      float[] var41 = var2.flat;
      DirectionalLighting var42 = var41 != null ? CharacterLighting.current() : null;
      if (var40 != null) {
         levels(LEVELS, var7, var8, var9);
      }

      float[] var43 = var11 == 0.0F && var12 == 0.0F ? null : var2.joint;
      float var44 = var10.jointX;
      float var45 = var10.jointY;
      float var46 = var10.jointZ;
      if (var43 != null) {
         levels(JOINT_LEVELS, var11, var12, 0.0F);
      }

      for (int var47 = 0; var47 < var13; var47++) {
         float var48 = var38[var47 * (3)];
         float var49 = var38[var47 * (3) + (1)];
         float var50 = var38[var47 * (3) + (2)];
         float var51 = var39[var47 * (3)];
         float var52 = var39[var47 * (3) + (1)];
         float var53 = var39[var47 * (3) + (2)];
         if (var43 != null) {
            int var54 = Math.round(var43[var47] * 16.0F);
            if (var54 > 0) {
               float[] var55 = JOINT_LEVELS;
               int var56 = var54 * (9);
               float var57 = var48 - var44;
               float var58 = var49 - var45;
               float var59 = var50 - var46;
               var48 = var44 + var55[var56] * var57 + var55[var56 + (1)] * var58 + var55[var56 + (2)] * var59;
               var49 = var45
                  + var55[var56 + (3)] * var57
                  + var55[var56 + (4)] * var58
                  + var55[var56 + (5)] * var59;
               var50 = var46
                  + var55[var56 + (6)] * var57
                  + var55[var56 + (7)] * var58
                  + var55[var56 + (8)] * var59;
               float var60 = var55[var56] * var51 + var55[var56 + (1)] * var52 + var55[var56 + (2)] * var53;
               float var61 = var55[var56 + (3)] * var51
                  + var55[var56 + (4)] * var52
                  + var55[var56 + (5)] * var53;
               var53 = var55[var56 + (6)] * var51
                  + var55[var56 + (7)] * var52
                  + var55[var56 + (8)] * var53;
               var51 = var60;
               var52 = var61;
            }
         }

         if (var40 != null) {
            int var69 = Math.round(var40[var47] * 16.0F) * (9);
            float[] var72 = LEVELS;
            float var75 = var72[var69] * var48 + var72[var69 + (1)] * var49 + var72[var69 + (2)] * var50;
            float var77 = var72[var69 + (3)] * var48
               + var72[var69 + (4)] * var49
               + var72[var69 + (5)] * var50;
            float var79 = var72[var69 + (6)] * var48
               + var72[var69 + (7)] * var49
               + var72[var69 + (8)] * var50;
            float var82 = var72[var69] * var51 + var72[var69 + (1)] * var52 + var72[var69 + (2)] * var53;
            float var83 = var72[var69 + (3)] * var51
               + var72[var69 + (4)] * var52
               + var72[var69 + (5)] * var53;
            float var84 = var72[var69 + (6)] * var51
               + var72[var69 + (7)] * var52
               + var72[var69 + (8)] * var53;
            var48 = var75;
            var49 = var77;
            var50 = var79;
            var51 = var82;
            var52 = var83;
            var53 = var84;
         }

         int var70 = var47 * (6);
         var14[var70] = var17 * var48 + var18 * var49 + var19 * var50 + var20;
         var14[var70 + (1)] = var21 * var48 + var22 * var49 + var23 * var50 + var24;
         var14[var70 + (2)] = var25 * var48 + var26 * var49 + var27 * var50 + var28;
         float var73 = var29 * var51 + var30 * var52 + var31 * var53;
         float var76 = var32 * var51 + var33 * var52 + var34 * var53;
         float var78 = var35 * var51 + var36 * var52 + var37 * var53;
         float var80 = var73 * var73 + var76 * var76 + var78 * var78;
         if (var80 > 9.999999960041972e-13F
            && Math.abs(var80 - 1.0F) > 0.0010000000474974513F) {
            var80 = 1.0F / (float)Math.sqrt((double)var80);
            var73 *= var80;
            var76 *= var80;
            var78 *= var80;
         }

         var14[var70 + (3)] = var73;
         var14[var70 + (4)] = var76;
         var14[var70 + (5)] = var78;
         if (var42 != null && var41[var47] > 0.0F) {
            var42.flatten(var14, var70 + (3), var41[var47]);
         }
      }

      int[] var62 = var2.quads;
      int[] var63 = var2.color;
      float[] var64 = var2.uv;
      byte[] var65 = var2.glow;

      for (int var66 = 0; var66 < var62.length; var66++) {
         int var67 = var62[var66];
         int var68 = var67 * (6);
         int var71 = var5 == (255) ? var63[var67] : var63[var67] & (16777215) | var5 << (24);
         int var74 = var65 != null && var65[var67] != 0 ? 15728880 : var3;
         var1.vertex(
            var14[var68],
            var14[var68 + (1)],
            var14[var68 + (2)],
            var71,
            var64[var67 * (2)],
            var64[var67 * (2) + (1)],
            var4,
            var74,
            var14[var68 + (3)],
            var14[var68 + (4)],
            var14[var68 + (5)]
         );
      }
   }

   private static void levels(float[] var0, float var1, float var2, float var3) {
      for (int var4 = 0; var4 <= (16); var4++) {
         float var5 = (float)var4 / 16.0F;
         float var6 = (float)Math.cos((double)(var1 * var5));
         float var7 = (float)Math.sin((double)(var1 * var5));
         float var8 = (float)Math.cos((double)(var2 * var5));
         float var9 = (float)Math.sin((double)(var2 * var5));
         float var10 = (float)Math.cos((double)(var3 * var5));
         float var11 = (float)Math.sin((double)(var3 * var5));
         int var12 = var4 * (9);
         var0[var12] = var10 * var8;
         var0[var12 + (1)] = var10 * var9 * var7 - var11 * var6;
         var0[var12 + (2)] = var10 * var9 * var6 + var11 * var7;
         var0[var12 + (3)] = var11 * var8;
         var0[var12 + (4)] = var11 * var9 * var7 + var10 * var6;
         var0[var12 + (5)] = var11 * var9 * var6 - var10 * var7;
         var0[var12 + (6)] = -var9;
         var0[var12 + (7)] = var8 * var7;
         var0[var12 + (8)] = var8 * var6;
      }
   }
}
