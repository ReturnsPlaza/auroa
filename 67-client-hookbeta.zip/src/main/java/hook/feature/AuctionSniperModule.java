package hook.feature;

import com.google.gson.JsonObject;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.ItemSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.module.setting.StringSetting;
import hook.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.item.tooltip.TooltipType.Default;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public final class AuctionSniperModule extends Module {
   private final ItemSetting snipingItem;
   private final StringSetting price;
   private final ModeSetting<AuctionSniperModule.SnipingMode> mode;
   private final StringSetting apiKey;
   private final NumberSetting refreshDelay;
   private final NumberSetting buyDelay;
   private final NumberSetting apiRefreshRate;
   private final BooleanSetting showApiNotifications;
   private int delayCounter;
   private boolean isProcessing;
   private long lastApiCallTimestamp;
   private final Map<String, Double> snipingItems;
   private boolean isApiQueryInProgress;
   private boolean isAuctionSniping;
   private int auctionPageCounter;
   private String currentSellerName;

   public AuctionSniperModule() {
      super(EncryptedString.of("Auction Sniper"),
            EncryptedString.of("Snipes items on auction house for cheap"), -1, Category.MISC);
      snipingItem = new ItemSetting(EncryptedString.of("Sniping Item"), Items.AIR);
      price = new StringSetting(EncryptedString.of("Price"), "1k");
      mode = new ModeSetting<>(EncryptedString.of("Mode"), SnipingMode.MANUAL, SnipingMode.class)
            .setDescription(EncryptedString.of("Manual is faster but api doesnt require auction gui opened all the time"));
      apiKey = new StringSetting(EncryptedString.of("Api Key"), "")
            .setDescription(EncryptedString.of("You can get it by typing /api in chat"));
      refreshDelay = new NumberSetting(EncryptedString.of("Refresh Delay"), 0.0, 100.0, 2.0, 1.0);
      buyDelay = new NumberSetting(EncryptedString.of("Buy Delay"), 0.0, 100.0, 2.0, 1.0);
      apiRefreshRate = new NumberSetting(EncryptedString.of("API Refresh Rate"), 10.0, 5000.0, 250.0, 10.0)
            .getValue(EncryptedString.of("How often to query the API (in milliseconds)"));
      showApiNotifications = new BooleanSetting(EncryptedString.of("Show API Notifications"), true)
            .setDescription(EncryptedString.of("Show chat notifications for API actions"));
      snipingItems = new HashMap<>();
      auctionPageCounter = -1;
      currentSellerName = "";
      addSettings(new Setting[]{snipingItem, price, mode, apiKey, refreshDelay, buyDelay,
            apiRefreshRate, showApiNotifications});
   }

   public void onEnable() {
      super.onEnable();
      double var1 = this.parsePrice(this.price.getValue());
      if (var1 == -1.0) {
         if (this.mc.player != null) {
            ClientPlayerEntity var3 = this.mc.player;
            var3.sendMessage(
               Text.of("Invalid Price"),
               true
            );
         }

         this.toggle();
      } else {
         if (this.snipingItem.getItem() != Items.AIR) {
            Map var4 = this.snipingItems;
            var4.put(this.snipingItem.getItem().toString(), var1);
         }

         this.lastApiCallTimestamp = 0L;
         this.isApiQueryInProgress = false;
         this.isAuctionSniping = false;
         this.currentSellerName = "";
      }
   }

   public void onDisable() {
      super.onDisable();
      this.isAuctionSniping = false;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null) {
         if (this.delayCounter > 0) {
            this.delayCounter -= 1;
         } else if (this.mode.isMode(AuctionSniperModule.SnipingMode.API)) {
            this.handleApiMode();
         } else if (this.mode.isMode(AuctionSniperModule.SnipingMode.MANUAL)) {
            ScreenHandler var2 = this.mc.player.currentScreenHandler;
            if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)) {
               String[] var3 = this.snipingItem
                  .getItem()
                  .getTranslationKey()
                  .split("\\.");
               String var4 = var3[var3.length - (1)];
               String var5 = Arrays.stream(
                     var4.replace(
                           "_",
                           " "
                        )
                        .split(" ")
                  )
                  .map(var0 -> var0.substring(0, 1).toUpperCase() + var0.substring(1))
                  .collect(Collectors.joining(" "));
               this.mc.getNetworkHandler().sendChatCommand("ah " + var5);
               this.delayCounter = 20;
               return;
            }

            if (((GenericContainerScreenHandler)var2).getRows() == (6)) {
               this.processSixRowAuction((GenericContainerScreenHandler)var2);
            } else if (((GenericContainerScreenHandler)var2).getRows() == (3)) {
               this.processThreeRowAuction((GenericContainerScreenHandler)var2);
            }
         }
      }
   }

   private void handleApiMode() {
      if (!this.isAuctionSniping) {
         if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler
            && this.mc.currentScreen.getTitle().getString().contains("Page")) {
            this.mc.player.closeHandledScreen();
            this.delayCounter = 20;
         } else if (!this.isApiQueryInProgress) {
            long var1 = System.currentTimeMillis();
            long var3 = var1 - this.lastApiCallTimestamp;
            if (var3 > (long)this.apiRefreshRate.getIntValue()) {
               this.lastApiCallTimestamp = var1;
               if (this.apiKey.getValue().isEmpty()) {
                  if (this.showApiNotifications.getValue()) {
                     ClientPlayerEntity var5 = this.mc.player;
                     var5.sendMessage(
                        Text.of(
                           "§cAPI key is not set. Set it using /api in-game."
                        ),
                        false
                     );
                  }

                  return;
               }

               this.isApiQueryInProgress = true;
               this.queryApi().thenAccept(this::processApiResponse);
            }
         }
      } else {
         ScreenHandler var6 = this.mc.player.currentScreenHandler;
         if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)) {
            if (this.auctionPageCounter != (-1)) {
               if (this.auctionPageCounter <= (40)) {
                  this.auctionPageCounter += 1;
               } else {
                  this.isAuctionSniping = false;
                  this.currentSellerName = "";
               }
            } else {
               this.mc.getNetworkHandler().sendChatCommand("ah " + this.currentSellerName);
               this.auctionPageCounter = 0;
            }
         } else {
            this.auctionPageCounter = -1;
            if (((GenericContainerScreenHandler)var6).getRows() == (6)) {
               this.processSixRowAuction((GenericContainerScreenHandler)var6);
            } else if (((GenericContainerScreenHandler)var6).getRows() == (3)) {
               this.processThreeRowAuction((GenericContainerScreenHandler)var6);
            }
         }
      }
   }

   private CompletableFuture<List<?>> queryApi() {
      return CompletableFuture.supplyAsync(() -> Collections.emptyList());
   }

   private void processApiResponse(List var1) {
      for (Object var3 : var1) {
         try {
            String var4 = ((JsonObject)var3)
               .getAsJsonObject("item")
               .get("id")
               .getAsString();
            long var15 = ((JsonObject)var3).get("price").getAsLong();
            String var7 = ((JsonObject)var3)
               .getAsJsonObject("seller")
               .get("name")
               .getAsString();

            for (Entry var9 : this.snipingItems.entrySet()) {
               String var10 = (String)var9.getKey();
               double var11 = (Double)var9.getValue();
               if (var4.contains(var10) && (double)var15 <= var11) {
                  if (this.showApiNotifications.getValue() && this.mc.player != null) {
                     ClientPlayerEntity var13 = this.mc.player;
                     var13.sendMessage(
                        Text.of(
                           "§aFound "
                              + var4
                              + " for "
                              + this.formatPrice((double)var15)
                              + " §r(threshold: "
                              + this.formatPrice(var11)
                              + ") §afrom seller: "
                              + var7
                        ),
                        false
                     );
                  }

                  this.isAuctionSniping = true;
                  this.currentSellerName = var7;
                  return;
               }
            }
         } catch (Exception var14) {
            if (this.showApiNotifications.getValue() && this.mc.player != null) {
               ClientPlayerEntity var5 = this.mc.player;
               var5.sendMessage(Text.of("§cError processing auction: " + var14.getMessage()), false);
            }
         }
      }
   }

   private void processSixRowAuction(GenericContainerScreenHandler var1) {
      ItemStack var2 = var1.getSlot(47).getStack();
      if (var2.isOf(Items.AIR)) {
         this.delayCounter = 2;
      } else {
         for (Object var4 : var2.getTooltip(TooltipContext.DEFAULT, this.mc.player, TooltipType.BASIC)) {
            String var5 = var4.toString();
            if (var5.contains("Recently Listed")
               && (
                  ((Text)var4).getStyle().toString().contains("white")
                     || var5.contains("white")
               )) {
               this.mc
                  .interactionManager
                  .clickSlot(
                     this.mc.player.currentScreenHandler.syncId, 47, 1, SlotActionType.QUICK_MOVE, this.mc.player
                  );
               this.delayCounter = 5;
               return;
            }
         }

         for (int var6 = 0; var6 < (44); var6++) {
            ItemStack var7 = var1.getSlot(var6).getStack();
            if (var7.isOf(this.snipingItem.getItem()) && this.isValidAuctionItem(var7)) {
               if (this.isProcessing) {
                  this.mc
                     .interactionManager
                     .clickSlot(this.mc.player.currentScreenHandler.syncId, var6, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.isProcessing = false;
                  return;
               }

               this.isProcessing = true;
               this.delayCounter = this.buyDelay.getIntValue();
               return;
            }
         }

         if (this.isAuctionSniping) {
            this.isAuctionSniping = false;
            this.currentSellerName = "";
            this.mc.player.closeHandledScreen();
         } else {
            this.mc
               .interactionManager
               .clickSlot(
                  this.mc.player.currentScreenHandler.syncId, 49, 1, SlotActionType.QUICK_MOVE, this.mc.player
               );
            this.delayCounter = this.refreshDelay.getIntValue();
         }
      }
   }

   private void processThreeRowAuction(GenericContainerScreenHandler var1) {
      if (this.isValidAuctionItem(var1.getSlot(13).getStack())) {
         this.mc
            .interactionManager
            .clickSlot(this.mc.player.currentScreenHandler.syncId, 15, 1, SlotActionType.QUICK_MOVE, this.mc.player);
         this.delayCounter = 20;
      }

      if (this.isAuctionSniping) {
         this.isAuctionSniping = false;
         this.currentSellerName = "";
      }
   }

   private double parseTooltipPrice(List var1) {
      if (var1 != null && !var1.isEmpty()) {
         Iterator var2 = var1.iterator();

         while (var2.hasNext()) {
            String var3 = ((Text)var2.next()).getString();
            if (var3.matches("(?i).*price\\s*:\\s*\\$.*")) {
               String var4 = var3.replaceAll(
                  "[,$]",
                  ""
               );
               Matcher var5 = Pattern.compile(
                     "([\\d]+(?:\\.[\\d]+)?)\\s*([KMB])?", 2
                  )
                  .matcher(var4);
               if (var5.find()) {
                  String var6 = var5.group(1);
                  String var7 = var5.group(2) != null
                     ? var5.group(2).toUpperCase()
                     : "";
                  return this.parsePrice(var6 + var7);
               }
            }
         }

         return -1.0;
      } else {
         return -1.0;
      }
   }

   private boolean isValidAuctionItem(ItemStack var1) {
      List var2 = var1.getTooltip(TooltipContext.DEFAULT, this.mc.player, TooltipType.BASIC);
      double var3 = this.parseTooltipPrice(var2) / (double)var1.getCount();
      double var5 = this.parsePrice(this.price.getValue());
      if (var5 == -1.0) {
         if (this.mc.player != null) {
            ClientPlayerEntity var10 = this.mc.player;
            var10.sendMessage(
               Text.of("Invalid Price"),
               true
            );
         }

         this.toggle();
         return false;
      } else if (var3 != -1.0) {
         return ((var3 <= var5));
      } else {
         if (this.mc.player != null) {
            ClientPlayerEntity var7 = this.mc.player;
            var7.sendMessage(
               Text.of("Invalid Auction Item Price"),
               true
            );

            for (int var8 = 0; var8 < var2.size() - (1); var8++) {
               PrintStream var9 = System.out;
               var9.println(var8 + ". " + ((Text)var2.get(var8)).getString());
            }
         }

         this.toggle();
         return false;
      }
   }

   private double parsePrice(String var1) {
      if (var1 == null) {
         return -1.0;
      } else if (var1.isEmpty()) {
         return -1.0;
      } else {
         String var2 = var1.trim().toUpperCase();
         double var3 = 1.0;
         if (var2.endsWith("B")) {
            var3 = 1000000000.0;
            var2 = var2.substring(0, var2.length() - (1));
         } else if (var2.endsWith("M")) {
            var3 = 1000000.0;
            var2 = var2.substring(0, var2.length() - (1));
         } else if (var2.endsWith("K")) {
            var3 = 1000.0;
            var2 = var2.substring(0, var2.length() - (1));
         }

         try {
            return Double.parseDouble(var2) * var3;
         } catch (NumberFormatException var6) {
            return -1.0;
         }
      }
   }

   private String formatPrice(double var1) {
      if (var1 >= 1000000000.0) {
         Object[] var9 = new Object[1];
         var9[0] = var1 / 1000000000.0;
         Object[] var6 = var9;
         return String.format("%.2fB", var6);
      } else if (var1 >= 1000000.0) {
         Object[] var8 = new Object[1];
         var8[0] = var1 / 1000000.0;
         Object[] var5 = var8;
         return String.format("%.2fM", var5);
      } else if (var1 >= 1000.0) {
         Object[] var7 = new Object[1];
         var7[0] = var1 / 1000.0;
         Object[] var4 = var7;
         return String.format("%.2fK", var4);
      } else {
         Object[] var10000 = new Object[1];
         var10000[0] = var1;
         Object[] var3 = var10000;
         return String.format("%.2f", var3);
      }
   }

   public static enum SnipingMode {
      API("API", 0),
      MANUAL("MANUAL", 1);

      private SnipingMode(final String name, final int ordinal) {
      }
   }
}
