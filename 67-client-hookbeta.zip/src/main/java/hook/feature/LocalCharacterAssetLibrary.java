package hook.feature;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import hook.feature.GltfCharacterBaker.CharacterProfile;
import hook.feature.GltfCharacterBaker.BakedCharacterModel;
import hook.feature.UiTextureAtlas.TexturePixels;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Environment(EnvType.CLIENT)
final class LocalCharacterAssetLibrary {
   private static final Logger LOGGER = LoggerFactory.getLogger(
      "67 Client"
   );
   private static final long MAX_FILE = 268435456L;
   private static final int MAX_TEXTURE = 8192;

   private LocalCharacterAssetLibrary() {
   }

   static Path folder() {
      return FabricLoader.getInstance()
         .getConfigDir()
         .resolve("hook")
         .resolve("characters");
   }

   private static Path cache() {
      return folder().resolve(".baked");
   }

   static List<BakedCharacterAsset> scan() {
      ArrayList var0 = new ArrayList();

      try (DirectoryStream var1 = Files.newDirectoryStream(folder(), "*.{glb,GLB}")) {
         for (Object var3Object : var1) { Path var3 = (Path)var3Object;
            if (Files.isRegularFile(var3)) {
               var0.add(var3);
            }
         }
      } catch (IOException var11) {
         return List.of();
      }

      var0.sort(null);
      ArrayList var12 = new ArrayList();
      HashSet var13 = new HashSet();

      for (Object var4Object : var0) { Path var4 = (Path)var4Object;
         String var5 = var4.getFileName().toString();
         var5 = var5.substring(0, var5.length() - (4));

         try {
            String var6 = var5 + Files.size(var4) + Files.getLastModifiedTime(var4).toMillis() + "3";
            String var7 = "custom_" + slug(var5) + "_" + Integer.toHexString(var6.hashCode());
            var13.add(var7);
            var12.add(new BakedCharacterAsset(var7, var5, () -> open(var4, var7)));
         } catch (IOException var9) {
            LOGGER.warn(
               "[Hook] Skipping custom character {}: {}",
               var4,
               var9.toString()
            );
         }
      }

      prune(var13);
      return var12;
   }

   private static String slug(String var0) {
      String var1 = var0.toLowerCase(Locale.ROOT)
         .replaceAll(
            "[^a-z0-9]+",
            "_"
         )
         .replaceAll(
            "^_+|_+$",
            ""
         );
      return var1.isEmpty()
         ? "model"
         : (var1.length() > (32) ? var1.substring(0, 32) : var1);
   }

   private static void prune(Set<String> var0) {
      try (DirectoryStream var1 = Files.newDirectoryStream(
            cache(), "*.anc"
         )) {
         for (Object var3Object : var1) { Path var3 = (Path)var3Object;
            String var4 = var3.getFileName()
               .toString()
               .replace(
                  ".anc",
                  ""
               );
            if (!var0.contains(var4)) {
               Files.deleteIfExists(var3);
            }
         }
      } catch (IOException var7) {
      }
   }

   private static synchronized InputStream open(Path var0, String var1) throws IOException {
      Path var2 = cache().resolve(var1 + ".anc");
      if (Files.exists(var2)) {
         return Files.newInputStream(var2);
      } else if (Files.size(var0) > (268435456L)) {
         throw new IOException("the file is larger than 256 MB");
      } else {
         String var3 = var0.getFileName().toString();
         Character3dModule.baking(var3);
         long var4 = System.nanoTime();
         BakedCharacterModel var6 = GltfCharacterBaker.bake(
            Files.readAllBytes(var0), new CharacterProfile(), LocalCharacterAssetLibrary::decode
         );
         Logger var10000 = LOGGER;
         String var10001 = "[Hook] Baked custom character {} in {} ms, moving {}";
         Object[] var10002 = new Object[3];
         var10002[0] = var3;
         var10002[1] = (System.nanoTime() - var4) / (1000000L);
         var10002[2] = var6.limbs();
         var10000.info(var10001, var10002);
         if (var6.limbs().size() < (3)) {
            Character3dModule.notice(var3, var6.limbs());
         }

         Files.createDirectories(cache());
         Path var7 = cache().resolve(var1 + ".tmp");
         Files.write(var7, var6.data());
         CopyOption[] var8 = new CopyOption[1];
         var8[0] = StandardCopyOption.REPLACE_EXISTING;
         Files.move(var7, var2, var8);
         return new ByteArrayInputStream(var6.data());
      }
   }

   private static TexturePixels decode(byte[] var0) throws IOException {
      ByteBuffer var1 = MemoryUtil.memAlloc(var0.length);

      TexturePixels var2;
      try {
         MemoryStack var3 = MemoryStack.stackPush();

         try {
            var1.put(var0).flip();
            IntBuffer var4 = var3.mallocInt(1);
            IntBuffer var5 = var3.mallocInt(1);
            IntBuffer var6 = var3.mallocInt(1);
            ByteBuffer var7 = STBImage.stbi_load_from_memory(var1, var4, var5, var6, 4);
            if (var7 == null) {
               throw new IOException("a texture can't be read: " + STBImage.stbi_failure_reason());
            }

            try {
               int var8 = var4.get(0);
               int var9 = var5.get(0);
               if (var8 > (8192) || var9 > (8192)) {
                  throw new IOException("a texture is over 8192 px");
               }

               int[] var10 = new int[var8 * var9];

               for (int var11 = 0; var11 < var10.length; var11++) {
                  int var12 = var7.get(var11 * (4)) & (255);
                  int var13 = var7.get(var11 * (4) + (1)) & (255);
                  int var14 = var7.get(var11 * (4) + (2)) & (255);
                  int var15 = var7.get(var11 * (4) + (3)) & (255);
                  var10[var11] = var15 << (24) | var12 << (16) | var13 << (8) | var14;
               }

               var2 = new TexturePixels(var8, var9, var10);
            } finally {
               STBImage.stbi_image_free(var7);
            }
         } catch (Throwable var28) {
            if (var3 != null) {
               try {
                  var3.close();
               } catch (Throwable var26) {
                  var28.addSuppressed(var26);
               }
            }

            throw var28;
         }

         if (var3 != null) {
            var3.close();
         }
      } finally {
         MemoryUtil.memFree(var1);
      }

      return var2;
   }
}
