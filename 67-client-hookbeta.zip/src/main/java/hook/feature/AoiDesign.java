package hook.feature;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import hook.feature.SdfShapes.DistanceField3D;
import hook.utils.BytecodeException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class AoiDesign extends CharacterDefinition {
   private static final float TAU = (float) (Math.PI * 2);
   private static final float NECK = 24.4F;
   private static final float HEAD_K = 1.16F;
   private static final float HEAD_DY = -0.25F;
   private static final float FACE_X = 2.25F;
   private static final float FACE_TOP = 28.6F;
   private static final float FACE_LOW = 26.08F;
   private static final float FACE_PX = 80.0F;
   private static final float YOKE = 21.75F;
   private static final float BEND = 13.0F;
   private static final int SKIN = -9274;
   private static final int SKIN_SHADE = -1331558;
   private static final int SKIN_LINE = -6657438;
   private static final int HAIR = -14140794;
   private static final int HAIR_DEEP = -15063975;
   private static final int HAIR_TOP = -12756032;
   private static final int HAIR_BLUE = -12948262;
   private static final int HAIR_TIP = -13246209;
   private static final int HAIR_INNER = -13646610;
   private static final int HAIR_SHINE = -7363350;
   private static final int HAIR_LINE = -15327158;
   private static final int CYAN = -13703425;
   private static final int NAVY = -14932394;
   private static final int JACKET = -12959662;
   private static final int JACKET_DARK = -14210250;
   private static final int JACKET_WHITE = -1446155;
   private static final int JACKET_SHADE = -3945254;
   private static final int LINE = -15065558;
   private static final int TOP = -525828;
   private static final int TOP_SHADE = -2498584;
   private static final int SKIRT = -12892555;
   private static final int SKIRT_DARK = -14472632;
   private static final int BLACK = -15263457;
   private static final int SILVER = -3550757;
   private static final int SOCK = -14012606;
   private static final int SOLE = -920586;
   private static final float SKIRT_ZC = -0.05F;
   private static final float SKIRT_TOP = 17.3F;
   private static final float SKIRT_HEM = 11.25F;
   private static final int PLEATS = 18;
   private static final float[][] MAIN_LOCKS;
   private static final float[][] ACCENT_LOCKS;

   public AoiDesign() {
      super(
         "aoi", "Aoi"
      );
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-15065558, 0.12999999523162842F)
         .occlusion(0.3499999940395355F);
      PixelCanvas var2 = stripe();
      Sdf3D var3 = headShape();
      List var4 = fringeLocks(
         var3, MAIN_LOCKS, 0.20000000298023224F, 0.17000000178813934F
      );
      List var5 = fringeLocks(
         var3, ACCENT_LOCKS, 0.20000000298023224F, 0.17000000178813934F
      );
      var1.part(CharacterBone.HEAD)
         .pivot(0.0F, 24.399999618530273F, 0.0F)
         .shape(grow(var3.color(-9274)))
         .detail(1.100000023841858F)
         .resolution(0.8500000238418579F)
         .outline(-6657438, 0.09000000357627869F)
         .flatLight(1.0F)
         .occlusion(0.20000000298023224F)
         .decal(face(var4));
      hair(var1, var4, var5);
      ponytail(var1);
      Sdf3D var6 = body(var1, var2);
      skirt(var1, var2);
      arms(var1, var2);
      legs(var1);
      gear(var1, var6);
   }

   private static Sdf3D grow(Sdf3D var0) {
      return var0.scale(
            1.159999966621399F,
            0.0F,
            24.399999618530273F,
            0.0F
         )
         .move(0.0F, -0.25F, 0.0F);
   }

   private static float hy(float var0) {
      return 24.399999618530273F
         + (var0 - 24.399999618530273F) * 1.159999966621399F
         + -0.25F;
   }

   private static Sdf3D headShape() {
      Sdf3D var0 = SdfShapes.ellipsoid(
         0.0F,
         28.520000457763672F,
         -0.15000000596046448F,
         2.2799999713897705F,
         2.240000009536743F,
         2.319999933242798F
      );
      Sdf3D var1 = SdfShapes.ellipsoid(
         0.0F,
         27.399999618530273F,
         0.699999988079071F,
         1.9500000476837158F,
         1.100000023841858F,
         1.4500000476837158F
      );
      Sdf3D var2 = SdfShapes.cone(
         0.0F,
         27.25F,
         0.41999998688697815F,
         1.6799999475479126F,
         0.0F,
         26.149999618530273F,
         1.1799999475479126F,
         0.550000011920929F
      );
      float[] var10000 = new float[42];
      var10000[0] = -2.5999999046325684F;
      var10000[1] = 31.5F;
      var10000[2] = -2.5999999046325684F;
      var10000[3] = 29.0F;
      var10000[4] = -2.240000009536743F;
      var10000[5] = 27.600000381469727F;
      var10000[6] = -2.109999895095825F;
      var10000[7] = 27.200000762939453F;
      var10000[8] = -1.899999976158142F;
      var10000[9] = 26.799999237060547F;
      var10000[10] = -1.6200000047683716F;
      var10000[11] = 26.440000534057617F;
      var10000[12] = -1.2799999713897705F;
      var10000[13] = 26.1200008392334F;
      var10000[14] = -0.9200000166893005F;
      var10000[15] = 25.90999984741211F;
      var10000[16] = -0.5400000214576721F;
      var10000[17] = 25.790000915527344F;
      var10000[18] = -0.25F;
      var10000[19] = 25.75F;
      var10000[20] = 0.0F;
      var10000[21] = 25.739999771118164F;
      var10000[22] = 0.25F;
      var10000[23] = 25.75F;
      var10000[24] = 0.5400000214576721F;
      var10000[25] = 25.790000915527344F;
      var10000[26] = 0.9200000166893005F;
      var10000[27] = 25.90999984741211F;
      var10000[28] = 1.2799999713897705F;
      var10000[29] = 26.1200008392334F;
      var10000[30] = 1.6200000047683716F;
      var10000[31] = 26.440000534057617F;
      var10000[32] = 1.899999976158142F;
      var10000[33] = 26.799999237060547F;
      var10000[34] = 2.109999895095825F;
      var10000[35] = 27.200000762939453F;
      var10000[36] = 2.240000009536743F;
      var10000[37] = 27.600000381469727F;
      var10000[38] = 2.5999999046325684F;
      var10000[39] = 29.0F;
      var10000[40] = 2.5999999046325684F;
      var10000[41] = 31.5F;
      Sdf3D var3 = SdfShapes.extrude(
         Sdf2D.polygon(var10000), 4.0F, 0.0F
      );
      float var6 = 0.8999999761581421F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = var0;
      var10001[1] = var1;
      var10001[2] = var2;
      Sdf3D var4 = SdfShapes.blend(var6, var10001);
      Sdf3D var5 = var4.intersect(0.30000001192092896F, var3);
      return SdfShapes.field((var2x, var3x, var4x) -> {
         float var5x = var3x > 28.799999237060547F ? var4.distance(var2x, var3x, var4x) : var5.distance(var2x, var3x, var4x);
         return Math.max(var5x, Math.max(-1.0F - var4x, var3x - 30.100000381469727F));
      }, var4.minX(), var4.minY(), -1.100000023841858F, var4.maxX(), 30.200000762939453F, var4.maxZ());
   }

   private static List<float[]> fringeLocks(Sdf3D var0, float[][] var1, float var2, float var3) {
      ArrayList var4 = new ArrayList();
      float[][] var5 = var1;
      int var6 = var1.length;

      for (int var7 = 0; var7 < var6; var7++) {
         float[] var8 = var5[var7];
         int var9 = (var8.length - (1)) / (2);
         float[] var10 = new float[var9 * (4)];

         for (int var11 = 0; var11 < var9; var11++) {
            float var12 = var8[(1) + var11 * (2)];
            float var13 = var8[(2) + var11 * (2)];
            float var14 = 1.0F
               - var12 * var12 / 6.760000228881836F
               - (var13 - 28.6200008392334F)
                  * (var13 - 28.6200008392334F)
                  / 7.079999923706055F;
            float var15 = Math.max(
               frontZ(var0, var12, var13, 5.0F),
               -0.5F
                  + 2.640000104904175F * (float)Math.sqrt((double)Math.max(0.0F, var14))
            );
            float var17 = var13 - 28.299999237060547F;
            float var18 = var15 + 0.4000000059604645F;
            float var19 = (float)Math.sqrt((double)(var12 * var12 + var17 * var17 + var18 * var18));
            float var20 = (float)var11 / ((float)var9 - 1.0F);
            float var21 = (var11 == 0 ? 0.10000000149011612F : (var11 == var9 - (1) ? var3 : var2))
               + 0.2199999988079071F
                  * smooth(1.2999999523162842F, 2.200000047683716F, Math.abs(var12));
            var10[var11 * (4)] = var12 + var12 / var19 * var21;
            var10[(1) + var11 * (4)] = var13 + var17 / var19 * var21;
            var10[(2) + var11 * (4)] = var15 + var18 / var19 * var21;
            var10[(3) + var11 * (4)] = var8[0]
                  * (float)Math.pow(
                     (double)(1.0F - var20), 1.2000000476837158
                  )
               + 0.05000000074505806F * var20;
         }

         var4.add(var10);
      }

      return var4;
   }

   private static void hair(CharacterRig var0, List<float[]> var1, List<float[]> var2) {
      ArrayList var3 = new ArrayList();
      var3.add(
         SdfShapes.subtract(
               0.3499999940395355F,
               SdfShapes.ellipsoid(
                  0.0F,
                  28.6200008392334F,
                  -0.20000000298023224F,
                  2.5999999046325684F,
                  2.6600000858306885F,
                  2.640000104904175F
               ),
               SdfShapes.ellipsoid(
                  0.0F,
                  26.75F,
                  2.75F,
                  2.450000047683716F,
                  2.8499999046325684F,
                  2.7200000286102295F
               )
            )
            .intersect(SdfShapes.above(26.0F))
      );
      float[] var10000 = new float[6];
      var10000[0] = -155.0F;
      var10000[1] = -118.0F;
      var10000[2] = -80.0F;
      var10000[3] = 80.0F;
      var10000[4] = 118.0F;
      var10000[5] = 155.0F;
      float[] var4 = var10000;
      int var5 = var4.length;

      for (int var6 = 0; var6 < var5; var6++) {
         float var7 = var4[var6];
         var3.add(flowLock(var7));
      }

      var0.extra("hair", CharacterBone.HEAD)
         .shape(
            grow(
               SdfShapes.union(((Sdf3D[]) var3.toArray(new Sdf3D[0]))).paint(capPaint())
            )
         )
         .detail(0.800000011920929F)
         .resolution(0.949999988079071F)
         .outline(-15327158, 0.10000000149011612F)
         .flatLight(0.5F)
         .occlusion(0.4000000059604645F);
      CharacterPartBuilder var10 = var0.extra("fringe", CharacterBone.HEAD)
         .shape(grow(fringe(var1, var2)))
         .detail(0.4000000059604645F)
         .resolution(0.550000011920929F)
         .outline(-15327158, 0.09000000357627869F)
         .flatLight(0.5F)
         .occlusion(0.20000000298023224F);
      shine(var10, var1);
      BoneMotionProfile var11 = BoneMotionProfile.hair()
         .idle(
            1.5F,
            0.0F,
            1.5F,
            0.3499999940395355F
         )
         .walk(
            3.0F,
            0.0F,
            3.0F,
            2.0F
         )
         .drag(8.0F)
         .hang(0.699999988079071F)
         .turn(10.0F, 0.0F)
         .spring(60.0F, 7.0F)
         .bend(1.2999999523162842F);
      SurfacePaint var12 = SurfacePaint.field(
         (var0x, var1x, var2x) -> ArgbColors.mix(
               ArgbColors.mix(
                  -14140794,
                  -12948262,
                  smooth(28.200000762939453F, 25.799999237060547F, var1x)
               ),
               -13246209,
               smooth(26.200000762939453F, 24.399999618530273F, var1x)
            )
      );
      SurfacePaint var13 = SurfacePaint.field(
         (var0x, var1x, var2x) -> ArgbColors.mix(
               -13646610,
               -13246209,
               smooth(27.0F, 25.0F, var1x)
            )
      );
      Sdf3D[] var14 = new Sdf3D[2];
      int var10002 = 0;
      float[] var10003 = new float[24];
      var10003[0] = -1.5499999523162842F;
      var10003[1] = 29.950000762939453F;
      var10003[2] = 1.0F;
      var10003[3] = 0.4000000059604645F;
      var10003[4] = -2.319999933242798F;
      var10003[5] = 28.5F;
      var10003[6] = 1.399999976158142F;
      var10003[7] = 0.550000011920929F;
      var10003[8] = -2.549999952316284F;
      var10003[9] = 27.100000381469727F;
      var10003[10] = 1.2999999523162842F;
      var10003[11] = 0.5199999809265137F;
      var10003[12] = -2.4800000190734863F;
      var10003[13] = 25.899999618530273F;
      var10003[14] = 1.149999976158142F;
      var10003[15] = 0.41999998688697815F;
      var10003[16] = -2.299999952316284F;
      var10003[17] = 24.899999618530273F;
      var10003[18] = 1.2000000476837158F;
      var10003[19] = 0.2800000011920929F;
      var10003[20] = -2.0999999046325684F;
      var10003[21] = 24.299999237060547F;
      var10003[22] = 1.340000033378601F;
      var10003[23] = 0.03999999910593033F;
      var14[var10002] = SdfShapes.tube(var10003)
         .flattenFrom(
            2.0F,
            0.0F,
            27.5F,
            -0.5F
         )
         .paint(var12);
      var10002 = 1;
      var10003 = new float[20];
      var10003[0] = -1.7000000476837158F;
      var10003[1] = 29.700000762939453F;
      var10003[2] = 0.699999988079071F;
      var10003[3] = 0.36000001430511475F;
      var10003[4] = -2.2799999713897705F;
      var10003[5] = 28.200000762939453F;
      var10003[6] = 1.0499999523162842F;
      var10003[7] = 0.4399999976158142F;
      var10003[8] = -2.359999895095825F;
      var10003[9] = 26.799999237060547F;
      var10003[10] = 0.949999988079071F;
      var10003[11] = 0.41999998688697815F;
      var10003[12] = -2.2200000286102295F;
      var10003[13] = 25.600000381469727F;
      var10003[14] = 0.8999999761581421F;
      var10003[15] = 0.30000001192092896F;
      var10003[16] = -2.049999952316284F;
      var10003[17] = 24.549999237060547F;
      var10003[18] = 1.0F;
      var10003[19] = 0.03999999910593033F;
      var14[var10002] = SdfShapes.tube(var10003)
         .flattenFrom(
            2.0F,
            0.0F,
            27.5F,
            -0.5F
         )
         .paint(var13);
      Sdf3D var8 = SdfShapes.union(var14);
      CharacterPartBuilder var9 = var0.extra("lock_r", CharacterBone.HEAD)
         .pivot(
            -2.319999933242798F,
            hy(29.200000762939453F),
            1.159999966621399F
         )
         .shape(grow(var8))
         .motion(var11)
         .detail(0.699999988079071F)
         .resolution(0.699999988079071F)
         .outline(-15327158, 0.10000000149011612F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F);
      var0.extra("lock_l", CharacterBone.HEAD).mirrorOf(var9);
   }

   private static Sdf3D flowLock(float var0) {
      float var1 = 0.0F;
      float var2 = 28.6200008392334F;
      float var3 = -0.20000000298023224F;
      float var4 = 2.5999999046325684F;
      float var5 = 2.6600000858306885F;
      float var6 = 2.640000104904175F;
      float var7 = (float)Math.toRadians((double)var0);
      float var8 = Math.abs(var0);
      float var9 = 29.100000381469727F
         - 1.7000000476837158F
            * smooth(20.0F, 90.0F, var8)
         - 1.2000000476837158F
            * smooth(95.0F, 160.0F, var8);
      float var10 = (float)Math.asin(
         (double)Math.max(-0.949999988079071F, Math.min(0.949999988079071F, (var9 - var2) / var5))
      );
      float var11 = (float)(Math.sin((double)var7) * Math.cos((double)var10));
      float var12 = (float)Math.sin((double)var10);
      float var13 = (float)(Math.cos((double)var7) * Math.cos((double)var10));
      float var14 = 0.0F;
      float var15 = 30.25F - var2;
      float var16 = -1.9500000476837158F - var3;
      float var17 = (float)Math.sqrt((double)(var14 * var14 + var15 * var15 + var16 * var16));
      var14 /= var17;
      var15 /= var17;
      var16 /= var17;
      float[] var10000 = new float[4];
      var10000[0] = 0.0F;
      var10000[1] = 0.3499999940395355F;
      var10000[2] = 0.699999988079071F;
      var10000[3] = 1.0F;
      float[] var18 = var10000;
      var10000 = new float[4];
      var10000[0] = 0.5F;
      var10000[1] = 0.5600000023841858F;
      var10000[2] = 0.5F;
      var10000[3] = 0.3199999928474426F;
      float[] var19 = var10000;
      float[] var20 = new float[16];

      for (int var21 = 0; var21 < (4); var21++) {
         float var22 = var11 + (var14 - var11) * var18[var21];
         float var23 = var12 + (var15 - var12) * var18[var21];
         float var24 = var13 + (var16 - var13) * var18[var21];
         float var25 = (float)Math.sqrt((double)(var22 * var22 + var23 * var23 + var24 * var24));
         var22 /= var25;
         var23 /= var25;
         var24 /= var25;
         float var26 = 1.0F
            / (float)Math.sqrt((double)(var22 * var22 / (var4 * var4) + var23 * var23 / (var5 * var5) + var24 * var24 / (var6 * var6)));
         float var27 = var21 == (3) ? -0.10000000149011612F : 0.03999999910593033F;
         var20[var21 * (4)] = var1 + var22 * (var26 + var27);
         var20[var21 * (4) + (1)] = var2 + var23 * (var26 + var27);
         var20[var21 * (4) + (2)] = var3 + var24 * (var26 + var27);
         var20[var21 * (4) + (3)] = var19[var21];
      }

      return SdfShapes.tube(var20).flattenFrom(2.4000000953674316F, var1, var2, var3);
   }

   private static SurfacePaint capPaint() {
      return SurfacePaint.field(
         (var0, var1, var2) -> ArgbColors.mix(
               ArgbColors.mix(
                  -15063975,
                  -14140794,
                  smooth(26.200000762939453F, 28.399999618530273F, var1)
               ),
               -12756032,
               smooth(29.399999618530273F, 31.200000762939453F, var1)
                  * 0.800000011920929F
            )
      );
   }

   private static Sdf3D fringe(List<float[]> var0, List<float[]> var1) {
      Sdf3D[] var2 = new Sdf3D[var0.size() + var1.size()];

      for (int var3 = 0; var3 < var2.length; var3++) {
         int var4 = var3 >= var0.size() ? 1 : 0;
         float[] var5 = var4 != 0 ? (float[])var1.get(var3 - var0.size()) : (float[])var0.get(var3);
         int var6 = var5.length / (4);
         float[] var7 = new float[var6 * (2)];

         for (int var8 = 0; var8 < var6; var8++) {
            var7[var8 * (2)] = var5[var8 * (4)];
            var7[var8 * (2) + (1)] = var5[var8 * (4) + (1)];
         }

         float var9 = var4 != 0
            ? 1.1200000047683716F
            : ((var3 & (1)) == 0 ? 0.9300000071525574F : 1.0399999618530273F);
         var2[var3] = SdfShapes.tube(var5)
            .flattenFrom(
               2.5999999046325684F,
               0.0F,
               28.399999618530273F,
               -0.30000001192092896F
            )
            .intersect(
               SdfShapes.extrude(
                  Sdf2D.path(
                     var5[3] * 2.5999999046325684F, 0.019999999552965164F, var7
                  ),
                  4.0F,
                  0.0F
               )
            )
            .paint(
               SurfacePaint.field(
                  (var1x, var2x, var3x) -> ArgbColors.shade(
                        ArgbColors.mix(
                           ArgbColors.mix(
                              -14140794,
                              -12756032,
                              smooth(29.600000381469727F, 30.600000381469727F, var2x)
                                 * 0.5F
                           ),
                           -12948262,
                           smooth(28.899999618530273F, 27.399999618530273F, var2x)
                              * 0.8500000238418579F
                        ),
                        var9
                     )
               )
            );
      }

      return SdfShapes.union(var2);
   }

   private static void shine(CharacterPartBuilder var0, List<float[]> var1) {
      for (int var2 = 0; var2 < var1.size(); var2++) {
         float[] var3 = (float[])var1.get(var2);
         int var4 = var3.length / (4);

         for (int var5 = 1; var5 < var4; var5++) {
            float var6 = var3[var5 * (4) - (3)];
            float var7 = var3[var5 * (4) + (1)];
            if (!(var6 < 29.149999618530273F) && !(var7 > 29.149999618530273F)) {
               float var8 = (var6 - 29.149999618530273F) / (var6 - var7);
               float var9 = var3[var5 * (4) - (4)]
                  + (var3[var5 * (4)] - var3[var5 * (4) - (4)]) * var8;
               float var10 = var3[var5 * (4) - (2)]
                  + (var3[var5 * (4) + (2)] - var3[var5 * (4) - (2)])
                     * var8;
               float var11 = var3[var5 * (4) - (1)]
                  + (var3[var5 * (4) + (3)] - var3[var5 * (4) - (1)])
                     * var8;
               float var12 = (float)Math.atan2((double)var9, (double)(var10 + 0.20000000298023224F));
               if (!(Math.abs(var12) > 0.9599999785423279F)) {
                  float var13 = var11
                     * 1.100000023841858F
                     / (float)Math.sqrt(
                        (double)(
                           var9 * var9 + (var10 + 0.20000000298023224F) * (var10 + 0.20000000298023224F)
                        )
                     );
                  float var14 = 7.0F
                     + (float)Math.toDegrees((double)var13) * 0.25F;
                  float var15 = 64.0F / (var13 * 1.5F);
                  float[] var16 = new float[6];
                  float[] var17 = new float[6];

                  for (int var18 = 0; var18 < (3); var18++) {
                     float var19 = var13
                        * 0.6000000238418579F
                        * ((float)var18 * 0.5F - 1.0F);
                     float var20 = var13 * 0.6000000238418579F * (float)var18 * 0.5F;
                     var16[var18 * (2)] = 32.0F + var19 * var15;
                     var16[var18 * (2) + (1)] = 13.0F
                        + 25.0F * ((float)Math.cos((double)var12) - (float)Math.cos((double)(var12 + var19)));
                     var17[var18 * (2)] = 32.0F + var20 * var15;
                     var17[var18 * (2) + (1)] = 13.0F
                        + 25.0F * ((float)Math.cos((double)var12) - (float)Math.cos((double)(var12 + var20)));
                  }

                  PixelCanvas var21 = new PixelCanvas(64, 26);
                  var21.fill(
                     Sdf2D.path(var14 * 0.20000000298023224F, var14, var16)
                        .union(Sdf2D.path(var14, var14 * 0.20000000298023224F, var17)),
                     ArgbColors.withAlpha(-7363350, 0.5F),
                     5.0F
                  );
                  float var22 = hy(29.100000381469727F)
                     + 0.08100000023841858F
                     - 0.28999999165534973F * (1.0F - (float)Math.cos((double)var12))
                     + (float)((var2 & (1)) * (2) - (1))
                        * 0.029999999329447746F;
                  var0.decal(
                     SurfaceDecal.wrap(
                           var21,
                           0.0F,
                           var22,
                           -0.23199999332427979F,
                           0.0F,
                           1.0F,
                           0.0F,
                           (float)Math.sin((double)var12),
                           0.0F,
                           (float)Math.cos((double)var12),
                           (float)Math.toDegrees((double)(var13 * 1.5F)),
                           0.30159997940063477F
                        )
                        .radius(1.7999999523162842F, 4.199999809265137F)
                        .flatLight(0.800000011920929F)
                  );
               }
            }
         }
      }
   }

   private static void ponytail(CharacterRig var0) {
      float[][] var10000 = new float[11][];
      int var10002 = 0;
      float[] var10003 = new float[2];
      var10003[0] = 30.399999618530273F;
      var10003[1] = -2.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[2];
      var10003[0] = 31.100000381469727F;
      var10003[1] = -2.5F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[2];
      var10003[0] = 31.350000381469727F;
      var10003[1] = -3.25F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[2];
      var10003[0] = 30.950000762939453F;
      var10003[1] = -3.950000047683716F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[2];
      var10003[0] = 29.700000762939453F;
      var10003[1] = -4.300000190734863F;
      var10000[var10002] = var10003;
      var10002 = 5;
      var10003 = new float[2];
      var10003[0] = 27.600000381469727F;
      var10003[1] = -4.380000114440918F;
      var10000[var10002] = var10003;
      var10002 = 6;
      var10003 = new float[2];
      var10003[0] = 25.100000381469727F;
      var10003[1] = -4.21999979019165F;
      var10000[var10002] = var10003;
      var10002 = 7;
      var10003 = new float[2];
      var10003[0] = 22.5F;
      var10003[1] = -4.0F;
      var10000[var10002] = var10003;
      var10002 = 8;
      var10003 = new float[2];
      var10003[0] = 19.899999618530273F;
      var10003[1] = -3.799999952316284F;
      var10000[var10002] = var10003;
      var10002 = 9;
      var10003 = new float[2];
      var10003[0] = 17.5F;
      var10003[1] = -3.680000066757202F;
      var10000[var10002] = var10003;
      var10002 = 10;
      var10003 = new float[2];
      var10003[0] = 15.300000190734863F;
      var10003[1] = -3.740000009536743F;
      var10000[var10002] = var10003;
      float[][] var1 = var10000;
      int var2 = var1.length;
      float[] var41 = new float[11];
      var41[0] = 0.0F;
      var41[1] = 0.550000011920929F;
      var41[2] = 1.0F;
      var41[3] = 1.1799999475479126F;
      var41[4] = 1.2200000286102295F;
      var41[5] = 1.1799999475479126F;
      var41[6] = 1.0800000429153442F;
      var41[7] = 0.9599999785423279F;
      var41[8] = 0.8600000143051147F;
      var41[9] = 0.9800000190734863F;
      var41[10] = 1.350000023841858F;
      float[] var3 = var41;
      float[] var42 = new float[11];
      var42[0] = 0.44999998807907104F;
      var42[1] = 0.8799999952316284F;
      var42[2] = 1.0499999523162842F;
      var42[3] = 1.100000023841858F;
      var42[4] = 1.100000023841858F;
      var42[5] = 1.0499999523162842F;
      var42[6] = 0.9800000190734863F;
      var42[7] = 0.8600000143051147F;
      var42[8] = 0.699999988079071F;
      var42[9] = 0.5199999809265137F;
      var42[10] = 0.3400000035762787F;
      float[] var4 = var42;
      float[] var5 = new float[var2];
      float[] var6 = new float[var2];

      for (int var7 = 0; var7 < var2; var7++) {
         int var8 = Math.max(0, var7 - (1));
         int var9 = Math.min(var2 - (1), var7 + (1));
         float var10 = var1[var9][0] - var1[var8][0];
         float var11 = var1[var9][1] - var1[var8][1];
         float var12 = (float)Math.sqrt((double)(var10 * var10 + var11 * var11));
         var5[var7] = var11 / var12;
         var6[var7] = -var10 / var12;
      }

      var10000 = new float[8][];
      var10002 = 0;
      var10003 = new float[6];
      var10003[0] = -1.0199999809265137F;
      var10003[1] = 0.25F;
      var10003[2] = 10.100000381469727F;
      var10003[3] = 0.6800000071525574F;
      var10003[4] = 0.0F;
      var10003[5] = -1.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[6];
      var10003[0] = -0.5F;
      var10003[1] = -0.30000001192092896F;
      var10003[2] = 10.25F;
      var10003[3] = 0.7200000286102295F;
      var10003[4] = 1.100000023841858F;
      var10003[5] = -1.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[6];
      var10003[0] = 0.019999999552965164F;
      var10003[1] = 0.30000001192092896F;
      var10003[2] = 10.800000190734863F;
      var10003[3] = 0.7400000095367432F;
      var10003[4] = 2.299999952316284F;
      var10003[5] = 0.0F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[6];
      var10003[0] = 0.5400000214576721F;
      var10003[1] = -0.2800000011920929F;
      var10003[2] = 9.699999809265137F;
      var10003[3] = 0.7200000286102295F;
      var10003[4] = 0.6000000238418579F;
      var10003[5] = 1.0F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[6];
      var10003[0] = 1.0299999713897705F;
      var10003[1] = 0.2199999988079071F;
      var10003[2] = 9.550000190734863F;
      var10003[3] = 0.6600000262260437F;
      var10003[4] = 1.7000000476837158F;
      var10003[5] = 1.0F;
      var10000[var10002] = var10003;
      var10002 = 5;
      var10003 = new float[6];
      var10003[0] = -0.7200000286102295F;
      var10003[1] = 0.6200000047683716F;
      var10003[2] = 9.399999618530273F;
      var10003[3] = 0.6200000047683716F;
      var10003[4] = 2.9000000953674316F;
      var10003[5] = -1.0F;
      var10000[var10002] = var10003;
      var10002 = 6;
      var10003 = new float[6];
      var10003[0] = 0.7400000095367432F;
      var10003[1] = 0.6000000238418579F;
      var10003[2] = 9.5F;
      var10003[3] = 0.6200000047683716F;
      var10003[4] = 0.30000001192092896F;
      var10003[5] = 1.0F;
      var10000[var10002] = var10003;
      var10002 = 7;
      var10003 = new float[6];
      var10003[0] = -0.05000000074505806F;
      var10003[1] = -0.6200000047683716F;
      var10003[2] = 10.600000381469727F;
      var10003[3] = 0.6399999856948853F;
      var10003[4] = 2.0F;
      var10003[5] = 0.0F;
      var10000[var10002] = var10003;
      float[][] var22 = var10000;
      ArrayList var23 = new ArrayList();
      float[][] var24 = var22;
      int var26 = var22.length;

      for (int var29 = 0; var29 < var26; var29++) {
         float[] var32 = var24[var29];
         int var13 = Math.min((int)Math.floor((double)var32[2]), var2 - (1));
         float var14 = var32[2] - (float)var13;
         float[] var15 = new float[(var13 + (2)) * (4)];

         for (int var16 = 0; var16 <= var13; var16++) {
            float var17 = var3[var16];
            float var18 = smooth(6.5F, 8.600000381469727F, (float)var16);
            float var19 = 0.14000000059604645F
               * (float)Math.sin((double)((float)var16 * 0.8999999761581421F + var32[4]))
               * smooth(1.0F, 4.0F, (float)var16)
               * (1.0F - var18);
            float var20 = var32[0] * var17 + var19;
            float var21 = var32[1]
               * var17
               * 0.75F
               * (1.0F - 0.6000000238418579F * var18);
            var15[var16 * (4)] = var20
               + (
                     var32[5] * 1.149999976158142F * var17
                        + var32[0] * 0.20000000298023224F * var17
                        - var20
                  )
                  * var18;
            var15[var16 * (4) + (1)] = var1[var16][0] + var5[var16] * var21;
            var15[var16 * (4) + (2)] = var1[var16][1] + var6[var16] * var21;
            var15[var16 * (4) + (3)] = var32[3]
               * 1.0800000429153442F
               * var4[var16];
         }

         int var38 = (var13 + (1)) * (4);
         int var39 = Math.min(var13 + (1), var2 - (1));
         float var40 = Math.max(var14, 0.44999998807907104F);
         var15[var38] = var15[var13 * (4)] * 1.1200000047683716F
            + var32[5] * 0.20000000298023224F;
         var15[var38 + (1)] = var1[var13][0]
            + (var1[var39][0] - var1[var13][0]) * var40
            - 1.100000023841858F;
         var15[var38 + (2)] = var15[var13 * (4) + (2)]
            + (var1[var39][1] - var1[var13][1]) * var40
            - 0.10000000149011612F;
         var15[var38 + (3)] = 0.03999999910593033F;
         split(var23, var15, 6, 1.600000023841858F, true);
      }

      float[] var25 = new float[36];

      for (int var27 = 0; var27 < (9); var27++) {
         var25[var27 * (4) + (1)] = var1[var27][0];
         var25[var27 * (4) + (2)] = var1[var27][1];
         var25[var27 * (4) + (3)] = 0.6399999856948853F * var4[var27];
      }

      split(var23, var25, 5, 1.399999976158142F, false);
      var10000 = new float[3][];
      var10002 = 0;
      var10003 = new float[12];
      var10003[0] = 0.05000000074505806F;
      var10003[1] = 30.549999237060547F;
      var10003[2] = -2.1500000953674316F;
      var10003[3] = 0.10000000149011612F;
      var10003[4] = 31.450000762939453F;
      var10003[5] = -2.5999999046325684F;
      var10003[6] = 0.15000000596046448F;
      var10003[7] = 32.04999923706055F;
      var10003[8] = -3.3499999046325684F;
      var10003[9] = 0.10000000149011612F;
      var10003[10] = 31.850000381469727F;
      var10003[11] = -4.150000095367432F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[12];
      var10003[0] = 0.30000001192092896F;
      var10003[1] = 30.5F;
      var10003[2] = -2.0999999046325684F;
      var10003[3] = 0.7200000286102295F;
      var10003[4] = 31.25F;
      var10003[5] = -2.700000047683716F;
      var10003[6] = 0.9800000190734863F;
      var10003[7] = 31.719999313354492F;
      var10003[8] = -3.450000047683716F;
      var10003[9] = 1.0800000429153442F;
      var10003[10] = 31.420000076293945F;
      var10003[11] = -4.050000190734863F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[12];
      var10003[0] = -0.3499999940395355F;
      var10003[1] = 30.5F;
      var10003[2] = -2.0999999046325684F;
      var10003[3] = -0.7599999904632568F;
      var10003[4] = 31.200000762939453F;
      var10003[5] = -2.75F;
      var10003[6] = -1.0199999809265137F;
      var10003[7] = 31.6200008392334F;
      var10003[8] = -3.4000000953674316F;
      var10003[9] = -1.1200000047683716F;
      var10003[10] = 31.31999969482422F;
      var10003[11] = -4.0F;
      var10000[var10002] = var10003;
      float[][] var28 = var10000;
      float[][] var30 = var28;
      int var33 = var28.length;

      for (int var35 = 0; var35 < var33; var35++) {
         float[] var37 = var30[var35];
         float[] var10001 = new float[16];
         var10001[0] = var37[0];
         var10001[1] = var37[1];
         var10001[2] = var37[2];
         var10001[3] = 0.36000001430511475F;
         var10001[4] = var37[3];
         var10001[5] = var37[4];
         var10001[6] = var37[5];
         var10001[7] = 0.4399999976158142F;
         var10001[8] = var37[6];
         var10001[9] = var37[7];
         var10001[10] = var37[8];
         var10001[11] = 0.30000001192092896F;
         var10001[12] = var37[9];
         var10001[13] = var37[10];
         var10001[14] = var37[11];
         var10001[15] = 0.03999999910593033F;
         var23.add(
            SdfShapes.tube(var10001)
               .flattenFrom(
                  1.7999999523162842F,
                  0.0F,
                  26.0F,
                  0.5F
               )
         );
      }

      SurfacePaint var31 = SurfacePaint.field(
         (var0x, var1x, var2x) -> {
            int var3x = ArgbColors.mix(
               -14140794,
               -12948262,
               smooth(27.5F, 21.5F, var1x)
            );
            var3x = ArgbColors.mix(
               var3x, -13246209, smooth(21.5F, 16.0F, var1x)
            );
            float var4x = smooth(30.899999618530273F, 31.5F, var1x)
               * smooth(-2.4000000953674316F, -3.200000047683716F, var2x);
            return ArgbColors.mix(var3x, -7363350, var4x * 0.5F);
         }
      );
      Sdf3D var34 = SdfShapes.union(((Sdf3D[]) var23.toArray(new Sdf3D[0]))).paint(var31);
      Sdf3D var36 = ring(
            0.0F,
            30.3799991607666F,
            -2.049999952316284F,
            0.0F,
            0.550000011920929F,
            -0.8299999833106995F,
            0.5199999809265137F,
            0.3799999952316284F
         )
         .roughen(0.05000000074505806F, 0.30000001192092896F)
         .color(-13703425);
      CharacterPartBuilder var45 = var0.extra("ponytail", CharacterBone.HEAD)
         .pivot(
            0.0F,
            hy(30.350000381469727F),
            -2.377999782562256F
         );
      Sdf3D[] var46 = new Sdf3D[2];
      var46[0] = var34;
      var46[1] = var36;
      var45.shape(grow(SdfShapes.union(var46)))
         .detail(1.0F)
         .resolution(1.2999999523162842F)
         .outline(-15327158, 0.11999999731779099F)
         .flatLight(0.4000000059604645F)
         .occlusion(0.4000000059604645F)
         .motion(
            BoneMotionProfile.hair()
               .idle(
                  3.0F,
                  0.0F,
                  2.5F,
                  0.30000001192092896F
               )
               .walk(
                  7.0F,
                  0.0F,
                  5.0F,
                  2.0F
               )
               .drag(22.0F)
               .hang(0.30000001192092896F)
               .follow(CharacterBone.BODY, 0.6000000238418579F)
               .turn(18.0F, 4.0F)
               .spring(36.0F, 4.199999809265137F)
               .bend(1.5F)
               .limit(70.0F)
         );
   }

   private static void split(List<Sdf3D> var0, float[] var1, int var2, float var3, boolean var4) {
      int var5 = var1.length / (4);
      if (var5 < var2 + (3)) {
         var0.add(
            SdfShapes.tube(var1)
               .flattenFrom(
                  var3,
                  0.0F,
                  26.0F,
                  0.5F
               )
         );
      } else {
         var0.add(
            SdfShapes.tube(Arrays.copyOfRange(var1, 0, (var2 + (2)) * (4)))
               .flattenFrom(
                  var3,
                  0.0F,
                  26.0F,
                  0.5F
               )
         );
         Object var6 = SdfShapes.tube(
               Arrays.copyOfRange(var1, (var2 - (1)) * (4), var5 * (4))
            )
            .flattenFrom(
               var3, 0.0F, 26.0F, 0.5F
            );
         if (var4) {
            int var7 = (var5 - (3)) * (4);
            int var8 = (var5 - (2)) * (4);
            int var9 = (var5 - (1)) * (4);
            float var10000 = 2.4000000953674316F;
            float var10001 = 0.019999999552965164F;
            float[] var10002 = new float[6];
            var10002[0] = var1[var7];
            var10002[1] = var1[var7 + (1)];
            var10002[2] = var1[var8];
            var10002[3] = var1[var8 + (1)];
            var10002[4] = var1[var9];
            var10002[5] = var1[var9 + (1)];
            Sdf2D var10 = Sdf2D.path(var10000, var10001, var10002);
            Sdf3D[] var11 = new Sdf3D[2];
            var11[0] = SdfShapes.above(var1[var8 + (1)]);
            var11[1] = SdfShapes.extrude(
               var10, 8.0F, 0.0F
            );
            var6 = ((Sdf3D)var6).intersect(SdfShapes.union(var11));
         }

          var0.add((Sdf3D)var6);
      }
   }

   private static Sdf3D body(CharacterRig var0, PixelCanvas var1) {
      SurfacePaint var2 = SurfacePaint.field(
            (var0x, var1x, var2x) -> ArgbColors.mix(
                  -9274,
                  -1331558,
                  smooth(24.899999618530273F, 25.5F, var1x)
               )
         )
         .flatLight(1.0F)
         .occlusion(0.10000000149011612F);
      Sdf3D var3 = SdfShapes.cone(
            0.0F,
            23.200000762939453F,
            -0.2199999988079071F,
            0.6600000262260437F,
            0.0F,
            26.299999237060547F,
            0.0F,
            0.5799999833106995F
         )
         .paint(var2);
      float var10000 = 1.0F;
      Sdf3D[] var10001 = new Sdf3D[5];
      var10001[0] = SdfShapes.ellipsoid(
         0.0F,
         21.149999618530273F,
         0.0F,
         2.25F,
         2.049999952316284F,
         1.4500000476837158F
      );
      var10001[1] = SdfShapes.ellipsoid(
         0.0F,
         18.700000762939453F,
         0.0F,
         1.7799999713897705F,
         1.75F,
         1.2200000286102295F
      );
      var10001[2] = SdfShapes.ellipsoid(
         0.0F,
         16.600000381469727F,
         -0.05000000074505806F,
         2.0F,
         1.5F,
         1.399999976158142F
      );
      var10001[3] = SdfShapes.capsule(
         -2.200000047683716F,
         22.299999237060547F,
         -0.18000000715255737F,
         0.0F,
         22.6200008392334F,
         -0.18000000715255737F,
         0.8799999952316284F
      );
      var10001[4] = SdfShapes.capsule(
         0.0F,
         22.6200008392334F,
         -0.18000000715255737F,
         2.200000047683716F,
         22.299999237060547F,
         -0.18000000715255737F,
         0.8799999952316284F
      );
      Sdf3D var24 = SdfShapes.blend(var10000, var10001);
      float var29 = 0.6000000238418579F;
      Sdf3D[] var10002 = new Sdf3D[1];
      var10002[0] = SdfShapes.ellipsoid(
            0.8199999928474426F,
            20.850000381469727F,
            0.550000011920929F,
            0.8799999952316284F,
            0.8199999928474426F,
            0.8500000238418579F
         )
         .mirrorX();
      Sdf3D var4 = var24.blend(var29, var10002);
      var4.paint(
         SurfacePaint.vertical(
               -2498584, 17.200000762939453F, -525828, 19.399999618530273F
            )
            .flatLight(0.4000000059604645F)
      );
      Sdf3D var5 = SdfShapes.cone(
            0.0F,
            23.0F,
            -0.20000000298023224F,
            0.8999999761581421F,
            0.0F,
            25.299999237060547F,
            -0.11999999731779099F,
            0.7400000095367432F
         )
         .intersect(0.05999999865889549F, SdfShapes.below(25.100000381469727F))
         .color(-15263457);
      Sdf3D var6 = SdfShapes.ellipsoid(
            0.0F,
            14.949999809265137F,
            -0.05000000074505806F,
            1.9500000476837158F,
            1.2000000476837158F,
            1.350000023841858F
         )
         .color(-15263457);
      var10000 = 1.100000023841858F;
      var10001 = new Sdf3D[4];
      var10001[0] = SdfShapes.ellipsoid(
         0.0F,
         21.0F,
         -0.10000000149011612F,
         2.700000047683716F,
         2.4000000953674316F,
         1.9800000190734863F
      );
      var10001[1] = SdfShapes.capsule(
         -2.619999885559082F,
         22.25F,
         -0.2199999988079071F,
         0.0F,
         22.600000381469727F,
         -0.2199999988079071F,
         1.0399999618530273F
      );
      var10001[2] = SdfShapes.capsule(
         0.0F,
         22.600000381469727F,
         -0.2199999988079071F,
         2.619999885559082F,
         22.25F,
         -0.2199999988079071F,
         1.0399999618530273F
      );
      var10001[3] = oval(
         -0.10000000149011612F,
         18.299999237060547F,
         20.299999237060547F,
         2.450000047683716F,
         1.9700000286102295F,
         2.549999952316284F,
         1.9700000286102295F
      );
      Sdf3D var7 = SdfShapes.blend(var10000, var10001)
         .paint(
            SurfacePaint.field(
                  (var0x, var1x, var2x) -> ArgbColors.mix(
                        -12959662,
                        -1446155,
                        smooth(21.719999313354492F, 21.780000686645508F, var1x)
                     )
               )
               .flatLight(0.30000001192092896F)
               .occlusion(0.18000000715255737F)
         );
      Sdf3D var8 = oval(
            -0.10000000149011612F,
            17.420000076293945F,
            18.450000762939453F,
            2.450000047683716F,
            2.0299999713897705F,
            2.4700000286102295F,
            2.0199999809265137F
         )
         .color(-14210250);
      Sdf3D var9 = SdfShapes.torus(
            0.0F,
            23.520000457763672F,
            -0.2800000011920929F,
            1.2799999713897705F,
            0.3799999952316284F
         )
         .rotate(
            16.0F,
            0.0F,
            0.0F,
            0.0F,
            23.520000457763672F,
            -0.2800000011920929F
         )
         .color(-14210250);
      Sdf3D[] var26 = new Sdf3D[3];
      var26[0] = var7;
      var26[1] = var8;
      var26[2] = var9;
      Sdf3D var10 = SdfShapes.union(var26);
      Sdf3D var11 = SdfShapes.subtract(
         0.05999999865889549F, var10, opening(0.0F)
      );
      float var12 = frontZ(
         var10, -1.850000023841858F, 18.950000762939453F, 6.0F
      );
      float var13 = 16.950000762939453F;
      float var14 = flare(skirtT(var13));
      float var15 = 1.850000023841858F
         + 1.600000023841858F * var14
         + 0.2199999988079071F;
      float var16 = 1.5F
         + 1.399999976158142F * var14
         + 0.2199999988079071F;
      Sdf3D var17 = ovalRing(
            -0.05000000074505806F,
            var13,
            0.41999998688697815F,
            var15,
            var16,
            0.25999999046325684F
         )
         .color(-15263457);
      float var18 = -0.05000000074505806F
         + var16 * (float)Math.sqrt((double)(1.0F - 0.30250000953674316F / (var15 * var15)))
         + 0.25999999046325684F;
      Sdf3D var19 = SdfShapes.box(
            0.550000011920929F,
            var13,
            var18 + 0.05000000074505806F,
            0.46000000834465027F,
            0.36000001430511475F,
            0.14000000059604645F,
            0.10000000149011612F
         )
         .color(-13749702);
      CharacterPartBuilder var27 = var0.part(CharacterBone.BODY)
         .pivot(0.0F, 24.399999618530273F, 0.0F);
      var10001 = new Sdf3D[7];
      var10001[0] = var3;
      var10001[1] = var5;
      var10001[2] = var4;
      var10001[3] = var6;
      var10001[4] = var11;
      var10001[5] = var17;
      var10001[6] = var19;
      CharacterPartBuilder var20 = var27.shape(SdfShapes.union(var10001))
         .detail(1.0F)
         .outline(-15065558, 0.12999999523162842F)
         .occlusion(0.30000001192092896F);
      PixelCanvas var21 = backStripe();
      PixelCanvas var22 = band();
      var20.decal(topGraphic())
         .decal(
            SurfaceDecal.back(
                  var21,
                  2.0199999809265137F,
                  19.600000381469727F,
                  -2.0F,
                  0.6000000238418579F,
                  4.0F
               )
               .depth(1.399999976158142F, 1.399999976158142F)
         )
         .decal(
            SurfaceDecal.back(
                  var21,
                  -2.0199999809265137F,
                  19.600000381469727F,
                  -2.0F,
                  0.6000000238418579F,
                  4.0F
               )
               .depth(1.399999976158142F, 1.399999976158142F)
         )
         .decal(
            SurfaceDecal.wrap(
                  var1,
                  0.0F,
                  18.1200008392334F,
                  -0.10000000149011612F,
                  0.0F,
                  1.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  1.0F,
                  360.0F,
                  0.30000001192092896F
               )
               .radius(1.9500000476837158F, 3.200000047683716F)
         )
         .decal(
            SurfaceDecal.front(
                  pocket(),
                  -1.850000023841858F,
                  18.950000762939453F,
                  var12,
                  0.949999988079071F,
                  0.36000001430511475F
               )
               .depth(0.5F, 0.5F)
               .maxAngle(70.0F)
         )
         .decal(
            SurfaceDecal.front(
                  pocket().mirrored(),
                  1.850000023841858F,
                  18.950000762939453F,
                  var12,
                  0.949999988079071F,
                  0.36000001430511475F
               )
               .depth(0.5F, 0.5F)
               .maxAngle(70.0F)
         )
         .decal(
            SurfaceDecal.front(
                  var22,
                  0.0F,
                  17.6200008392334F,
                  1.899999976158142F,
                  2.0F,
                  0.2800000011920929F
               )
               .depth(1.2000000476837158F, 0.4000000059604645F)
               .maxAngle(70.0F)
         )
         .decal(
            SurfaceDecal.wrap(
                  var22,
                  0.0F,
                  24.799999237060547F,
                  -0.14000000059604645F,
                  0.0F,
                  1.0F,
                  0.0F,
                  0.0F,
                  0.0F,
                  1.0F,
                  240.0F,
                  0.25999999046325684F
               )
               .radius(0.4000000059604645F, 1.0499999523162842F)
         )
         .decal(
            SurfaceDecal.front(
                  buckle(),
                  0.550000011920929F,
                  var13,
                  var18 + 0.1899999976158142F,
                  0.9200000166893005F,
                  0.7200000286102295F
               )
               .depth(0.4000000059604645F, 0.30000001192092896F)
               .maxAngle(60.0F)
         );
      Sdf3D[] var28 = new Sdf3D[2];
      int var32 = 0;
      float[] var10003 = new float[16];
      var10003[0] = 0.9800000190734863F;
      var10003[1] = 16.700000762939453F;
      var10003[2] = var18 + 0.019999999552965164F;
      var10003[3] = 0.2800000011920929F;
      var10003[4] = 1.0199999809265137F;
      var10003[5] = 15.800000190734863F;
      var10003[6] = var18 + 0.25999999046325684F;
      var10003[7] = 0.2800000011920929F;
      var10003[8] = 1.0499999523162842F;
      var10003[9] = 14.899999618530273F;
      var10003[10] = var18 + 0.44999998807907104F;
      var10003[11] = 0.27000001072883606F;
      var10003[12] = 1.0700000524520874F;
      var10003[13] = 14.300000190734863F;
      var10003[14] = var18 + 0.550000011920929F;
      var10003[15] = 0.25999999046325684F;
      var28[var32] = SdfShapes.tube(var10003)
         .flatten(
            2.200000047683716F,
            0.0F,
            0.0F,
            1.0F
         )
         .color(-15263457);
      var28[1] = SdfShapes.box(
            1.0700000524520874F,
            14.149999618530273F,
            var18 + 0.5600000023841858F,
            0.2800000011920929F,
            0.20000000298023224F,
            0.12999999523162842F,
            0.07999999821186066F
         )
         .color(-3550757);
      Sdf3D var23 = SdfShapes.union(var28);
      var0.extra("strap", CharacterBone.BODY)
         .pivot(0.9800000190734863F, 16.700000762939453F, var18)
         .shape(var23)
         .resolution(0.699999988079071F)
         .detail(0.30000001192092896F)
         .noOutline()
         .motion(
            BoneMotionProfile.cloth()
               .walk(
                  8.0F,
                  0.0F,
                  5.0F,
                  2.0F
               )
               .drag(6.0F)
               .spring(40.0F, 5.0F)
               .bend(1.2000000476837158F)
         );
      return var10;
   }

   private static float openingWidth(float var0) {
      return 0.8500000238418579F
         + 0.6499999761581421F
            * (24.899999618530273F - var0)
            / 10.100000381469727F;
   }

   private static Sdf3D opening(float var0) {
      float[] var10000 = new float[8];
      var10000[0] = -0.8500000238418579F - var0;
      var10000[1] = 24.899999618530273F;
      var10000[2] = 0.8500000238418579F + var0;
      var10000[3] = 24.899999618530273F;
      var10000[4] = 1.5F + var0;
      var10000[5] = 14.800000190734863F;
      var10000[6] = -1.5F - var0;
      var10000[7] = 14.800000190734863F;
      return SdfShapes.extrude(
            Sdf2D.polygon(var10000), 2.5999999046325684F, 0.0F
         )
         .move(0.0F, 0.0F, 3.1500000953674316F);
   }

   private static Sdf3D piping(Sdf3D var0, float var1, float var2, float var3) {
      float[] var4 = new float[24];

      for (int var5 = 0; var5 < (8); var5++) {
         float var6 = var2 + (var3 - var2) * (float)var5 / 7.0F;
         float var7 = openingWidth(var6);
         var4[var5 * (3)] = var1 * (var7 + 0.09000000357627869F);
         var4[var5 * (3) + (1)] = var6;
         var4[var5 * (3) + (2)] = frontZ(
               var0, var1 * (var7 + 0.10000000149011612F), var6, 6.0F
            )
            - 0.05999999865889549F;
      }

      return SdfShapes.strand(0.12999999523162842F, 0.12999999523162842F, var4);
   }

   private static void skirt(CharacterRig var0, PixelCanvas var1) {
      SurfacePaint var2 = SurfacePaint.field(
            (var0x, var1x, var2x) -> {
               float var3x = (float)Math.atan2((double)var0x, (double)(var2x - -0.05000000074505806F));
               float var4x = pleat(var3x * 18.0F / 6.2831854820251465F);
               return ArgbColors.mix(
                  -14472632,
                  -12892555,
                  0.4000000059604645F
                     + 0.6000000238418579F
                        * (0.5F + 0.5F * var4x)
               );
            }
         )
         .flatLight(0.15000000596046448F);
      SurfaceDecal var3 = SurfaceDecal.wrap(
            var1,
            0.0F,
            11.770000457763672F,
            -0.05000000074505806F,
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            0.27000001072883606F
         )
         .radius(2.4000000953674316F, 4.599999904632568F);
      float var4 = (float)Math.toRadians(30.0);
      float var5 = (float)Math.toRadians(14.0);
      String[] var10000 = new String[3];
      var10000[0] = "skirt_f";
      var10000[1] = "skirt_s";
      var10000[2] = "skirt_b";
      String[] var6 = var10000;
      float[] var16 = new float[3];
      var16[0] = -30.0F;
      var16[1] = -90.0F;
      var16[2] = -150.0F;
      float[] var7 = var16;
      float[] var17 = new float[3];
      var17[0] = 0.5F;
      var17[1] = 0.41999998688697815F;
      var17[2] = 0.5F;
      float[] var8 = var17;
      float[] var18 = new float[3];
      var18[0] = 16.0F;
      var18[1] = 13.0F;
      var18[2] = 15.0F;
      float[] var9 = var18;

      for (int var10 = 0; var10 < (3); var10++) {
         float var11 = (float)Math.toRadians((double)var7[var10]);
         float var12 = 1.7999999523162842F * (float)Math.sin((double)var11);
         float var13 = -0.05000000074505806F + 1.4500000476837158F * (float)Math.cos((double)var11);
         BoneMotionProfile var14 = BoneMotionProfile.skirt(CharacterBone.RIGHT_LEG)
            .follow(CharacterBone.RIGHT_LEG, var8[var10], var9[var10])
            .drag(var10 == 0 ? 0.0F : 3.0F);
         CharacterPartBuilder var15 = var0.extra(var6[var10] + "_r", CharacterBone.BODY)
            .pivot(var12, 16.899999618530273F, var13)
            .shape(skirtPanel(var11, var4, var5).paint(var2))
            .motion(var14)
            .detail(0.3199999928474426F)
            .resolution(1.0F)
            .occlusion(0.30000001192092896F)
            .noOutline()
            .decal(var3);
         var0.extra(var6[var10] + "_l", CharacterBone.BODY).mirrorOf(var15);
      }
   }

   private static float skirtT(float var0) {
      return clamp01((17.299999237060547F - var0) / 6.049999237060547F);
   }

   private static float flare(float var0) {
      return var0 * (1.25F - 0.25F * var0);
   }

   private static float skirtRadius(float var0, float var1, float var2, float var3, float var4) {
      float var5 = skirtT(var4);
      float var6 = flare(var5);
      float var7 = 1.850000023841858F + 1.600000023841858F * var6;
      float var8 = 1.5F + 1.399999976158142F * var6;
      float var9 = (float)Math.sqrt((double)(var8 * var8 * var0 * var0 + var7 * var7 * var1 * var1));
      float var10 = var9 < 9.999999747378752e-06F ? var7 : var7 * var8 * var2 / var9;
      return var10
         + (0.05000000074505806F + 0.23999999463558197F * var5)
            * pleat(var3 * 18.0F / 6.2831854820251465F);
   }

   private static Sdf3D skirtPanel(float var0, float var1, float var2) {
      float var3 = 0.0F;
      float var4 = 0.0F;
      float var5 = -0.05000000074505806F;
      float var6 = -0.05000000074505806F;

      for (int var7 = 0; var7 <= (16); var7++) {
         float var8 = var0
            - var1
            - var2
            + (var1 + var2) * 2.0F * (float)var7 / 16.0F;
         float[] var10000 = new float[2];
         var10000[0] = 1.399999976158142F;
         var10000[1] = 4.050000190734863F;
         float[] var9 = var10000;
         int var10 = var9.length;

         for (int var11 = 0; var11 < var10; var11++) {
            float var12 = var9[var11];
            var3 = Math.min(var3, var12 * (float)Math.sin((double)var8));
            var4 = Math.max(var4, var12 * (float)Math.sin((double)var8));
            var5 = Math.min(var5, -0.05000000074505806F + var12 * (float)Math.cos((double)var8));
            var6 = Math.max(var6, -0.05000000074505806F + var12 * (float)Math.cos((double)var8));
         }
      }

      return SdfShapes.field(
         (var3x, var4x, var5x) -> {
            float var6x = var5x - -0.05000000074505806F;
            float var7x = (float)Math.atan2((double)var3x, (double)var6x);
            float var8x = var7x - var0;
            if ((double)var8x > 3.141592653589793) {
               var8x -= 6.2831854820251465F;
            }

            if ((double)var8x < -3.141592653589793) {
               var8x += 6.2831854820251465F;
            }

            float var9x = Math.abs(var8x) - var1;
            float var10x = (float)Math.sqrt((double)(var3x * var3x + var6x * var6x));
            float var11x = skirtRadius(var3x, var6x, var10x, var7x, var4x)
               - 0.3199999928474426F
                  * smooth(0.0F, 0.05000000074505806F, var9x);
            float var12x = Math.abs(var10x - var11x) - 0.41999998688697815F;
            float var13 = Math.max(var4x - 17.299999237060547F, 11.25F - var4x);
            float var14 = Math.max(-1.2000000476837158F, Math.min(1.2000000476837158F, var9x - var2));
            float var15 = var10x * var14 * (1.0F - var14 * var14 / 6.0F);
            return Math.max(var12x, Math.max(var13, var15)) * 0.800000011920929F;
         },
         var3 - 0.20000000298023224F,
         11.050000190734863F,
         var5 - 0.20000000298023224F,
         var4 + 0.20000000298023224F,
         17.5F,
         var6 + 0.20000000298023224F
      );
   }

   private static void arms(CharacterRig var0, PixelCanvas var1) {
      float var2 = -3.680000066757202F;
      float var3 = 18.399999618530273F;
      float var4 = -0.10000000149011612F;
      float var5 = var2 + 3.299999952316284F;
      float var6 = var3 - 21.799999237060547F;
      float var7 = var4 + 0.11999999731779099F;
      float var8 = (float)Math.sqrt((double)(var5 * var5 + var6 * var6 + var7 * var7));
      var5 /= var8;
      var6 /= var8;
      var7 /= var8;
      float var10000 = 0.44999998807907104F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.sphere(
         -3.2200000286102295F,
         22.200000762939453F,
         -0.15000000596046448F,
         1.100000023841858F
      );
      var10001[1] = SdfShapes.cone(
         -3.299999952316284F,
         21.799999237060547F,
         -0.11999999731779099F,
         1.0700000524520874F,
         var2,
         var3,
         var4,
         0.9599999785423279F
      );
      Sdf3D var9 = SdfShapes.blend(var10000, var10001);
      Sdf3D var10 = var9.intersect(SdfShapes.plane(var2, var3, var4, var5, var6, var7).color(-14210250))
         .paint(
            SurfacePaint.field(
                  (var0x, var1x, var2x) -> ArgbColors.mix(
                        -1446155,
                        -3945254,
                        smooth(-3.200000047683716F, -2.5999999046325684F, var0x)
                           * 0.699999988079071F
                     )
               )
               .flatLight(0.30000001192092896F)
         );
      float var11 = var2 - var5 * 0.05000000074505806F;
      float var12 = var3 - var6 * 0.05000000074505806F;
      float var13 = var4 - var7 * 0.05000000074505806F;
      Sdf3D var14 = ring(
            var11, var12, var13, var5, var6, var7, 0.8600000143051147F, 0.3400000035762787F
         )
         .color(-14210250);
      SurfacePaint var15 = SurfacePaint.of(-9274)
         .flatLight(1.0F)
         .occlusion(0.25F);
      Sdf3D var16 = SdfShapes.cone(
            var2,
            var3 - 0.10000000149011612F,
            var4 + 0.05000000074505806F,
            0.550000011920929F,
            -3.9200000762939453F,
            14.65999984741211F,
            0.15000000596046448F,
            0.38999998569488525F
         )
         .paint(var15)
         .rotate(
            -13.0F,
            0.0F,
            0.0F,
            var2,
            var3,
            var4
         );
      float var17 = -1.5F;
      float var18 = (float)Math.cos(Math.toRadians((double)var17));
      float var19 = (float)Math.sin(Math.toRadians((double)var17));
      float var20 = -3.299999952316284F
         + (var11 + 3.299999952316284F) * var18
         - (var12 - 22.399999618530273F) * var19;
      float var21 = 22.399999618530273F
         + (var11 + 3.299999952316284F) * var19
         + (var12 - 22.399999618530273F) * var18;
      float var22 = var5 * var18 - var6 * var19;
      float var23 = var5 * var19 + var6 * var18;
      float[] var24 = bent(
         -4.150000095367432F,
         12.75F,
         0.44999998807907104F,
         var2,
         var3,
         var4
      );
      float var25 = -3.299999952316284F
         + (var24[0] + 3.299999952316284F) * var18
         - (var24[1] - 22.399999618530273F) * var19;
      float var26 = 22.399999618530273F
         + (var24[0] + 3.299999952316284F) * var19
         + (var24[1] - 22.399999618530273F) * var18;
      CharacterPartBuilder var34 = var0.part(CharacterBone.RIGHT_ARM)
         .pivot(-3.299999952316284F, 22.399999618530273F, -0.10000000149011612F)
         .grip(var25, var26, var24[2]);
      var10001 = new Sdf3D[3];
      var10001[0] = var10;
      var10001[1] = var14;
      var10001[2] = var16;
      CharacterPartBuilder var27 = var34.shape(
            SdfShapes.union(var10001)
               .rotate(
                  0.0F,
                  0.0F,
                  var17,
                  -3.299999952316284F,
                  22.399999618530273F,
                  -0.10000000149011612F
               )
         )
         .outline(-12959918, 0.11999999731779099F)
         .occlusion(0.30000001192092896F)
         .swing(0.800000011920929F)
         .joint(
            -3.7799999713897705F,
            18.40999984741211F,
            -0.10000000149011612F,
            0.550000011920929F
         );
      CharacterPartBuilder var28 = var0.part(CharacterBone.LEFT_ARM).mirrorOf(var27);
      var27.decal(
         SurfaceDecal.wrap(
               var1,
               var20,
               var21,
               var13,
               -var22,
               -var23,
               -var7,
               -1.0F,
               0.0F,
               0.30000001192092896F,
               250.0F,
               0.4000000059604645F
            )
            .radius(0.949999988079071F, 1.600000023841858F)
      );
      var28.decal(
         SurfaceDecal.wrap(
               var1,
               -var20,
               var21,
               var13,
               var22,
               -var23,
               -var7,
               1.0F,
               0.0F,
               0.30000001192092896F,
               250.0F,
               0.4000000059604645F
            )
            .radius(0.949999988079071F, 1.600000023841858F)
      );
      var28.decal(
         SurfaceDecal.left(
               sleevePatch(),
               4.449999809265137F,
               20.299999237060547F,
               -0.10000000149011612F,
               1.0499999523162842F,
               1.0499999523162842F
            )
            .depth(0.800000011920929F, 0.800000011920929F)
            .maxAngle(65.0F)
      );
      var27.decal(
         SurfaceDecal.right(
               sleeveText(),
               -4.5F,
               20.200000762939453F,
               -0.10000000149011612F,
               0.6200000047683716F,
               1.75F
            )
            .depth(0.800000011920929F, 0.800000011920929F)
            .maxAngle(65.0F)
      );
      CharacterPartBuilder var29 = var0.extra(
            "hand_r", CharacterBone.RIGHT_ARM
         )
         .shape(
            hand()
               .rotate(
                  -13.0F,
                  0.0F,
                  0.0F,
                  var2,
                  var3,
                  var4
               )
               .rotate(
                  0.0F,
                  0.0F,
                  var17,
                  -3.299999952316284F,
                  22.399999618530273F,
                  -0.10000000149011612F
               )
         )
         .resolution(0.44999998807907104F)
         .detail(0.5F)
         .outline(-6657438, 0.10000000149011612F)
         .flatLight(1.0F)
         .occlusion(0.25F);
      var0.extra("hand_l", CharacterBone.LEFT_ARM).mirrorOf(var29);
      CharacterPartBuilder var30 = var0.extra(
            "wrist_r", CharacterBone.RIGHT_ARM
         )
         .shape(
            SdfShapes.ellipsoid(
                  -3.9700000286102295F,
                  14.119999885559082F,
                  0.1599999964237213F,
                  0.3100000023841858F,
                  0.5F,
                  0.3700000047683716F
               )
               .color(-9274)
               .rotate(
                  -13.0F,
                  0.0F,
                  0.0F,
                  var2,
                  var3,
                  var4
               )
               .rotate(
                  0.0F,
                  0.0F,
                  var17,
                  -3.299999952316284F,
                  22.399999618530273F,
                  -0.10000000149011612F
               )
         )
         .resolution(0.6000000238418579F)
         .detail(1.399999976158142F)
         .outline(-6657438, 0.10000000149011612F)
         .flatLight(1.0F)
         .occlusion(0.25F);
      var0.extra("wrist_l", CharacterBone.LEFT_ARM).mirrorOf(var30);
   }

   private static float[] bent(float var0, float var1, float var2, float var3, float var4, float var5) {
      double var6 = Math.toRadians(-13.0);
      float var8 = (float)Math.cos(var6);
      float var9 = (float)Math.sin(var6);
      float var10 = var1 - var4;
      float var11 = var2 - var5;
      float[] var10000 = new float[3];
      var10000[0] = var0;
      var10000[1] = var4 + var10 * var8 - var11 * var9;
      var10000[2] = var5 + var10 * var9 + var11 * var8;
      return var10000;
   }

   private static Sdf3D hand() {
      Sdf3D var0 = SdfShapes.ellipsoid(
         -4.0F,
         13.199999809265137F,
         0.14000000059604645F,
         0.30000001192092896F,
         0.6800000071525574F,
         0.5400000214576721F
      );
      float var10000 = 0.20000000298023224F;
      float var10001 = 0.15000000596046448F;
      float[] var10002 = new float[9];
      var10002[0] = -3.859999895095825F;
      var10002[1] = 13.350000381469727F;
      var10002[2] = 0.6000000238418579F;
      var10002[3] = -3.7200000286102295F;
      var10002[4] = 12.899999618530273F;
      var10002[5] = 0.9200000166893005F;
      var10002[6] = -3.619999885559082F;
      var10002[7] = 12.5F;
      var10002[8] = 0.9800000190734863F;
      TaperedTubeSdf3D var1 = SdfShapes.strand(var10000, var10001, var10002);
      Sdf3D[] var3 = new Sdf3D[4];
      int var5 = 0;
      float var10003 = 0.17000000178813934F;
      float var10004 = 0.15000000596046448F;
      float[] var10005 = new float[9];
      var10005[0] = -3.9800000190734863F;
      var10005[1] = 12.720000267028809F;
      var10005[2] = 0.5600000023841858F;
      var10005[3] = -3.9200000762939453F;
      var10005[4] = 12.100000381469727F;
      var10005[5] = 0.7200000286102295F;
      var10005[6] = -3.799999952316284F;
      var10005[7] = 11.65999984741211F;
      var10005[8] = 0.800000011920929F;
      var3[var5] = SdfShapes.strand(var10003, var10004, var10005);
      int var6 = 1;
      var10003 = 0.17000000178813934F;
      var10004 = 0.15000000596046448F;
      var10005 = new float[9];
      var10005[0] = -4.0F;
      var10005[1] = 12.739999771118164F;
      var10005[2] = 0.23999999463558197F;
      var10005[3] = -3.880000114440918F;
      var10005[4] = 12.119999885559082F;
      var10005[5] = 0.2800000011920929F;
      var10005[6] = -3.6600000858306885F;
      var10005[7] = 11.800000190734863F;
      var10005[8] = 0.30000001192092896F;
      var3[var6] = SdfShapes.strand(var10003, var10004, var10005);
      int var7 = 2;
      var10003 = 0.16500000655651093F;
      var10004 = 0.14499999582767487F;
      var10005 = new float[9];
      var10005[0] = -4.0F;
      var10005[1] = 12.720000267028809F;
      var10005[2] = -0.07999999821186066F;
      var10005[3] = -3.880000114440918F;
      var10005[4] = 12.180000305175781F;
      var10005[5] = -0.07999999821186066F;
      var10005[6] = -3.6600000858306885F;
      var10005[7] = 11.880000114440918F;
      var10005[8] = -0.05999999865889549F;
      var3[var7] = SdfShapes.strand(var10003, var10004, var10005);
      int var8 = 3;
      var10003 = 0.15000000596046448F;
      var10004 = 0.12999999523162842F;
      var10005 = new float[9];
      var10005[0] = -3.990000009536743F;
      var10005[1] = 12.65999984741211F;
      var10005[2] = -0.36000001430511475F;
      var10005[3] = -3.880000114440918F;
      var10005[4] = 12.300000190734863F;
      var10005[5] = -0.36000001430511475F;
      var10005[6] = -3.700000047683716F;
      var10005[7] = 12.0600004196167F;
      var10005[8] = -0.33000001311302185F;
      var3[var8] = SdfShapes.strand(var10003, var10004, var10005);
      Sdf3D var2 = SdfShapes.union(var3);
      Sdf3D[] var4 = new Sdf3D[2];
      int var9 = 0;
      var10003 = 0.11999999731779099F;
      Sdf3D[] var17 = new Sdf3D[3];
      var17[0] = var0;
      var17[1] = var1;
      var17[2] = var2;
      var4[var9] = SdfShapes.blend(var10003, var17).color(-9274);
      var4[1] = SdfShapes.cylinder(
            -3.950000047683716F,
            14.220000267028809F,
            0.18000000715255737F,
            -3.930000066757202F,
            14.899999618530273F,
            0.15000000596046448F,
            0.5F,
            0.10000000149011612F
         )
         .color(-13703425);
      return SdfShapes.union(var4);
   }

   private static void legs(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.cone(
         -1.2400000095367432F,
         14.100000381469727F,
         0.0F,
         1.2999999523162842F,
         -1.100000023841858F,
         8.300000190734863F,
         0.10000000149011612F,
         0.8399999737739563F
      );
      Sdf3D var2 = SdfShapes.sphere(
         -1.0700000524520874F,
         7.679999828338623F,
         0.18000000715255737F,
         0.75F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -1.059999942779541F,
         7.800000190734863F,
         0.5F,
         0.5199999809265137F
      );
      Sdf3D var4 = SdfShapes.cone(
         -1.0700000524520874F,
         7.300000190734863F,
         0.05999999865889549F,
         0.7799999713897705F,
         -1.1200000047683716F,
         2.5999999046325684F,
         -0.10000000149011612F,
         0.5F
      );
      Sdf3D var5 = SdfShapes.ellipsoid(
         -1.1200000047683716F,
         5.800000190734863F,
         -0.20000000298023224F,
         0.7200000286102295F,
         1.5F,
         0.7400000095367432F
      );
      Sdf3D var6 = SdfShapes.sphere(
         -1.100000023841858F,
         14.399999618530273F,
         -0.05000000074505806F,
         1.3200000524520874F
      );
      SurfacePaint var7 = SurfacePaint.field(
         (var0x, var1x, var2x) -> ArgbColors.mix(
               ArgbColors.mix(
                  -14012606,
                  -9274,
                  smooth(6.699999809265137F, 6.949999809265137F, var1x)
               ),
               -15263457,
               smooth(12.199999809265137F, 12.399999618530273F, var1x)
            )
      );
      Sdf3D[] var10000 = new Sdf3D[2];
      int var10002 = 0;
      float var10003 = 0.5F;
      Sdf3D[] var10004 = new Sdf3D[4];
      var10004[0] = var1;
      var10004[1] = var2;
      var10004[2] = var4;
      var10004[3] = var5;
      Sdf3D var27 = SdfShapes.blend(var10003, var10004);
      float var29 = 0.30000001192092896F;
      Sdf3D[] var10005 = new Sdf3D[1];
      var10005[0] = var3;
      var10000[var10002] = var27.blend(var29, var10005);
      var10000[1] = var6;
      Sdf3D var8 = SdfShapes.union(var10000).paint(var7);
      var10000 = new Sdf3D[2];
      var10002 = 0;
      var10003 = 0.5F;
      var10004 = new Sdf3D[2];
      var10004[0] = var4;
      var10004[1] = var5;
      var10000[var10002] = SdfShapes.blend(var10003, var10004)
         .inflate(0.10000000149011612F)
         .intersect(SdfShapes.below(6.949999809265137F));
      var10000[1] = SdfShapes.torus(
         -1.0750000476837158F,
         6.900000095367432F,
         0.0F,
         0.8600000143051147F,
         0.15000000596046448F
      );
      Sdf3D var9 = SdfShapes.union(var10000).color(-14012606);
      CharacterPartBuilder var10 = var0.part(CharacterBone.RIGHT_LEG)
         .pivot(-1.2000000476837158F, 14.300000190734863F, 0.0F)
         .shape(var8)
         .outline(-11914188, 0.11999999731779099F)
         .flatLight(0.699999988079071F)
         .occlusion(0.30000001192092896F)
         .swing(0.550000011920929F, 30.0F)
         .joint(
            -1.0700000524520874F,
            7.679999828338623F,
            0.18000000715255737F,
            0.75F
         );
      var0.part(CharacterBone.LEFT_LEG).mirrorOf(var10);
      CharacterPartBuilder var11 = var0.extra(
            "sock_r", CharacterBone.RIGHT_LEG
         )
         .shape(var9)
         .resolution(0.699999988079071F)
         .detail(0.44999998807907104F)
         .outline(-15460836, 0.11999999731779099F);
      CharacterPartBuilder var12 = var0.extra(
            "sock_l", CharacterBone.LEFT_LEG
         )
         .mirrorOf(var11);
      PixelCanvas var13 = socks();
      var11.decal(
         SurfaceDecal.wrap(
               var13,
               -1.100000023841858F,
               6.420000076293945F,
               -0.05000000074505806F,
               0.0F,
               1.0F,
               0.0F,
               0.0F,
               0.0F,
               1.0F,
               360.0F,
               0.30000001192092896F
            )
            .radius(0.30000001192092896F, 1.399999976158142F)
      );
      var12.decal(
         SurfaceDecal.wrap(
               var13,
               1.100000023841858F,
               6.420000076293945F,
               -0.05000000074505806F,
               0.0F,
               1.0F,
               0.0F,
               0.0F,
               0.0F,
               1.0F,
               360.0F,
               0.30000001192092896F
            )
            .radius(0.30000001192092896F, 1.399999976158142F)
      );
      float var14 = -1.1399999856948853F;
      float var15 = -7.0F;
      CharacterPartBuilder var16 = var0.extra(
            "shoe_r", CharacterBone.RIGHT_LEG
         )
         .shape(
            shoe(var14)
               .rotate(
                  0.0F,
                  var15,
                  0.0F,
                  var14,
                  1.0F,
                  0.30000001192092896F
               )
         )
         .resolution(0.800000011920929F)
         .detail(0.550000011920929F)
         .outline(-12959664, 0.11999999731779099F);
      CharacterPartBuilder var17 = var0.extra(
            "shoe_l", CharacterBone.LEFT_LEG
         )
         .mirrorOf(var16);
      PixelCanvas var18 = laces();
      double var19 = Math.toRadians((double)var15);
      float var21 = (float)Math.cos(var19);
      float var22 = (float)Math.sin(var19);
      float var23 = var14 + 0.6499999761581421F * var22;
      float var24 = 0.30000001192092896F + 0.6499999761581421F * var21;
      var16.decal(
         SurfaceDecal.project(
               var18,
               var23,
               2.0999999046325684F,
               var24,
               0.8700000047683716F * var22,
               0.5F,
               0.8700000047683716F * var21,
               -0.5F * var22,
               0.8700000047683716F,
               -0.5F * var21,
               0.800000011920929F,
               1.2799999713897705F
            )
            .depth(0.699999988079071F, 0.699999988079071F)
            .maxAngle(75.0F)
      );
      var17.decal(
         SurfaceDecal.project(
               var18,
               -var23,
               2.0999999046325684F,
               var24,
               -0.8700000047683716F * var22,
               0.5F,
               0.8700000047683716F * var21,
               0.5F * var22,
               0.8700000047683716F,
               -0.5F * var21,
               0.800000011920929F,
               1.2799999713897705F
            )
            .depth(0.699999988079071F, 0.699999988079071F)
            .maxAngle(75.0F)
      );
   }

   private static Sdf3D shoe(float var0) {
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.box(
         var0,
         0.41999998688697815F,
         0.4000000059604645F,
         0.8799999952316284F,
         0.41999998688697815F,
         1.4500000476837158F,
         0.36000001430511475F
      );
      var10001[1] = SdfShapes.ellipsoid(
         var0,
         0.4399999976158142F,
         1.6200000047683716F,
         0.8799999952316284F,
         0.4399999976158142F,
         0.949999988079071F
      );
      var10001[2] = SdfShapes.ellipsoid(
         var0,
         0.4399999976158142F,
         -0.8500000238418579F,
         0.8399999737739563F,
         0.4399999976158142F,
         0.699999988079071F
      );
      Sdf3D var1 = SdfShapes.blend(var10000, var10001);
      Sdf3D var2 = SdfShapes.ellipsoid(
         var0,
         1.1200000047683716F,
         1.350000023841858F,
         0.7599999904632568F,
         0.5799999833106995F,
         1.100000023841858F
      );
      Sdf3D var3 = SdfShapes.capsule(
         var0,
         1.2999999523162842F,
         0.8500000238418579F,
         var0,
         2.049999952316284F,
         0.10000000149011612F,
         0.699999988079071F
      );
      Sdf3D var4 = SdfShapes.ellipsoid(
         var0,
         1.4500000476837158F,
         -0.6200000047683716F,
         0.800000011920929F,
         0.8199999928474426F,
         0.8199999928474426F
      );
      Sdf3D[] var9 = new Sdf3D[2];
      var9[0] = SdfShapes.cone(
            var0,
            1.7999999523162842F,
            -0.30000001192092896F,
            0.8399999737739563F,
            var0,
            3.5F,
            -0.17000000178813934F,
            0.7400000095367432F
         )
         .intersect(SdfShapes.below(3.200000047683716F));
      var9[1] = SdfShapes.torus(
         var0,
         3.180000066757202F,
         -0.1899999976158142F,
         0.6600000262260437F,
         0.15000000596046448F
      );
      Sdf3D var5 = SdfShapes.union(var9);
      Sdf3D var6 = SdfShapes.ellipsoid(
         var0,
         3.049999952316284F,
         0.41999998688697815F,
         0.46000000834465027F,
         0.7200000286102295F,
         0.30000001192092896F
      );
      var10000 = 0.4000000059604645F;
      var10001 = new Sdf3D[4];
      var10001[0] = var2;
      var10001[1] = var3;
      var10001[2] = var4;
      var10001[3] = var5;
      Sdf3D var11 = SdfShapes.blend(var10000, var10001);
      float var14 = 0.15000000596046448F;
      Sdf3D[] var10002 = new Sdf3D[1];
      var10002[0] = var6;
      Sdf3D var7 = var11.blend(var14, var10002);
      SurfacePaint var8 = SurfacePaint.field(
         (var0x, var1x, var2x) -> var1x < 0.8999999761581421F
               ? ArgbColors.mix(
                  -14012872,
                  -920586,
                  smooth(0.05000000074505806F, 0.23999999463558197F, var1x)
               )
               : ArgbColors.mix(
                  -591621,
                  -14210250,
                  smooth(2.799999952316284F, 3.049999952316284F, var1x)
               )
      );
      Sdf3D[] var12 = new Sdf3D[2];
      var12[0] = var1;
      var12[1] = var7;
      return SdfShapes.union(var12).paint(var8);
   }

   private static void gear(CharacterRig var0, Sdf3D var1) {
      ArrayList var2 = new ArrayList();
      PixelCanvas var3 = phoneRing();
      CharacterPartBuilder var4 = var0.extra("gear", CharacterBone.BODY);

      for (int var5 = -1; var5 <= (1); var5 += 2) {
         float var6 = (float)var5 * 0.3499999940395355F;
         float var7 = 0.44999998807907104F;
         float var8 = 0.8199999928474426F;
         float var9 = (float)Math.sqrt((double)(var6 * var6 + var7 * var7 + var8 * var8));
         var6 /= var9;
         var7 /= var9;
          var8 /= var9;
          final float var6Normalized = var6;
          final float var8Normalized = var8;
         float var10 = (float)var5 * 1.5499999523162842F;
         float var11 = 23.5F;
         float var12 = 1.1200000047683716F;
         float var14 = var7;
         Sdf3D var19 = SdfShapes.cylinder(
               var10 - var6 * 0.10000000149011612F,
               var11 - var7 * 0.10000000149011612F,
               var12 - var8 * 0.10000000149011612F,
               var10 + var6 * 0.1599999964237213F,
               var11 + var7 * 0.1599999964237213F,
               var12 + var8 * 0.1599999964237213F,
               0.8600000143051147F,
               0.11999999731779099F
            )
            .paint(
               SurfacePaint.field(
                  (var6x, var7x, var8x) -> {
                      float var9x = (var6x - var10) * var6Normalized + (var7x - var11) * var14 + (var8x - var12) * var8Normalized;
                     return ArgbColors.mix(
                        -14210250,
                        -723206,
                        smooth(0.029999999329447746F, 0.10000000149011612F, var9x)
                     );
                  }
               )
            );
         Sdf3D var20 = SdfShapes.cylinder(
               var10 - var6 * 0.36000001430511475F,
               var11 - var7 * 0.36000001430511475F,
               var12 - var8 * 0.36000001430511475F,
               var10 - var6 * 0.07999999821186066F,
               var11 - var7 * 0.07999999821186066F,
               var12 - var8 * 0.07999999821186066F,
               0.7799999713897705F,
               0.10000000149011612F
            )
            .color(-14210250);
         Sdf3D var21 = SdfShapes.capsule(
               var10 - var6 * 0.10000000149011612F - (float)var5 * 0.10000000149011612F,
               var11 + 0.800000011920929F,
               var12 - var8 * 0.10000000149011612F - 0.20000000298023224F,
               (float)var5 * 1.2999999523162842F,
               24.399999618530273F,
               0.5F,
               0.20000000298023224F
            )
            .color(-14210250);
         Sdf3D[] var10001 = new Sdf3D[3];
         var10001[0] = var19;
         var10001[1] = var20;
         var10001[2] = var21;
         var2.add(SdfShapes.union(var10001));
         var4.decal(
            SurfaceDecal.project(
                  var3,
                  var10 + var6 * 0.17000000178813934F,
                  var11 + var7 * 0.17000000178813934F,
                  var12 + var8 * 0.17000000178813934F,
                  var6,
                  var7,
                  var8,
                  0.0F,
                  1.0F,
                  0.0F,
                  1.2999999523162842F,
                  1.2999999523162842F
               )
               .depth(0.4000000059604645F, 0.4000000059604645F)
               .maxAngle(70.0F)
               .glow()
         );
      }

      float[] var31 = new float[28];
      var31[0] = 1.2999999523162842F;
      var31[1] = 24.399999618530273F;
      var31[2] = 0.5F;
      var31[3] = 0.23999999463558197F;
      var31[4] = 1.2200000286102295F;
      var31[5] = 24.850000381469727F;
      var31[6] = -0.3499999940395355F;
      var31[7] = 0.25999999046325684F;
      var31[8] = 0.7200000286102295F;
      var31[9] = 25.020000457763672F;
      var31[10] = -1.2000000476837158F;
      var31[11] = 0.25999999046325684F;
      var31[12] = 0.0F;
      var31[13] = 25.079999923706055F;
      var31[14] = -1.4199999570846558F;
      var31[15] = 0.25999999046325684F;
      var31[16] = -0.7200000286102295F;
      var31[17] = 25.020000457763672F;
      var31[18] = -1.2000000476837158F;
      var31[19] = 0.25999999046325684F;
      var31[20] = -1.2200000286102295F;
      var31[21] = 24.850000381469727F;
      var31[22] = -0.3499999940395355F;
      var31[23] = 0.25999999046325684F;
      var31[24] = -1.2999999523162842F;
      var31[25] = 24.399999618530273F;
      var31[26] = 0.5F;
      var31[27] = 0.23999999463558197F;
      var2.add(
         SdfShapes.tube(var31)
            .flattenFrom(
               1.7999999523162842F,
               0.0F,
               24.899999618530273F,
               -0.20000000298023224F
            )
            .color(-14210250)
      );
      Sdf3D[] var32 = new Sdf3D[2];
      var32[0] = piping(
         var1, 1.0F, 23.299999237060547F, 17.5F
      );
      var32[1] = piping(
         var1, -1.0F, 23.299999237060547F, 17.5F
      );
      var2.add(SdfShapes.union(var32).color(-13703425));
      var4.shape(SdfShapes.union(((Sdf3D[]) var2.toArray(new Sdf3D[0]))))
         .resolution(0.699999988079071F)
         .detail(0.699999988079071F)
         .outline(-15065820, 0.10000000149011612F)
         .flatLight(0.699999988079071F)
         .occlusion(0.15000000596046448F);
      float[] var10000 = new float[8];
      var10000[0] = 1.75F;
      var10000[1] = 22.649999618530273F;
      var10000[2] = 1.850000023841858F;
      var10000[3] = 21.799999237060547F;
      var10000[4] = 1.9199999570846558F;
      var10000[5] = 20.899999618530273F;
      var10000[6] = 1.9500000476837158F;
      var10000[7] = 20.149999618530273F;
      float[] var22 = var10000;
      float[] var24 = new float[12];

      for (int var26 = 0; var26 < (4); var26++) {
         var24[var26 * (3)] = var22[var26 * (2)];
         var24[var26 * (3) + (1)] = var22[var26 * (2) + (1)];
         var24[var26 * (3) + (2)] = var26 == 0
            ? 1.2999999523162842F
            : frontZ(
                  var1,
                  var22[var26 * (2)],
                  var22[var26 * (2) + (1)],
                  6.0F
               )
               + 0.1599999964237213F;
      }

      float var27 = var24[11];
      Sdf3D[] var30 = new Sdf3D[3];
      var30[0] = SdfShapes.strand(
            0.12999999523162842F, 0.12999999523162842F, var24
         )
         .color(-7563613);
      var30[1] = SdfShapes.capsule(
            1.9500000476837158F,
            20.200000762939453F,
            var27,
            1.9600000381469727F,
            19.649999618530273F,
            var27 + 0.019999999552965164F,
            0.1899999976158142F
         )
         .color(-12959662);
      var30[2] = SdfShapes.capsule(
            1.9600000381469727F,
            19.600000381469727F,
            var27 + 0.019999999552965164F,
            1.9600000381469727F,
            19.299999237060547F,
            var27 + 0.029999999329447746F,
            0.11999999731779099F
         )
         .color(-3550757);
      Sdf3D var29 = SdfShapes.union(var30);
      var0.extra("cable", CharacterBone.BODY)
         .pivot(1.75F, 22.649999618530273F, 1.2999999523162842F)
         .shape(var29)
         .resolution(0.5F)
         .detail(0.25F)
         .noOutline()
         .motion(
            BoneMotionProfile.cloth()
               .idle(
                  1.0F,
                  0.0F,
                  1.5F,
                  0.3499999940395355F
               )
               .walk(
                  4.0F,
                  0.0F,
                  5.0F,
                  2.0F
               )
               .drag(-2.0F)
               .hang(0.4000000059604645F)
               .spring(45.0F, 5.0F)
               .bend(1.100000023841858F)
         );
   }

   private static float fu(float var0) {
      return (var0 + 2.25F) * 80.0F;
   }

   private static float fv(float var0) {
      return (28.600000381469727F - var0) * 80.0F;
   }

   private static SurfaceDecal face(List<float[]> var0) {
      PixelCanvas var1 = new PixelCanvas(
         Math.round(360.0F), Math.round(201.60003662109375F)
      );

      for (float[] var3 : var0) {
         Sdf2D var4 = null;

         for (int var5 = 0; var5 + (7) < var3.length; var5 += 4) {
            if (!(var3[var5 + (1)] > 29.200000762939453F)
               || !(var3[var5 + (5)] > 29.200000762939453F)) {
               Sdf2D var6 = Sdf2D.taper(
                  fu(var3[var5]),
                  fv(var3[var5 + (1)] - 0.2199999988079071F),
                  var3[var5 + (3)] * 80.0F * 1.7000000476837158F,
                  fu(var3[var5 + (4)]),
                  fv(var3[var5 + (5)] - 0.2199999988079071F),
                  Math.max(
                     2.0F,
                     var3[var5 + (7)] * 80.0F * 1.5F
                  )
               );
               var4 = var4 == null ? var6 : var4.union(var6);
            }
         }

         if (var4 != null) {
            var1.fill(var4, 2028380826, 3.0F);
         }
      }

      for (int var7 = -1; var7 <= (1); var7 += 2) {
         eye(var1, var7);
      }

      var1.fill(
         Sdf2D.taper(
            fu(0.05999999865889549F),
            fv(26.799999237060547F),
            4.0F,
            fu(-0.019999999552965164F),
            fv(26.639999389648438F),
            2.0F
         ),
         -1714123650,
         0.0F
      );
      var1.fill(
         Sdf2D.curve(
            fu(-0.2199999988079071F),
            fv(26.200000762939453F),
            fu(0.0F),
            fv(26.100000381469727F),
            fu(0.20000000298023224F),
            fv(26.229999542236328F),
            3.4000000953674316F,
            2.200000047683716F
         ),
         -7455931,
         0.0F
      );

      for (int var8 = -1; var8 <= (1); var8 += 2) {
         var1.fill(
            Sdf2D.ellipse(
               fu((float)var8 * 1.25F),
               fv(26.420000076293945F),
               32.0F,
               11.0F
            ),
            1442807955,
            10.0F
         );
      }

      float var9 = 27.34000015258789F;
      return SurfaceDecal.front(
            var1,
            0.0F,
            hy(var9),
            3.131999969482422F,
            5.21999979019165F,
            2.9232003688812256F
         )
         .depth(3.0159997940063477F, 0.800000011920929F)
         .maxAngle(72.0F)
         .flatLight(1.0F)
         .occlusion(0.30000001192092896F);
   }

   private static void eye(PixelCanvas var0, int var1) {
      float var2 = fu((float)var1 * 0.9800000190734863F);
      float var3 = fv(27.200000762939453F);
      float var4 = var2 - (float)var1 * 2.0F;
      float var5 = var3 + 4.0F;
      float var6 = var2 - (float)var1 * 46.0F;
      float var7 = var2 + (float)var1 * 47.0F;
      float var8 = var3 - 40.0F;
      float var9 = var3 - 50.0F;
      float var10 = var2 - (float)var1 * 2.0F;
      float var11 = var3 - 49.0F;
      float[] var10000 = new float[14];
      var10000[0] = var6 - (float)var1 * 30.0F;
      var10000[1] = var8 + 2.0F;
      var10000[2] = var6;
      var10000[3] = var8;
      var10000[4] = var10;
      var10000[5] = var11;
      var10000[6] = var7;
      var10000[7] = var9;
      var10000[8] = var7 + (float)var1 * 30.0F;
      var10000[9] = var9;
      var10000[10] = var7 + (float)var1 * 30.0F;
      var10000[11] = var3 + 90.0F;
      var10000[12] = var6 - (float)var1 * 30.0F;
      var10000[13] = var3 + 90.0F;
      Sdf2D var12 = Sdf2D.polygon(var10000);
      Sdf2D var13 = Sdf2D.ellipse(
            var2,
            var3 - 2.0F,
            47.0F,
            53.0F
         )
         .intersect(var12);
      float var10003 = var3 - 50.0F;
      float var10005 = var3 + 50.0F;
      int[] var10006 = new int[3];
      var10006[0] = -2498062;
      var10006[1] = -1;
      var10006[2] = -1;
      var0.fill(var13, ColorField2D.linear(var2, var10003, var2, var10005, var10006));
      Sdf2D var14 = Sdf2D.ellipse(
         var4, var5, 32.0F, 43.0F
      );
      Sdf2D var15 = var14.intersect(var13);
      var10003 = var5 - 43.0F;
      var10005 = var5 + 43.0F;
      var10006 = new int[4];
      var10006[0] = -16050107;
      var10006[1] = -15449954;
      var10006[2] = -14711060;
      var10006[3] = -10687489;
      var0.fill(var15, ColorField2D.linear(var4, var10003, var4, var10005, var10006));
      var0.fill(
         Sdf2D.ellipse(
               var4,
               var5 + 25.0F,
               22.0F,
               14.0F
            )
            .intersect(var15),
         -1871645953,
         6.0F
      );
      var0.fill(
         Sdf2D.ellipse(
            var4,
            var5 + 3.0F,
            12.0F,
            19.0F
         ),
         -16315098,
         0.0F
      );
      var0.fill(
         var14.outline(4.5F).intersect(var13), -536210893, 0.0F
      );
      var0.fill(
         Sdf2D.ellipse(
               var2,
               var3 - 44.0F,
               62.0F,
               20.0F
            )
            .intersect(var13),
         1714438256,
         8.0F
      );
      var0.fill(
         Sdf2D.box(
               var4 - 12.0F,
               var5 - 15.0F,
               6.5F,
               10.5F,
               3.5F
            )
            .rotate(
               -14.0F,
               var4 - 12.0F,
               var5 - 15.0F
            ),
         -1,
         0.0F
      );
      var0.fill(
         Sdf2D.box(
               var4 - 2.0F,
               var5 - 20.0F,
               2.200000047683716F,
               5.0F,
               1.5F
            )
            .rotate(
               -14.0F,
               var4 - 2.0F,
               var5 - 20.0F
            ),
         -855638017,
         0.0F
      );
      var0.fill(
         Sdf2D.circle(
            var4 + 13.0F,
            var5 + 21.0F,
            4.199999809265137F
         ),
         -570425345,
         0.0F
      );
      int var16 = -15724002;
      float var10001 = 5.0F;
      float var10002 = 9.0F;
      float[] var18 = new float[6];
      var18[0] = var6;
      var18[1] = var8 + 1.0F;
      var18[2] = var10;
      var18[3] = var11 - 1.0F;
      var18[4] = var7;
      var18[5] = var9;
      var0.fill(Sdf2D.path(var10001, var10002, var18), var16, 0.0F);
      var0.fill(
         Sdf2D.taper(
            var7 - (float)var1 * 6.0F,
            var9 + 1.0F,
            7.5F,
            var7 + (float)var1 * 12.0F,
            var9 - 7.0F,
            1.5F
         ),
         var16,
         0.0F
      );
      var0.fill(
         Sdf2D.curve(
            var2 + (float)var1 * 6.0F,
            var3 + 51.0F,
            var2 + (float)var1 * 32.0F,
            var3 + 46.0F,
            var7 - (float)var1 * 3.0F,
            var3 + 22.0F,
            1.2000000476837158F,
            3.0F
         ),
         -1072030672,
         0.0F
      );
      var0.fill(
         Sdf2D.curve(
            var2 - (float)var1 * 40.0F,
            var3 - 72.0F,
            var2 + (float)var1 * 2.0F,
            var3 - 80.0F,
            var2 + (float)var1 * 42.0F,
            var3 - 72.0F,
            3.5999999046325684F,
            2.0F
         ),
         -14011280,
         0.0F
      );
   }

   private static PixelCanvas stripe() {
      PixelCanvas var0 = new PixelCanvas(64, 10);
      var0.fill(
         Sdf2D.box(
            32.0F,
            3.299999952316284F,
            40.0F,
            2.799999952316284F,
            0.0F
         ),
         -13703425
      );
      var0.fill(
         Sdf2D.box(
            32.0F,
            8.199999809265137F,
            40.0F,
            0.800000011920929F,
            0.0F
         ),
         -1
      );
      return var0;
   }

   private static PixelCanvas band() {
      PixelCanvas var0 = new PixelCanvas(64, 8);
      var0.fill(
         Sdf2D.box(
            32.0F,
            4.0F,
            40.0F,
            3.0F,
            0.0F
         ),
         -13703425
      );
      return var0;
   }

   private static PixelCanvas socks() {
      PixelCanvas var0 = new PixelCanvas(64, 12);
      var0.fill(
         Sdf2D.box(
            32.0F,
            2.5F,
            40.0F,
            2.0F,
            0.0F
         ),
         -13703425
      );
      var0.fill(
         Sdf2D.box(
            32.0F,
            9.5F,
            40.0F,
            2.0F,
            0.0F
         ),
         -13703425
      );
      return var0;
   }

   private static PixelCanvas phoneRing() {
      PixelCanvas var0 = new PixelCanvas(96, 96);
      var0.fill(
         Sdf2D.circle(
               48.0F, 48.0F, 33.0F
            )
            .outline(5.0F),
         -13703425
      );
      return var0;
   }

   private static SurfaceDecal topGraphic() {
      PixelCanvas var0 = new PixelCanvas(152, 120);
      var0.fill(
         Sdf2D.circle(
               76.0F, 60.0F, 42.0F
            )
            .outline(10.0F),
         -13703425
      );
      float[] var10000 = new float[9];
      var10000[0] = 16.0F;
      var10000[1] = 30.0F;
      var10000[2] = 50.0F;
      var10000[3] = 72.0F;
      var10000[4] = 94.0F;
      var10000[5] = 72.0F;
      var10000[6] = 50.0F;
      var10000[7] = 30.0F;
      var10000[8] = 16.0F;
      float[] var1 = var10000;

      for (int var2 = 0; var2 < var1.length; var2++) {
         var0.fill(
            Sdf2D.box(
               76.0F + (float)(var2 - (4)) * 15.0F,
               60.0F,
               4.599999904632568F,
               var1[var2] * 0.5F,
               3.0F
            ),
            -14932394
         );
      }

      return SurfaceDecal.front(
            var0,
            0.0F,
            20.299999237060547F,
            1.899999976158142F,
            1.7000000476837158F,
            1.340000033378601F
         )
         .depth(0.75F, 0.44999998807907104F)
         .maxAngle(62.0F);
   }

   private static PixelCanvas backStripe() {
      PixelCanvas var0 = new PixelCanvas(12, 80);
      var0.fill(
         Sdf2D.box(
            6.0F,
            40.0F,
            3.0999999046325684F,
            39.0F,
            0.8999999761581421F
         ),
         -13703425
      );
      var0.fill(
         Sdf2D.box(
            0.8999999761581421F,
            40.0F,
            0.699999988079071F,
            39.0F,
            0.3499999940395355F
         ),
         -1512206
      );
      var0.fill(
         Sdf2D.box(
            11.100000381469727F,
            40.0F,
            0.699999988079071F,
            39.0F,
            0.3499999940395355F
         ),
         -1512206
      );
      return var0;
   }

   private static PixelCanvas buckle() {
      PixelCanvas var0 = new PixelCanvas(64, 48);
      Sdf2D var10001 = Sdf2D.box(
         32.0F,
         24.0F,
         31.0F,
         23.0F,
         7.0F
      );
      float var10002 = 0.0F;
      float var10003 = 2.0F;
      float var10004 = 0.0F;
      float var10005 = 46.0F;
      int[] var10006 = new int[2];
      var10006[0] = -1643535;
      var10006[1] = -7563613;
      var0.fill(var10001, ColorField2D.linear(var10002, var10003, var10004, var10005, var10006));
      var0.fill(
         Sdf2D.box(
            32.0F,
            24.0F,
            21.0F,
            12.0F,
            4.0F
         ),
         -14276045
      );
      var0.fill(
         Sdf2D.box(
            32.0F,
            24.0F,
            14.0F,
            3.5F,
            1.5F
         ),
         -13703425
      );
      var0.fill(
         Sdf2D.box(
            8.5F,
            24.0F,
            2.0F,
            9.0F,
            1.0F
         ),
         -14276045
      );
      var0.fill(
         Sdf2D.box(
            55.5F,
            24.0F,
            2.0F,
            9.0F,
            1.0F
         ),
         -14276045
      );
      return var0;
   }

   private static PixelCanvas pocket() {
      PixelCanvas var0 = new PixelCanvas(64, 24);
      var0.fill(
         Sdf2D.box(
            32.0F,
            12.0F,
            28.0F,
            3.4000000953674316F,
            3.0F
         ),
         -15460837
      );
      var0.fill(
         Sdf2D.box(
            32.0F,
            12.0F,
            25.0F,
            0.800000011920929F,
            0.4000000059604645F
         ),
         -13703425
      );
      var0.fill(
         Sdf2D.box(
            54.0F,
            15.5F,
            2.200000047683716F,
            5.0F,
            1.2000000476837158F
         ),
         -3550757
      );
      return var0;
   }

   private static PixelCanvas sleeveText() {
      float var0 = 0.4300000071525574F;
      PixelCanvas var1 = new PixelCanvas(41, 117);
      Sdf2D[] var10000 = new Sdf2D[3];
      var10000[0] = Sdf2D.line(
         26.0F,
         86.0F,
         48.0F,
         14.0F,
         13.0F
      );
      var10000[1] = Sdf2D.line(
         48.0F,
         14.0F,
         70.0F,
         86.0F,
         13.0F
      );
      var10000[2] = Sdf2D.line(
         36.0F,
         62.0F,
         60.0F,
         62.0F,
         10.0F
      );
      Sdf2D var2 = Sdf2D.union(var10000);
      Sdf2D var3 = Sdf2D.ellipse(
            48.0F,
            136.0F,
            22.0F,
            34.0F
         )
         .outline(13.0F);
      var10000 = new Sdf2D[3];
      var10000[0] = Sdf2D.line(
         48.0F,
         190.0F,
         48.0F,
         258.0F,
         13.0F
      );
      var10000[1] = Sdf2D.line(
         32.0F,
         190.0F,
         64.0F,
         190.0F,
         9.0F
      );
      var10000[2] = Sdf2D.line(
         32.0F,
         258.0F,
         64.0F,
         258.0F,
         9.0F
      );
      Sdf2D var4 = Sdf2D.union(var10000);
      var10000 = new Sdf2D[3];
      var10000[0] = var2;
      var10000[1] = var3;
      var10000[2] = var4;
      Sdf2D var5 = Sdf2D.union(var10000);
      ink(
         var1,
         var0,
         var5.move(3.0F, 3.0F),
         -13703425,
         0.0F
      );
      ink(var1, var0, var5, -14932394, 0.0F);
      return var1;
   }

   private static PixelCanvas sleevePatch() {
      float var0 = 0.625F;
      PixelCanvas var1 = new PixelCanvas(80, 80);
      ink(
         var1,
         var0,
         Sdf2D.circle(
            64.0F, 64.0F, 60.0F
         ),
         -14210250,
         0.0F
      );
      ink(
         var1,
         var0,
         Sdf2D.circle(
               64.0F, 64.0F, 52.0F
            )
            .outline(6.0F),
         -13703425,
         0.0F
      );
      ink(
         var1,
         var0,
         Sdf2D.arc(
            64.0F,
            70.0F,
            30.0F,
            180.0F,
            360.0F,
            8.0F
         ),
         -591621,
         0.0F
      );
      ink(
         var1,
         var0,
         Sdf2D.box(
            36.0F,
            78.0F,
            8.0F,
            14.0F,
            5.0F
         ),
         -591621,
         0.0F
      );
      ink(
         var1,
         var0,
         Sdf2D.box(
            92.0F,
            78.0F,
            8.0F,
            14.0F,
            5.0F
         ),
         -591621,
         0.0F
      );
      return var1;
   }

   private static PixelCanvas laces() {
      float var0 = 0.5F;
      PixelCanvas var1 = new PixelCanvas(48, 80);

      for (int var2 = 0; var2 < (4); var2++) {
         float var3 = 30.0F + (float)var2 * 32.0F;
         ink(
            var1,
            var0,
            Sdf2D.line(
               20.0F,
               var3,
               76.0F,
               var3 + 16.0F,
               9.0F
            ),
            -13703425,
            0.0F
         );
         ink(
            var1,
            var0,
            Sdf2D.line(
               76.0F,
               var3,
               20.0F,
               var3 + 16.0F,
               9.0F
            ),
            -13703425,
            0.0F
         );
         ink(
            var1,
            var0,
            Sdf2D.circle(14.0F, var3, 5.0F),
            -3550757,
            0.0F
         );
         ink(
            var1,
            var0,
            Sdf2D.circle(82.0F, var3, 5.0F),
            -3550757,
            0.0F
         );
      }

      return var1;
   }

   private static void ink(PixelCanvas var0, float var1, Sdf2D var2, int var3, float var4) {
      var0.fill(var2.scale(var1, 0.0F, 0.0F), var3, var4 * var1);
   }

   private static float frontZ(Sdf3D var0, float var1, float var2, float var3) {
      float var4 = var3;

      for (int var5 = 0; var5 < (400) && var4 > -8.0F; var5++) {
         float var6 = var0.distance(var1, var2, var4);
         if (var6 < 0.003000000026077032F) {
            return var4;
         }

         var4 -= Math.max(0.004999999888241291F, var6 * 0.699999988079071F);
      }

      return var4;
   }

   private static Sdf3D ring(
      float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7
   ) {
      float var8 = (float)Math.sqrt((double)(var3 * var3 + var4 * var4 + var5 * var5));
      float var9 = var3 / var8;
      float var10 = var4 / var8;
      float var11 = var5 / var8;
      Sdf3D var12 = SdfShapes.torus(var0, var1, var2, var6, var7);
      if (var9 * var9 + var11 * var11 < 9.99999993922529e-09F) {
         return var12;
      } else {
         float var13 = (float)Math.toDegrees(
            Math.acos((double)Math.max(-1.0F, Math.min(1.0F, var10)))
         );
         return var12.rotateAxis(var11, 0.0F, -var9, var13, var0, var1, var2);
      }
   }

   private static Sdf3D oval(float var0, float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = Math.max(var3, var5);
      float var8 = Math.max(var4, var6);
      return SdfShapes.field((var7x, var8x, var9) -> {
         float var10 = clamp01((var8x - var1) / (var2 - var1));
         float var11 = ellipse(var7x, var9 - var0, var3 + (var5 - var3) * var10, var4 + (var6 - var4) * var10);
         return Math.max(var11 * 0.949999988079071F, Math.max(var1 - var8x, var8x - var2));
      }, -var7, var1, var0 - var8, var7, var2, var0 + var8);
   }

   private static Sdf3D ovalRing(float var0, float var1, float var2, float var3, float var4, float var5) {
      float var6 = Math.min(var5, var2) * 0.5F;
      return SdfShapes.field(
         (var7, var8, var9) -> {
            float var10 = Math.abs(ellipse(var7, var9 - var0, var3, var4)) - var5 + var6;
            float var11 = Math.abs(var8 - var1) - var2 + var6;
            float var12 = Math.max(var10, 0.0F);
            float var13 = Math.max(var11, 0.0F);
            return (
                  (float)Math.sqrt((double)(var12 * var12 + var13 * var13))
                     + Math.min(Math.max(var10, var11), 0.0F)
                     - var6
               )
               * 0.949999988079071F;
         },
         -var3 - var5,
         var1 - var2,
         var0 - var4 - var5,
         var3 + var5,
         var1 + var2,
         var0 + var4 + var5
      );
   }

   private static float ellipse(float var0, float var1, float var2, float var3) {
      float var4 = (float)Math.sqrt((double)(var0 * var0 / (var2 * var2) + var1 * var1 / (var3 * var3)));
      float var5 = (float)Math.sqrt((double)(var0 * var0 / (var2 * var2 * var2 * var2) + var1 * var1 / (var3 * var3 * var3 * var3)));
      return var5 < 9.999999974752427e-07F ? -Math.min(var2, var3) : var4 * (var4 - 1.0F) / var5;
   }

   private static float pleat(float var0) {
      float var1 = tri(var0);
      return var1 * (1.5F - 0.5F * var1 * var1);
   }

   private static float tri(float var0) {
      float var1 = var0 - (float)Math.floor((double)var0);
      return 4.0F * Math.min(var1, 1.0F - var1)
         - 1.0F;
   }

   private static float clamp01(float var0) {
      return var0 < 0.0F
         ? 0.0F
         : Math.min(var0, 1.0F);
   }

   private static float smooth(float var0, float var1, float var2) {
      float var3 = clamp01((var2 - var0) / (var1 - var0));
      return var3 * var3 * (3.0F - 2.0F * var3);
   }



   static {
      float[][] var5 = new float[5][];
      float[] var15;
      (var15 = new float[11])[0] = 0.95F;
      var15[1] = -1.55F;
      var15[2] = 29.85F;
      var15[3] = -2.0F;
      var15[4] = 29.5F;
      var15[5] = -2.3F;
      var15[6] = 28.45F;
      var15[7] = -2.24F;
      var15[8] = 27.65F;
      var15[9] = -2.0F;
      var15[10] = 27.42F;
      var5[0] = var15;
      float[] var17;
      (var17 = new float[11])[0] = 0.95F;
      var17[1] = -1.15F;
      var17[2] = 29.95F;
      var17[3] = -1.38F;
      var17[4] = 29.5F;
      var17[5] = -1.6F;
      var17[6] = 28.6F;
      var17[7] = -1.55F;
      var17[8] = 28.12F;
      var17[9] = -1.3F;
      var17[10] = 27.93F;
      var5[1] = var17;
      float[] var19;
      (var19 = new float[11])[0] = 0.85F;
      var19[1] = -0.64F;
      var19[2] = 29.95F;
      var19[3] = -0.45F;
      var19[4] = 29.4F;
      var19[5] = -0.08F;
      var19[6] = 28.25F;
      var19[7] = 0.16F;
      var19[8] = 27.4F;
      var19[9] = 0.04F;
      var19[10] = 27.02F;
      var5[2] = var19;
      float[] var5x;
      (var5x = new float[11])[0] = 1.0F;
      var5x[1] = -0.08F;
      var5x[2] = 30.0F;
      var5x[3] = 0.35F;
      var5x[4] = 29.6F;
      var5x[5] = 0.9F;
      var5x[6] = 28.7F;
      var5x[7] = 1.2F;
      var5x[8] = 28.22F;
      var5x[9] = 0.98F;
      var5x[10] = 28.0F;
      var5[3] = var5x;
      float[] var23;
      (var23 = new float[11])[0] = 1.05F;
      var23[1] = 0.56F;
      var23[2] = 30.0F;
      var23[3] = 1.15F;
      var23[4] = 29.7F;
      var23[5] = 1.8F;
      var23[6] = 28.75F;
      var23[7] = 2.08F;
      var23[8] = 27.8F;
      var23[9] = 1.85F;
      var23[10] = 27.45F;
      var5[4] = var23;
      MAIN_LOCKS = var5;
      float[][] var7 = new float[3][];
      float[] var25;
      (var25 = new float[9])[0] = 0.55F;
      var25[1] = -0.95F;
      var25[2] = 29.85F;
      var25[3] = -1.0F;
      var25[4] = 29.3F;
      var25[5] = -0.9F;
      var25[6] = 28.5F;
      var25[7] = -0.76F;
      var25[8] = 28.3F;
      var7[0] = var25;
      float[] var27;
      (var27 = new float[9])[0] = 0.55F;
      var27[1] = -0.22F;
      var27[2] = 29.85F;
      var27[3] = 0.14F;
      var27[4] = 29.35F;
      var27[5] = 0.52F;
      var27[6] = 28.72F;
      var27[7] = 0.44F;
      var27[8] = 28.55F;
      var7[1] = var27;
      float[] var29;
      (var29 = new float[9])[0] = 0.5F;
      var29[1] = 0.5F;
      var29[2] = 29.85F;
      var29[3] = 1.02F;
      var29[4] = 29.4F;
      var29[5] = 1.5F;
      var29[6] = 28.5F;
      var29[7] = 1.44F;
      var29[8] = 28.2F;
      var7[2] = var29;
      ACCENT_LOCKS = var7;
   }
}
