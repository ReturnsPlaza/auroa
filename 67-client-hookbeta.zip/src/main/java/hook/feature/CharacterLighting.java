package hook.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DiffuseLighting.Type;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.dimension.DimensionType.CardinalLightType;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@Environment(EnvType.CLIENT)
public final class CharacterLighting {
   private static final Vector3f LIGHT_0 = new Vector3f(0.2F, 1.0F, -0.7F).normalize();
   private static final Vector3f LIGHT_1 = new Vector3f(-0.2F, 1.0F, 0.7F).normalize();
   private static final DirectionalLighting NETHER =
      new DirectionalLighting(0.2F, 1.0F, -0.7F, -0.2F, -1.0F, 0.7F);
   private static final DirectionalLighting INVENTORY =
      new DirectionalLighting(0.2F, -1.0F, 1.0F, -0.2F, -1.0F, 0.0F);
   private static final DirectionalLighting ITEMS_FLAT = transformed(
      new Matrix4f().rotationY((float)(-Math.PI / 8)).rotateX((float)(Math.PI * 3.0 / 4.0))
   );
   private static final DirectionalLighting ITEMS_3D = transformed(
      new Matrix4f().scaling(1.0F, -1.0F, 1.0F)
         .rotateYXZ(1.0821041F, 3.2375858F, 0.0F)
         .rotateYXZ((float)(-Math.PI / 8), (float)(Math.PI * 3.0 / 4.0), 0.0F)
   );
   private static Type entry = Type.LEVEL;

   private CharacterLighting() {}

   public static void setup(Type type) {
      entry = type;
   }

   static DirectionalLighting current() {
      return switch (entry) {
         case LEVEL -> nether() ? NETHER : DirectionalLighting.WORLD;
         case ITEMS_FLAT -> ITEMS_FLAT;
         case ITEMS_3D -> ITEMS_3D;
         case ENTITY_IN_UI, PLAYER_SKIN -> INVENTORY;
         default -> throw new MatchException(null, null);
      };
   }

   private static boolean nether() {
      ClientWorld world = MinecraftClient.getInstance().world;
      return world != null && world.getDimension().cardinalLightType() == CardinalLightType.NETHER;
   }

   private static DirectionalLighting transformed(Matrix4f transform) {
      Vector3f a = transform.transformDirection(LIGHT_0, new Vector3f());
      Vector3f b = transform.transformDirection(LIGHT_1, new Vector3f());
      return new DirectionalLighting(a.x, a.y, a.z, b.x, b.y, b.z);
   }
}
