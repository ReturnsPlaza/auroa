package hook.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.client.toast.Toast.Visibility;

@Environment(EnvType.CLIENT)
public class StackedNotificationToast implements Toast {
   private static final Identifier BACKGROUND = Identifier.ofVanilla("toast/advancement");
   private static final int TITLE_COLOR = -30465;
   private static final int MESSAGE_COLOR = -1;
   private static final int TEXT_X = 30;
   private static final int TEXT_PAD = 4;
   private static final int MAX_WIDTH = 240;
   private static final long DISPLAY_MILLIS = 5000L;
   private final Object token;
   private final ItemStack icon;
   private final boolean sound;
   private Text title;
   private Text message;
   private int width;
   private int count = 1;
   private boolean changed;
   private boolean hiding;
   private long changedAt;
   private Visibility wanted = Visibility.HIDE;

   public StackedNotificationToast(ItemStack var1, Text var2, Text var3, boolean var4) {
      this(TYPE, var1, var2, var3, var4);
   }

   private StackedNotificationToast(Object var1, ItemStack var2, Text var3, Text var4, boolean var5) {
      this.token = var1;
      this.icon = var2.copy();
      this.icon.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
      this.title = var3;
      this.message = var4;
      this.sound = var5;
      this.fit();
   }

   public static void addOrUpdate(ItemStack var0, String var1, Text var2, boolean var3) {
      addOrUpdate(var0, var1, null, var2, var3);
   }

   public static void addOrUpdate(ItemStack var0, String var1, String var2, Text var3, boolean var4) {
      MinecraftClient var5 = MinecraftClient.getInstance();
      if (!var5.isOnThread()) {
         var5.execute(() -> addOrUpdate(var0, var1, var2, var3, var4));
      } else {
         ToastManager var6 = var5.getToastManager();
         StackedNotificationToast var7 = (StackedNotificationToast)var6.getToast(StackedNotificationToast.class, var1);
         if (var7 == null) {
            var6.add(new StackedNotificationToast(var1, var0, Text.literal(var1), var3, var4));
         } else {
            var7.count++;
            if (var2 != null) {
               var7.title = Text.literal(var7.count + " " + var2);
            }

            var7.message = var3;
            var7.changed = true;
            var7.fit();
         }
      }
   }

   private void fit() {
      TextRenderer var1 = MinecraftClient.getInstance().textRenderer;
      int var2 = Math.max(var1.getWidth(this.title), var1.getWidth(this.message));
      this.width = MathHelper.clamp(30 + var2 + 4, 160, 240);
   }

   public Object getType() {
      return this.token;
   }

   public SoundEvent getSoundEvent() {
      return this.sound ? (SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.value() : null;
   }

   public Visibility getVisibility() {
      return this.wanted;
   }

   public int getWidth() {
      return this.width;
   }

   public void update(ToastManager var1, long var2) {
      if (!this.hiding) {
         if (this.changed) {
            this.changedAt = var2;
            this.changed = false;
         }

         this.hiding = (double)(var2 - this.changedAt) >= 5000.0 * var1.getNotificationDisplayTimeMultiplier();
         this.wanted = this.hiding ? Visibility.HIDE : Visibility.SHOW;
      }
   }

   public void onFinishedRendering() {
      if (this.changed) {
         this.hiding = false;
         MinecraftClient.getInstance().getToastManager().add(this);
      }
   }

   public void draw(DrawContext var1, TextRenderer var2, long var3) {
      int var5 = this.width / 2;
      drawBackground(var1, 0, 0, var5);
      drawBackground(var1, 160 - (this.width - var5), var5, this.width - var5);
      boolean var6 = this.message.getString().isEmpty();
      this.drawText(var1, var2, this.title, var6 ? 12 : 7, -30465);
      if (!var6) {
         this.drawText(var1, var2, this.message, 18, -1);
      }

      var1.drawItemWithoutEntity(this.icon, 8, 8);
   }

   private static void drawBackground(DrawContext var0, int var1, int var2, int var3) {
      var0.drawGuiTexture(RenderPipelines.GUI_TEXTURED, BACKGROUND, 160, 32, var1, 0, var2, 0, var3, 32);
   }

   private void drawText(DrawContext var1, TextRenderer var2, Text var3, int var4, int var5) {
      int var6 = this.width - 30 - 4;
      int var7 = var2.getWidth(var3);
      if (var7 <= var6) {
         var1.drawText(var2, var3, 30, var4, var5, false);
      } else {
         var1.getMatrices().pushMatrix();
         var1.getMatrices().translate(30.0F, (float)var4);
         var1.getMatrices().scale((float)var6 / (float)var7, 1.0F);
         var1.drawText(var2, var3, 0, 0, var5, false);
         var1.getMatrices().popMatrix();
      }
   }
}
