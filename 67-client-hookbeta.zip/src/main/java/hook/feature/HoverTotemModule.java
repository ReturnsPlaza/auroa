package hook.feature;

import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.mixin.HandledScreenMixin;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.utils.EncryptedString;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public final class HoverTotemModule extends Module {
   private final NumberSetting tickDelay;
   private final BooleanSetting hotbarTotem;
   private final NumberSetting hotbarSlot;
   private final BooleanSetting autoSwitchToTotem;
   private int remainingDelay;

   public HoverTotemModule() {
      super(
         EncryptedString.of("Hover Totem"),
         EncryptedString.of("Equips a totem in offhand and optionally hotbar when hovering over one in inventory"),
         -1,
         Category.COMBAT
      );
      this.tickDelay = new NumberSetting(EncryptedString.of("Tick Delay"), 0.0, 20.0, 0.0, 1.0)
         .getValue(EncryptedString.of("Ticks to wait between operations"));
      this.hotbarTotem = new BooleanSetting(EncryptedString.of("Hotbar Totem"), true)
         .setDescription(EncryptedString.of("Also places a totem in your preferred hotbar slot"));
      this.hotbarSlot = new NumberSetting(EncryptedString.of("Hotbar Slot"), 1.0, 9.0, 1.0, 1.0)
         .getValue(EncryptedString.of("Your preferred hotbar slot for totem (1-9)"));
      this.autoSwitchToTotem = new BooleanSetting(EncryptedString.of("Auto Switch To Totem"), false)
         .setDescription(EncryptedString.of("Automatically switches to totem slot when inventory is opened"));
      this.addSettings(this.tickDelay, this.hotbarTotem, this.hotbarSlot, this.autoSwitchToTotem);
   }

   @Override
   public void onEnable() {
      this.resetDelay();
      super.onEnable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player == null) {
         return;
      }
      Screen screen = this.mc.currentScreen;
      if (!(screen instanceof InventoryScreen inventoryScreen)) {
         this.resetDelay();
         return;
      }
      Slot focused = ((HandledScreenMixin)screen).getFocusedSlot();
      if (focused == null || focused.getIndex() > 35) {
         return;
      }
      if (this.autoSwitchToTotem.getValue()) {
         this.mc.player.getInventory().setSelectedSlot(this.hotbarSlot.getIntValue() - 1);
      }
      if (focused.getStack().getItem() != Items.TOTEM_OF_UNDYING) {
         return;
      }
      if (this.remainingDelay > 0) {
         this.remainingDelay--;
         return;
      }

      int hoveredSlot = focused.getIndex();
      int syncId = ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).syncId;
      if (!this.mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
         this.equipOffhandTotem(syncId, hoveredSlot);
      } else if (this.hotbarTotem.getValue()) {
         int selectedHotbarSlot = this.hotbarSlot.getIntValue() - 1;
         if (!this.mc.player.getInventory().getStack(selectedHotbarSlot).isOf(Items.TOTEM_OF_UNDYING)) {
            this.equipHotbarTotem(syncId, hoveredSlot, selectedHotbarSlot);
         }
      }
   }

   private void equipOffhandTotem(int syncId, int hoveredSlot) {
      this.mc.interactionManager.clickSlot(syncId, hoveredSlot, 40, SlotActionType.SWAP, this.mc.player);
      this.resetDelay();
   }

   private void equipHotbarTotem(int syncId, int hoveredSlot, int hotbarSlot) {
      this.mc.interactionManager.clickSlot(syncId, hoveredSlot, hotbarSlot, SlotActionType.SWAP, this.mc.player);
      this.resetDelay();
   }

   private void resetDelay() {
      this.remainingDelay = this.tickDelay.getIntValue();
   }
}
