package hook.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class TungTungSahurDesign extends CharacterDefinition {
   public static final float R = 5.0F;
   private static final float BOTTOM = 12.0F;
   private static final float TOP = 34.0F;
   private static final float RIM = 0.85F;
   private static final float FIST_X = -7.0F;
   private static final float FIST_Y = 11.6F;
   private static final float FIST_Z = 0.72F;
   private static final float[] KNUCKLE_DIR = unit(
      -0.1599999964237213F, 0.8600000143051147F, 0.47999998927116394F
   );
   private static final int WOOD = -1063542;
   private static final int WOOD_DARK = -4158378;
   private static final int WOOD_WORN = -5868993;
   private static final int FISSURE = -9551070;
   private static final int KNOT = -11653867;
   private static final int CUT = -1389672;
   private static final int LIMB = -3567528;
   private static final int LIMB_DARK = -7053254;
   private static final int INK = -15003638;
   private static final int LINE = -12967406;

   public TungTungSahurDesign() {
      super(
         "tung_tung_sahur",
         "Tung Tung Tung Sahur"
      );
   }

   @Override
   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-12967406, 0.1599999964237213F)
         .occlusion(0.30000001192092896F)
         .firstPersonArms(false);
      var1.part(CharacterBone.HEAD)
         .pivot(0.0F, 12.5F, 0.0F);
      CharacterPartBuilder var2 = var1.extra("upright", CharacterBone.HEAD)
         .motion(BoneMotionProfile.none().hang(1.0F).limit(100.0F));
      var1.extra("log", var2)
         .shape(log())
         .detail(1.5F)
         .resolution(1.2000000476837158F)
         .flatLight(0.3499999940395355F)
         .neck(
            0.0F,
            22.5F,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            4.0F
         )
         .look(0.6000000238418579F, 0.0F, 40.0F)
         .motion(
            BoneMotionProfile.none()
               .walk(
                  0.0F,
                  4.0F,
                  -6.0F,
                  1.0F
               )
               .drag(6.0F)
         )
         .decal(eyes())
         .decal(mouth())
         .decal(rings());
      CharacterPartBuilder var3 = var1.part(CharacterBone.RIGHT_ARM)
         .pivot(-5.300000190734863F, 22.799999237060547F, 0.20000000298023224F)
         .grip(-7.0F, 11.600000381469727F, 0.7200000286102295F)
         .shape(arm())
         .joint(
            -6.570000171661377F,
            17.100000381469727F,
            0.14000000059604645F,
            0.6000000238418579F
         );
      var1.part(CharacterBone.LEFT_ARM).mirrorOf(var3);
      CharacterPartBuilder var4 = var1.extra(
            "hand_r", CharacterBone.RIGHT_ARM
         )
         .shape(hand())
         .resolution(0.6000000238418579F)
         .detail(0.800000011920929F);
      var1.extra("hand_l", CharacterBone.LEFT_ARM).mirrorOf(var4);
      CharacterPartBuilder var5 = var1.part(CharacterBone.RIGHT_LEG)
         .pivot(-2.200000047683716F, 12.800000190734863F, 0.0F)
         .shape(leg())
         .swing(0.6000000238418579F, 35.0F)
         .joint(
            -2.299999952316284F,
            6.75F,
            0.1599999964237213F,
            0.699999988079071F
         );
      var1.part(CharacterBone.LEFT_LEG).mirrorOf(var5);
      CharacterPartBuilder var6 = var1.extra(
            "foot_r", CharacterBone.RIGHT_LEG
         )
         .shape(foot())
         .resolution(0.699999988079071F)
         .detail(0.800000011920929F);
      var1.extra("foot_l", CharacterBone.LEFT_LEG).mirrorOf(var6);
   }

   private static Sdf3D log() {
      Sdf3D var0 = SdfShapes.field(
         TungTungSahurDesign::trunk,
         -5.5F,
         11.800000190734863F,
         -5.5F,
         5.5F,
         34.20000076293945F,
         5.5F
      );
      PaintWrapper var1 = new PaintWrapper(
         SurfacePaint.wood(
               -1063542,
               -4158378,
               0.30000001192092896F,
               0.0F,
               -0.20000000298023224F,
               0.0F,
               1.0F,
               0.0F,
               0.800000011920929F
            )
            .noise(-5868993, 3.5F, 0.07999999821186066F)
            .grain(0.3499999940395355F, 0.03999999910593033F)
      );
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[8];
      var10001[0] = var0.paint(var1);
      var10001[1] = knot(
         38.0F, 17.200000762939453F, 0.800000011920929F
      );
      var10001[2] = knot(
         165.0F, 27.5F, 0.949999988079071F
      );
      var10001[3] = knot(
         -120.0F, 19.5F, 0.699999988079071F
      );
      var10001[4] = knot(
         -58.0F, 14.199999809265137F, 0.550000011920929F
      );
      var10001[5] = stub(
         128.0F, 25.200000762939453F
      );
      var10001[6] = eye(1.0F, var1);
      var10001[7] = eye(-1.0F, var1);
      Sdf3D var2 = SdfShapes.blend(var10000, var10001);
      Sdf3D var3 = SdfShapes.ellipsoid(
         0.0F,
         25.350000381469727F,
         radius(
               0.0F, 25.350000381469727F, 1.0F
            )
            + 0.11999999731779099F,
         2.700000047683716F,
         1.0499999523162842F,
         0.550000011920929F
      );
      var10000 = 0.11999999731779099F;
      Sdf3D var5 = SdfShapes.subtract(0.3499999940395355F, var2, var3);
      Sdf3D[] var10002 = new Sdf3D[2];
      var10002[0] = hole(
         165.0F, 27.5F, 0.3199999928474426F
      );
      var10002[1] = hole(
         -120.0F, 19.5F, 0.23999999463558197F
      );
      return SdfShapes.subtract(var10000, var5, SdfShapes.union(var10002));
   }

   private static Sdf3D stub(float var0, float var1) {
      float var2 = (float)Math.sin(Math.toRadians((double)var0));
      float var3 = (float)Math.cos(Math.toRadians((double)var0));
      float var4 = (float)Math.cos(Math.toRadians(32.0));
      float var5 = (float)Math.sin(Math.toRadians(32.0));
      float var6 = var2 * var4;
      float var8 = var3 * var4;
      float var9 = var2 * 3.9000000953674316F;
      float var10 = var3 * 3.9000000953674316F;
      float var11 = var9 + var6 * 3.049999952316284F;
      float var12 = var1 + var5 * 3.049999952316284F;
      float var13 = var10 + var8 * 3.049999952316284F;
      Sdf3D var14 = SdfShapes.cone(
            var9,
            var1,
            var10,
            0.9800000190734863F,
            var11 + var6 * 0.4000000059604645F,
            var12 + var5 * 0.4000000059604645F,
            var13 + var8 * 0.4000000059604645F,
            0.6399999856948853F
         )
         .paint(
            SurfacePaint.wood(
               -1063542, -4158378, var9, var1, var10, var6, var5, var8, 0.30000001192092896F
            )
         );
      SurfacePaint var15 = SurfacePaint.radial(
         -6264264, var11, var12, var13, 0.75F, -1389672
      );
      return SdfShapes.subtract(var14, SdfShapes.plane(var11, var12, var13, -var6, -var5, -var8).paint(var15));
   }

   private static Sdf3D eye(float var0, SurfacePaint var1) {
      float var2 = var0 * 2.140000104904175F;
      float var3 = 28.719999313354492F;
      float var4 = var2 / 5.0F;
      float var5 = (float)Math.sqrt((double)(1.0F - var4 * var4));
      float var6 = radius(var4, var3, var5) - 0.5F;
      float var7 = (float)Math.toDegrees(Math.asin((double)var4));
      return SdfShapes.ellipsoid(
            var4 * var6,
            var3,
            var5 * var6,
            1.850000023841858F,
            1.7999999523162842F,
            0.8500000238418579F
         )
         .rotate(0.0F, var7, 0.0F, var4 * var6, var3, var5 * var6)
         .paint(var1);
   }

   private static Sdf3D knot(float var0, float var1, float var2) {
      float var3 = (float)Math.sin(Math.toRadians((double)var0));
      float var4 = (float)Math.cos(Math.toRadians((double)var0));
      float var5 = radius(var3, var1, var4) + 0.2800000011920929F;
      float var6 = var5 - var2;
      return SdfShapes.ellipsoid(var3 * var6, var1, var4 * var6, var2, var2 * 1.350000023841858F, var2)
         .paint(
            SurfacePaint.radial(
               -11653867, var3 * var5, var1, var4 * var5, var2 * 1.0499999523162842F, -4158378
            )
         );
   }

   private static Sdf3D hole(float var0, float var1, float var2) {
      float var3 = (float)Math.sin(Math.toRadians((double)var0));
      float var4 = (float)Math.cos(Math.toRadians((double)var0));
      float var5 = radius(var3, var1, var4) + 0.2800000011920929F;
      return SdfShapes.ellipsoid(var3 * var5, var1, var4 * var5, var2, var2 * 1.2999999523162842F, var2)
         .color(-11653867);
   }

   private static float radius(float var0, float var1, float var2) {
      float var3 = 0.17000000178813934F
         * PerlinNoise.noise(
            var0 * 1.100000023841858F + 2.299999952316284F,
            var1 * 0.10000000149011612F,
            var2 * 1.100000023841858F - 1.2999999523162842F
         );
      return 5.0F + var3 - 0.17000000178813934F * fissure(var0, var1, var2);
   }

   private static float fissure(float var0, float var1, float var2) {
      float var3 = Math.abs(
         PerlinNoise.noise(
            var0 * 3.0F - 5.099999904632568F,
            var1 * 0.07999999821186066F,
            var2 * 3.0F + 0.699999988079071F
         )
      );
      float var4 = smooth(0.30000001192092896F, 0.6200000047683716F, var2)
         * smooth(21.799999237060547F, 23.600000381469727F, var1);
      return Math.max(
            0.0F, 1.0F - var3 / 0.2800000011920929F
         )
         * (1.0F - 0.8799999952316284F * var4);
   }

   private static float trunk(float var0, float var1, float var2) {
      float var3 = (float)Math.sqrt((double)(var0 * var0 + var2 * var2));
      float var4 = var3 > 9.999999747378752e-05F ? var0 / var3 : 0.0F;
      float var5 = var3 > 9.999999747378752e-05F ? var2 / var3 : 1.0F;
      float var6 = var3 - radius(var4, var1, var5) + 0.8500000238418579F;
      float var7 = Math.abs(var1 - 23.0F)
         - 11.0F
         + 0.8500000238418579F;
      float var8 = Math.max(var6, 0.0F);
      float var9 = Math.max(var7, 0.0F);
      return (float)Math.sqrt((double)(var8 * var8 + var9 * var9))
         + Math.min(Math.max(var6, var7), 0.0F)
         - 0.8500000238418579F;
   }

   private static Sdf3D arm() {
      SurfacePaint var0 = stick(
         -5.400000095367432F,
         22.600000381469727F,
         0.20000000298023224F,
         -7.0F,
         11.600000381469727F,
         0.7200000286102295F
      );
      float var10000 = 0.20000000298023224F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.sphere(
         -5.300000190734863F,
         22.799999237060547F,
         0.20000000298023224F,
         0.699999988079071F
      );
      var10001[1] = SdfShapes.capsule(
         -5.300000190734863F,
         22.799999237060547F,
         0.20000000298023224F,
         -3.9000000953674316F,
         22.799999237060547F,
         0.20000000298023224F,
         0.550000011920929F
      );
      Sdf3D var1 = SdfShapes.blend(var10000, var10001);
      Sdf3D var2 = SdfShapes.cone(
         -5.400000095367432F,
         22.5F,
         0.20000000298023224F,
         0.6399999856948853F,
         -6.550000190734863F,
         17.299999237060547F,
         0.11999999731779099F,
         0.5400000214576721F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -6.570000171661377F,
         17.100000381469727F,
         0.14000000059604645F,
         0.6000000238418579F
      );
      Sdf3D var4 = SdfShapes.cone(
         -6.599999904632568F,
         16.850000381469727F,
         0.14000000059604645F,
         0.550000011920929F,
         -6.929999828338623F,
         12.600000381469727F,
         0.5F,
         0.5F
      );
      var10000 = 0.30000001192092896F;
      var10001 = new Sdf3D[4];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      return SdfShapes.blend(var10000, var10001).paint(var0);
   }

   private static Sdf3D hand() {
      float var0 = KNUCKLE_DIR[0];
      float var1 = KNUCKLE_DIR[1];
      float var2 = KNUCKLE_DIR[2];
      Sdf3D var3 = SdfShapes.ellipsoid(
         -6.920000076293945F,
         11.65000057220459F,
         0.7000000476837158F,
         0.8600000143051147F,
         1.0499999523162842F,
         0.8999999761581421F
      );
      Sdf3D var4 = SdfShapes.cone(
         -6.929999828338623F,
         12.75F,
         0.5F,
         0.5F,
         -6.949999809265137F,
         12.15000057220459F,
         0.7200000286102295F,
         0.6399999856948853F
      );
      Sdf3D[] var5 = new Sdf3D[4];

      for (int var6 = 0; var6 < (4); var6++) {
         float var7 = -0.6600000262260437F + (float)var6 * 0.4399999976158142F;
         float var8 = -7.0F + var0 * var7 - 0.2800000011920929F;
         float var9 = 11.600000381469727F + var1 * var7;
         float var10 = 0.7200000286102295F + var2 * var7 + 0.7200000286102295F;
         var5[var6] = SdfShapes.capsule(
            var8 - 0.3499999940395355F,
            var9,
            var10 - 0.30000001192092896F,
            var8 + 0.30000001192092896F,
            var9,
            var10 + 0.10000000149011612F,
            0.25999999046325684F + 0.019999999552965164F * (float)((3) - var6)
         );
      }

      Sdf3D var11 = SdfShapes.capsule(
         -6.380000114440918F,
         12.100000381469727F,
         0.9200000166893005F,
         -6.820000171661377F,
         12.320000648498535F,
         1.6700000762939453F,
         0.27000001072883606F
      );
      float var10000 = 0.18000000715255737F;
      Sdf3D[] var10001 = new Sdf3D[3];
      int var10003 = 0;
      float var10004 = 0.30000001192092896F;
      Sdf3D[] var10005 = new Sdf3D[2];
      var10005[0] = var3;
      var10005[1] = var4;
      var10001[var10003] = SdfShapes.blend(var10004, var10005);
      var10001[1] = SdfShapes.union(var5);
      var10001[2] = var11;
      return SdfShapes.blend(var10000, var10001)
         .paint(
            stick(
               -6.900000095367432F,
               12.800000190734863F,
               0.5F,
               -7.0F,
               10.600000381469727F,
               0.7200000286102295F
            )
         );
   }

   private static Sdf3D leg() {
      SurfacePaint var0 = stick(
         -2.200000047683716F,
         12.800000190734863F,
         0.0F,
         -2.3499999046325684F,
         1.399999976158142F,
         0.0F
      );
      Sdf3D var1 = SdfShapes.sphere(
         -2.200000047683716F,
         12.600000381469727F,
         0.0F,
         0.800000011920929F
      );
      Sdf3D var2 = SdfShapes.cone(
         -2.200000047683716F,
         12.399999618530273F,
         0.0F,
         0.7400000095367432F,
         -2.299999952316284F,
         7.0F,
         0.11999999731779099F,
         0.6200000047683716F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -2.299999952316284F,
         6.75F,
         0.1599999964237213F,
         0.6800000071525574F
      );
      Sdf3D var4 = SdfShapes.cone(
         -2.299999952316284F,
         6.5F,
         0.11999999731779099F,
         0.6200000047683716F,
         -2.359999895095825F,
         1.899999976158142F,
         0.0F,
         0.550000011920929F
      );
      float var10000 = 0.30000001192092896F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      return SdfShapes.blend(var10000, var10001).paint(var0);
   }

   private static Sdf3D foot() {
      float var10000 = 0.5F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.ellipsoid(
         -2.4200000762939453F,
         0.550000011920929F,
         1.0F,
         1.2000000476837158F,
         0.550000011920929F,
         1.899999976158142F
      );
      var10001[1] = SdfShapes.ellipsoid(
         -2.359999895095825F,
         0.949999988079071F,
         -0.10000000149011612F,
         0.800000011920929F,
         0.8500000238418579F,
         1.0F
      );
      var10001[2] = SdfShapes.sphere(
         -2.359999895095825F,
         1.75F,
         0.0F,
         0.550000011920929F
      );
      Sdf3D var0 = SdfShapes.blend(var10000, var10001);
      Sdf3D[] var2 = new Sdf3D[4];
      var2[0] = SdfShapes.sphere(
         -1.7000000476837158F,
         0.3799999952316284F,
         2.549999952316284F,
         0.4000000059604645F
      );
      var2[1] = SdfShapes.sphere(
         -2.200000047683716F,
         0.3499999940395355F,
         2.799999952316284F,
         0.36000001430511475F
      );
      var2[2] = SdfShapes.sphere(
         -2.680000066757202F,
         0.3400000035762787F,
         2.759999990463257F,
         0.33000001311302185F
      );
      var2[3] = SdfShapes.sphere(
         -3.119999885559082F,
         0.33000001311302185F,
         2.5199999809265137F,
         0.3100000023841858F
      );
      Sdf3D var1 = SdfShapes.union(var2);
      var10000 = 0.2199999988079071F;
      var10001 = new Sdf3D[2];
      var10001[0] = var0;
      var10001[1] = var1;
      return SdfShapes.intersect(
            SdfShapes.blend(var10000, var10001), SdfShapes.above(0.0F)
         )
         .paint(
            stick(
               -2.4000000953674316F,
               0.6000000238418579F,
               -1.0F,
               -2.4000000953674316F,
               0.6000000238418579F,
               3.0F
            )
         );
   }

   private static SurfacePaint stick(float var0, float var1, float var2, float var3, float var4, float var5) {
      return SurfacePaint.wood(
            -3567528,
            -7053254,
            var0,
            var1,
            var2,
            var3 - var0,
            var4 - var1,
            var5 - var2,
            0.3499999940395355F
         )
         .grain(0.30000001192092896F, 0.05000000074505806F);
   }

   private static SurfaceDecal eyes() {
      PixelCanvas var0 = new PixelCanvas(336, 208);

      for (int var1 = -1; var1 <= (1); var1 += 2) {
         float var2 = 168.0F + (float)var1 * 85.5F;
         float var3 = 122.0F;
         var0.fill(
            Sdf2D.circle(var2, var3, 75.0F),
            808458248,
            13.0F
         );
         var0.fill(Sdf2D.circle(var2, var3, 66.0F), -15003638);
         Sdf2D var10001 = Sdf2D.circle(var2, var3, 60.75F);
         float var10002 = var2 - 15.0F;
         float var10003 = var3 - 18.0F;
         float var10004 = 78.0F;
         int[] var10005 = new int[3];
         var10005[0] = -1;
         var10005[1] = -132105;
         var10005[2] = -1054240;
         var0.fill(var10001, ColorField2D.radial(var10002, var10003, var10004, var10005));
         float var4 = var2 - (float)var1 * 1.5F;
         float var5 = var3 + 1.0F;
         var0.fill(Sdf2D.circle(var4, var5, 12.0F), -15857658);
         var0.fill(
            Sdf2D.circle(
               var4 - 3.9000000953674316F,
               var5 - 4.400000095367432F,
               3.5999999046325684F
            ),
            -285212673
         );
      }

      Sdf2D var6 = Sdf2D.curve(
         15.0F,
         48.0F,
         74.0F,
         18.0F,
         147.0F,
         71.0F,
         21.0F,
         34.5F
      );
      var0.fill(var6, -15003638);
      var0.fill(
         var6.mirrorX(168.0F)
            .rotate(6.0F, 321.0F, 48.0F)
            .move(0.0F, -7.0F),
         -15003638
      );
      return SurfaceDecal.front(
            var0,
            0.0F,
            29.174999237060547F,
            5.0F,
            8.399999618530273F,
            5.199999809265137F
         )
         .depth(3.5999999046325684F, 1.5F)
         .maxAngle(72.0F)
         .flatLight(1.0F)
         .occlusion(0.0F);
   }

   private static SurfaceDecal mouth() {
      PixelCanvas var0 = new PixelCanvas(272, 104);
      Sdf2D var1 = Sdf2D.ellipse(
            136.0F,
            19.0F,
            124.5F,
            78.0F
         )
         .subtract(
            Sdf2D.circle(
               136.0F, -482.0F, 507.0F
            )
         );
      var0.fill(var1.inflate(6.0F), -15003638);
      float var10002 = 136.0F;
      float var10003 = 10.0F;
      float var10004 = 136.0F;
      float var10005 = 95.5F;
      int[] var10006 = new int[2];
      var10006[0] = -15071227;
      var10006[1] = -12970996;
      var0.fill(var1, ColorField2D.linear(var10002, var10003, var10004, var10005, var10006));
      var0.fill(
         Sdf2D.ellipse(
               136.0F,
               98.5F,
               75.0F,
               39.0F
            )
            .intersect(var1),
         -3646898
      );
      return SurfaceDecal.front(
            var0,
            0.0F,
            24.674999237060547F,
            5.0F,
            6.800000190734863F,
            2.5999999046325684F
         )
         .depth(3.5999999046325684F, 1.5F)
         .maxAngle(72.0F);
   }

   private static SurfaceDecal rings() {
      PixelCanvas var0 = new PixelCanvas(168, 168);
      Sdf2D var10001 = Sdf2D.circle(
         84.0F, 84.0F, 72.0F
      );
      float var10002 = 81.0F;
      float var10003 = 86.0F;
      float var10004 = 72.0F;
      int[] var10005 = new int[4];
      var10005[0] = -3565470;
      var10005[1] = -1917818;
      var10005[2] = -1521774;
      var10005[3] = -2709138;
      var0.fill(var10001, ColorField2D.radial(var10002, var10003, var10004, var10005), 4.0F);
      Sdf2D var1 = Sdf2D.field(
         (var0x, var1x) -> {
            float var2 = var0x - 81.0F;
            float var3 = var1x - 86.0F;
            float var4 = (float)Math.sqrt((double)(var2 * var2 + var3 * var3)) + 0.0010000000474974513F;
            float var5 = var4
               + 2.5F
                  * PerlinNoise.noise(
                     var2 / var4 * 1.2999999523162842F,
                     var3 / var4 * 1.2999999523162842F,
                     var4 * 0.02800000086426735F
                  );
            float var6 = var5 / 8.25F;
            float var7 = var6 - (float)Math.round(var6);
            return Math.max(
               Math.max(
                  Math.abs(var7) * 8.25F - 0.8199999928474426F,
                  var4 - 67.5F
               ),
               6.699999809265137F - var4
            );
         },
         12.0F,
         17.0F,
         150.0F,
         155.0F
      );
      var0.fill(var1, -1602927328);
      var0.fill(
         Sdf2D.circle(
            81.0F, 86.0F, 3.5999999046325684F
         ),
         -9813984
      );
      var0.fill(
         Sdf2D.taper(
            87.0F,
            81.0F,
            3.0F,
            133.0F,
            52.0F,
            1.0F
         ),
         -1069538288
      );
      var0.fill(
         Sdf2D.taper(
            77.0F,
            91.0F,
            2.200000047683716F,
            47.0F,
            126.0F,
            1.0F
         ),
         -1337973744
      );
      return SurfaceDecal.top(
            var0,
            0.0F,
            34.0F,
            0.0F,
            9.678000450134277F,
            9.678000450134277F
         )
         .depth(0.6000000238418579F, 0.6000000238418579F)
         .maxAngle(35.0F);
   }

   private static float smooth(float var0, float var1, float var2) {
      float var3 = Math.max(
         0.0F, Math.min(1.0F, (var2 - var0) / (var1 - var0))
      );
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   private static float[] unit(float var0, float var1, float var2) {
      float var3 = (float)Math.sqrt((double)(var0 * var0 + var1 * var1 + var2 * var2));
      float[] var10000 = new float[3];
      var10000[0] = var0 / var3;
      var10000[1] = var1 / var3;
      var10000[2] = var2 / var3;
      return var10000;
   }

   @Environment(EnvType.CLIENT)
   private static final class PaintWrapper extends SurfacePaint {
      private final SurfacePaint base;

      PaintWrapper(SurfacePaint var1) {
         this.base = var1;
      }

      @Override
      public void apply(float var1, float var2, float var3, SurfaceMaterialSample var4) {
         this.base.apply(var1, var2, var3, var4);
         float var5 = (float)Math.sqrt((double)(var1 * var1 + var3 * var3));
         if (!(var5 < 0.5F)) {
            float var6 = TungTungSahurDesign.smooth(3.950000047683716F, 4.699999809265137F, var5)
               * TungTungSahurDesign.smooth(12.0F, 12.600000381469727F, var2)
               * (
                  1.0F
                     - TungTungSahurDesign.smooth(33.400001525878906F, 34.0F, var2)
               );
            float var7 = TungTungSahurDesign.fissure(var1 / var5, var2, var3 / var5) * var6;
            if (var7 > 0.0F) {
               var4.toward(-9551070, Math.min(1.0F, var7 * 0.6200000047683716F));
            }
         }
      }
   }
}
