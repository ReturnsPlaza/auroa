package hook.feature;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.IntPredicate;
import java.util.function.UnaryOperator;
import java.util.stream.IntStream;
import hook.event.EventListener;
import hook.event.events.Render2DEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.utils.EncryptedString;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Matrix3x2fStack;

public final class OgScoreboardModule extends Module {
   private static OgScoreboardModule instance;
   private final BooleanSetting hideVanilla;
   private final NumberSetting scale;
   private final NumberSetting x;
   private final NumberSetting y;
   private int lastKnownPing;
   private long lastPingUpdateMs;

   public OgScoreboardModule() {
      super(EncryptedString.of("OG Scoreboard"), EncryptedString.of("Recreates the old Donut SMP sidebar from live scoreboard data"), -1, Category.DONUT);
      EncryptedString var27 = EncryptedString.of("Hide Vanilla");
      BooleanSetting var19 = new BooleanSetting(var27, true);
      this.hideVanilla = var19;
      EncryptedString var29 = EncryptedString.of("Scale");
      NumberSetting var20 = new NumberSetting(var29, 0.5, 3.0, 1.0, 0.1);
      this.scale = var20;
      EncryptedString var31 = EncryptedString.of("X");
      NumberSetting var21 = new NumberSetting(var31, -1.0, 3000.0, -1.0, 1.0);
      this.x = var21;
      EncryptedString var33 = EncryptedString.of("Y");
      NumberSetting var22 = new NumberSetting(var33, -1.0, 3000.0, -1.0, 1.0);
      this.y = var22;
      Setting[] var24 = new Setting[4];
      BooleanSetting var46 = this.hideVanilla;
      var24[0] = var46;
      NumberSetting var48 = this.scale;
      var24[1] = var48;
      NumberSetting var50 = this.x;
      var24[2] = var50;
      NumberSetting var52 = this.y;
      var24[3] = var52;
      this.addSettings(var24);
      instance = this;
   }

   public static boolean shouldHideVanillaSidebar() {
      return ((instance != null && instance.isEnabled() && instance.hideVanilla.getValue()));
   }

   @EventListener
   private void onRender2D(Render2DEvent var1) {
      this.renderScoreboard(var1.context);
   }

   private void renderScoreboard(DrawContext var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.player != null && var2.world != null && var2.textRenderer != null) {
         OgScoreboardModule.ScoreboardData var3 = this.readScoreboard(var2);
         ArrayList var4 = new ArrayList(8);
         var4.add(Text.empty());
         var4.add(
            statRow(
               "$",
               "Money",
               safe(var3.money),
               65280,
               true
            )
         );
         var4.add(
            statRow(
               "★",
               "Shards",
               safe(var3.shards),
               10813692,
               false
            )
         );
         var4.add(
            statRow(
               "⚔",
               "Kills",
               safe(var3.kills),
               16711680,
               false
            )
         );
         var4.add(
            statRow(
               "☠",
               "Deaths",
               safe(var3.deaths),
               16546163,
               false
            )
         );
         var4.add(
            statRow(
               "⌚",
               "Playtime",
               safe(var3.playtime),
               16766464,
               false
            )
         );
         var4.add(Text.empty());
         var4.add(footerRow(safe(var3.ping)));
         MutableText var5 = donutTitle();
         int var6 = var2.textRenderer.getWidth(var5);

         for (Object var8Object : var4) { Text var8 = (Text)var8Object;
            var6 = Math.max(var6, var2.textRenderer.getWidth(var8));
         }

         int var20 = 3;
         int var21 = 9;
         int var9 = var6 + var20 * (2);
         int var10 = var21 + (2);
         int var11 = var10 + var4.size() * var21 + (2);
         float var12 = Math.max(0.5F, Math.min(3.0F, this.scale.getFloatValue()));
         int var13 = Math.round((float)var9 * var12);
         int var14 = Math.round((float)var11 * var12);
         int var15 = this.x.getValue() < 0.0
            ? var1.getScaledWindowWidth() - var13 - (2)
            : this.x.getIntValue();
         int var16 = this.y.getValue() < 0.0
            ? (var1.getScaledWindowHeight() - var14) / (2)
            : this.y.getIntValue();
         var1.getMatrices().pushMatrix();
         var1.getMatrices().translate((float)var15, (float)var16);
         var1.getMatrices().scale(var12, var12);
         var1.fill(0, 0, var9, var10, -2147483648);
         var1.fill(0, var10, var9, var11, 1610612736);
         var1.drawText(
            var2.textRenderer,
            var5,
            (var9 - var2.textRenderer.getWidth(var5)) / (2),
            2,
            -1,
            false
         );
         int var17 = var10 + (1);

         for (Object var19Object : var4) { Text var19 = (Text)var19Object;
            var1.drawText(var2.textRenderer, var19, var20, var17, -1, false);
            var17 += var21;
         }

         var1.getMatrices().popMatrix();
      }
   }

   private OgScoreboardModule.ScoreboardData readScoreboard(MinecraftClient var1) {
      OgScoreboardModule.ScoreboardData var2 = new OgScoreboardModule.ScoreboardData();

      try {
         Scoreboard var3 = var1.world.getScoreboard();
         ScoreboardObjective var4 = var3.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
         if (var4 == null) {
            var2.ping = String.valueOf(this.currentPing(var1));
            return var2;
         }

         Collection var5 = var3.getScoreboardEntries(var4);
         ArrayList var6 = new ArrayList(var5);
         var6.sort(Comparator.comparingInt(ScoreboardEntry::value).reversed());
         boolean[] var7 = new boolean[5];
         int var8 = 0;

         for (Object var10Object : var6) { ScoreboardEntry var10 = (ScoreboardEntry)var10Object;
            String var11 = this.plain(var3, var10);
            if (!var11.isEmpty()) {
               String var12 = var11.toLowerCase(Locale.ROOT);
               if (!var7[0]) {
                  String[] var10002 = new String[5];
                  var10002[0] = "$";
                  var10002[1] = "money";
                  var10002[2] = "balance";
                  var10002[3] = "coins";
                  var10002[4] = "bal";
                  if (matchesAny(var11, var12, var10002)) {
                     var2.money = extractValue(var11);
                     var7[0] = true;
                     var8++;
                     continue;
                  }
               }

               if (!var7[1]) {
                  String[] var14 = new String[4];
                  var14[0] = "*";
                  var14[1] = "shard";
                  var14[2] = "nirmata";
                  var14[3] = "gem";
                  if (matchesAny(var11, var12, var14)) {
                     var2.shards = extractValue(var11);
                     var7[1] = true;
                     var8++;
                     continue;
                  }
               }

               if (!var7[2]) {
                  String[] var15 = new String[1];
                  var15[0] = "kill";
                  if (matchesAny(var11, var12, var15)) {
                     var2.kills = extractValue(var11);
                     var7[2] = true;
                     var8++;
                     continue;
                  }
               }

               if (!var7[3]) {
                  String[] var16 = new String[1];
                  var16[0] = "death";
                  if (matchesAny(var11, var12, var16)) {
                     var2.deaths = extractValue(var11);
                     var7[3] = true;
                     var8++;
                     continue;
                  }
               }

               if (!var7[4]) {
                  String[] var17 = new String[4];
                  var17[0] = "playtime";
                  var17[1] = "play time";
                  var17[2] = "time played";
                  var17[3] = "uptime";
                  if (matchesAny(var11, var12, var17)) {
                     var2.playtime = extractPlaytime(var11);
                     var7[4] = true;
                     var8++;
                  }
               }
            }
         }

         if (var8 < (3)) {
            this.positionFallback(var3, var6, var2, var7);
         }

         var2.ping = String.valueOf(this.currentPing(var1));
      } catch (Throwable var13) {
         var2.ping = String.valueOf(this.currentPing(var1));
      }

      return var2;
   }

   private void positionFallback(Scoreboard var1, List<ScoreboardEntry> var2, OgScoreboardModule.ScoreboardData var3, boolean[] var4) {
      ArrayList var5 = new ArrayList();

      for (ScoreboardEntry var7 : var2) {
         String var8 = this.plain(var1, var7);
         if (!var8.isEmpty() && !looksLikeSeparator(var8)) {
            var5.add(var8);
         }
      }

      int var9 = !var5.isEmpty() && !hasDigit((String)var5.getFirst()) ? 1 : 0;
      String[] var10 = new String[5];

      for (int var11 = 0; var11 + var9 < var5.size() && var11 < var10.length; var11++) {
         var10[var11] = (String)var5.get(var11 + var9);
      }

      if (!var4[0] && var10[0] != null) {
         var3.money = extractValue(var10[0]);
      }

      if (!var4[1] && var10[1] != null) {
         var3.shards = extractValue(var10[1]);
      }

      if (!var4[2] && var10[2] != null) {
         var3.kills = extractValue(var10[2]);
      }

      if (!var4[3] && var10[3] != null) {
         var3.deaths = extractValue(var10[3]);
      }

      if (!var4[4] && var10[4] != null) {
         var3.playtime = extractPlaytime(var10[4]);
      }
   }

   private String plain(Scoreboard var1, ScoreboardEntry var2) {
       Text var3 = var2.name();
      if (var3 == null) {
         var3 = Text.literal(var2.owner() == null ? "" : var2.owner());
      }

       Text var4 = var3;

      try {
         Team var5 = var1.getScoreHolderTeam(var2.owner());
         if (var5 != null) {
            var4 = var5.decorateName((Text)var3);
         }
      } catch (Throwable var6) {
      }

      return sanitise(var4.getString());
   }

   private int currentPing(MinecraftClient var1) {
      int var2 = this.readPing(var1);
      long var3 = System.currentTimeMillis();
      if (var2 > 0) {
         this.lastKnownPing = var2;
         this.lastPingUpdateMs = var3;
         return var2;
      } else {
         return this.lastKnownPing > 0 && var3 - this.lastPingUpdateMs < (60000L)
            ? this.lastKnownPing
            : 0;
      }
   }

   private int readPing(MinecraftClient var1) {
      if (var1.player != null && var1.getNetworkHandler() != null) {
         try {
            UUID var2 = var1.player.getUuid();
            String var3 = var1.player.getName().getString();
            PlayerListEntry var4 = var1.getNetworkHandler().getPlayerListEntry(var2);
            if (var4 != null && var4.getLatency() > 0) {
               return var4.getLatency();
            }

            for (PlayerListEntry var6 : var1.getNetworkHandler().getPlayerList()) {
               if (var6 != null && var6.getProfile() != null) {
                  if (var2.equals(var6.getProfile().id()) && var6.getLatency() > 0) {
                     return var6.getLatency();
                  }

                  if (var3.equals(var6.getProfile().name()) && var6.getLatency() > 0) {
                     return var6.getLatency();
                  }
               }
            }

            for (PlayerListEntry var9 : var1.getNetworkHandler().getPlayerList()) {
               if (var9 != null && var9.getLatency() > 0) {
                  return var9.getLatency();
               }
            }
         } catch (Throwable var7) {
         }

         return 0;
      } else {
         return 0;
      }
   }

   private static MutableText statRow(String var0, String var1, String var2, int var3, boolean var4) {
      return Text.empty()
         .append(Text.literal(var0).setStyle(Style.EMPTY.withColor(var3).withBold(var4)))
         .append(Text.literal(" " + var1 + " ").formatted(Formatting.GRAY))
         .append(Text.literal(var2).styled(var1x -> var1x.withColor(var3)));
   }

   private static MutableText footerRow(String var0) {
      return Text.empty()
         .append(
            Text.literal("EU Central ")
               .styled(var0x -> var0x.withColor(11184810))
         )
         .append(Text.literal("(" + var0 + "ms)").styled(var0x -> var0x.withColor(42751)));
   }

   private static MutableText donutTitle() {
      String var0 = "Donut SMP";
      int[] var10000 = new int[9];
      var10000[0] = 32252;
      var10000[1] = 35068;
      var10000[2] = 37628;
      var10000[3] = 40444;
      var10000[4] = 43260;
      var10000[5] = 46076;
      var10000[6] = 48892;
      var10000[7] = 51708;
      var10000[8] = 54524;
      int[] var1 = var10000;
      MutableText var2 = Text.empty();

      for (int var3 = 0; var3 < var0.length(); var3++) {
         int var4 = var1[Math.min(var3, var1.length - (1))];
         var2.append(
            Text.literal(String.valueOf(var0.charAt(var3)))
               .styled(var1x -> var1x.withColor(var4).withBold(Boolean.valueOf(true)))
         );
      }

      return var2;
   }

   private static boolean matchesAny(String var0, String var1, String... var2) {
      String[] var3 = var2;
      int var4 = var2.length;

      for (int var5 = 0; var5 < var4; var5++) {
         String var6 = var3[var5];
         if (var6 != null && !var6.isEmpty() && (var0.contains(var6) || isLetterWord(var6) && var1.contains(var6.toLowerCase(Locale.ROOT)))) {
            return true;
         }
      }

      return false;
   }

   private static boolean isLetterWord(String var0) {
      for (int var1 = 0; var1 < var0.length(); var1++) {
         if (Character.isLetter(var0.charAt(var1))) {
            return true;
         }
      }

      return false;
   }

   private static boolean looksLikeSeparator(String var0) {
      String var1 = sanitise(var0);
      return ((!var1.isEmpty()
            && !var1.chars()
               .allMatch(
                  var0x -> ((!(var0x != (32)
                           && var0x != (45)
                           && var0x != (95)
                           && var0x != (46)
                           && var0x != (42))))
               )
         ? 0
         : 1) != 0);
   }

   private static boolean hasDigit(String var0) {
      for (int var1 = 0; var1 < var0.length(); var1++) {
         if (Character.isDigit(var0.charAt(var1))) {
            return true;
         }
      }

      return false;
   }

   private static String extractValue(String var0) {
      String var1 = sanitise(var0);
      if (var1.isEmpty()) {
         return "0";
      } else {
         String[] var2 = var1.split("\\s+");

         for (int var3 = var2.length - (1); var3 >= 0; var3--) {
            if (hasDigit(var2[var3])) {
               return var2[var3];
            }
         }

         for (int var4 = var2.length - (1); var4 >= 0; var4--) {
            if (!var2[var4].isEmpty()) {
               return var2[var4];
            }
         }

         return "0";
      }
   }

   private static String extractPlaytime(String var0) {
      String var1 = sanitise(var0);
      if (var1.isEmpty()) {
         return "0";
      } else {
         String[] var2 = var1.split("\\s+");
         ArrayList var3 = new ArrayList();

         for (int var4 = var2.length - (1); var4 >= 0; var4--) {
            String var5 = var2[var4];
            if (!var5.matches("\\d+[dhmsy]")
               && !var5.matches("\\d+")) {
               break;
            }

            var3.addFirst(var5);
         }

         return !var3.isEmpty() ? String.join(" ", var3) : extractValue(var1);
      }
   }

   private static String sanitise(String var0) {
      if (var0 == null) {
         return "";
      } else {
         StringBuilder var1 = new StringBuilder(var0.length());

         for (int var2 = 0; var2 < var0.length(); var2++) {
            char var3 = var0.charAt(var2);
            if (var3 == (167)) {
               var2++;
            } else {
               int var4 = Character.getType(var3);
               if (var4 != (15)
                  && var4 != (16)
                  && var4 != (19)
                  && var3 != (8203)
                  && var3 != (8204)
                  && var3 != (8205)
                  && var3 != (65279)) {
                  var1.append(var3);
               } else {
                  var1.append((char)(32));
               }
            }
         }

         return var1.toString().trim();
      }
   }

   private static String safe(String var0) {
      return var0 != null && !var0.isEmpty() ? var0 : "0";
   }

   private static final class ScoreboardData {
      private String money = "0";
      private String shards = "0";
      private String kills = "0";
      private String deaths = "0";
      private String playtime = "0";
      private String ping = "0";
   }
}
