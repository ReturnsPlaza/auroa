package hook.feature;

import hook.module.Category;
import hook.module.Module;
import hook.module.NewFeature;
import hook.module.setting.BooleanSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.NumberSetting;
import hook.utils.EncryptedString;
import hook.halloween.Halloween;
import hook.module.setting.ButtonSetting;

public final class HalloweenModule extends Module implements NewFeature {
   public static final NumberSetting darkness = new NumberSetting(
      EncryptedString.of("Halloween Darkness"), 0.0, 100.0, 60.0, 1.0
   ).getValue(EncryptedString.of("How dark the Halloween night gets (fullbright is overridden)"));
   public static final NumberSetting fogDensity = new NumberSetting(
      EncryptedString.of("Fog Density"), 0.0, 100.0, 55.0, 1.0
   ).getValue(EncryptedString.of("How thick the Halloween fog and ground mist are"));
   public static final NumberSetting eventVolume = new NumberSetting(
      EncryptedString.of("Event Music Volume"), 0.0, 100.0, 60.0, 1.0
   ).getValue(EncryptedString.of("Volume of the Halloween event song"));

   private final ButtonSetting replay;

   public HalloweenModule() {
      super(EncryptedString.of("Halloween"),
         EncryptedString.of("A 67 Client Halloween night: darkness, fog, a haunted sky and a visitor on a broom"),
         -1, Category.RENDER);
      replay = new ButtonSetting(EncryptedString.of("Replay Intro"), Halloween::replayIntro);
      replay.setDescription(EncryptedString.of("Plays the Halloween welcome event again"));
      addSettings(darkness, fogDensity, eventVolume, replay);
   }

   @Override
   public void onEnable() {
      Halloween.onModuleEnabled();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      Halloween.onModuleDisabled();
      super.onDisable();
   }
}
