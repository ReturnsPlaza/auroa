package hook.feature;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import hook.module.Category;
import hook.module.Module;
import hook.module.NewFeature;
import hook.module.modules.client.Hook;
import hook.module.setting.BindSetting;
import hook.module.setting.BooleanSetting;
import hook.module.setting.ButtonSetting;
import hook.module.setting.ChoiceSetting;
import hook.module.setting.ItemSetting;
import hook.module.setting.MinMaxSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.RgbSetting;
import hook.module.setting.Setting;
import hook.module.setting.SettingVisibility;
import hook.module.setting.StorageBlocksSetting;
import hook.module.setting.StringSetting;

public final class HookUiController {
   private static final float WIN_W = 1000.0F;
   private static final float WIN_H = 624.0F;
   private static final float SIDE_W = 236.0F;
   private static final float GAP = 14.0F;
   private static final float SEARCH_H = 56.0F;
   private static final float PLAYER_H = 108.0F;
   private static final float HEADER_H = 78.0F;
   private static final float CARD_H = 90.0F;
   private static final float CARD_GAP = 12.0F;
   private static final float ROW_GAP = 8.0F;
   private static final float PANEL_R = 22.0F;
   private static final int TEXT = UiRenderer.argb(1.0F, 244, 245, 247);
   private static final int SUB = UiRenderer.white(0.56F);
   private static final int FAINT = UiRenderer.white(0.34F);
   private static final int INK = UiRenderer.argb(1.0F, 22, 23, 27);
   private final HookUiController.UiDataSource host;
   private final ConfigUiScreen configs = new ConfigUiScreen();
   private final Map<String, float[]> anims = new HashMap<>();
   private final List<HookUiController.ClickRegion> hits = new ArrayList<>();
   private final List<HookUiController.UiParticleState> particles = new ArrayList<>();
   private final Map<Setting, float[]> tracks = new IdentityHashMap<>();
   private final Random random = new Random();
   private final HalloweenGhostOverlay halloween = new HalloweenGhostOverlay();
   private float hw;
   private Category tab = Category.values()[0];
   private Module page;
   private Module pageShown;
   private float tabT = 10.0F;
   private float vis;
   private boolean closing;
   private long last;
   private float dt;
   private float time = (float)(Math.random() * 1000.0);
   private double mx;
   private double my;
   private int sw;
   private int sh;
   private float u = 1.0F;
   private float wx;
   private float wy;
   private float offX;
   private float offY;
   private boolean posLoaded;
   private boolean dragging;
   private double grabX;
   private double grabY;
   private String query = "";
   private boolean searchFocus;
   private float caretT;
   private StringSetting editing;
   private BindSetting listening;
   private Module listeningModule;
   private Setting sliding;
   private int slideKnob;
   private final float[] gridScroll = new float[2];
   private final float[] pageScroll = new float[2];
   private final float[] pickScroll = new float[2];
   private float gridMax;
   private float pageMax;
   private float pickMax;
   private final float[] gridRect = new float[4];
   private final float[] pageRect = new float[4];
   private final float[] pickRect = new float[4];
   private ItemSetting picking;
   private RgbSetting coloring;
   private int colorDrag;
   private final float[] hsv = new float[3];
   private float alphaPick = 1.0F;
   private final float[] svRect = new float[4];
   private final float[] hueRect = new float[4];
   private final float[] alphaRect = new float[4];
   private String pickQuery = "";
   private List<?> pickItems;
   private int layerNow;
   private float[] hitClip;
   private String tip;
   private float tipX;
   private float tipY;
   private static final Object THEME_GRID = new Object();

   public HookUiController(HookUiController.UiDataSource var1) {
      this.host = var1;
   }

   public void onOpen(boolean var1) {
      this.closing = false;
      this.last = 0L;
      if (var1) {
         this.vis = 0.0F;
         this.dragging = false;
         this.searchFocus = false;
         this.editing = null;
         this.listening = null;
         this.sliding = null;
         this.picking = null;
         this.tabT = 0.0F;
         UiAudio.play(UiAudio.Cue.GUI_OPEN);
      } else {
         this.vis = Math.max(this.vis, 0.6F);
      }
   }

   public void requestClose() {
      if (!this.closing) {
         this.closing = true;
         UiAudio.play(UiAudio.Cue.GUI_CLOSE);
         this.dragging = false;
         this.sliding = null;
         this.searchFocus = false;
         this.editing = null;
         this.listening = null;
      }
   }

   public boolean isClosing() {
      return this.closing;
   }

   public float visibility() {
      return UiEasing.out(this.vis);
   }

   public boolean isTyping() {
      return this.configs.active() || this.searchFocus || this.editing != null || this.listening != null || this.picking != null || this.coloring != null;
   }

   public void render(UiRenderer var1, int var2, int var3, double var4, double var6, float var8) {
      long var9 = System.nanoTime();
      this.dt = this.last == 0L ? 0.016F : UiEasing.clamp((float)(var9 - this.last) / 1.0E9F, 0.0F, 0.1F);
      this.last = var9;
      this.time = this.time + this.dt;
      this.tabT = this.tabT + this.dt;
      this.caretT = this.caretT + this.dt;
      this.mx = var4;
      this.my = var6;
      this.sw = var2;
      this.sh = var3;
      this.hits.clear();
      this.tip = null;
      this.loadPosition();
      float var11 = (float)var3 / 1080.0F * var8;
      this.u = Math.max(0.45F, Math.min(var11, Math.min((float)(var2 - 40) / 1000.0F, (float)(var3 - 40) / 624.0F)));
      if (this.closing) {
         this.vis = this.vis - this.dt / 0.22F;
         if (this.vis <= 0.0F) {
            this.vis = 0.0F;
            this.closing = false;
            this.host.closeNow();
         }
      } else {
         this.vis = Math.min(1.0F, this.vis + this.dt / 0.34F);
      }

      float var12 = UiEasing.out(this.vis);
      if (this.dragging) {
         this.offX = (float)((this.mx - this.grabX) / (double)this.u);
         this.offY = (float)((this.my - this.grabY) / (double)this.u);
      }

      this.clampPosition();
      this.wx = (float)Math.round(((float)var2 - 1000.0F * this.u) / 2.0F + this.offX * this.u);
      this.wy = (float)Math.round(((float)var3 - 624.0F * this.u) / 2.0F + this.offY * this.u);
      this.applySlide();
      this.applyColorDrag();
      this.hw = UiPalette.halloween();
      float[] var13 = new float[]{0.0F, 0.0F};
      float var14 = this.host.shakeStrength();
      if (this.hw > 0.003F && var14 > 0.0F) {
         var13 = this.halloween.shake(this.dt, this.host.beat() * this.hw, var14, (float)var3, this.time);
      } else {
         this.halloween.shake(this.dt, 0.0F, 0.0F, (float)var3, this.time);
         this.halloween.calm();
      }

      var1.pushTransform(var13[0], var13[1], 1.0F);
      this.drawBackground(var1, var12);
      this.drawParticles(var1, var12);
      if (this.hw > 0.003F) {
         var1.pushAlpha(var12);
         this.halloween.background(var1, (float)var2, (float)var3, this.time, this.dt, this.hw, new float[]{this.wx, this.wy, this.d(1000.0F), this.d(624.0F)});
         var1.popAlpha();
      }

      var1.popTransform();
      float var15 = 0.955F + 0.045F * var12;
      float var16 = this.wx + 1000.0F * this.u / 2.0F;
      float var17 = this.wy + 624.0F * this.u / 2.0F;
      var1.pushTransform(var16 * (1.0F - var15), var17 * (1.0F - var15) + (1.0F - var12) * 14.0F * this.u, var15);
      var1.pushAlpha(var12);
      this.layerNow = 0;
      this.drawSidebar(var1);
      this.drawPlayer(var1);
      this.drawMain(var1);
      this.drawSearchBar(var1);
      if (this.tip != null) {
         this.drawTip(var1);
      }

      this.layerNow = 1;
      this.drawPicker(var1);
      this.drawColorPicker(var1);
      this.layerNow = 2;
      this.configs.render(var1, this.mainX(), this.wy, this.mainW(), this.mainH(), this.u, this.dt, this.mx, this.my, !this.closing && this.vis >= 0.6F);
      var1.popAlpha();
      var1.popTransform();
   }

   private float d(float var1) {
      return var1 * this.u;
   }

   private float an(String var1, float var2, float var3) {
      float[] var4 = this.anims.computeIfAbsent(var1, var1x -> new float[]{var2});
      var4[0] += (var2 - var4[0]) * (1.0F - (float)Math.exp((double)(-var3 * this.dt)));
      if (Math.abs(var2 - var4[0]) < 5.0E-4F) {
         var4[0] = var2;
      }

      return var4[0];
   }

   private void drawBackground(UiRenderer var1, float var2) {
      var1.pushAlpha(var2);
      float var3 = (float)this.sh * 0.04F;
      var1.rect(-var3, -var3, (float)this.sw + 2.0F * var3, (float)this.sh + 2.0F * var3, UiRenderer.argb(0.38F, 5, 6, 8));
      var1.gradient(-var3, -var3, (float)this.sw + 2.0F * var3, (float)this.sh + 2.0F * var3, UiPalette.bgTop(0.2F), UiPalette.bgBottom(0.5F));
      float var4 = (float)Math.max(this.sw, this.sh);
      float var5 = UiPalette.lightAmount();
      float var6 = this.time;
      float var7 = UiPalette.selected() == UiPalette.Hook ? 0.35F : 1.0F;
      var1.glow(
         (float)this.sw * (0.28F + 0.16F * (float)Math.sin((double)var6 * 0.031)),
         (float)this.sh * (0.3F + 0.14F * (float)Math.cos((double)var6 * 0.026)),
         var4 * 0.62F,
         UiPalette.light(0.05F * var5 * var7)
      );
      var1.glow(
         (float)this.sw * (0.74F + 0.14F * (float)Math.cos((double)var6 * 0.022 + 1.7)),
         (float)this.sh * (0.66F + 0.16F * (float)Math.sin((double)var6 * 0.028 + 0.6)),
         var4 * 0.58F,
         UiEasing.mix(UiRenderer.argb(0.06F * var7, 190, 195, 205), UiPalette.light(0.06F * var5 * var7), 0.75F)
      );
      var1.glow(
         (float)this.sw * (0.5F + 0.3F * (float)Math.sin((double)var6 * 0.017 + 3.1)),
         (float)this.sh * (0.5F + 0.24F * (float)Math.sin((double)var6 * 0.021 + 2.2)),
         var4 * 0.4F,
         UiRenderer.white(0.025F * var7)
      );
      var1.popAlpha();
   }

   private void drawParticles(UiRenderer var1, float var2) {
      if (this.particles.isEmpty()) {
         int var18 = UiPalette.selected() == UiPalette.Hook ? 26 : 48;
         for (int var3 = 0; var3 < var18; var3++) {
            HookUiController.UiParticleState var4 = new HookUiController.UiParticleState();
            var4.x = this.random.nextFloat();
            var4.y = this.random.nextFloat();
            var4.speed = 0.004F + this.random.nextFloat() * 0.01F;
            var4.size = 0.8F + this.random.nextFloat() * 1.7F;
            var4.phase = this.random.nextFloat() * 100.0F;
            var4.fade = 0.18F + this.random.nextFloat() * 0.35F;
            var4.sway = 0.004F + this.random.nextFloat() * 0.01F;
            var4.base = 0.25F + this.random.nextFloat() * 0.55F;
            this.particles.add(var4);
         }
      }

      var1.pushAlpha(var2);
      float var17 = this.hw;

      for (HookUiController.UiParticleState var5 : this.particles) {
         var5.y = var5.y - var5.speed * this.dt * (1.0F + 0.5F * var17);
         var5.x = var5.x + (float)Math.sin((double)(this.time * 0.35F + var5.phase)) * var5.sway * this.dt;
         if (var5.y < -0.05F) {
            var5.y = 1.05F;
            var5.x = this.random.nextFloat();
         }

         if (var5.x < -0.05F) {
            var5.x = 1.05F;
         } else if (var5.x > 1.05F) {
            var5.x = -0.05F;
         }

         float var6 = 0.5F + 0.5F * (float)Math.sin((double)(this.time * var5.fade + var5.phase));
         float var7 = var5.base * var6 * var6;
         float var8 = var5.x * (float)this.sw;
         float var9 = var5.y * (float)this.sh;
         float var10 = var5.size * Math.max(1.0F, this.u);
         int var11 = UiEasing.mix(UiRenderer.white(0.045F * var7), UiPalette.light(0.06F * var7), 0.7F);
         int var12 = UiEasing.mix(UiRenderer.white(0.42F * var7), UiPalette.light(0.42F * var7), 0.35F);
         if (var17 > 0.003F) {
            float var13 = 0.75F + 0.25F * (float)Math.sin((double)(this.time * 9.0F + var5.phase * 3.0F));
            boolean var14 = (int)(var5.phase * 10.0F) % 5 == 0;
            int var15 = var14 ? UiRenderer.argb(0.06F * var7, 170, 110, 255) : UiRenderer.argb(0.07F * var7 * var13, 255, 120, 40);
            int var16 = var14 ? UiRenderer.argb(0.45F * var7, 225, 200, 255) : UiRenderer.argb(0.55F * var7 * var13, 255, 196, 120);
            var11 = UiEasing.mix(var11, var15, var17);
            var12 = UiEasing.mix(var12, var16, var17);
         }

         var1.glow(var8, var9, var10 * 9.0F, var11);
         var1.glow(var8, var9, var10 * 2.4F, var12);
      }

      var1.popAlpha();
   }

   private void glass(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      var1.shadow(var2, var3, var4, var5, var6, this.d(30.0F), UiRenderer.argb(0.42F, 0, 0, 0));
      var1.round(var2, var3, var4, var5, var6, UiPalette.glass(0.6F));
      var1.roundGradient(
         var2, var3, var4, Math.min(var5, Math.max(var5 * 0.5F, Math.min(var5, this.d(150.0F)))), var6, UiRenderer.white(0.05F), UiRenderer.white(0.0F)
      );
      float var8 = Math.min(var4, var5) * 0.5F;
      float var9 = var2 + var8 + (var4 - 2.0F * var8) * (0.5F + 0.5F * (float)Math.sin((double)(this.time * 0.09F + var7)));
      float var10 = var3 + var8 + (var5 - 2.0F * var8) * (0.35F + 0.35F * (float)Math.cos((double)(this.time * 0.07F + var7 * 1.3F)));
      var1.glow(var9, var10, var8, UiEasing.mix(UiRenderer.white(0.04F), UiPalette.light(0.05F * UiPalette.lightAmount()), 0.7F));
      var1.outline(var2, var3, var4, var5, var6, Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.085F));
      var1.rect(var2 + var6, var3 + Math.max(1.0F, this.u), var4 - 2.0F * var6, Math.max(1.0F, this.u * 0.8F), UiRenderer.white(0.05F));
   }

   private float sideX() {
      return this.wx;
   }

   private float mainX() {
      return this.wx + this.d(250.0F);
   }

   private float mainW() {
      return this.d(750.0F);
   }

   private float mainH() {
      return this.d(554.0F);
   }

   private void drawSidebar(UiRenderer var1) {
      float var2 = this.sideX();
      float var3 = this.wy;
      float var4 = this.d(236.0F);
      float var5 = this.d(502.0F);
      this.glass(var1, var2, var3, var4, var5, this.d(22.0F), 0.4F);
      this.halloween.panelWeb(var1, var2, var3, var4, var5, this.u, this.time, this.hw, true);
      float var6 = this.d(86.0F);
      this.hit(var2, var3, var4, var6, var1x -> this.startDrag());
      float var8 = var2 + this.d(20.0F);
      float var9 = var3 + this.d(23.0F);
      var1.glow(
         var8 + this.d(48.0F), var9 + this.d(20.0F), this.d(54.0F), UiEasing.mix(UiRenderer.white(0.035F), UiPalette.light(0.045F), 0.6F)
      );
      float var11 = var1.text("67 Client", var8, var9 + this.d(2.0F), this.d(23.0F), 1, TEXT);
      HalloweenGhostOverlay.lantern(var1, var8 + this.d(6.0F) + var11, var9 + this.d(4.0F), this.d(19.0F), this.time, this.hw);
      var1.text("Automation client", var8 + this.d(1.0F), var9 + this.d(27.0F), this.d(10.5F), 0, FAINT);
      var1.rect(var2 + this.d(18.0F), var3 + var6, var4 - this.d(36.0F), Math.max(1.0F, this.u), UiRenderer.white(0.06F));
      Category[] var12 = Category.values();
      float var13 = var3 + var6 + this.d(14.0F);
      float var14 = this.d(46.0F);
      boolean var15 = !this.query.isEmpty();

      for (Category var19 : var12) {
         String var20 = "tab:" + var19.name();
         float var21 = var2 + this.d(12.0F);
         float var22 = var4 - this.d(24.0F);
         boolean var23 = var19 == this.tab && !var15;
         boolean var24 = this.hot(var21, var13, var22, var14);
         float var25 = this.an(var20 + ":h", var24 ? 1.0F : 0.0F, 14.0F);
         float var26 = this.an(var20 + ":s", var23 ? 1.0F : 0.0F, 11.0F);
         if (var26 > 0.01F) {
            var1.glow(
               var21 + this.d(30.0F),
               var13 + var14 / 2.0F,
               this.d(70.0F),
               UiEasing.mix(UiRenderer.white(0.045F * var26), UiPalette.accent(0.07F * var26), 0.6F)
            );
         }

         var1.round(
            var21,
            var13,
            var22,
            var14,
            this.d(14.0F),
            UiEasing.mix(UiRenderer.white(0.035F * var25 + 0.085F * var26), UiPalette.accent(0.035F * var25 + 0.085F * var26), 0.35F * var26)
         );
         if (var26 > 0.01F) {
            var1.outline(
               var21,
               var13,
               var22,
               var14,
               this.d(14.0F),
               Math.max(1.0F, this.u * 0.9F),
               UiEasing.mix(UiRenderer.white(0.1F * var26), UiPalette.accent(0.16F * var26), 0.6F)
            );
            float var27 = this.d(18.0F) * var26;
            var1.round(var21 + this.d(3.0F), var13 + (var14 - var27) / 2.0F, this.d(3.0F), var27, this.d(1.5F), UiPalette.accent(0.95F * var26));
         }

         int var34 = UiEasing.mix(UiRenderer.white(0.66F), TEXT, Math.max(var25 * 0.6F, var26));
         float var28 = this.d(19.0F);
         var1.icon(iconFor(var19), var21 + this.d(16.0F), var13 + (var14 - var28) / 2.0F, var28, var34);
         var1.text(var19.name.toString(), var21 + this.d(46.0F), var13 + (var14 - this.d(15.0F)) / 2.0F - this.d(0.5F), this.d(14.5F), 0, var34);
         int var29 = this.modules(var19).size();
         String var30 = String.valueOf(var29);
         float var31 = Math.max(this.d(24.0F), var1.textWidth(var30, this.d(11.0F), 1) + this.d(14.0F));
         float var32 = var21 + var22 - var31 - this.d(10.0F);
         var1.round(var32, var13 + (var14 - this.d(22.0F)) / 2.0F, var31, this.d(22.0F), this.d(11.0F), UiRenderer.white(0.05F + 0.05F * var26));
         var1.textCentered(
            var30, var32 + var31 / 2.0F, var13 + (var14 - this.d(11.0F)) / 2.0F - this.d(0.5F), this.d(11.0F), 1, UiRenderer.white(0.45F + 0.4F * var26)
         );
         this.hit(var21, var13, var22, var14, var2x -> this.selectTab(var19));
         var13 += var14 + this.d(6.0F);
      }
   }

   private void selectTab(Category var1) {
      boolean var2 = var1 != this.tab || !this.query.isEmpty() || this.page != null;
      this.tab = var1;
      this.query = "";
      this.searchFocus = false;
      this.page = null;
      if (var2) {
         this.tabT = 0.0F;
         this.gridScroll[0] = 0.0F;
         this.gridScroll[1] = 0.0F;
         UiAudio.play(UiAudio.Cue.TAB);
      }
   }

   private static UiIcon iconFor(Category var0) {
      return switch (var0) {
         case COMBAT -> UiIcon.SWORD;
         case MISC -> UiIcon.GRID;
         case MACROS -> UiIcon.BOLT;
         case DONUT -> UiIcon.DONUT;
         case RENDER -> UiIcon.EYE;
         case AUTOMATION -> UiIcon.ACTIVITY;
         case CLIENT -> UiIcon.MONITOR;
      };
   }

   private void drawPlayer(UiRenderer var1) {
      float var2 = this.sideX();
      float var3 = this.d(108.0F);
      float var4 = this.wy + this.d(624.0F) - var3;
      float var5 = this.d(236.0F);
      this.glass(var1, var2, var4, var5, var3, this.d(22.0F), 2.2F);
      float var6 = this.d(52.0F);
      float var7 = var2 + this.d(18.0F);
      float var8 = var4 + (var3 - var6) / 2.0F;
      var1.round(var7, var8, var6, var6, this.d(16.0F), UiRenderer.white(0.07F));
      var1.outline(var7, var8, var6, var6, this.d(16.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.1F));
      float var9 = this.d(32.0F);
      var1.head(var7 + (var6 - var9) / 2.0F, var8 + (var6 - var9) / 2.0F, var9);
      float var10 = var7 + var6 + this.d(14.0F);
      float var11 = var2 + var5 - var10 - this.d(14.0F);
      var1.text(var1.ellipsize(this.host.playerName(), var11, this.d(15.0F), 1), var10, var4 + this.d(25.0F), this.d(15.0F), 1, TEXT);
      var1.text(var1.ellipsize(this.host.serverLine(), var11, this.d(11.5F), 0), var10, var4 + this.d(47.0F), this.d(11.5F), 0, SUB);
      int var12 = 0;

      for (Module var14 : this.allModules()) {
         if (var14.isEnabled()) {
            var12++;
         }
      }

      float var15 = 0.55F + 0.45F * (float)Math.sin((double)(this.time * 2.2F));
      float var16 = var4 + this.d(71.0F);
      var1.glow(var10 + this.d(3.5F), var16 + this.d(3.5F), this.d(9.0F), UiPalette.accent(0.22F * var15));
      var1.circle(var10 + this.d(3.5F), var16 + this.d(3.5F), this.d(3.0F), UiPalette.accent(0.9F));
      var1.text(var12 + (var12 == 1 ? " module active" : " modules active"), var10 + this.d(13.0F), var16 - this.d(2.0F), this.d(11.0F), 0, FAINT);
   }

   private void drawMain(UiRenderer var1) {
      float var2 = this.mainX();
      float var3 = this.wy;
      float var4 = this.mainW();
      float var5 = this.mainH();
      this.glass(var1, var2, var3, var4, var5, this.d(22.0F), 4.1F);
      this.halloween.panelWeb(var1, var2, var3, var4, var5, this.u, this.time, this.hw * 0.8F, false);
      float var6 = this.configs.visibility();
      if (!(var6 >= 0.995F)) {
         var1.pushAlpha(1.0F - var6);
         float var7 = this.an("page", this.page != null ? 1.0F : 0.0F, 10.0F);
         if (this.page != null) {
            this.pageShown = this.page;
         }

         float var8 = this.d(36.0F);
         if (var7 < 0.995F) {
            var1.pushAlpha(1.0F - var7);
            var1.pushTransform(-var8 * UiEasing.inOut(var7), 0.0F, 1.0F);
            this.drawGridPage(var1, var2, var3, var4, var5, var7 < 0.5F);
            var1.popTransform();
            var1.popAlpha();
         }

         if (var7 > 0.005F && this.pageShown != null) {
            var1.pushAlpha(var7);
            var1.pushTransform(var8 * (1.0F - UiEasing.inOut(var7)), 0.0F, 1.0F);
            this.drawSettingsPage(var1, this.pageShown, var2, var3, var4, var5, var7 >= 0.5F);
            var1.popTransform();
            var1.popAlpha();
         }

         var1.popAlpha();
      }
   }

   private void header(UiRenderer var1, float var2, float var3, float var4, UiIcon var5, String var6, String var7, boolean var8) {
      if (var8) {
         this.hit(var2, var3, var4, this.d(78.0F), var1x -> this.startDrag());
      }

      float var9 = this.d(44.0F);
      float var10 = var2 + this.d(22.0F);
      float var11 = var3 + this.d(18.0F);
      var1.round(var10, var11, var9, var9, this.d(14.0F), UiRenderer.white(0.07F));
      var1.outline(var10, var11, var9, var9, this.d(14.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.09F));
      float var12 = this.d(21.0F);
      var1.icon(var5, var10 + (var9 - var12) / 2.0F, var11 + (var9 - var12) / 2.0F, var12, TEXT);
      var1.text(var6, var10 + var9 + this.d(16.0F), var11 + this.d(1.0F), this.d(21.0F), 1, TEXT);
      var1.text(var1.ellipsize(var7, var4 - this.d(260.0F), this.d(12.0F), 0), var10 + var9 + this.d(17.0F), var11 + this.d(27.0F), this.d(12.0F), 0, SUB);
      float var13 = this.d(18.0F);
      var1.icon(UiIcon.GRIP, var2 + var4 - this.d(22.0F) - var13, var3 + this.d(30.0F), var13, UiRenderer.white(0.22F));
      var1.rect(var2 + this.d(20.0F), var3 + this.d(78.0F), var4 - this.d(40.0F), Math.max(1.0F, this.u), UiRenderer.white(0.055F));
   }

   private void drawGridPage(UiRenderer var1, float var2, float var3, float var4, float var5, boolean var6) {
      boolean var7 = !this.query.isEmpty();
      List var8 = var7 ? this.searchResults() : this.modules(this.tab);
      int var9 = 0;

      for (Object var11Raw : var8) {Module var11 = (Module)var11Raw;
         if (var11.isEnabled()) {
            var9++;
         }
      }

      String var29 = var7 ? "Search" : this.tab.name.toString();
      String var30 = var7
         ? var8.size() + (var8.size() == 1 ? " result for \"" : " results for \"") + this.query + "\""
         : var8.size() + (var8.size() == 1 ? " module" : " modules") + "  ·  " + var9 + " enabled";
      this.header(var1, var2, var3, var4, var7 ? UiIcon.SEARCH : iconFor(this.tab), var29, var30, var6);
      float var12 = var2 + this.d(18.0F);
      float var13 = var3 + this.d(92.0F);
      float var14 = var4 - this.d(36.0F);
      float var15 = var5 - this.d(92.0F) - this.d(14.0F);
      this.gridRect[0] = var12;
      this.gridRect[1] = var13;
      this.gridRect[2] = var14;
      this.gridRect[3] = var15;
      int var16 = var14 >= this.d(600.0F) ? 2 : 1;
      float var17 = (var14 - this.d(12.0F) * (float)(var16 - 1)) / (float)var16;
      float var18 = this.d(90.0F);
      int var19 = (var8.size() + var16 - 1) / var16;
      float var20 = (float)var19 * var18 + (float)Math.max(0, var19 - 1) * this.d(12.0F);
      this.gridMax = Math.max(0.0F, var20 - var15);
      float var21 = this.scroll(this.gridScroll, this.gridMax);
      if (var8.isEmpty()) {
         var1.icon(
            var7 ? UiIcon.SEARCH : iconFor(this.tab),
            var12 + var14 / 2.0F - this.d(16.0F),
            var13 + var15 / 2.0F - this.d(46.0F),
            this.d(32.0F),
            UiRenderer.white(0.22F)
         );
         var1.textCentered(var7 ? "No modules match" : "Nothing here yet", var12 + var14 / 2.0F, var13 + var15 / 2.0F, this.d(15.0F), 1, SUB);
      } else {
         var1.pushClip(var12 - this.d(10.0F), var13, var14 + this.d(20.0F), var15);
         this.hitClip = new float[]{var12, var13, var14, var15};

         for (int var22 = 0; var22 < var8.size(); var22++) {
            Module var23 = (Module)var8.get(var22);
            int var24 = var22 % var16;
            int var25 = var22 / var16;
            float var26 = var12 + (float)var24 * (var17 + this.d(12.0F));
            float var27 = var13 + (float)var25 * (var18 + this.d(12.0F)) - var21;
            if (!(var27 + var18 < var13 - this.d(20.0F)) && !(var27 > var13 + var15 + this.d(20.0F))) {
               float var28 = UiEasing.out((this.tabT - (float)var22 * 0.028F) / 0.34F);
               var1.pushAlpha(var28);
               var1.pushTransform(0.0F, (1.0F - var28) * this.d(12.0F), 1.0F);
               this.drawCard(var1, var23, var26, var27, var17, var18, var6 && var28 > 0.9F);
               var1.popTransform();
               var1.popAlpha();
            }
         }

         this.hitClip = null;
         var1.popClip();
         this.scrollbar(var1, var12 + var14 + this.d(4.0F), var13, var15, var21, this.gridMax, var20);
      }
   }

   private void drawCard(UiRenderer var1, Module var2, float var3, float var4, float var5, float var6, boolean var7) {
      String var8 = var2.getName().toString();
      String var9 = "card:" + var8;
      boolean var10 = var7 && this.hot(var3, var4, var5, var6);
      float var11 = this.an(var9 + ":h", var10 ? 1.0F : 0.0F, 13.0F);
      float var12 = this.an(var9 + ":on", var2.isEnabled() ? 1.0F : 0.0F, 10.0F);
      if (var11 > 0.01F) {
         var1.shadow(var3, var4, var5, var6, this.d(18.0F), this.d(16.0F), UiRenderer.white(0.035F * var11));
      }

      var1.round(var3, var4, var5, var6, this.d(18.0F), UiRenderer.white(0.035F + 0.03F * var11));
      if (var12 > 0.01F) {
         var1.round(var3, var4, var5, var6, this.d(18.0F), UiEasing.mix(UiRenderer.white(0.035F * var12), UiPalette.accent(0.05F * var12), 0.6F));
      }

      if (var11 > 0.01F) {
         var1.pushClip(var3, var4, var5, var6);
         var1.glow(UiEasing.clamp((float)this.mx, var3, var3 + var5), var4 + var6 * 0.15F, var5 * 0.45F, UiRenderer.white(0.045F * var11));
         var1.popClip();
      }

      var1.outline(
         var3,
         var4,
         var5,
         var6,
         this.d(18.0F),
         Math.max(1.0F, this.u * 0.9F),
         UiEasing.mix(
            UiRenderer.white(0.06F + 0.08F * var11 + 0.06F * var12), UiPalette.accent(0.06F + 0.08F * var11 + 0.1F * var12), 0.5F * var12
         )
      );
      float var13 = this.d(20.0F);
      float var14 = this.d(44.0F);
      float var15 = this.d(24.0F);
      float var16 = var3 + var5 - var13 - var14;
      float var17 = var4 + (var6 - var15) / 2.0F;
      float var18 = this.d(32.0F);
      float var19 = var16 - this.d(12.0F) - var18;
      float var20 = var4 + (var6 - var18) / 2.0F;
      float var21 = var19 - this.d(10.0F) - (var3 + var13);
      int var22 = UiEasing.mix(UiRenderer.white(0.86F), TEXT, var12);
      if (var12 > 0.01F) {
         var1.glow(var3 + var13 + this.d(4.0F), var4 + this.d(29.0F), this.d(16.0F), UiPalette.accent(0.26F * var12));
         var1.circle(var3 + var13 + this.d(3.0F), var4 + this.d(29.0F), this.d(3.0F) * (0.6F + 0.4F * var12), UiPalette.accent(0.97F * var12));
      }

      float var23 = var3 + var13 + this.d(13.0F) * var12;
      boolean var24 = var2 instanceof NewFeature;
      float var25 = var24 ? this.d(52.0F) : 0.0F;
      String var26 = var1.ellipsize(var8, var21 - this.d(13.0F) * var12 - var25, this.d(15.0F), 1);
      float var27 = var1.text(var26, var23, var4 + this.d(20.0F), this.d(15.0F), 1, var22);
      if (var24) {
         float var28 = 0.5F + 0.5F * (float)Math.sin((double)(this.time * 1.8F));
         var1.outline(
            var3,
            var4,
            var5,
            var6,
            this.d(18.0F),
            Math.max(1.0F, this.u * 1.1F),
            UiEasing.mix(UiRenderer.argb(0.2F + 0.12F * var28, 255, 150, 70), UiRenderer.argb(0.2F + 0.12F * var28, 170, 110, 255), var28)
         );
         HalloweenGhostOverlay.newBadge(var1, var23 + var27 + this.d(8.0F), var4 + this.d(19.0F), this.d(17.0F), this.time, 1.0F);
      }

      List var32 = this.wrap(var1, var2.getDescription() == null ? "" : var2.getDescription().toString(), var21, this.d(11.8F), 2);

      for (int var29 = 0; var29 < var32.size(); var29++) {
         var1.text((String)var32.get(var29), var3 + var13, var4 + this.d(45.0F) + (float)var29 * this.d(16.0F), this.d(11.8F), 0, SUB);
      }

      boolean var33 = var7 && this.hot(var19, var20, var18, var18);
      float var30 = this.an(var9 + ":g", var33 ? 1.0F : 0.0F, 16.0F);
      var1.round(var19, var20, var18, var18, this.d(11.0F), UiRenderer.white(0.035F + 0.03F * var11 + 0.07F * var30));
      float var31 = this.d(17.0F);
      var1.icon(
         UiIcon.GEAR,
         var19 + (var18 - var31) / 2.0F,
         var20 + (var18 - var31) / 2.0F,
         var31,
         UiRenderer.white(0.42F + 0.25F * var11 + 0.33F * var30)
      );
      this.toggle(var1, var16, var17, var14, var15, var12, var11);
      if (var7) {
         this.hit(var3, var4, var5, var6, var2x -> {
            if (var2x == 1) {
               this.openPage(var2);
            } else if (var2x == 0) {
               this.toggleModule(var2);
            }
         });
         this.hit(var19, var20, var18, var18, var2x -> this.openPage(var2));
      }
   }

   private void toggle(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      float var8 = UiEasing.inOut(var6);
      int var9 = UiEasing.mix(UiRenderer.white(0.1F + 0.05F * var7), UiPalette.accent(0.93F), var8);
      var1.round(var2, var3, var4, var5, var5 / 2.0F, var9);
      if (var8 < 0.98F) {
         var1.outline(var2, var3, var4, var5, var5 / 2.0F, Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.1F * (1.0F - var8)));
      }

      float var10 = var5 - this.d(6.0F);
      float var11 = UiEasing.lerp(var2 + this.d(3.0F), var2 + var4 - this.d(3.0F) - var10, var8);
      float var12 = var3 + this.d(3.0F);
      if (var8 > 0.02F) {
         var1.glow(var2 + var4 / 2.0F, var3 + var5 / 2.0F, var4 * 0.9F, UiPalette.accent(0.08F * var8));
      }

      var1.shadow(var11, var12, var10, var10, var10 / 2.0F, this.d(4.0F), UiRenderer.argb(0.35F, 0, 0, 0));
      var1.round(var11, var12, var10, var10, var10 / 2.0F, UiEasing.mix(UiRenderer.white(0.92F), INK, var8));
   }

   private void toggleModule(Module var1) {
      var1.toggle();
      UiAudio.play(var1.isEnabled() ? UiAudio.Cue.ON : UiAudio.Cue.OFF);
   }

   private void openPage(Module var1) {
      this.page = var1;
      this.pageScroll[0] = 0.0F;
      this.pageScroll[1] = 0.0F;
      this.editing = null;
      this.listening = null;
      UiAudio.play(UiAudio.Cue.OPEN);
   }

   private void closePage() {
      this.page = null;
      this.editing = null;
      this.listening = null;
      UiAudio.play(UiAudio.Cue.BACK);
   }

   private void drawSettingsPage(UiRenderer var1, Module var2, float var3, float var4, float var5, float var6, boolean var7) {
      String var8 = var2.getDescription() == null ? "" : var2.getDescription().toString();
      if (var7) {
         this.hit(var3, var4, var5, this.d(78.0F), var1x -> this.startDrag());
      }

      float var9 = this.d(44.0F);
      float var10 = var3 + this.d(22.0F);
      float var11 = var4 + this.d(18.0F);
      boolean var12 = var7 && this.hot(var10, var11, var9, var9);
      float var13 = this.an("back", var12 ? 1.0F : 0.0F, 15.0F);
      var1.round(var10, var11, var9, var9, this.d(14.0F), UiRenderer.white(0.07F + 0.07F * var13));
      var1.outline(var10, var11, var9, var9, this.d(14.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.09F + 0.08F * var13));
      float var14 = this.d(22.0F);
      var1.icon(UiIcon.CHEVRON_LEFT, var10 + (var9 - var14) / 2.0F - this.d(2.0F) * var13, var11 + (var9 - var14) / 2.0F, var14, TEXT);
      if (var7) {
         this.hit(var10, var11, var9, var9, var1x -> this.closePage());
      }

      String var15 = var2.getName().toString();
      boolean var16 = this.isClient(var2);
      String var17 = var16 ? "Client settings" : var15;
      String var18 = var16 ? "Themes, sound and interface" : var8;
      float var19 = var1.text(var17, var10 + var9 + this.d(16.0F), var11 + this.d(1.0F), this.d(21.0F), 1, TEXT);
      if (var2 instanceof NewFeature) {
         HalloweenGhostOverlay.newBadge(var1, var10 + var9 + this.d(26.0F) + var19, var11 + this.d(3.0F), this.d(19.0F), this.time, 1.0F);
      }

      var1.text(var1.ellipsize(var18, var5 - this.d(300.0F), this.d(12.0F), 0), var10 + var9 + this.d(17.0F), var11 + this.d(27.0F), this.d(12.0F), 0, SUB);
      float var20 = this.d(52.0F);
      float var21 = this.d(28.0F);
      float var22 = var3 + var5 - this.d(24.0F) - var20;
      float var23 = var11 + (var9 - var21) / 2.0F;
      if (var16) {
         float var24 = this.d(18.0F);
         var1.icon(UiIcon.GRIP, var3 + var5 - this.d(22.0F) - var24, var4 + this.d(30.0F), var24, UiRenderer.white(0.22F));
      } else {
         boolean var36 = var7 && this.hot(var22, var23, var20, var21);
         float var25 = this.an("page:on:" + var15, var2.isEnabled() ? 1.0F : 0.0F, 10.0F);
         this.toggle(var1, var22, var23, var20, var21, var25, this.an("page:toh", var36 ? 1.0F : 0.0F, 15.0F));
         var1.textRight(
            var2.isEnabled() ? "Enabled" : "Disabled", var22 - this.d(12.0F), var23 + (var21 - this.d(12.0F)) / 2.0F - this.d(1.0F), this.d(12.0F), 0, SUB
         );
         if (var7) {
            this.hit(var22, var23, var20, var21, var2x -> this.toggleModule(var2));
         }
      }

      var1.rect(var3 + this.d(20.0F), var4 + this.d(78.0F), var5 - this.d(40.0F), Math.max(1.0F, this.u), UiRenderer.white(0.055F));
      float var37 = var3 + this.d(18.0F);
      float var38 = var4 + this.d(92.0F);
      float var26 = var5 - this.d(36.0F);
      float var27 = var6 - this.d(92.0F) - this.d(14.0F);
      this.pageRect[0] = var37;
      this.pageRect[1] = var38;
      this.pageRect[2] = var26;
      this.pageRect[3] = var27;
      List var28 = this.pageItems(var2);
      float var29 = 0.0F;

      for (Object var31 : var28) {
         var29 += this.itemHeight(var31, var26) + this.d(8.0F);
      }

      var29 = Math.max(0.0F, var29 - this.d(8.0F));
      this.pageMax = Math.max(0.0F, var29 - var27);
      float var40 = this.scroll(this.pageScroll, this.pageMax);
      var1.pushClip(var37 - this.d(10.0F), var38, var26 + this.d(20.0F), var27);
      this.hitClip = new float[]{var37, var38, var26, var27};
      float var41 = var38 - var40;

      for (Object var33 : var28) {
         float var34 = this.itemHeight(var33, var26);
         if (!(var41 + var34 < var38 - this.d(20.0F)) && !(var41 > var38 + var27 + this.d(20.0F))) {
            if (var33 instanceof Setting var35) {
               this.drawRow(var1, var2, var35, var37, var41, var26, var34, var7);
            } else if (var33 == THEME_GRID) {
               this.drawThemes(var1, var37, var41, var26, var7);
            } else {
               this.section(var1, (String)var33, var37, var41, var26);
            }
         }

         var41 += var34 + this.d(8.0F);
      }

      this.hitClip = null;
      var1.popClip();
      this.scrollbar(var1, var37 + var26 + this.d(4.0F), var38, var27, var40, this.pageMax, var29);
   }

   private boolean isClient(Module var1) {
      return var1 instanceof Hook;
   }

   private List<Object> pageItems(Module var1) {
      ArrayList var2 = new ArrayList();
      if (!this.isClient(var1)) {
         for (Setting var8 : var1.getSettings()) {
            if (SettingVisibility.visible(var8)) {
               var2.add(var8);
            }
         }

         return var2;
      } else {
         Setting[] var3 = new Setting[]{Hook.uiSounds, Hook.uiVolume};
         Setting[] var4 = new Setting[]{Hook.halloweenMusic, Hook.halloweenVolume, Hook.beatShake, Hook.shakeStrength};
         var2.add("Theme");
         var2.add(THEME_GRID);
         var2.add("Sound");
         var2.addAll(List.of(var3));
         var2.add("Halloween");
         var2.addAll(List.of(var4));
         var2.add("Interface");

         for (Setting var6 : var1.getSettings()) {
            if (var6 != Hook.theme && !List.of(var3).contains(var6) && !List.of(var4).contains(var6)) {
               var2.add(var6);
            }
         }

         return var2;
      }
   }

   private float itemHeight(Object var1, float var2) {
      if (var1 instanceof Setting) {
         return this.d(62.0F);
      } else if (var1 == THEME_GRID) {
         int var3 = (UiPalette.values().length + 3) / 4;
         return (float)var3 * this.d(108.0F) + (float)(var3 - 1) * this.d(12.0F);
      } else {
         return this.d(26.0F);
      }
   }

   private void section(UiRenderer var1, String var2, float var3, float var4, float var5) {
      float var6 = var4 + this.d(8.0F);
      var1.text(var2.toUpperCase(Locale.ROOT), var3 + this.d(6.0F), var6, this.d(10.5F), 1, UiRenderer.white(0.42F));
      float var7 = var1.textWidth(var2.toUpperCase(Locale.ROOT), this.d(10.5F), 1);
      var1.rect(var3 + this.d(16.0F) + var7, var6 + this.d(7.0F), var5 - var7 - this.d(22.0F), Math.max(1.0F, this.u), UiRenderer.white(0.06F));
   }

   private void drawThemes(UiRenderer var1, float var2, float var3, float var4, boolean var5) {
      UiPalette[] var6 = UiPalette.values();
      UiPalette var7 = UiPalette.selected();
      byte var8 = 4;
      float var9 = this.d(12.0F);
      float var10 = (var4 - var9 * (float)(var8 - 1)) / (float)var8;
      float var11 = this.d(108.0F);

      for (int var12 = 0; var12 < var6.length; var12++) {
         UiPalette var13 = var6[var12];
         float var14 = var2 + (float)(var12 % var8) * (var10 + var9);
         float var15 = var3 + (float)(var12 / var8) * (var11 + var9);
         String var16 = "theme:" + var13.name();
         boolean var17 = var5 && this.hot(var14, var15, var10, var11);
         float var18 = this.an(var16 + ":h", var17 ? 1.0F : 0.0F, 13.0F);
         float var19 = this.an(var16 + ":s", var13 == var7 ? 1.0F : 0.0F, 9.0F);
         float var20 = this.d(2.0F) * var18;
         var15 -= var20;
         if (var19 > 0.01F) {
            var1.shadow(var14, var15, var10, var11, this.d(18.0F), this.d(18.0F), var13.previewAccent() & 16777215 | Math.round(0.1F * var19 * 255.0F) << 24);
         }

         var1.round(var14, var15, var10, var11, this.d(18.0F), UiRenderer.white(0.035F + 0.03F * var18 + 0.03F * var19));
         float var21 = var14 + this.d(10.0F);
         float var22 = var15 + this.d(10.0F);
         float var23 = var10 - this.d(20.0F);
         float var24 = this.d(58.0F);
         int var25 = var13.previewTop();
         var1.roundGradient(var21, var22, var23, var24, this.d(12.0F), UiEasing.mix(var25, -14013648, 0.25F), UiEasing.mix(var25, -16448250, 0.55F));
         var1.pushClip(var21, var22, var23, var24);
         var1.glow(
            var21 + var23 * 0.72F,
            var22 + var24 * 0.35F,
            var23 * 0.55F,
            var13.previewLight() & 16777215 | Math.round(Math.min(1.0F, (0.12F + 0.06F * var18) * var13.lightAmount) * 255.0F) << 24
         );
         var1.popClip();
         var1.outline(var21, var22, var23, var24, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F));
         float var26 = this.d(26.0F);
         var1.imageGradient("logo", var21 + this.d(12.0F), var22 + (var24 - var26) / 2.0F, var26, -1, var13.previewLogo());
         float var27 = this.d(30.0F);
         float var28 = this.d(16.0F);
         float var29 = var21 + var23 - this.d(12.0F) - var27;
         float var30 = var22 + (var24 - var28) / 2.0F;
         var1.round(var29, var30, var27, var28, var28 / 2.0F, var13.previewAccent() & 16777215 | -318767104);
         float var31 = var28 - this.d(4.0F);
         var1.round(var29 + var27 - this.d(2.0F) - var31, var30 + this.d(2.0F), var31, var31, var31 / 2.0F, INK);
         var1.text(
            var13.name(),
            var14 + this.d(14.0F),
            var15 + var11 - this.d(31.0F),
            this.d(13.0F),
            1,
            UiEasing.mix(UiRenderer.white(0.78F), TEXT, Math.max(var19, var18))
         );
         if (var19 > 0.01F) {
            float var32 = this.d(9.0F) * (0.7F + 0.3F * var19);
            float var33 = var14 + var10 - this.d(22.0F);
            float var34 = var15 + var11 - this.d(23.0F);
            var1.glow(var33, var34, var32 * 2.4F, var13.previewAccent() & 16777215 | Math.round(0.25F * var19 * 255.0F) << 24);
            var1.circle(var33, var34, var32, var13.previewAccent() & 16777215 | Math.round(var19 * 255.0F) << 24);
            float var35 = var32 * 1.3F;
            var1.icon(UiIcon.CHECK, var33 - var35 / 2.0F, var34 - var35 / 2.0F, var35, UiRenderer.argb(var19, 22, 23, 27));
         }

         var1.outline(
            var14,
            var15,
            var10,
            var11,
            this.d(18.0F),
            Math.max(1.0F, this.u * 0.9F),
            UiEasing.mix(UiRenderer.white(0.06F + 0.08F * var18), var13.previewAccent() & 16777215 | Math.round(153.0F) << 24, var19)
         );
         if (var5) {
            int var37 = var12;
            this.hit(var14, var15, var10, var11, var1x -> {
               if (Hook.theme.getModeIndex() != var37) {
                  Hook.theme.setModeIndex(var37);
                  UiAudio.play(UiAudio.Cue.THEME);
               }
            });
         }
      }
   }

   private void drawRow(UiRenderer var1, Module var2, Setting var3, float var4, float var5, float var6, float var7, boolean var8) {
      String var9 = "row:" + System.identityHashCode(var3);
      boolean var10 = var8 && this.hot(var4, var5, var6, var7);
      float var11 = this.an(var9 + ":h", var10 ? 1.0F : 0.0F, 13.0F);
      var1.round(var4, var5, var6, var7, this.d(16.0F), UiRenderer.white(0.03F + 0.025F * var11));
      var1.outline(var4, var5, var6, var7, this.d(16.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.05F + 0.05F * var11));
      String var12 = var3.getName() == null ? "" : var3.getName().toString();
      String var13 = var3.getDescription() == null ? "" : var3.getDescription().toString();
      float var14 = this.d(20.0F);
      float var15 = this.d(300.0F);
      float var16 = var6 - var14 * 2.0F - var15 - this.d(12.0F);
      if (var13.isEmpty()) {
         var1.text(var1.ellipsize(var12, var16, this.d(14.0F), 1), var4 + var14, var5 + (var7 - this.d(14.0F)) / 2.0F - this.d(1.0F), this.d(14.0F), 1, TEXT);
      } else {
         var1.text(var1.ellipsize(var12, var16, this.d(14.0F), 1), var4 + var14, var5 + this.d(14.0F), this.d(14.0F), 1, TEXT);
         var1.text(var1.ellipsize(var13, var16, this.d(11.5F), 0), var4 + var14, var5 + this.d(35.0F), this.d(11.5F), 0, SUB);
      }

      float var17 = var4 + var6 - var14;
      float var18 = var5 + var7 / 2.0F;
      if (var3 instanceof BooleanSetting var19) {
         float var30 = this.d(44.0F);
         float var31 = this.d(24.0F);
         float var32 = this.an(var9 + ":on", var19.getValue() ? 1.0F : 0.0F, 10.0F);
         this.toggle(var1, var17 - var30, var18 - var31 / 2.0F, var30, var31, var32, var11);
         if (var8) {
            this.hit(var4, var5, var6, var7, var1x -> {
               var19.toggle();
               UiAudio.play(var19.getValue() ? UiAudio.Cue.ON : UiAudio.Cue.OFF);
            });
         }
      } else if (var3 instanceof NumberSetting var20) {
         float var40 = this.d(66.0F);
         float var50 = this.d(200.0F);
         float var60 = var17 - var40 - this.d(14.0F) - var50;
         double var33 = var20.getMax() - var20.getMin();
         float var35 = var33 <= 0.0 ? 0.0F : (float)((var20.getValue() - var20.getMin()) / var33);
         float var36 = this.an(var9 + ":v", var35, 18.0F);
         boolean var37 = this.sliding == var20;
         float var38 = this.an(var9 + ":a", !var37 && !var10 ? 0.0F : 1.0F, 14.0F);
         this.slider(var1, var20, var60, var18, var50, var36, -1.0F, var38);
         this.valuePill(var1, format(var20.getValue(), var20.getFormat()), var17 - var40, var18, var40);
         if (var8) {
            this.hit(var60 - this.d(8.0F), var18 - this.d(14.0F), var50 + this.d(16.0F), this.d(28.0F), var2x -> this.beginSlide(var20, 0));
         }
      } else if (var3 instanceof MinMaxSetting var21) {
         float var41 = this.d(96.0F);
         float var51 = this.d(170.0F);
         float var61 = var17 - var41 - this.d(14.0F) - var51;
         double var70 = var21.getMaxValue() - var21.getMinValue();
         float var86 = var70 <= 0.0 ? 0.0F : (float)((var21.getCurrentMin() - var21.getMinValue()) / var70);
         float var95 = var70 <= 0.0 ? 1.0F : (float)((var21.getCurrentMax() - var21.getMinValue()) / var70);
         float var104 = this.an(var9 + ":v1", var86, 18.0F);
         float var112 = this.an(var9 + ":v2", var95, 18.0F);
         float var39 = this.an(var9 + ":a", this.sliding != var21 && !var10 ? 0.0F : 1.0F, 14.0F);
         this.slider(var1, var21, var61, var18, var51, var104, var112, var39);
         this.valuePill(
            var1, format(var21.getCurrentMin(), var21.getStep()) + " – " + format(var21.getCurrentMax(), var21.getStep()), var17 - var41, var18, var41
         );
         if (var8) {
            this.hit(var61 - this.d(8.0F), var18 - this.d(14.0F), var51 + this.d(16.0F), this.d(28.0F), var4x -> {
               float[] var5x = this.tracks.get(var21);
               float var6x = var5x == null ? 0.0F : (float)((this.mx - (double)var5x[0]) / (double)var5x[1]);
               this.beginSlide(var21, Math.abs(var6x - var86) <= Math.abs(var6x - var95) && !(var6x > var95) ? 0 : 1);
            });
         }
      } else if (var3 instanceof ModeSetting var22) {
         float var42 = this.d(200.0F);
         float var52 = this.d(34.0F);
         float var62 = var17 - var42;
         float var71 = var18 - var52 / 2.0F;
         boolean var34 = var8 && this.hot(var62, var71, var42, var52);
         float var87 = this.an(var9 + ":m", var34 ? 1.0F : 0.0F, 15.0F);
         var1.round(var62, var71, var42, var52, this.d(12.0F), UiRenderer.white(0.05F + 0.04F * var87));
         var1.outline(var62, var71, var42, var52, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.07F * var87));
         float var96 = this.d(16.0F);
         var1.icon(UiIcon.CHEVRON_LEFT, var62 + this.d(8.0F), var18 - var96 / 2.0F, var96, UiRenderer.white(0.45F + 0.4F * var87));
         var1.icon(UiIcon.CHEVRON_RIGHT, var62 + var42 - this.d(8.0F) - var96, var18 - var96 / 2.0F, var96, UiRenderer.white(0.45F + 0.4F * var87));
         String var105 = prettyEnum(String.valueOf(var22.getValue()));
         float var113 = this.an(var9 + ":idx", (float)var22.getModeIndex(), 16.0F);
         float var117 = (var113 - (float)var22.getModeIndex()) * this.d(10.0F);
         var1.pushClip(var62 + this.d(28.0F), var71, var42 - this.d(56.0F), var52);
         var1.textCentered(
            var1.ellipsize(var105, var42 - this.d(64.0F), this.d(12.5F), 1), var62 + var42 / 2.0F + var117, var18 - this.d(7.5F), this.d(12.5F), 1, TEXT
         );
         var1.popClip();
         if (var8) {
            this.hit(var62, var71, var42 / 2.0F, var52, var1x -> {
               if (var1x == 1) {
                  var22.cycleUp();
               } else {
                  var22.cycleDown();
               }

               UiAudio.play(UiAudio.Cue.TICK);
            });
            this.hit(var62 + var42 / 2.0F, var71, var42 / 2.0F, var52, var1x -> {
               if (var1x == 1) {
                  var22.cycleDown();
               } else {
                  var22.cycleUp();
               }

               UiAudio.play(UiAudio.Cue.TICK);
            });
         }
      } else if (var3 instanceof ChoiceSetting var23) {
         float var43 = this.d(200.0F);
         float var53 = this.d(34.0F);
         float var63 = var17 - var43;
         float var72 = var18 - var53 / 2.0F;
         boolean var79 = var8 && this.hot(var63, var72, var43, var53);
         float var88 = this.an(var9 + ":m", var79 ? 1.0F : 0.0F, 15.0F);
         var1.round(var63, var72, var43, var53, this.d(12.0F), UiRenderer.white(0.05F + 0.04F * var88));
         var1.outline(var63, var72, var43, var53, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.07F * var88));
         float var97 = this.d(16.0F);
         var1.icon(UiIcon.CHEVRON_LEFT, var63 + this.d(8.0F), var18 - var97 / 2.0F, var97, UiRenderer.white(0.45F + 0.4F * var88));
         var1.icon(UiIcon.CHEVRON_RIGHT, var63 + var43 - this.d(8.0F) - var97, var18 - var97 / 2.0F, var97, UiRenderer.white(0.45F + 0.4F * var88));
         float var106 = this.an(var9 + ":idx", (float)var23.getIndex(), 16.0F);
         float var114 = (var106 - (float)var23.getIndex()) * this.d(10.0F);
         var1.pushClip(var63 + this.d(28.0F), var72, var43 - this.d(56.0F), var53);
         var1.textCentered(
            var1.ellipsize(var23.getMode(), var43 - this.d(64.0F), this.d(12.5F), 1),
            var63 + var43 / 2.0F + var114,
            var18 - this.d(7.5F),
            this.d(12.5F),
            1,
            TEXT
         );
         var1.popClip();
         if (var8) {
            this.hit(var63, var72, var43 / 2.0F, var53, var1x -> {
               if (var1x == 1) {
                  var23.cycleUp();
               } else {
                  var23.cycleDown();
               }

               UiAudio.play(UiAudio.Cue.TICK);
            });
            this.hit(var63 + var43 / 2.0F, var72, var43 / 2.0F, var53, var1x -> {
               if (var1x == 1) {
                  var23.cycleDown();
               } else {
                  var23.cycleUp();
               }

               UiAudio.play(UiAudio.Cue.TICK);
            });
         }
      } else if (var3 instanceof ButtonSetting var24) {
         float var44 = this.d(150.0F);
         float var54 = this.d(34.0F);
         float var64 = var17 - var44;
         float var73 = var18 - var54 / 2.0F;
         boolean var80 = var8 && this.hot(var64, var73, var44, var54);
         float var89 = this.an(var9 + ":b", var80 ? 1.0F : 0.0F, 15.0F);
         float var98 = this.an(var9 + ":press", 0.0F, 9.0F);
         var1.round(
            var64, var73, var44, var54, this.d(12.0F), UiEasing.mix(UiRenderer.white(0.06F + 0.06F * var89), UiPalette.accent(0.3F), var98)
         );
         var1.outline(
            var64,
            var73,
            var44,
            var54,
            this.d(12.0F),
            Math.max(1.0F, this.u * 0.9F),
            UiEasing.mix(UiRenderer.white(0.1F + 0.1F * var89), UiPalette.accent(0.6F), Math.max(var98, 0.4F * var89))
         );
         var1.textCentered("Run", var64 + var44 / 2.0F, var18 - this.d(7.5F), this.d(12.5F), 1, TEXT);
         if (var8) {
            String var107 = var9 + ":press";
            this.hit(var64, var73, var44, var54, var3x -> {
               this.anims.put(var107, new float[]{1.0F});
               UiAudio.play(UiAudio.Cue.CONFIRM);
               var24.run();
            });
         }
      } else if (var3 instanceof RgbSetting var25) {
         float var45 = this.d(150.0F);
         float var55 = this.d(34.0F);
         float var65 = var17 - var45;
         float var74 = var18 - var55 / 2.0F;
         boolean var81 = var8 && this.hot(var65, var74, var45, var55);
         float var90 = this.an(var9 + ":c", !var81 && this.coloring != var25 ? 0.0F : 1.0F, 15.0F);
         var1.round(var65, var74, var45, var55, this.d(12.0F), UiRenderer.white(0.05F + 0.05F * var90));
         var1.outline(var65, var74, var45, var55, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.1F * var90));
         float var99 = this.d(20.0F);
         float var108 = var65 + this.d(9.0F);
         this.checker(var1, var108, var18 - var99 / 2.0F, var99, var99, this.d(5.0F));
         var1.round(var108, var18 - var99 / 2.0F, var99, var99, this.d(7.0F), var25.getArgb());
         var1.outline(var108, var18 - var99 / 2.0F, var99, var99, this.d(7.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.3F));
         var1.text(hex(var25.getArgb()), var108 + var99 + this.d(10.0F), var18 - this.d(7.5F), this.d(12.5F), 1, TEXT);
         if (var8) {
            this.hit(var65, var74, var45, var55, var2x -> this.openColor(var25));
         }
      } else if (var3 instanceof BindSetting var26) {
         float var46 = this.d(150.0F);
         float var56 = this.d(34.0F);
         float var66 = var17 - var46;
         float var75 = var18 - var56 / 2.0F;
         boolean var82 = this.listening == var26;
         boolean var91 = var8 && this.hot(var66, var75, var46, var56);
         float var100 = this.an(var9 + ":k", !var91 && !var82 ? 0.0F : 1.0F, 15.0F);
         float var109 = var82 ? 0.5F + 0.5F * (float)Math.sin((double)(this.time * 6.0F)) : 0.0F;
         var1.round(var66, var75, var46, var56, this.d(12.0F), UiRenderer.white(0.05F + 0.05F * var100 + 0.05F * var109));
         var1.outline(var66, var75, var46, var56, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.1F * var100 + 0.12F * var109));
         float var115 = this.d(16.0F);
         var1.icon(UiIcon.KEYBOARD, var66 + this.d(12.0F), var18 - var115 / 2.0F, var115, UiRenderer.white(0.55F + 0.3F * var100));
         String var118 = var82 ? "Press a key…" : this.keyLabel(var26.getValue());
         var1.text(
            var1.ellipsize(var118, var46 - this.d(44.0F), this.d(12.5F), 1), var66 + this.d(36.0F), var18 - this.d(7.5F), this.d(12.5F), 1, var82 ? SUB : TEXT
         );
         if (var8) {
            this.hit(var66, var75, var46, var56, var3x -> {
               if (var3x == 1) {
                  this.assignBind(var26, var2, -1);
               } else {
                  this.listening = var26;
                  this.listeningModule = var2;
                  UiAudio.play(UiAudio.Cue.TICK);
               }
            });
         }
      } else if (var3 instanceof StringSetting var27) {
         float var47 = this.d(260.0F);
         float var57 = this.d(34.0F);
         float var67 = var17 - var47;
         float var76 = var18 - var57 / 2.0F;
         boolean var83 = this.editing == var27;
         boolean var92 = var8 && this.hot(var67, var76, var47, var57);
         float var101 = this.an(var9 + ":f", var83 ? 1.0F : (var92 ? 0.5F : 0.0F), 15.0F);
         this.field(var1, var67, var76, var47, var57, var27.getValue() == null ? "" : var27.getValue(), "Type here…", var83, var101, null);
         if (var8) {
            this.hit(var67, var76, var47, var57, var2x -> {
               this.editing = var27;
               this.caretT = 0.0F;
            });
         }
      } else if (var3 instanceof ItemSetting var28) {
         float var48 = this.d(220.0F);
         float var58 = this.d(38.0F);
         float var68 = var17 - var48;
         float var77 = var18 - var58 / 2.0F;
         boolean var84 = var8 && this.hot(var68, var77, var48, var58);
         float var93 = this.an(var9 + ":i", var84 ? 1.0F : 0.0F, 15.0F);
         var1.round(var68, var77, var48, var58, this.d(12.0F), UiRenderer.white(0.05F + 0.06F * var93));
         var1.outline(var68, var77, var48, var58, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.08F * var93));
         Object var102 = this.host.itemOf(var28);
         float var110 = this.d(24.0F);
         var1.item(var102, var68 + this.d(9.0F), var18 - var110 / 2.0F, var110);
         var1.text(
            var1.ellipsize(this.host.itemName(var102), var48 - this.d(70.0F), this.d(12.5F), 0),
            var68 + this.d(42.0F),
            var18 - this.d(7.5F),
            this.d(12.5F),
            0,
            TEXT
         );
         float var116 = this.d(16.0F);
         var1.icon(
            UiIcon.CHEVRON_RIGHT, var68 + var48 - this.d(10.0F) - var116, var18 - var116 / 2.0F, var116, UiRenderer.white(0.4F + 0.4F * var93)
         );
         if (var8) {
            this.hit(var68, var77, var48, var58, var2x -> this.openPicker(var28));
         }
      } else if (var3 instanceof StorageBlocksSetting var29) {
         float var49 = this.d(170.0F);
         float var59 = this.d(34.0F);
         float var69 = var17 - var49;
         float var78 = var18 - var59 / 2.0F;
         boolean var85 = var8 && this.hot(var69, var78, var49, var59);
         float var94 = this.an(var9 + ":s", var85 ? 1.0F : 0.0F, 15.0F);
         var1.round(var69, var78, var49, var59, this.d(12.0F), UiRenderer.white(0.05F + 0.06F * var94));
         var1.outline(var69, var78, var49, var59, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.08F + 0.08F * var94));
         String var103 = var29.isColorOnly() ? "Edit color" : var29.selectedCount() + " selected";
         float var111 = this.d(16.0F);
         var1.icon(UiIcon.BOX, var69 + this.d(12.0F), var18 - var111 / 2.0F, var111, UiRenderer.white(0.6F + 0.3F * var94));
         var1.text(var103, var69 + this.d(36.0F), var18 - this.d(7.5F), this.d(12.5F), 1, TEXT);
         var1.icon(
            UiIcon.CHEVRON_RIGHT, var69 + var49 - this.d(10.0F) - var111, var18 - var111 / 2.0F, var111, UiRenderer.white(0.4F + 0.4F * var94)
         );
         if (var8) {
            this.hit(var69, var78, var49, var59, var2x -> this.host.openStorage(var29));
         }
      }
   }

   private void slider(UiRenderer var1, Setting var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      this.tracks.put(var2, new float[]{var3, var5});
      float var9 = this.d(6.0F);
      var1.round(var3, var4 - var9 / 2.0F, var5, var9, var9 / 2.0F, UiRenderer.white(0.12F));
      boolean var10 = var7 >= 0.0F;
      float var11 = var10 ? UiEasing.clamp(var6, 0.0F, 1.0F) : 0.0F;
      float var12 = var10 ? UiEasing.clamp(var7, 0.0F, 1.0F) : UiEasing.clamp(var6, 0.0F, 1.0F);
      if (var12 - var11 > 0.0F) {
         var1.round(var3 + var5 * var11, var4 - var9 / 2.0F, Math.max(var9, var5 * (var12 - var11)), var9, var9 / 2.0F, UiPalette.accent(0.92F));
      }

      float var13 = this.d(16.0F) + this.d(2.0F) * var8;
      if (var10) {
         this.knob(var1, var3 + var5 * var11, var4, var13, var8);
      }

      this.knob(var1, var3 + var5 * var12, var4, var13, var8);
   }

   private void knob(UiRenderer var1, float var2, float var3, float var4, float var5) {
      var1.glow(var2, var3, var4 * 1.4F, UiPalette.accent(0.14F * var5));
      var1.shadow(var2 - var4 / 2.0F, var3 - var4 / 2.0F, var4, var4, var4 / 2.0F, this.d(5.0F), UiRenderer.argb(0.45F, 0, 0, 0));
      var1.round(var2 - var4 / 2.0F, var3 - var4 / 2.0F, var4, var4, var4 / 2.0F, UiRenderer.white(0.97F));
      var1.round(
         var2 - var4 * 0.18F,
         var3 - var4 * 0.18F,
         var4 * 0.36F,
         var4 * 0.36F,
         var4 * 0.18F,
         UiEasing.mix(UiRenderer.argb(0.9F, 40, 41, 46), UiPalette.accent(0.95F), 0.55F)
      );
   }

   private void valuePill(UiRenderer var1, String var2, float var3, float var4, float var5) {
      float var6 = this.d(30.0F);
      var1.round(var3, var4 - var6 / 2.0F, var5, var6, this.d(10.0F), UiRenderer.white(0.06F));
      var1.textCentered(var1.ellipsize(var2, var5 - this.d(10.0F), this.d(12.0F), 1), var3 + var5 / 2.0F, var4 - this.d(7.0F), this.d(12.0F), 1, TEXT);
   }

   private void field(
      UiRenderer var1, float var2, float var3, float var4, float var5, String var6, String var7, boolean var8, float var9, UiIcon var10
   ) {
      var1.round(var2, var3, var4, var5, Math.min(var5 / 2.0F, this.d(12.0F)), UiRenderer.white(0.04F + 0.04F * var9));
      var1.outline(
         var2,
         var3,
         var4,
         var5,
         Math.min(var5 / 2.0F, this.d(12.0F)),
         Math.max(1.0F, this.u * 0.9F),
         UiEasing.mix(UiRenderer.white(0.08F + 0.16F * var9), UiPalette.accent(0.1F + 0.3F * var9), var9)
      );
      float var11 = var2 + this.d(12.0F);
      if (var10 != null) {
         float var12 = this.d(17.0F);
         var1.icon(var10, var11, var3 + (var5 - var12) / 2.0F, var12, UiRenderer.white(0.5F + 0.4F * var9));
         var11 += var12 + this.d(10.0F);
      }

      float var17 = var2 + var4 - var11 - this.d(12.0F);
      float var13 = var3 + (var5 - this.d(13.0F)) / 2.0F - this.d(1.0F);
      var1.pushClip(var11, var3, var17 + this.d(4.0F), var5);
      float var14 = 0.0F;
      if (var6.isEmpty()) {
         var1.text(var7, var11, var13, this.d(13.0F), 0, FAINT);
      } else {
         float var15 = var1.textWidth(var6, this.d(13.0F), 0);
         float var16 = Math.max(0.0F, var15 - var17);
         var14 = var1.text(var6, var11 - var16, var13, this.d(13.0F), 0, TEXT) - var16;
      }

      if (var8) {
         float var18 = 0.5F + 0.5F * (float)Math.cos((double)(this.caretT * 6.0F));
         var1.rect(var11 + var14 + this.d(1.0F), var3 + var5 * 0.26F, Math.max(1.0F, this.u * 1.4F), var5 * 0.48F, UiRenderer.white(0.9F * var18));
      }

      var1.popClip();
   }

   private void beginSlide(Setting var1, int var2) {
      this.sliding = var1;
      this.slideKnob = var2;
      this.applySlide();
   }

   private void applySlide() {
      if (this.sliding != null) {
         float[] var1 = this.tracks.get(this.sliding);
         if (var1 != null && var1[1] > 0.0F) {
            double var2 = (double)UiEasing.clamp((float)((this.mx - (double)var1[0]) / (double)var1[1]), 0.0F, 1.0F);
            if (this.sliding instanceof NumberSetting var4) {
               double var10 = snap(var4.getMin() + var2 * (var4.getMax() - var4.getMin()), var4.getFormat());
               double var8 = Math.max(var4.getMin(), Math.min(var4.getMax(), var10));
               if (var8 != var4.getValue()) {
                  var4.getValue(var8);
                  UiAudio.play(UiAudio.Cue.SLIDE);
               }
            } else if (this.sliding instanceof MinMaxSetting var5) {
               double var12 = snap(var5.getMinValue() + var2 * (var5.getMaxValue() - var5.getMinValue()), var5.getStep());
               var12 = Math.max(var5.getMinValue(), Math.min(var5.getMaxValue(), var12));
               if (this.slideKnob == 0) {
                  var5.setCurrentMin(Math.min(var12, var5.getCurrentMax()));
               } else {
                  var5.setCurrentMax(Math.max(var12, var5.getCurrentMin()));
               }
            }
         }
      }
   }

   private static double snap(double var0, double var2) {
      return var2 > 0.0 ? (double)Math.round(var0 / var2) * var2 : var0;
   }

   static String format(double var0, double var2) {
      if (!(var2 >= 1.0) && !(var2 <= 0.0)) {
         int var4 = Math.max(1, Math.min(4, (int)Math.ceil(-Math.log10(var2) - 1.0E-9)));
         return String.format(Locale.ROOT, "%." + var4 + "f", var0);
      } else {
         return String.valueOf(Math.round(var0));
      }
   }

   private static String prettyEnum(String var0) {
      if (var0.isEmpty()) {
         return var0;
      } else {
         String var1 = var0.replace('_', ' ').toLowerCase(Locale.ROOT);
         StringBuilder var2 = new StringBuilder();
         boolean var3 = true;

         for (char var7 : var1.toCharArray()) {
            var2.append(var3 ? Character.toUpperCase(var7) : var7);
            var3 = var7 == ' ' || Character.isDigit(var7);
         }

         return var2.toString();
      }
   }

   private String keyLabel(int var1) {
      if (var1 < 0) {
         return "None";
      } else {
         String var2 = this.host.keyName(var1);
         return var2 != null && !var2.isBlank() ? var2 : "Key " + var1;
      }
   }

   private void assignBind(BindSetting var1, Module var2, int var3) {
      var1.setValue(var3);
      if (var1.isModuleKey() && var2 != null) {
         var2.setKeybind(var3);
      }

      var1.setListening(false);
      this.listening = null;
      UiAudio.play(UiAudio.Cue.CONFIRM);
   }

   private void drawSearchBar(UiRenderer var1) {
      float var2 = this.mainX();
      float var3 = this.wy + this.d(568.0F);
      float var4 = this.d(56.0F);
      float var6 = this.d(10.0F);
      float var7 = this.mainW() - (var4 + var6) * 3.0F;
      boolean var8 = this.hot(var2, var3, var7, var4);
      float var9 = this.an("search:f", this.searchFocus ? 1.0F : (var8 ? 0.45F : 0.0F), 13.0F);
      this.glass(var1, var2, var3, var7, var4, var4 / 2.0F, 6.3F);
      var1.round(var2, var3, var7, var4, var4 / 2.0F, UiRenderer.white(0.035F * var9));
      var1.outline(
         var2,
         var3,
         var7,
         var4,
         var4 / 2.0F,
         Math.max(1.0F, this.u * 0.9F),
         UiEasing.mix(UiRenderer.white(0.14F * var9), UiPalette.accent(0.32F * var9), var9)
      );
      float var10 = this.d(19.0F);
      var1.icon(UiIcon.SEARCH, var2 + this.d(22.0F), var3 + (var4 - var10) / 2.0F, var10, UiRenderer.white(0.55F + 0.4F * var9));
      float var11 = var2 + this.d(54.0F);
      float var12 = var3 + (var4 - this.d(14.5F)) / 2.0F - this.d(1.0F);
      float var13 = var7 - this.d(54.0F) - this.d(80.0F);
      var1.pushClip(var11, var3, var13, var4);
      float var14 = 0.0F;
      if (this.query.isEmpty()) {
         var1.text("Search modules…", var11, var12, this.d(14.5F), 0, FAINT);
      } else {
         float var15 = var1.textWidth(this.query, this.d(14.5F), 0);
         float var16 = Math.max(0.0F, var15 - var13 + this.d(6.0F));
         var14 = var1.text(this.query, var11 - var16, var12, this.d(14.5F), 0, TEXT) - var16;
      }

      if (this.searchFocus) {
         float var21 = 0.5F + 0.5F * (float)Math.cos((double)(this.caretT * 6.0F));
         var1.rect(var11 + var14 + this.d(1.5F), var3 + var4 * 0.3F, Math.max(1.0F, this.u * 1.4F), var4 * 0.4F, UiRenderer.white(0.9F * var21));
      }

      var1.popClip();
      if (!this.query.isEmpty()) {
         float var22 = this.d(28.0F);
         float var27 = var2 + var7 - this.d(16.0F) - var22;
         float var17 = var3 + (var4 - var22) / 2.0F;
         boolean var18 = this.hot(var27, var17, var22, var22);
         float var19 = this.an("search:clear", var18 ? 1.0F : 0.0F, 15.0F);
         var1.round(var27, var17, var22, var22, var22 / 2.0F, UiRenderer.white(0.06F + 0.08F * var19));
         float var20 = this.d(14.0F);
         var1.icon(UiIcon.CLOSE, var27 + (var22 - var20) / 2.0F, var17 + (var22 - var20) / 2.0F, var20, UiRenderer.white(0.6F + 0.4F * var19));
         this.hit(var2, var3, var7, var4, var1x -> {
            this.searchFocus = true;
            this.caretT = 0.0F;
         });
         this.hit(var27, var17, var22, var22, var1x -> {
            this.query = "";
            this.tabT = 0.0F;
         });
      } else {
         String var23 = "CTRL F";
         float var28 = var1.textWidth(var23, this.d(10.0F), 1) + this.d(16.0F);
         float var30 = var2 + var7 - this.d(18.0F) - var28;
         var1.round(var30, var3 + (var4 - this.d(24.0F)) / 2.0F, var28, this.d(24.0F), this.d(8.0F), UiRenderer.white(0.05F * (1.0F - var9)));
         var1.textCentered(
            var23, var30 + var28 / 2.0F, var3 + (var4 - this.d(10.0F)) / 2.0F - this.d(0.5F), this.d(10.0F), 1, UiRenderer.white(0.3F * (1.0F - var9))
         );
         this.hit(var2, var3, var7, var4, var1x -> {
            this.searchFocus = true;
            this.caretT = 0.0F;
         });
      }

      float var24 = var2 + var7 + var6;
      this.utilityButton(var1, "profiles", var24, var3, var4, UiIcon.FOLDER, "Configs", true, var1x -> {
         this.searchFocus = false;
         this.editing = null;
         this.listening = null;
         this.sliding = null;
         this.configs.open();
      });
      var24 += var4 + var6;
      boolean var29 = this.host.inWorld();
      this.utilityButton(
         var1, "hud", var24, var3, var4, UiIcon.LAYOUT, var29 ? "Edit HUD" : "Edit HUD (join a world)", var29, var1x -> this.host.openHudEditor()
      );
      var24 += var4 + var6;
      this.utilityButton(var1, "cfg", var24, var3, var4, UiIcon.GEAR, "Client settings", true, var1x -> {
         Module var2x = this.clientModule();
         if (var2x != null) {
            this.query = "";
            this.searchFocus = false;
            this.openPage(var2x);
         }
      });
   }

   private void utilityButton(
      UiRenderer var1, String var2, float var3, float var4, float var5, UiIcon var6, String var7, boolean var8, HookUiController.ClickAction var9
   ) {
      boolean var10 = this.hot(var3, var4, var5, var5);
      float var11 = this.an("btn:" + var2, var10 ? 1.0F : 0.0F, 14.0F);
      this.glass(var1, var3, var4, var5, var5, this.d(18.0F), var3 * 0.01F);
      var1.round(var3, var4, var5, var5, this.d(18.0F), UiRenderer.white(0.05F * var11));
      var1.outline(var3, var4, var5, var5, this.d(18.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.12F * var11));
      if (var11 > 0.01F) {
         var1.glow(var3 + var5 / 2.0F, var4 + var5 / 2.0F, var5 * 0.8F, UiRenderer.white(0.05F * var11));
      }

      float var12 = this.d(20.0F);
      var1.icon(
         var6,
         var3 + (var5 - var12) / 2.0F,
         var4 + (var5 - var12) / 2.0F - this.d(1.0F) * var11,
         var12,
         UiRenderer.white(var8 ? 0.7F + 0.3F * var11 : 0.28F)
      );
      if (var10) {
         this.tip = var7;
         this.tipX = var3 + var5 / 2.0F;
         this.tipY = var4 - this.d(10.0F);
      }

      if (var8) {
         this.hit(var3, var4, var5, var5, var9);
      } else {
         this.hit(var3, var4, var5, var5, var0 -> {
         });
      }
   }

   private void drawTip(UiRenderer var1) {
      float var2 = this.an("tip", 1.0F, 12.0F);
      float var3 = var1.textWidth(this.tip, this.d(11.5F), 0) + this.d(22.0F);
      float var4 = this.d(28.0F);
      float var5 = Math.min(this.tipX - var3 / 2.0F, this.wx + this.d(1000.0F) - var3);
      float var6 = this.tipY - var4;
      var1.pushAlpha(var2);
      var1.shadow(var5, var6, var3, var4, this.d(10.0F), this.d(12.0F), UiRenderer.argb(0.4F, 0, 0, 0));
      var1.round(var5, var6, var3, var4, this.d(10.0F), UiRenderer.argb(0.92F, 28, 29, 33));
      var1.outline(var5, var6, var3, var4, this.d(10.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.1F));
      var1.textCentered(this.tip, var5 + var3 / 2.0F, var6 + (var4 - this.d(11.5F)) / 2.0F - this.d(1.0F), this.d(11.5F), 0, TEXT);
      var1.popAlpha();
   }

   private void openColor(RgbSetting var1) {
      this.coloring = var1;
      this.colorDrag = 0;
      int var2 = var1.getArgb();
      Color.RGBtoHSB(var2 >> 16 & 0xFF, var2 >> 8 & 0xFF, var2 & 0xFF, this.hsv);
      this.alphaPick = (float)(var2 >>> 24) / 255.0F;
      UiAudio.play(UiAudio.Cue.OPEN);
   }

   private void closeColor() {
      this.coloring = null;
      this.colorDrag = 0;
      UiAudio.play(UiAudio.Cue.BACK);
   }

   private void writeColor() {
      if (this.coloring != null) {
         int var1 = Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 16777215;
         this.coloring.setArgb(Math.round(UiEasing.clamp(this.alphaPick, 0.0F, 1.0F) * 255.0F) << 24 | var1);
      }
   }

   private void applyColorDrag() {
      if (this.coloring != null && this.colorDrag != 0) {
         if (this.colorDrag == 1) {
            this.hsv[1] = UiEasing.clamp((float)((this.mx - (double)this.svRect[0]) / (double)this.svRect[2]), 0.0F, 1.0F);
            this.hsv[2] = 1.0F - UiEasing.clamp((float)((this.my - (double)this.svRect[1]) / (double)this.svRect[3]), 0.0F, 1.0F);
         } else if (this.colorDrag == 2) {
            this.hsv[0] = UiEasing.clamp((float)((this.my - (double)this.hueRect[1]) / (double)this.hueRect[3]), 0.0F, 0.999F);
         } else if (this.colorDrag == 3) {
            this.alphaPick = 1.0F - UiEasing.clamp((float)((this.my - (double)this.alphaRect[1]) / (double)this.alphaRect[3]), 0.0F, 1.0F);
         }

         this.writeColor();
      }
   }

   private static String hex(int var0) {
      return var0 >>> 24 >= 255 ? String.format("#%06X", var0 & 16777215) : String.format("#%08X", var0);
   }

   private void checker(UiRenderer var1, float var2, float var3, float var4, float var5, float var6) {
      var1.round(var2, var3, var4, var5, var6, UiRenderer.argb(1.0F, 205, 205, 210));
      float var7 = Math.max(2.0F, this.d(5.0F));
      var1.pushClip(var2 + var6 * 0.3F, var3 + var6 * 0.3F, var4 - var6 * 0.6F, var5 - var6 * 0.6F);

      for (float var8 = var3; var8 < var3 + var5; var8 += var7) {
         for (float var9 = var2; var9 < var2 + var4; var9 += var7) {
            if (((int)((var9 - var2) / var7) + (int)((var8 - var3) / var7)) % 2 == 0) {
               var1.rect(var9, var8, var7, var7, UiRenderer.argb(1.0F, 150, 150, 158));
            }
         }
      }

      var1.popClip();
   }

   private void drawColorPicker(UiRenderer var1) {
      float var2 = this.an("colorpicker", this.coloring != null ? 1.0F : 0.0F, 13.0F);
      if (!(var2 < 0.005F) && (this.coloring != null || !(var2 < 0.02F))) {
         RgbSetting var3 = this.coloring;
         var1.pushAlpha(var2);
         float var4 = this.mainX();
         var1.round(var4, this.wy, this.mainW(), this.mainH(), this.d(22.0F), UiRenderer.argb(0.45F, 4, 4, 6));
         float var5 = this.d(470.0F);
         float var6 = this.d(284.0F);
         float var7 = var4 + (this.mainW() - var5) / 2.0F;
         float var8 = this.wy + (this.mainH() - var6) / 2.0F;
         float var9 = 0.94F + 0.06F * UiEasing.out(var2);
         var1.pushTransform((var7 + var5 / 2.0F) * (1.0F - var9), (var8 + var6 / 2.0F) * (1.0F - var9), var9);
         var1.shadow(var7, var8, var5, var6, this.d(20.0F), this.d(34.0F), UiRenderer.argb(0.55F, 0, 0, 0));
         var1.round(var7, var8, var5, var6, this.d(20.0F), UiRenderer.argb(0.94F, 24, 25, 29));
         var1.outline(var7, var8, var5, var6, this.d(20.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.1F));
         String var10 = var3 == null ? "" : var3.getName().toString();
         var1.text(var1.ellipsize(var10, var5 - this.d(90.0F), this.d(17.0F), 1), var7 + this.d(22.0F), var8 + this.d(20.0F), this.d(17.0F), 1, TEXT);
         float var11 = this.d(30.0F);
         float var12 = var7 + var5 - this.d(18.0F) - var11;
         float var13 = var8 + this.d(16.0F);
         boolean var14 = var3 != null && this.hot(var12, var13, var11, var11);
         float var15 = this.an("colorpicker:x", var14 ? 1.0F : 0.0F, 15.0F);
         var1.round(var12, var13, var11, var11, var11 / 2.0F, UiRenderer.white(0.05F + 0.08F * var15));
         float var16 = this.d(14.0F);
         var1.icon(UiIcon.CLOSE, var12 + (var11 - var16) / 2.0F, var13 + (var11 - var16) / 2.0F, var16, UiRenderer.white(0.6F + 0.4F * var15));
         if (var3 != null) {
            this.hit(var7, var8, var5, var6, var0 -> {
            });
            this.hit(var12, var13, var11, var11, var1x -> this.closeColor());
         }

         float var17 = var7 + this.d(22.0F);
         float var18 = var8 + this.d(62.0F);
         float var19 = this.d(240.0F);
         float var20 = this.d(200.0F);
         this.svRect[0] = var17;
         this.svRect[1] = var18;
         this.svRect[2] = var19;
         this.svRect[3] = var20;
         int var21 = Math.max(24, Math.round(var19 / Math.max(1.0F, this.u * 2.0F)));
         float var22 = var19 / (float)var21;

         for (int var23 = 0; var23 < var21; var23++) {
            float var24 = ((float)var23 + 0.5F) / (float)var21;
            int var25 = 0xFF000000 | Color.HSBtoRGB(this.hsv[0], var24, 1.0F) & 16777215;
            var1.gradient(var17 + (float)var23 * var22, var18, var22 + 1.0F, var20, var25, -16777216);
         }

         var1.outline(var17, var18, var19, var20, this.d(4.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.14F));
         float var42 = var17 + this.hsv[1] * var19;
         float var43 = var18 + (1.0F - this.hsv[2]) * var20;
         var1.circle(var42, var43, this.d(8.0F), UiRenderer.argb(0.6F, 0, 0, 0));
         var1.circle(var42, var43, this.d(7.0F), UiRenderer.white(1.0F));
         var1.circle(var42, var43, this.d(5.0F), 0xFF000000 | Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 16777215);
         if (var3 != null) {
            this.hit(var17, var18, var19, var20, var1x -> {
               this.colorDrag = 1;
               this.applyColorDrag();
            });
         }

         float var44 = var17 + var19 + this.d(16.0F);
         float var26 = this.d(18.0F);
         this.hueRect[0] = var44;
         this.hueRect[1] = var18;
         this.hueRect[2] = var26;
         this.hueRect[3] = var20;

         for (int var27 = 0; var27 < 6; var27++) {
            int var28 = 0xFF000000 | Color.HSBtoRGB((float)var27 / 6.0F, 1.0F, 1.0F) & 16777215;
            int var29 = 0xFF000000 | Color.HSBtoRGB((float)(var27 + 1) / 6.0F, 1.0F, 1.0F) & 16777215;
            var1.gradient(var44, var18 + var20 * (float)var27 / 6.0F, var26, var20 / 6.0F + 1.0F, var28, var29);
         }

         var1.outline(var44, var18, var26, var20, this.d(4.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.14F));
         float var45 = var18 + this.hsv[0] * var20;
         var1.round(var44 - this.d(3.0F), var45 - this.d(3.0F), var26 + this.d(6.0F), this.d(6.0F), this.d(3.0F), UiRenderer.white(1.0F));
         if (var3 != null) {
            this.hit(var44 - this.d(4.0F), var18, var26 + this.d(8.0F), var20, var1x -> {
               this.colorDrag = 2;
               this.applyColorDrag();
            });
         }

         float var46 = var44 + var26 + this.d(14.0F);
         this.alphaRect[0] = var46;
         this.alphaRect[1] = var18;
         this.alphaRect[2] = var26;
         this.alphaRect[3] = var20;
         this.checker(var1, var46, var18, var26, var20, this.d(4.0F));
         int var47 = 0xFF000000 | Color.HSBtoRGB(this.hsv[0], this.hsv[1], this.hsv[2]) & 16777215;
         var1.gradient(var46, var18, var26, var20, var47, var47 & 16777215);
         var1.outline(var46, var18, var26, var20, this.d(4.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.14F));
         float var30 = var18 + (1.0F - this.alphaPick) * var20;
         var1.round(var46 - this.d(3.0F), var30 - this.d(3.0F), var26 + this.d(6.0F), this.d(6.0F), this.d(3.0F), UiRenderer.white(1.0F));
         if (var3 != null) {
            this.hit(var46 - this.d(4.0F), var18, var26 + this.d(8.0F), var20, var1x -> {
               this.colorDrag = 3;
               this.applyColorDrag();
            });
         }

         float var31 = var46 + var26 + this.d(20.0F);
         float var32 = var7 + var5 - this.d(22.0F) - var31;
         int var33 = var3 != null ? var3.getArgb() : var47;
         this.checker(var1, var31, var18, var32, this.d(54.0F), this.d(12.0F));
         var1.round(var31, var18, var32, this.d(54.0F), this.d(12.0F), var33);
         var1.outline(var31, var18, var32, this.d(54.0F), this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.16F));
         var1.textCentered(hex(var33), var31 + var32 / 2.0F, var18 + this.d(66.0F), this.d(12.5F), 1, TEXT);
         var1.textCentered(Math.round(this.alphaPick * 100.0F) + "% opacity", var31 + var32 / 2.0F, var18 + this.d(86.0F), this.d(11.0F), 0, SUB);
         int[] var34 = new int[]{0xFF000000 | UiPalette.accent(1.0F) & 16777215, -1, -42406, -20898, -8090, -9508952, -10636545, -4809473};
         float var35 = (var32 - this.d(12.0F)) / 4.0F;
         float var36 = this.d(4.0F);

         for (int var37 = 0; var37 < var34.length; var37++) {
            float var38 = var31 + (float)(var37 % 4) * (var35 + var36);
            float var39 = var18 + this.d(112.0F) + (float)(var37 / 4) * (var35 + var36);
            boolean var40 = var3 != null && this.hot(var38, var39, var35, var35);
            var1.round(var38, var39, var35, var35, this.d(8.0F), var34[var37]);
            var1.outline(var38, var39, var35, var35, this.d(8.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(var40 ? 0.6F : 0.15F));
            if (var3 != null) {
               int var41 = var34[var37];
               this.hit(var38, var39, var35, var35, var2x -> {
                  Color.RGBtoHSB(var41 >> 16 & 0xFF, var41 >> 8 & 0xFF, var41 & 0xFF, this.hsv);
                  this.writeColor();
                  UiAudio.play(UiAudio.Cue.TICK);
               });
            }
         }

         var1.popTransform();
         var1.popAlpha();
      }
   }

   private void openPicker(ItemSetting var1) {
      this.picking = var1;
      this.pickQuery = "";
      this.pickItems = this.host.items();
      this.pickScroll[0] = 0.0F;
      this.pickScroll[1] = 0.0F;
      UiAudio.play(UiAudio.Cue.OPEN);
   }

   private void closePicker() {
      this.picking = null;
      UiAudio.play(UiAudio.Cue.BACK);
   }

   private void drawPicker(UiRenderer var1) {
      float var2 = this.an("picker", this.picking != null ? 1.0F : 0.0F, 13.0F);
      if (!(var2 < 0.005F)) {
         var1.pushAlpha(var2);
         float var3 = this.mainX();
         var1.round(var3, this.wy, this.mainW(), this.mainH(), this.d(22.0F), UiRenderer.argb(0.45F, 4, 4, 6));
         float var4 = this.d(560.0F);
         float var5 = this.d(440.0F);
         float var6 = var3 + (this.mainW() - var4) / 2.0F;
         float var7 = this.wy + (this.mainH() - var5) / 2.0F;
         float var8 = 0.94F + 0.06F * UiEasing.out(var2);
         var1.pushTransform((var6 + var4 / 2.0F) * (1.0F - var8), (var7 + var5 / 2.0F) * (1.0F - var8), var8);
         var1.shadow(var6, var7, var4, var5, this.d(20.0F), this.d(34.0F), UiRenderer.argb(0.55F, 0, 0, 0));
         var1.round(var6, var7, var4, var5, this.d(20.0F), UiRenderer.argb(0.94F, 24, 25, 29));
         var1.outline(var6, var7, var4, var5, this.d(20.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.1F));
         var1.text("Select item", var6 + this.d(22.0F), var7 + this.d(20.0F), this.d(17.0F), 1, TEXT);
         float var9 = this.d(30.0F);
         float var10 = var6 + var4 - this.d(18.0F) - var9;
         float var11 = var7 + this.d(16.0F);
         boolean var12 = this.picking != null && this.hot(var10, var11, var9, var9);
         float var13 = this.an("picker:x", var12 ? 1.0F : 0.0F, 15.0F);
         var1.round(var10, var11, var9, var9, var9 / 2.0F, UiRenderer.white(0.05F + 0.08F * var13));
         float var14 = this.d(14.0F);
         var1.icon(UiIcon.CLOSE, var10 + (var9 - var14) / 2.0F, var11 + (var9 - var14) / 2.0F, var14, UiRenderer.white(0.6F + 0.4F * var13));
         if (this.picking != null) {
            this.hit(var6, var7, var4, var5, var0 -> {
            });
            this.hit(var10, var11, var9, var9, var1x -> this.closePicker());
         }

         float var15 = var7 + this.d(60.0F);
         this.field(var1, var6 + this.d(20.0F), var15, var4 - this.d(40.0F), this.d(38.0F), this.pickQuery, "Search items…", true, 1.0F, UiIcon.SEARCH);
         float var16 = var6 + this.d(20.0F);
         float var17 = var15 + this.d(52.0F);
         float var18 = var4 - this.d(40.0F);
         float var19 = var7 + var5 - this.d(18.0F) - var17;
         this.pickRect[0] = var16;
         this.pickRect[1] = var17;
         this.pickRect[2] = var18;
         this.pickRect[3] = var19;
         ArrayList var20 = new ArrayList();
         String var21 = this.pickQuery.toLowerCase(Locale.ROOT);
         if (this.pickItems != null) {
            for (Object var23 : this.pickItems) {
               if (var21.isEmpty() || this.host.itemName(var23).toLowerCase(Locale.ROOT).contains(var21)) {
                  var20.add(var23);
               }
            }
         }

         float var40 = this.d(48.0F);
         float var41 = this.d(8.0F);
         int var24 = Math.max(1, (int)((var18 + var41) / (var40 + var41)));
         float var25 = (float)var24 * var40 + (float)(var24 - 1) * var41;
         float var26 = var16 + (var18 - var25) / 2.0F;
         int var27 = (var20.size() + var24 - 1) / var24;
         float var28 = (float)var27 * (var40 + var41) - var41;
         this.pickMax = Math.max(0.0F, var28 - var19);
         float var29 = this.scroll(this.pickScroll, this.pickMax);
         Object var30 = this.picking != null ? this.host.itemOf(this.picking) : null;
         var1.pushClip(var16, var17, var18, var19);
         this.hitClip = new float[]{var16, var17, var18, var19};
         String var31 = null;

         for (int var32 = 0; var32 < var20.size(); var32++) {
            float var33 = var26 + (float)(var32 % var24) * (var40 + var41);
            float var34 = var17 + (float)(var32 / var24) * (var40 + var41) - var29;
            if (!(var34 + var40 < var17) && !(var34 > var17 + var19)) {
               Object var35 = var20.get(var32);
               boolean var36 = this.picking != null && this.hot(var33, var34, var40, var40);
               boolean var37 = var35 == var30;
               var1.round(var33, var34, var40, var40, this.d(12.0F), UiRenderer.white(0.04F + (var36 ? 0.08F : 0.0F) + (var37 ? 0.1F : 0.0F)));
               if (var37) {
                  var1.outline(var33, var34, var40, var40, this.d(12.0F), Math.max(1.0F, this.u * 0.9F), UiRenderer.white(0.5F));
               }

               float var38 = this.d(30.0F);
               var1.item(var35, var33 + (var40 - var38) / 2.0F, var34 + (var40 - var38) / 2.0F, var38);
               if (var36) {
                  var31 = this.host.itemName(var35);
               }

               if (this.picking != null) {
                  ItemSetting var39 = this.picking;
                  this.hit(var33, var34, var40, var40, var3x -> {
                     this.host.setItem(var39, var35);
                     this.picking = null;
                     UiAudio.play(UiAudio.Cue.CONFIRM);
                  });
               }
            }
         }

         this.hitClip = null;
         var1.popClip();
         if (var31 != null) {
            var1.textRight(var31, var6 + var4 - this.d(22.0F), var7 + this.d(24.0F), this.d(12.0F), 0, SUB);
         }

         var1.popTransform();
         var1.popAlpha();
      }
   }

   private void scrollbar(UiRenderer var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      if (var6 > 0.5F) {
         float var8 = var4 / var7;
         float var9 = Math.max(this.d(30.0F), var4 * var8);
         float var10 = var3 + (var4 - var9) * (var5 / var6);
         var1.round(var2, var10, this.d(4.0F), var9, this.d(2.0F), UiRenderer.white(0.18F));
      }
   }

   private float scroll(float[] var1, float var2) {
      var1[1] = UiEasing.clamp(var1[1], 0.0F, var2);
      var1[0] += (var1[1] - var1[0]) * (1.0F - (float)Math.exp((double)(-16.0F * this.dt)));
      if (Math.abs(var1[1] - var1[0]) < 0.2F) {
         var1[0] = var1[1];
      }

      return var1[0];
   }

   private List<String> wrap(UiRenderer var1, String var2, float var3, float var4, int var5) {
      ArrayList var6 = new ArrayList();
      if (var2 != null && !var2.isBlank()) {
         String[] var7 = var2.trim().split("\\s+");
         StringBuilder var8 = new StringBuilder();
         int var9 = 0;

         while (var9 < var7.length) {
            String var10 = var8.length() == 0 ? var7[var9] : var8 + " " + var7[var9];
            if (!(var1.textWidth(var10, var4, 0) <= var3) && var8.length() != 0) {
               var6.add(var8.toString());
               var8.setLength(0);
               if (var6.size() == var5 - 1) {
                  StringBuilder var11 = new StringBuilder();

                  for (int var12 = var9; var12 < var7.length; var12++) {
                     var11.append(var12 == var9 ? "" : " ").append(var7[var12]);
                  }

                  var6.add(var1.ellipsize(var11.toString(), var3, var4, 0));
                  return var6;
               }
            } else {
               var8.setLength(0);
               var8.append(var10);
               var9++;
            }
         }

         if (var8.length() > 0) {
            var6.add(var1.ellipsize(var8.toString(), var3, var4, 0));
         }

         return var6;
      } else {
         return var6;
      }
   }

   private List<Module> modules(Category var1) {
      return ModuleCatalog.category(this, var1);
   }

   private List<Module> allModules() {
      try {
         return hook.Hook.INSTANCE.getModuleManager().c();
      } catch (Throwable var2) {
         return List.of();
      }
   }

   private List<Module> searchResults() {
      return ModuleCatalog.search(this, this.query);
   }

   private Module clientModule() {
      for (Module var2 : this.allModules()) {
         if (var2 instanceof Hook) {
            return var2;
         }
      }

      return null;
   }

   private void hit(float var1, float var2, float var3, float var4, HookUiController.ClickAction var5) {
      if (this.hitClip != null) {
         float var6 = Math.min(var1 + var3, this.hitClip[0] + this.hitClip[2]);
         float var7 = Math.min(var2 + var4, this.hitClip[1] + this.hitClip[3]);
         var1 = Math.max(var1, this.hitClip[0]);
         var2 = Math.max(var2, this.hitClip[1]);
         var3 = var6 - var1;
         var4 = var7 - var2;
         if (var3 <= 0.0F || var4 <= 0.0F) {
            return;
         }
      }

      this.hits.add(new HookUiController.ClickRegion(var1, var2, var3, var4, this.layerNow, var5));
   }

   private int activeLayer() {
      return this.configs.active() ? 2 : (this.picking == null && this.coloring == null ? 0 : 1);
   }

   private boolean hot(float var1, float var2, float var3, float var4) {
      if (this.layerNow >= this.activeLayer() && !this.dragging && !this.closing && !(this.vis < 0.6F)) {
         return this.hitClip == null
               || !(this.mx < (double)this.hitClip[0])
                  && !(this.my < (double)this.hitClip[1])
                  && !(this.mx >= (double)(this.hitClip[0] + this.hitClip[2]))
                  && !(this.my >= (double)(this.hitClip[1] + this.hitClip[3]))
            ? this.mx >= (double)var1 && this.mx < (double)(var1 + var3) && this.my >= (double)var2 && this.my < (double)(var2 + var4)
            : false;
      } else {
         return false;
      }
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      if (this.configs.active()) {
         return this.configs.mouseClicked(var1, var3, var5);
      } else {
         this.mx = var1;
         this.my = var3;
         if (!this.closing && !(this.vis < 0.4F)) {
            if (this.listening != null) {
               if (var5 >= 2) {
                  this.assignBind(this.listening, this.listeningModule, var5);
               } else {
                  this.listening = null;
               }

               return true;
            } else {
               this.searchFocus = false;
               this.editing = null;
               int var6 = this.activeLayer();

               for (int var7 = this.hits.size() - 1; var7 >= 0; var7--) {
                  HookUiController.ClickRegion var8 = this.hits.get(var7);
                  if (var8.layer == var6
                     && var1 >= (double)var8.x
                     && var1 < (double)(var8.x + var8.w)
                     && var3 >= (double)var8.y
                     && var3 < (double)(var8.y + var8.h)) {
                     var8.act.on(var5);
                     return true;
                  }
               }

               if (var6 == 1) {
                  if (this.coloring != null) {
                     this.closeColor();
                  } else {
                     this.closePicker();
                  }
               } else if (var5 == 3 && this.page != null) {
                  this.closePage();
               }

               return true;
            }
         } else {
            return true;
         }
      }
   }

   public void mouseReleased(double var1, double var3, int var5) {
      this.mx = var1;
      this.my = var3;
      if (this.dragging) {
         this.dragging = false;
         this.savePosition();
      }

      if (this.sliding != null) {
         this.applySlide();
         this.sliding = null;
      }

      this.colorDrag = 0;
   }

   public void mouseDragged(double var1, double var3) {
      this.mx = var1;
      this.my = var3;
      this.applySlide();
      this.applyColorDrag();
   }

   public void mouseScrolled(double var1, double var3, double var5) {
      if (!this.configs.active()) {
         float var7 = this.d(70.0F) * (float)var5;
         if (this.picking != null) {
            if (inside(var1, var3, this.pickRect)) {
               this.pickScroll[1] = UiEasing.clamp(this.pickScroll[1] - var7, 0.0F, this.pickMax);
            }
         } else if (this.page != null) {
            if (inside(var1, var3, this.pageRect)) {
               this.pageScroll[1] = UiEasing.clamp(this.pageScroll[1] - var7, 0.0F, this.pageMax);
            }
         } else if (inside(var1, var3, this.gridRect)) {
            this.gridScroll[1] = UiEasing.clamp(this.gridScroll[1] - var7, 0.0F, this.gridMax);
         }
      }
   }

   private static boolean inside(double var0, double var2, float[] var4) {
      return var0 >= (double)var4[0] && var2 >= (double)var4[1] && var0 < (double)(var4[0] + var4[2]) && var2 < (double)(var4[1] + var4[3]);
   }

   public boolean keyPressed(int var1, int var2) {
      if (this.closing) {
         return true;
      } else if (this.configs.active()) {
         return this.configs.keyPressed(var1, var2);
      } else {
         boolean var3 = (var2 & 2) != 0;
         if (this.coloring != null) {
            if (var1 == 256 || var1 == 257 || var1 == 335) {
               this.closeColor();
            }

            return true;
         } else if (this.listening != null) {
            if (var1 == 256) {
               this.listening = null;
            } else if (var1 != 259 && var1 != 261) {
               this.assignBind(this.listening, this.listeningModule, var1);
            } else {
               this.assignBind(this.listening, this.listeningModule, -1);
            }

            return true;
         } else if (this.picking != null) {
            if (var1 == 256) {
               this.closePicker();
            } else if (var1 == 259 && !this.pickQuery.isEmpty()) {
               this.pickQuery = var3 ? "" : this.pickQuery.substring(0, this.pickQuery.length() - 1);
               this.pickScroll[1] = 0.0F;
            }

            return true;
         } else if (this.editing != null) {
            String var4 = this.editing.getValue() == null ? "" : this.editing.getValue();
            if (var1 == 256 || var1 == 257 || var1 == 335) {
               this.editing = null;
            } else if (var1 == 259 && !var4.isEmpty()) {
               this.editing.setValue(var3 ? "" : var4.substring(0, var4.length() - 1));
               this.caretT = 0.0F;
            }

            return true;
         } else if (this.searchFocus) {
            if (var1 == 256) {
               if (this.query.isEmpty()) {
                  this.searchFocus = false;
               } else {
                  this.query = "";
                  this.tabT = 0.0F;
               }
            } else if (var1 == 257 || var1 == 335) {
               this.searchFocus = false;
            } else if (var1 == 259 && !this.query.isEmpty()) {
               this.query = var3 ? "" : this.query.substring(0, this.query.length() - 1);
               this.gridScroll[1] = 0.0F;
               if (this.query.isEmpty()) {
                  this.tabT = 0.0F;
               }
            }

            return true;
         } else if ((!var3 || var1 != 70) && var1 != 47) {
            if (var1 == 256) {
               if (this.page != null) {
                  this.closePage();
               } else if (!this.query.isEmpty()) {
                  this.query = "";
                  this.tabT = 0.0F;
               } else {
                  this.requestClose();
               }

               return true;
            } else {
               return false;
            }
         } else {
            this.searchFocus = true;
            this.page = null;
            this.caretT = 0.0F;
            return true;
         }
      }
   }

   public boolean charTyped(char var1) {
      if (this.configs.active()) {
         return this.configs.charTyped(var1);
      } else if (Character.isISOControl(var1) || this.closing) {
         return false;
      } else if (this.picking != null) {
         if (this.pickQuery.length() < 32) {
            this.pickQuery = this.pickQuery + var1;
            this.pickScroll[1] = 0.0F;
         }

         return true;
      } else if (this.editing != null) {
         String var3 = this.editing.getValue() == null ? "" : this.editing.getValue();
         if (var3.length() < 256) {
            this.editing.setValue(var3 + var1);
            this.caretT = 0.0F;
         }

         return true;
      } else if (this.searchFocus) {
         if (this.query.length() < 40) {
            boolean var2 = this.query.isEmpty();
            this.query = this.query + var1;
            this.page = null;
            this.gridScroll[1] = 0.0F;
            this.caretT = 0.0F;
            if (var2) {
               this.tabT = 0.0F;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private void startDrag() {
      this.dragging = true;
      this.grabX = this.mx - (double)(this.offX * this.u);
      this.grabY = this.my - (double)(this.offY * this.u);
   }

   private void clampPosition() {
      float var1 = Math.max(0.0F, ((float)this.sw / this.u - 1000.0F) / 2.0F - 8.0F);
      float var2 = Math.max(0.0F, ((float)this.sh / this.u - 624.0F) / 2.0F - 8.0F);
      this.offX = UiEasing.clamp(this.offX, -var1, var1);
      this.offY = UiEasing.clamp(this.offY, -var2, var2);
   }

   private void loadPosition() {
      if (!this.posLoaded) {
         this.posLoaded = true;

         try {
            Path var1 = this.host.stateFile();
            if (var1 != null && Files.isRegularFile(var1)) {
               String[] var2 = Files.readString(var1, StandardCharsets.UTF_8).trim().split(",");
               this.offX = Float.parseFloat(var2[0]);
               this.offY = Float.parseFloat(var2[1]);
            }
         } catch (Throwable var3) {
         }
      }
   }

   private void savePosition() {
      try {
         Path var1 = this.host.stateFile();
         if (var1 != null) {
            Files.createDirectories(var1.getParent());
            Files.writeString(var1, String.format(Locale.ROOT, "%.2f,%.2f", this.offX, this.offY), StandardCharsets.UTF_8);
         }
      } catch (Throwable var2) {
      }
   }

   @FunctionalInterface
   private interface ClickAction {
      void on(int var1);
   }

   private static record ClickRegion(float x, float y, float w, float h, int layer, HookUiController.ClickAction act) {
   }

   public interface UiDataSource {
      String playerName();

      String serverLine();

      boolean inWorld();

      String keyName(int var1);

      void openStorage(StorageBlocksSetting var1);

      void openHudEditor();

      void closeNow();

      List<?> items();

      String itemName(Object var1);

      Object itemOf(ItemSetting var1);

      void setItem(ItemSetting var1, Object var2);

      Path stateFile();

      default float beat() {
         return 0.0F;
      }

      default float shakeStrength() {
         return 0.0F;
      }
   }

   private static final class UiParticleState {
      float x;
      float y;
      float speed;
      float size;
      float phase;
      float fade;
      float sway;
      float base;
   }
}
