package hook.feature;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import hook.utils.ext.ModuleChat.Body;
import net.minecraft.world.GameMode;

public final class VanishAlertRules {
   public static final List<String> DONUT_STAFF;
   private static final Set<String> STAFF_KEYS = staffKeys();

   private VanishAlertRules() {
   }

   public static boolean isStaffName(String var0) {
      return ((var0 != null && STAFF_KEYS.contains(var0.toLowerCase(Locale.ROOT))));
   }

   public static boolean isInYourRegion(UUID var0) {
      return false;
   }

   public static boolean alarmedRecently(UUID var0) {
      return false;
   }

   public static Body switchedTo(Body var0, String var1) {
      if (var1 == null) {
         return var0.text("switched game mode");
      } else {
         var0.text("switched to ");
         if (GameMode.SPECTATOR.getId().equals(var1)) {
            return var0.danger(var1);
         } else {
            return GameMode.CREATIVE.getId().equals(var1) ? var0.warn(var1) : var0.name(var1);
         }
      }
   }

   private static Set<String> staffKeys() {
      HashSet var0 = new HashSet();

      for (String var2 : DONUT_STAFF) {
         var0.add(var2.toLowerCase(Locale.ROOT));
      }

      return Set.copyOf(var0);
   }

   static {
      String[] var10000 = new String[20];
      var10000[0] = "FluffyMaster07";
      var10000[1] = "archivePedro";
      var10000[2] = "Munkerlich";
      var10000[3] = "Frenk_Btw";
      var10000[4] = "Napooo_";
      var10000[5] = "auzzitech";
      var10000[6] = "CryptoDaveYT";
      var10000[7] = "W1zox_";
      var10000[8] = "ZEEF69";
      var10000[9] = "showered";
      var10000[10] = "CaptainMoose35";
      var10000[11] = "BobIsFound";
      var10000[12] = "NoahvdAa";
      var10000[13] = "0GSummer";
      var10000[14] = "LzouzMP5";
      var10000[15] = "Pastagamer08";
      var10000[16] = "u_vv";
      var10000[17] = "Owen1212055";
      var10000[18] = "Splaterd";
      var10000[19] = "Fallerfly";
      DONUT_STAFF = List.of(var10000);
   }
}
