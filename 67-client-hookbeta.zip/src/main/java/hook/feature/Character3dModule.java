package hook.feature;

import it.unimi.dsi.fastutil.ints.Int2BooleanOpenHashMap;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.lang.ref.WeakReference;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import hook.module.ext.ClientModule;
import hook.module.ext.ModuleCategory;
import hook.module.ext.ModuleRegistry;
import hook.module.ext.Stage;
import hook.module.ext.event.EventType;
import hook.module.ext.event.TickEvent;
import hook.module.ext.setting.ActionSetting;
import hook.module.ext.setting.BooleanSetting;
import hook.module.ext.setting.ModeSetting;
import hook.utils.BytecodeException;
import hook.utils.ext.ModuleChat;
import hook.utils.ext.ModuleChat.Body;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.feature.Deadmau5FeatureRenderer;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.HeadFeatureRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.feature.ShoulderParrotFeatureRenderer;
import net.minecraft.client.render.entity.feature.StuckObjectsFeatureRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;


@Environment(EnvType.CLIENT)
public final class Character3dModule extends ClientModule {
   private static final long FRIEND_REFRESH_NANOS = 1000000000L;
   private static final float MODEL_PIXEL = 0.05859375F;
   private static volatile Character3dModule active;
   private final ModeSetting character = this.addSetting(
      "character", characterSetting()
   );
   private final ModeSetting detail;
   private final BooleanSetting heldItems;
   private final Int2BooleanOpenHashMap friendCache;
   private long friendsCheckedAt;
   private int scanTicks;
   private WeakReference<ClientWorld> level;

   public Character3dModule() {
      super(
         "character-3d",
         "3D Character",
         "Replaces your player model with a 3D character.",
         ModuleCategory.VISUALS
      );
      String var10002 = "detail";
      String var10005 = "Detail";
      String var10006 = CharacterDetailLevel.MEDIUM.label;
      String[] var10007 = new String[3];
      var10007[0] = CharacterDetailLevel.LOW.label;
      var10007[1] = CharacterDetailLevel.MEDIUM.label;
      var10007[2] = CharacterDetailLevel.HIGH.label;
      this.detail = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      this.heldItems = this.addSetting(
         "held-items",
         new BooleanSetting("Held Items", false)
      );
      this.friendCache = new Int2BooleanOpenHashMap();
      this.level = new WeakReference<>(null);
      this.addSetting(
         "characters-folder",
         new ActionSetting(
            "Open Characters Folder", this::openFolder
         )
      );
      this.character.onChange(this::prepare);
      this.detail.onChange(this::prepare);
   }

   private static ModeSetting characterSetting() {
      Character3dHelper.refresh();
      List var0 = Character3dHelper.names();
      return new ModeSetting(
         "Character",
         (String)var0.get(0),
         ((String[]) var0.toArray(new String[0]))
      );
   }

   private void refreshCharacters() {
      if (Character3dHelper.refresh()) {
         this.character.setModes(Character3dHelper.names());
      }
   }

   private void openFolder() {
      Path var1 = LocalCharacterAssetLibrary.folder();

      try {
         Files.createDirectories(var1);
      } catch (IOException var3) {
         ModuleChat.send(
            this,
            ModuleChat.body()
               .danger("Couldn't create ")
               .text(var1.toString())
         );
         return;
      }

      this.refreshCharacters();
      Util.getOperatingSystem().open(var1);
   }

   private void prepare() {
      if (this.isEnabled()) {
         CharacterModelCache.prepare(Character3dHelper.byName(this.character.get()), CharacterDetailLevel.byLabel(this.detail.get()));
      }
   }

   @Override
   public void onEnable() {
      CharacterModelCache.listen();
      this.reset();
      this.refreshCharacters();
      this.prepare();
      active = this;
      this.on(TickEvent.TYPE, Stage.POST, var1 -> {
         this.watchLevel();
         if ((this.scanTicks += 1) % (40) == 0) {
            this.refreshCharacters();
         }
      });
   }

   @Override
   public void onDisable() {
      if (active == this) {
         active = null;
      }

      this.reset();
      CharacterModelCache.clear();
   }

   private void reset() {
      this.friendCache.clear();
      CharacterMotionAnimator.clear();
      this.level = new WeakReference<>(MinecraftClient.getInstance().world);
   }

   private void watchLevel() {
      ClientWorld var1 = MinecraftClient.getInstance().world;
      if (this.level.get() != var1) {
         this.reset();
         CharacterModelCache.releaseTextures();
      }
   }

   public static void extract(Entity var0, PlayerEntityRenderState var1) {
      Character3dModule var2 = active;
      WornCharacterModel var3 = var2 == null ? null : var2.resolve(var1);
      CharacterRenderStateAccess var4 = (CharacterRenderStateAccess)var1;
      var4.hook$setCharacter(var3);
      if (var3 != null) {
         Entity var5 = var0.getVehicle();
         var4.hook$setSeat(
            var5 == null
               ? 0.0F
               : (var5 instanceof LivingEntity ? 1.350000023841858F : 0.30000001192092896F)
         );
         if (var1.nameLabelPos != null) {
            BakedCharacterData var6 = var3.model;
            float var7 = var6.maxY * var6.scale - 32.0F;
            if (var7 > 0.0F) {
               var1.nameLabelPos = var1.nameLabelPos
                  .add(
                     0.0,
                     (double)(var7 * 0.05859375F * var1.baseScale),
                     0.0
                  );
            }
         }
      }
   }

   static void baking(String var0) {
      Character3dModule var1 = active;
      if (var1 != null) {
         ModuleChat.send(
            var1,
            ModuleChat.body()
               .text("Preparing ")
               .name(var0)
               .text(", big models take a few seconds the first time")
         );
      }
   }

   static void notice(String var0, List<String> var1) {
      Character3dModule var2 = active;
      if (var2 != null) {
         Body var3 = ModuleChat.body().name(var0);
         if (var1.isEmpty()) {
            var3.text(
               " has no skeleton the client recognises, so it moves as one piece"
            );
         } else {
            var3.text(" only moves its ")
               .value(String.join(" and ", var1))
               .text(", the rest of its skeleton wasn't recognised");
         }

         ModuleChat.send(var2, var3);
      }
   }

   static void failed(CharacterDefinition var0, Throwable var1) {
      Character3dModule var2 = active;
      if (var2 != null) {
         Throwable var3 = var1 instanceof UncheckedIOException && var1.getCause() != null ? var1.getCause() : var1;
         String var4 = !(var3 instanceof IOException) && !(var3 instanceof IllegalStateException)
            ? "the file couldn't be read, see the log"
            : var3.getMessage();
         ModuleChat.send(
            var2,
            ModuleChat.body()
               .text("Couldn't load ")
               .name(var0.name())
               .text(": ")
               .danger(var4)
         );
      }
   }

   static WornCharacterModel worn(EntityRenderState var0) {
      return var0 instanceof CharacterRenderStateAccess var1 ? var1.hook$character() : null;
   }

   static float seat(EntityRenderState var0) {
      return var0 instanceof CharacterRenderStateAccess var1 ? var1.hook$seat() : 0.0F;
   }

   public static boolean hidesModel(EntityRenderState var0) {
      return ((worn(var0) != null));
   }

   public static boolean hidesLayer(FeatureRenderer<?, ?> var0, EntityRenderState var1) {
      return ((worn(var1) == null
         ? 0
         : (
            !(var0 instanceof ArmorFeatureRenderer)
                  && !(var0 instanceof CapeFeatureRenderer)
                  && !(var0 instanceof ElytraFeatureRenderer)
                  && !(var0 instanceof StuckObjectsFeatureRenderer)
                  && !(var0 instanceof HeadFeatureRenderer)
                  && !(var0 instanceof ShoulderParrotFeatureRenderer)
                  && !(var0 instanceof Deadmau5FeatureRenderer)
                  && (!(var0 instanceof HeldItemFeatureRenderer) || showsHeldItems())
               ? 0
               : 1
         )) != 0);
   }

   private static boolean showsHeldItems() {
      Character3dModule var0 = active;
      return ((var0 != null && var0.heldItems.get()));
   }

   static WornCharacterModel firstPerson() {
      Character3dModule var0 = active;
      if (var0 == null) {
         return null;
      } else {
         ClientPlayerEntity var1 = MinecraftClient.getInstance().player;
         if (var1 != null && !var1.isSpectator()) {
            WornCharacterModel var2 = CharacterModelCache.ready(
               Character3dHelper.byName(var0.character.get()), CharacterDetailLevel.byLabel(var0.detail.get())
            );
            return var2 != null && var2.model.firstPersonArms ? var2 : null;
         } else {
            return null;
         }
      }
   }

   private WornCharacterModel resolve(PlayerEntityRenderState var1) {
      if (var1.spectator) {
         return null;
      } else {
         MinecraftClient var2 = MinecraftClient.getInstance();
         return !this.wears(var2, var1)
            ? null
            : CharacterModelCache.ready(Character3dHelper.byName(this.character.get()), CharacterDetailLevel.byLabel(this.detail.get()));
      }
   }

   private boolean wears(MinecraftClient var1, PlayerEntityRenderState var2) {
      ClientPlayerEntity var3 = var1.player;
      if (var3 != null && var1.world != null) {
         if (var2.id != var3.getId()) {
            return false;
         } else {
            FreecamModule var4 = ModuleRegistry.get(FreecamModule.class);
            return (((var4 == null || !var4.isEnabled()) && var1.options.getPerspective().isFirstPerson()
               ? (var1.currentScreen != null && !var3.isSleeping() ? 1 : 0)
               : 1) != 0);
         }
      } else {
         return false;
      }
   }

   private boolean isFriend(MinecraftClient var1, int var2) {
      long var3 = System.nanoTime();
      if (var3 - this.friendsCheckedAt > (1000000000L)) {
         this.friendCache.clear();
         this.friendsCheckedAt = var3;
      }

      if (this.friendCache.containsKey(var2)) {
         return this.friendCache.get(var2);
      } else {
         int var5 = 0;
         this.friendCache.put(var2, (var5 != 0));
         return (var5 != 0);
      }
   }
}
