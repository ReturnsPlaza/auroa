package hook.feature;

import hook.module.Category;
import hook.module.Module;
import hook.module.setting.NumberSetting;
import hook.utils.EncryptedString;

/**
 * Forces the world lightmap toward full brightness so caves and night read as daylight.
 *
 * <p>The visual work is done by {@link hook.mixin.FullbrightLightmapMixin}, which bends the two
 * lightmap uniforms that control the flat ambient term: {@code AmbientLightFactor} and
 * {@code AmbientColor}. Blending the ambient factor toward 1 makes the lightmap resolve to plain
 * white for every sky/block light level, so textures keep their colours but lose all light-based
 * shading. This deliberately avoids the vanilla gamma path: in 1.21.11 the shader extrapolates the
 * gamma blend, so pushing the gamma option past 1 blows the whole picture out to white.
 */
public final class FullbrightModule extends Module {
   /** 0..100, how far the ambient light term is pushed toward white while the module is on. */
   public static final NumberSetting strength = new NumberSetting(
      EncryptedString.of("Strength"), 0.0, 100.0, 100.0, 1.0
   ).getValue(EncryptedString.of("How much of the vanilla lightmap darkness is removed (100 = fully lit)"));

   private static FullbrightModule instance;

   public FullbrightModule() {
      super(EncryptedString.of("Fullbright"),
         EncryptedString.of("Renders every block at full brightness, day or night, without touching your gamma setting"),
         -1, Category.RENDER);
      addSettings(strength);
      instance = this;
   }

   /** True only while the module is registered and enabled. */
   public static boolean active() {
      return instance != null && instance.isEnabled();
   }

   /**
    * Ambient factor written into the lightmap UBO: {@code 0} keeps vanilla light, {@code 1} is
    * fully lit. Hot path, called from a render mixin, so it must never allocate or throw.
    */
   public static float strength() {
      if (!active()) {
         return 0.0F;
      }

      double value = strength.getValue();
      return (float) Math.max(0.0, Math.min(100.0, value)) / 100.0F;
   }
}