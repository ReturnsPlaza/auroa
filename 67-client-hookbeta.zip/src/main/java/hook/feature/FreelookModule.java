package hook.feature;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import hook.Hook;
import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.utils.EncryptedString;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.option.Perspective;


public final class FreelookModule extends Module {
   private static final double CONSTANT_0281 = 0.15;
   private final NumberSetting distance = new NumberSetting(
      EncryptedString.of("Distance"),
      1.0,
      15.0,
      4.0,
      0.1
   );
   private final NumberSetting sensitivity = new NumberSetting(
      EncryptedString.of("Sensitivity"),
      0.1,
      3.0,
      1.0,
      0.1
   );
   private final BooleanSetting throughWalls = new BooleanSetting(
      EncryptedString.of("Through Walls"), false
   );
   private final BooleanSetting invertY = new BooleanSetting(
      EncryptedString.of("Invert Y"), false
   );
   private Perspective savedPerspective;
   private boolean savedChunkCulling;
   private float cameraYaw;
   private float cameraPitch;

   public FreelookModule() {
      super(
         EncryptedString.of("Freelook"),
         EncryptedString.of(
            "Rotates the third-person camera without changing player rotation"
         ),
         -1,
         Category.MISC
      );
      Setting[] var10001 = new Setting[4];
      var10001[0] = this.distance;
      var10001[1] = this.sensitivity;
      var10001[2] = this.throughWalls;
      var10001[3] = this.invertY;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      if (this.mc.player != null && this.mc.world != null) {
         FreecamModule var1 = (FreecamModule)Hook.INSTANCE
            .getModuleManager()
            .getModuleByClass(FreecamModule.class);
         if (var1 != null && var1.isEnabled()) {
            var1.toggle(false);
         }

         this.savedPerspective = this.mc.options.getPerspective();
         this.savedChunkCulling = this.mc.chunkCullingEnabled;
         this.cameraYaw = this.mc.player.getYaw();
         this.cameraPitch = this.mc.player.getPitch();
         this.mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         this.mc.chunkCullingEnabled = false;
         super.onEnable();
      } else {
         this.toggle(false);
      }
   }

   @Override
   public void onDisable() {
      if (this.savedPerspective != null) {
         this.mc.options.setPerspective(this.savedPerspective);
      }

      this.mc.chunkCullingEnabled = this.savedChunkCulling;
      super.onDisable();
   }

   @EventListener
   private void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null) {
         if (this.mc.options.getPerspective() != Perspective.THIRD_PERSON_BACK) {
            this.mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         }
      } else {
         this.toggle(false);
      }
   }

   public void consumeMouseDelta(double var1, double var3) {
      double var5 = 0.15 * this.sensitivity.getValue();
      this.cameraYaw = MathHelper.wrapDegrees(this.cameraYaw + (float)(var1 * var5));
      double var7 = var3
         * var5
         * (
            this.invertY.getValue()
               ? -1.0
               : 1.0
         );
      this.cameraPitch = MathHelper.clamp(
         this.cameraPitch + (float)var7, -90.0F, 90.0F
      );
   }

   public float getCameraYaw() {
      return this.cameraYaw;
   }

   public float getCameraPitch() {
      return this.cameraPitch;
   }

   public float getDistance() {
      return this.distance.getFloatValue();
   }

   public boolean isThroughWalls() {
      return this.throughWalls.getValue();
   }
}
