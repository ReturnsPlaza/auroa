package hook.feature;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;

final class HandAuraColors {
   private static int MixM4EWLFr;
   private transient int tNA3Xza2UU;

   private HandAuraColors() {
      super();
      int var4 = 589046324 ^ 1664058136;
      var4 = 1653809224 ^ var4;
      var4 = 1982689670 ^ 1519783894 ^ 236715828;
      this.tNA3Xza2UU = 591024484 ^ MixM4EWLFr;
      var4 = 1771045767 ^ var4;
      var4 = 1725235422 ^ var4;
   }

   static int argb() {
      int var6 = 707491992 ^ 1918899933 ^ 99518802;
      var6 = 1012900404 ^ var6;
      float var0 = 1.0F;
      int var2 = UiPalette.accent(var0);
      int var1 = -16777216;
      return var2 | var1;
   }

   static {
      int var3 = new Random(7385252709338376032L).nextInt();
      MixM4EWLFr = -1066088834 ^ var3;
   }




}
