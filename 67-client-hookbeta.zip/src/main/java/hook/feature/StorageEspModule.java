package hook.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import hook.event.EventListener;
import hook.event.events.Render3DEvent;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.module.setting.StorageBlocksSetting;
import hook.module.setting.StorageBlocksSetting.Entry;
import hook.utils.EncryptedString;
import hook.utils.RenderUtils;
import hook.utils.RenderVisibility;
import hook.utils.RenderUtils.ColoredBox;
import hook.utils.RenderUtils.ColoredLine;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ChiseledBookshelfBlockEntity;
import net.minecraft.block.entity.CrafterBlockEntity;
import net.minecraft.block.entity.DecoratedPotBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.world.chunk.WorldChunk;

public final class StorageEspModule extends Module {
   private final NumberSetting alpha;
   private final BooleanSetting tracers;
   private final StorageBlocksSetting storages;
   private List<StorageEspModule.StoragePair> targets;
   private final List<ColoredBox> renderBoxes;
   private final List<ColoredLine> renderLines;
   private Object scannedWorld;
   private int scanCooldown;
   private final Color[] renderColors;

   public StorageEspModule() {
      super(EncryptedString.of("Storage ESP"),
            EncryptedString.of("Highlights selected loaded storage blocks through walls"),
            -1, Category.RENDER);
      alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 53.0, 1.0);
      tracers = new BooleanSetting(EncryptedString.of("Tracers"), false);
      storages = new StorageBlocksSetting(EncryptedString.of("Storages"))
            .add("chest", "Chest", Items.CHEST, true, new Color(156, 91, 0))
            .add("ender_chest", "Ender Chest", Items.ENDER_CHEST, true, new Color(127, 91, 255))
            .add("shulker", "Shulker Box", Items.SHULKER_BOX, true, new Color(236, 85, 204))
            .add("spawner", "Spawner", Items.SPAWNER, true, new Color(255, 76, 98))
            .add("furnace", "Furnace", Items.FURNACE, true, new Color(102, 168, 255))
            .add("barrel", "Barrel", Items.BARREL, true, new Color(232, 151, 70))
            .add("enchanting_table", "Enchanting Table", Items.ENCHANTING_TABLE, true, new Color(62, 224, 207))
            .add("piston", "Moving Piston", Items.PISTON, true, new Color(151, 224, 88))
            .add("hopper", "Hopper", Items.HOPPER, true, new Color(0, 0, 255))
            .add("dispenser", "Dispenser", Items.DISPENSER, false, new Color(95, 188, 255))
            .add("dropper", "Dropper", Items.DROPPER, false, new Color(118, 134, 162))
            .add("brewing_stand", "Brewing Stand", Items.BREWING_STAND, false, new Color(249, 115, 140))
            .add("crafter", "Crafter", Items.CRAFTER, false, new Color(255, 195, 72))
            .add("chiseled_bookshelf", "Chiseled Bookshelf", Items.CHISELED_BOOKSHELF, false, new Color(189, 126, 255))
            .add("decorated_pot", "Decorated Pot", Items.DECORATED_POT, false, new Color(223, 119, 92));
      targets = List.of();
      renderBoxes = new ArrayList<>();
      renderLines = new ArrayList<>();
      renderColors = new Color[StorageType.values().length];
      addSettings(new Setting[]{alpha, tracers, storages});
   }

   public void onEnable() {
      this.targets = List.of();
      this.scannedWorld = null;
      this.scanCooldown = 0;
      super.onEnable();
   }

   public void onDisable() {
      this.targets = List.of();
      this.scannedWorld = null;
      this.renderBoxes.clear();
      this.renderLines.clear();
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.scannedWorld != this.mc.world) {
            this.targets = List.of();
            this.scannedWorld = this.mc.world;
            this.scanCooldown = 0;
         }

         int var10000 = this.scanCooldown;
         this.scanCooldown -= 1;
         if (var10000 <= 0) {
            this.refreshTargets();
            this.scanCooldown = 9;
         }
      } else {
         this.targets = List.of();
         this.scannedWorld = null;
         this.scanCooldown = 0;
      }
   }

   private void refreshTargets() {
      int var1 = this.mc.options.getClampedViewDistance();
      ChunkPos var2 = this.mc.player.getChunkPos();
      ArrayList var3 = new ArrayList();
      HashSet var4 = new HashSet();

      for (int var5 = var2.x - var1; var5 <= var2.x + var1; var5++) {
         for (int var6 = var2.z - var1; var6 <= var2.z + var1; var6++) {
            if (this.mc.world.isChunkLoaded(var5, var6)) {
               WorldChunk var7 = this.mc.world.getChunk(var5, var6);

               for (BlockEntity var9 : var7.getBlockEntities().values()) {
                  StorageEspModule.StorageType var10 = typeOf(var9);
                  if (var10 != null) {
                     BlockPos var11 = var9.getPos().toImmutable();
                     if (var10 == StorageEspModule.StorageType.CHEST) {
                        if (var4.contains(var11)) {
                           continue;
                        }

                        BlockPos var12 = this.chestPartner(var11);
                        if (var12 != null) {
                           var4.add(var11);
                           var4.add(var12);
                           var3.add(new StorageEspModule.StoragePair(var11, var12, var10));
                           continue;
                        }
                     }

                     var3.add(new StorageEspModule.StoragePair(var11, var11, var10));
                  }
               }
            }
         }
      }

      var3.sort(Comparator.comparingDouble(this::distanceSquared));
      this.targets = List.copyOf(var3);
   }

   private BlockPos chestPartner(BlockPos var1) {
      if (!(this.mc.world.getBlockEntity(var1) instanceof ChestBlockEntity)) {
         return null;
      } else {
         BlockState var2 = this.mc.world.getBlockState(var1);
         if (var2.getBlock() instanceof ChestBlock && var2.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
            for (Direction var4 : Type.HORIZONTAL) {
               BlockPos var5 = var1.offset(var4);
               BlockState var6 = this.mc.world.getBlockState(var5);
               if (var6.getBlock() == var2.getBlock()
                  && this.mc.world.getBlockEntity(var5) instanceof ChestBlockEntity
                  && var6.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                  return var5.toImmutable();
               }
            }

            return null;
         } else {
            return null;
         }
      }
   }

   private boolean targetStillLive(StorageEspModule.StoragePair var1) {
      if (!this.mc.world.isChunkLoaded(var1.first().getX() >> (4), var1.first().getZ() >> (4))) {
         return false;
      } else {
         BlockEntity var2 = this.mc.world.getBlockEntity(var1.first());
         if (var2 != null && !var2.isRemoved() && typeOf(var2) == var1.type()) {
            if (!var1.first().equals(var1.second())) {
               if (!this.mc
                  .world
                  .isChunkLoaded(var1.second().getX() >> (4), var1.second().getZ() >> (4))) {
                  return false;
               }

               BlockEntity var3 = this.mc.world.getBlockEntity(var1.second());
               if (var3 == null || var3.isRemoved() || typeOf(var3) != var1.type()) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (mc.world == null || mc.player == null || targets.isEmpty()) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }

      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      renderBoxes.clear();
      renderLines.clear();
      Vec3d tracerOrigin = tracerStart(camera);
      for (StoragePair pair : targets) {
         Entry entry = storages.get(pair.type().id);
         if (entry == null || !entry.enabled()) {
            continue;
         }
         Color rgb = entry.color();
         int argb = alpha.getIntValue() << 24 | rgb.getRGB() & 0xFFFFFF;
         Color color = renderColors[pair.type().ordinal()];
         if (color == null || color.getRGB() != argb) {
            color = new Color(argb, true);
            renderColors[pair.type().ordinal()] = color;
         }

         int minX = Math.min(pair.first().getX(), pair.second().getX());
         int minY = Math.min(pair.first().getY(), pair.second().getY());
         int minZ = Math.min(pair.first().getZ(), pair.second().getZ());
         int maxX = Math.max(pair.first().getX(), pair.second().getX()) + 1;
         int maxY = Math.max(pair.first().getY(), pair.second().getY()) + 1;
         int maxZ = Math.max(pair.first().getZ(), pair.second().getZ()) + 1;
         if (!tracers.getValue() && !RenderVisibility.box(minX, minY, minZ, maxX, maxY, maxZ)) {
            continue;
         }
         if (!targetStillLive(pair)) {
            continue;
         }
         if (alpha.getIntValue() > 0) {
            renderBoxes.add(new ColoredBox(minX + 0.08, minY + 0.08, minZ + 0.08,
                  maxX - 0.08, maxY - 0.08, maxZ - 0.08, color));
         }
         if (tracers.getValue()) {
            renderLines.add(new ColoredLine(tracerOrigin, pair.center(), color, 1.5F));
         }
      }
      RenderUtils.renderFilledBoxes(matrices, renderBoxes);
      RenderUtils.renderLines(matrices, renderLines);
      matrices.pop();
   }

   private double distanceSquared(StorageEspModule.StoragePair var1) {
      Vec3d var2 = var1.center();
      return this.mc.player.squaredDistanceTo(var2.x, var2.y, var2.z);
   }

   private static Vec3d tracerStart(Camera var0) {
      return RenderUtils.getTracerStart(var0);
   }

   private static StorageEspModule.StorageType typeOf(BlockEntity var0) {
      if (var0 instanceof ChestBlockEntity) {
         return StorageEspModule.StorageType.CHEST;
      } else if (var0 instanceof EnderChestBlockEntity) {
         return StorageEspModule.StorageType.ENDER_CHEST;
      } else if (var0 instanceof ShulkerBoxBlockEntity) {
         return StorageEspModule.StorageType.SHULKER;
      } else if (var0 instanceof MobSpawnerBlockEntity) {
         return StorageEspModule.StorageType.SPAWNER;
      } else if (var0 instanceof AbstractFurnaceBlockEntity) {
         return StorageEspModule.StorageType.FURNACE;
      } else if (var0 instanceof BarrelBlockEntity) {
         return StorageEspModule.StorageType.BARREL;
      } else if (var0 instanceof EnchantingTableBlockEntity) {
         return StorageEspModule.StorageType.ENCHANTING_TABLE;
      } else if (var0 instanceof PistonBlockEntity) {
         return StorageEspModule.StorageType.PISTON;
      } else if (var0 instanceof HopperBlockEntity) {
         return StorageEspModule.StorageType.HOPPER;
      } else if (var0 instanceof DropperBlockEntity) {
         return StorageEspModule.StorageType.DROPPER;
      } else if (var0 instanceof DispenserBlockEntity) {
         return StorageEspModule.StorageType.DISPENSER;
      } else if (var0 instanceof BrewingStandBlockEntity) {
         return StorageEspModule.StorageType.BREWING_STAND;
      } else if (var0 instanceof CrafterBlockEntity) {
         return StorageEspModule.StorageType.CRAFTER;
      } else if (var0 instanceof ChiseledBookshelfBlockEntity) {
         return StorageEspModule.StorageType.CHISELED_BOOKSHELF;
      } else {
         return var0 instanceof DecoratedPotBlockEntity ? StorageEspModule.StorageType.DECORATED_POT : null;
      }
   }

   private record StoragePair(BlockPos first, BlockPos second, StorageEspModule.StorageType type) {
      private Vec3d center() {
         return new Vec3d(
            (this.first.getX() + this.second.getX() + 1) * 0.5,
            (this.first.getY() + this.second.getY() + 1) * 0.5,
            (this.first.getZ() + this.second.getZ() + 1) * 0.5
         );
      }
   }

   private static enum StorageType {
      CHEST("chest"),
      ENDER_CHEST("ender_chest"),
      SHULKER("shulker"),
      SPAWNER("spawner"),
      FURNACE("furnace"),
      BARREL("barrel"),
      ENCHANTING_TABLE("enchanting_table"),
      PISTON("piston"),
      HOPPER("hopper"),
      DISPENSER("dispenser"),
      DROPPER("dropper"),
      BREWING_STAND("brewing_stand"),
      CRAFTER("crafter"),
      CHISELED_BOOKSHELF("chiseled_bookshelf"),
      DECORATED_POT("decorated_pot");

      private final String id;

      private StorageType(String nullxx) {
         this.id = nullxx;
      }
   }
}
