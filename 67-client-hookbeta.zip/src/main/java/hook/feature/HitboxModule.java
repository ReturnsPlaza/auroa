package hook.feature;

import hook.event.EventListener;
import hook.event.events.TargetMarginEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.utils.EncryptedString;
import net.minecraft.entity.player.PlayerEntity;

public final class HitboxModule extends Module {
   private final NumberSetting expand;
   private final BooleanSetting enableRender;

   public HitboxModule() {
      super(EncryptedString.of("HitBox"), EncryptedString.of("Expands a player's hitbox."), -1, Category.COMBAT);
      this.expand = new NumberSetting(EncryptedString.of("Expand"), 0.0, 2.0, 0.5, 0.05);
      this.enableRender = new BooleanSetting("Enable Render", true);
      this.addSettings(this.enableRender, this.expand);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTargetMargin(TargetMarginEvent event) {
      if (event.entity instanceof PlayerEntity) {
         event.cir.setReturnValue((float)this.expand.getValue());
      }
   }

   public double getHitboxExpansion() {
      return this.enableRender.getValue() ? this.expand.getValue() : 0.0;
   }
}
