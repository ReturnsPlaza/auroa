package hook.feature;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;

@Environment(EnvType.CLIENT)
final class CharacterAtlasTexture extends AbstractTexture {
   CharacterAtlasTexture(String name, int width, int height, int[][] mipPixels) {
      GpuDevice device = RenderSystem.getDevice();
      glTexture = device.createTexture(() -> name, 5, TextureFormat.RGBA8, width, height, 1, mipPixels.length);
      glTextureView = device.createTextureView(glTexture);
      CommandEncoder encoder = device.createCommandEncoder();

      int mipWidth = width;
      int mipHeight = height;
      for (int level = 0; level < mipPixels.length; level++) {
         int[] pixels = mipPixels[level];
         try (NativeImage image = new NativeImage(mipWidth, mipHeight, false)) {
            for (int y = 0; y < mipHeight; y++) {
               for (int x = 0; x < mipWidth; x++) {
                  image.setColorArgb(x, y, pixels[y * mipWidth + x]);
               }
            }
            encoder.writeToTexture(glTexture, image, level, 0, 0, 0, mipWidth, mipHeight, 0, 0);
         }
         mipWidth = Math.max(1, mipWidth / 2);
         mipHeight = Math.max(1, mipHeight / 2);
      }
      sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR, true);
   }
}
