package hook.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CharacterRenderStateAccess {
   WornCharacterModel hook$character();

   void hook$setCharacter(WornCharacterModel var1);

   float hook$seat();

   void hook$setSeat(float var1);
}
