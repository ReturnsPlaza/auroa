package hook.feature;

import java.util.List;
import net.minecraft.client.util.Window;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class AntiVanishHudOverlay {
   private static final int WARN = -22016;
   private static float shown;
   private static long last;

   private AntiVanishHudOverlay() {
   }

   public static void render(DrawContext var0) {
      try {
         PlayerWatchHud.render(var0);
         drawVanish(var0);
      } catch (Throwable var2) {
         System.err.println("Hook: HUD element failed: " + var2);
      }
   }

   private static void drawVanish(DrawContext var0) {
      List<AntiVanishModule.VanishHudEntry> var1 = AntiVanishModule.hudEntries();
      long var2 = System.nanoTime();
      float var4 = last == 0L ? 0.016F : Math.min(0.1F, (float)(var2 - last) / 1.0E9F);
      last = var2;
      shown = shown + ((var1.isEmpty() ? 0.0F : 1.0F) - shown) * (1.0F - (float)Math.exp((double)(-10.0F * var4)));
      if (!(shown < 0.01F) && !var1.isEmpty()) {
         MinecraftClient var5 = MinecraftClient.getInstance();
         Window var6 = var5.getWindow();
         float var7 = (float)var6.getScaleFactor();
         float var8 = Math.max(0.6F, (float)var6.getFramebufferHeight() / 1080.0F);
         var0.getMatrices().pushMatrix();
         var0.getMatrices().scale(1.0F / var7, 1.0F / var7);

         try {
            MinecraftUiRenderer var9 = new MinecraftUiRenderer(var0, var7);
            float var10 = 13.0F * var8;
            float var11 = 11.0F * var8;
            float var12 = 12.0F * var8;
            float var13 = 24.0F * var8;
            float var14 = 0.0F;
            float var15 = 0.0F;

            for (AntiVanishModule.VanishHudEntry var17 : var1) {
               var14 = Math.max(var14, var9.textWidth(AntiVanishModule.hudTag(var17), var11, 1));
               var15 = Math.max(var15, var9.textWidth(AntiVanishModule.hudValue(var17), var10, 0));
            }

            float var28 = var12 * 2.0F + var14 + 10.0F * var8 + var15;
            float var29 = var13 * (float)var1.size() + 8.0F * var8;
            float var18 = 12.0F * var8 - (1.0F - shown) * 14.0F * var8;
            float var19 = (float)var6.getFramebufferHeight() * 0.3F;
            var9.pushAlpha(shown);
            var9.shadow(var18, var19, var28, var29, 12.0F * var8, 16.0F * var8, UiRenderer.argb(0.35F, 0, 0, 0));
            var9.round(var18, var19, var28, var29, 12.0F * var8, UiPalette.glass(0.78F));
            var9.outline(var18, var19, var28, var29, 12.0F * var8, Math.max(1.0F, var8 * 0.9F), UiRenderer.white(0.09F));
            var9.round(var18 + 4.0F * var8, var19 + var29 * 0.25F, 3.0F * var8, var29 * 0.5F, 1.5F * var8, UiPalette.accent(0.95F));

            for (int var20 = 0; var20 < var1.size(); var20++) {
               AntiVanishModule.VanishHudEntry var21 = (AntiVanishModule.VanishHudEntry)var1.get(var20);
               String var22 = AntiVanishModule.hudTag(var21);
               boolean var23 = "ALERT".equals(var22) || "VANISH".equals(var22);
               float var24 = var19 + 4.0F * var8 + (float)var20 * var13;
               var9.text(var22, var18 + var12, var24 + (var13 - var11) / 2.0F, var11, 1, var23 ? -22016 : UiRenderer.white(0.55F));
               var9.text(
                  AntiVanishModule.hudValue(var21),
                  var18 + var12 + var14 + 10.0F * var8,
                  var24 + (var13 - var10) / 2.0F - var8,
                  var10,
                  0,
                  UiRenderer.white(0.95F)
               );
            }

            var9.popAlpha();
         } finally {
            var0.getMatrices().popMatrix();
         }
      }
   }
}
