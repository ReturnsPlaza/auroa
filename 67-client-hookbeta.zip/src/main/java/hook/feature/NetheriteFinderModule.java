package hook.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import hook.event.EventListener;
import hook.event.events.Render3DEvent;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.utils.BlockUtil;
import hook.utils.EncryptedString;
import hook.utils.RenderUtils;
import hook.utils.RenderUtils.ColoredBox;
import hook.utils.RenderUtils.ColoredLine;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class NetheriteFinderModule extends Module {
   private static final int RESCAN_TICKS = 20;
   private final NumberSetting maxShown;
   private final BooleanSetting tracers;
   private volatile List<NetheriteFinderModule.BoundingBox> hits;
   private final List<ColoredBox> renderBoxes;
   private final List<ColoredLine> renderLines;
   private final AtomicBoolean scanning;
   private ExecutorService worker;
   private int timer;

   public NetheriteFinderModule() {
      super(EncryptedString.of("Netherite Finder"),
            EncryptedString.of("Finds ancient debris even with anti-xray"), -1, Category.DONUT);
      maxShown = new NumberSetting(EncryptedString.of("Max Shown"), 1.0, 1000.0, 100.0, 1.0)
            .getValue(EncryptedString.of("Maximum hits shown, nearest exact blocks first"));
      tracers = new BooleanSetting(EncryptedString.of("Tracers"), false);
      hits = List.of();
      renderBoxes = new ArrayList<>();
      renderLines = new ArrayList<>();
      scanning = new AtomicBoolean();
      addSettings(new Setting[]{maxShown, tracers});
   }

   public void onEnable() {
      this.hits = List.of();
      this.renderBoxes.clear();
      this.renderLines.clear();
      this.timer = 0;
      this.scanning.set(false);
      this.worker = Executors.newSingleThreadExecutor(var0 -> {
         Thread var1 = new Thread(var0, "Hook-NetheriteFinder");
         var1.setDaemon(true);
         var1.setPriority(1);
         return var1;
      });
      super.onEnable();
   }

   public void onDisable() {
      ExecutorService var1 = this.worker;
      this.worker = null;
      if (var1 != null) {
         var1.shutdownNow();
      }

      this.hits = List.of();
      this.scanning.set(false);
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.world == null || mc.player == null || ++timer < RESCAN_TICKS) {
         return;
      }
      timer = 0;
      ExecutorService activeWorker = worker;
      if (activeWorker == null || activeWorker.isShutdown() || !scanning.compareAndSet(false, true)) {
         return;
      }

      double playerX = mc.player.getX();
      double playerY = mc.player.getY();
      double playerZ = mc.player.getZ();
      List<WorldChunk> loaded = BlockUtil.getLoadedChunksList();
      int cap = maxShown.getIntValue();
      activeWorker.submit(() -> {
         try {
            List<BoundingBox> found = scan(loaded, cap, playerX, playerY, playerZ);
            if (isEnabled() && worker == activeWorker) {
               hits = found;
            }
         } catch (Throwable ignored) {
         } finally {
            scanning.set(false);
         }
      });
   }

   private static List<NetheriteFinderModule.BoundingBox> scan(List<WorldChunk> loaded, int cap, double playerX, double playerY, double playerZ) {
      ArrayList<NetheriteFinderModule.BoundingBox> hits = new ArrayList<>();
      Iterator var9 = loaded.iterator();

      while (var9.hasNext()) {
         WorldChunk chunk;
         ChunkSection[] sections = (chunk = (WorldChunk)var9.next()).getSectionArray();
         int bottomSection = chunk.getBottomSectionCoord();
         ChunkPos chunkPos = chunk.getPos();

         for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            ChunkSection section;
            if ((section = sections[sectionIndex]) != null && section.getBlockStateContainer().hasAny(state -> state.isOf(Blocks.ANCIENT_DEBRIS))) {
               int sectionY = bottomSection + sectionIndex << 4;
               int priorHits = hits.size();

               for (int y = 0; y < 16; y++) {
                  for (int z = 0; z < 16; z++) {
                     for (int x = 0; x < 16; x++) {
                        if (section.getBlockState(x, y, z).isOf(Blocks.ANCIENT_DEBRIS)) {
                           int worldX = chunkPos.getStartX() + x;
                           int worldY = sectionY + y;
                           int worldZ = chunkPos.getStartZ() + z;
                           hits.add(
                              new NetheriteFinderModule.BoundingBox(
                                 (double)worldX, (double)worldY, (double)worldZ, (double)(worldX + 1), (double)(worldY + 1), (double)(worldZ + 1), true
                              )
                           );
                        }
                     }
                  }
               }

               if (hits.size() == priorHits) {
                  int xx = chunkPos.getStartX();
                  int z = chunkPos.getStartZ();
                  hits.add(
                     new NetheriteFinderModule.BoundingBox(
                        (double)xx, (double)sectionY, (double)z, (double)(xx + 16), (double)(sectionY + 16), (double)(z + 16), false
                     )
                  );
               }
            }
         }
      }

      hits.sort(Comparator.<NetheriteFinderModule.BoundingBox>comparingInt(hit -> hit.exact() ? 0 : 1).thenComparingDouble(hit -> {
         double dx = (hit.x1() + hit.x2()) * 0.5 - playerX;
         double dy = (hit.y1() + hit.y2()) * 0.5 - playerY;
         double dz = (hit.z1() + hit.z2()) * 0.5 - playerZ;
         return dx * dx + dy * dy + dz * dz;
      }));
      if (hits.size() > cap) {
         hits = new ArrayList<>(hits.subList(0, cap));
      }

      return List.copyOf(hits);
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      if (this.mc.world != null) {
         Camera var2 = RenderUtils.getCamera();
         if (var2 != null && var2.isReady()) {
            MatrixStack var3 = var1.matrixStack;
            var3.push();
            RenderUtils.applyCameraTransform(var3, var2);
            long var4 = System.currentTimeMillis() % (2000L);
            double var6 = var4 < (1000L)
               ? (double)var4 / 1000.0
               : (double)((2000L) - var4) / 1000.0;
            int var8 = (int)(
               255.0
                  - 155.0 * var6
            );
            Color var9 = new Color(190, 90, 255, var8);
            Color var10 = new Color(190, 90, 255, 255);
            this.renderBoxes.clear();
            this.renderLines.clear();
            Vec3d var11 = RenderUtils.getTracerStart(var2);

            for (NetheriteFinderModule.BoundingBox var13 : this.hits) {
               if (var13.exact()) {
                  this.renderBoxes.add(new ColoredBox(var13.x1(), var13.y1(), var13.z1(), var13.x2(), var13.y2(), var13.z2(), var9));
               }

               RenderUtils.addBoxOutline(
                  this.renderLines,
                  var13.x1(),
                  var13.y1(),
                  var13.z1(),
                  var13.x2(),
                  var13.y2(),
                  var13.z2(),
                  var10,
                  1.5F
               );
               if (var13.exact() || this.tracers.getValue()) {
                  this.renderLines
                     .add(new ColoredLine(var11, var13.center(), var10, 1.5F));
               }
            }

            for (Entity var17 : this.mc.world.getEntities()) {
               if (var17 instanceof ItemEntity) {
                  ItemEntity var14 = (ItemEntity)var17;
                  if (var14.getStack().isOf(Items.ANCIENT_DEBRIS)) {
                     Box var15 = var14.getBoundingBox();
                     this.renderBoxes
                        .add(
                           new ColoredBox(
                              var15.minX, var15.minY, var15.minZ, var15.maxX, var15.maxY, var15.maxZ, var9
                           )
                        );
                     RenderUtils.addBoxOutline(
                        this.renderLines,
                        var15.minX,
                        var15.minY,
                        var15.minZ,
                        var15.maxX,
                        var15.maxY,
                        var15.maxZ,
                        var10,
                        1.5F
                     );
                     this.renderLines
                        .add(
                           new ColoredLine(
                              var11,
                              new Vec3d(var14.getX(), var14.getY(), var14.getZ()),
                              var10,
                              1.5F
                           )
                        );
                  }
               }
            }

            RenderUtils.renderFilledBoxes(var3, this.renderBoxes);
            RenderUtils.renderLines(var3, this.renderLines);
            var3.pop();
         }
      }
   }

   private record BoundingBox(double x1, double y1, double z1, double x2, double y2, double z2, boolean exact) {
      private Vec3d center() {
         return new Vec3d((this.x1 + this.x2) * 0.5, (this.y1 + this.y2) * 0.5, (this.z1 + this.z2) * 0.5);
      }
   }
}
