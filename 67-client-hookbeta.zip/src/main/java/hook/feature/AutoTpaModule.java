package hook.feature;

import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.MinMaxSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.StringSetting;
import hook.utils.EncryptedString;
import net.minecraft.client.network.ClientPlayNetworkHandler;

public final class AutoTpaModule extends Module {
   private final MinMaxSetting delayRange;
   private final ModeSetting<Mode> mode;
   private final StringSetting playerName;
   private int delayCounter;

   public AutoTpaModule() {
      super(
         EncryptedString.of("Auto Tpa"),
         EncryptedString.of("Module that helps you teleport streamers to you"),
         -1,
         Category.MISC
      );
      this.delayRange = new MinMaxSetting(EncryptedString.of("Delay"), 1.0, 80.0, 1.0, 10.0, 30.0);
      this.mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.TPAHERE, Mode.class);
      this.playerName = new StringSetting(EncryptedString.of("Player"), "DrDonutt");
      this.addSettings(this.mode, this.delayRange, this.playerName);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.delayCounter > 0) {
         this.delayCounter--;
         return;
      }

      ClientPlayNetworkHandler network = this.mc.getNetworkHandler();
      String command = this.mode.getValue().equals(Mode.TPA) ? "tpa " : "tpahere ";
      network.sendChatCommand(command + this.playerName.getValue());
      this.delayCounter = this.delayRange.getRandomIntInRange();
   }

   enum Mode {
      TPA,
      TPAHERE
   }
}
