package hook.feature;

import java.util.Random;
import hook.event.EventListener;
import hook.event.events.TickEvent;
import hook.event.events.TotemPopEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.ModeSetting;
import hook.module.setting.NumberSetting;
import hook.module.setting.Setting;
import hook.utils.EncryptedString;
import hook.utils.FakeInvScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoInvTotemModule extends Module {
   private static final int OFFHAND_BUTTON = 40;
   private final ModeSetting<AutoInvTotemModule.TotemMode> equipMode;
   private final NumberSetting delay;
   private final NumberSetting randomDelay;
   private final BooleanSetting hotbar;
   private final NumberSetting totemSlot;
   private final BooleanSetting autoSwitch;
   private final BooleanSetting forceTotem;
   private final BooleanSetting autoOpen;
   private final NumberSetting stayOpenDuration;
   private final Random random;
   private int clickCooldown;
   private int stayOpenCounter;
   private boolean pendingPop;
   private boolean openedByModule;
   private boolean switchAfterClose;

   public AutoInvTotemModule() {
      super(EncryptedString.of("Auto Inv Totem"),
            EncryptedString.of("Automatically equips a totem in your offhand and main hand if empty"),
            -1, Category.COMBAT);
      equipMode = new ModeSetting<>(EncryptedString.of("Equip Mode"), TotemMode.Always, TotemMode.class)
            .setDescription(EncryptedString.of("Always keeps totems equipped, or only refills after your totem pops"));
      delay = new NumberSetting(EncryptedString.of("Delay"), 0.0, 20.0, 2.0, 1.0)
            .getValue(EncryptedString.of("Ticks to wait before each inventory click"));
      randomDelay = new NumberSetting(EncryptedString.of("Random Delay"), 0.0, 10.0, 2.0, 1.0)
            .getValue(EncryptedString.of("Adds up to this many extra ticks to each click so the timing varies"));
      hotbar = new BooleanSetting(EncryptedString.of("Hotbar"), true)
            .setDescription(EncryptedString.of("Also keeps a totem in your Totem Slot"));
      totemSlot = new NumberSetting(EncryptedString.of("Totem Slot"), 1.0, 9.0, 1.0, 1.0)
            .getValue(EncryptedString.of("Your preferred totem slot"));
      autoSwitch = new BooleanSetting(EncryptedString.of("Auto Switch"), false)
            .setDescription(EncryptedString.of("Selects the totem slot after the inventory closes"));
      forceTotem = new BooleanSetting(EncryptedString.of("Force Totem"), false)
            .setDescription(EncryptedString.of("Puts the totem in the slot, regardless if its space is taken up by something else"));
      autoOpen = new BooleanSetting(EncryptedString.of("Auto Open"), false)
            .setDescription(EncryptedString.of("Automatically opens and closes the inventory for you"));
      stayOpenDuration = new NumberSetting(EncryptedString.of("Stay Open For"), 0.0, 20.0, 0.0, 1.0);
      random = new Random();
      clickCooldown = -1;
      stayOpenCounter = -1;
      addSettings(new Setting[]{equipMode, delay, randomDelay, hotbar, totemSlot, autoSwitch,
            forceTotem, autoOpen, stayOpenDuration});
   }

   public void onEnable() {
      this.clickCooldown = -1;
      this.stayOpenCounter = -1;
      this.pendingPop = false;
      this.openedByModule = false;
      this.switchAfterClose = false;
      super.onEnable();
   }

   @EventListener
   public void onTotemPop(TotemPopEvent var1) {
      this.pendingPop = true;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.interactionManager != null) {
         boolean var2 = this.mc.currentScreen instanceof InventoryScreen;
         if (!var2) {
            this.clickCooldown = -1;
            this.stayOpenCounter = -1;
            this.openedByModule = false;
            if (this.mc.currentScreen == null && this.switchAfterClose) {
               this.switchAfterClose = false;
               this.selectTotemSlot();
            }
         }

         boolean var3 = this.hasWork();
         if (this.pendingPop && !var3) {
            this.pendingPop = false;
         }

         int var4 = !this.equipMode.isMode(AutoInvTotemModule.TotemMode.Always) && !this.pendingPop
            ? 0
            : 1;
         if (!var2) {
            if (var4 != 0 && var3 && this.autoOpen.getValue() && this.mc.currentScreen == null) {
               this.mc.setScreen(new FakeInvScreen(this.mc.player));
               this.openedByModule = true;
               this.scheduleClick(true);
            }
         } else {
            if (this.clickCooldown < 0) {
               this.scheduleClick(true);
            }

            if (var4 != 0 && var3) {
               this.stayOpenCounter = -1;
               if (this.clickCooldown > 0) {
                  this.clickCooldown -= 1;
               } else if (!this.mc.player.isSprinting() && !this.mc.player.isUsingItem()) {
                  if (this.clickOnce()) {
                     this.switchAfterClose = this.autoSwitch.getValue();
                     this.scheduleClick(false);
                  }
               }
            } else {
               if (this.openedByModule && this.mc.currentScreen instanceof FakeInvScreen) {
                  if (this.stayOpenCounter < 0) {
                     this.stayOpenCounter = this.stayOpenDuration.getIntValue();
                  }

                  if (this.stayOpenCounter > 0) {
                     this.stayOpenCounter -= 1;
                     return;
                  }

                  this.openedByModule = false;
                  this.mc.currentScreen.close();
               }
            }
         }
      }
   }

   private void scheduleClick(boolean var1) {
      int var2 = this.randomDelay.getIntValue() > 0
         ? this.random.nextInt(this.randomDelay.getIntValue() + (1))
         : 0;
      int var3 = this.delay.getIntValue() + var2;
      this.clickCooldown = var1 ? Math.max(1, var3) : var3;
   }

   private boolean clickOnce() {
      int var1 = ((PlayerScreenHandler)((InventoryScreen)this.mc.currentScreen).getScreenHandler()).syncId;
      int var2 = this.totemSlot.getIntValue() - (1);
      if (this.needsOffhand()) {
         int var3 = this.findTotem(
            this.hotbar.getValue() ? var2 : -1, true
         );
         if (var3 != (-1)) {
            this.mc.interactionManager.clickSlot(var1, toHandlerSlot(var3), 40, SlotActionType.SWAP, this.mc.player);
            return true;
         }
      }

      if (this.needsHotbar()) {
         int var4 = this.findTotem(var2, false);
         if (var4 != (-1)) {
            this.mc.interactionManager.clickSlot(var1, toHandlerSlot(var4), var2, SlotActionType.SWAP, this.mc.player);
            return true;
         }
      }

      return false;
   }

   private boolean hasWork() {
      int var1 = this.totemSlot.getIntValue() - (1);
      return (((
               !this.needsOffhand()
                  || this.findTotem(
                        this.hotbar.getValue() ? var1 : -1, true
                     )
                     == (-1)
            )
            && (!this.needsHotbar() || this.findTotem(var1, false) == (-1))
         ? 0
         : 1) != 0);
   }

   private boolean needsOffhand() {
      return ((this.mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING));
   }

   private boolean needsHotbar() {
      if (!this.hotbar.getValue()) {
         return false;
      } else {
         ItemStack var1 = this.mc.player.getInventory().getStack(this.totemSlot.getIntValue() - (1));
         return ((!(var1.getItem() == Items.TOTEM_OF_UNDYING || !var1.isEmpty() && !this.forceTotem.getValue())));
      }
   }

   private int findTotem(int var1, boolean var2) {
      PlayerInventory var3 = this.mc.player.getInventory();

      for (int var4 = 9; var4 < (36); var4++) {
         if (var3.getStack(var4).getItem() == Items.TOTEM_OF_UNDYING) {
            return var4;
         }
      }

      for (int var5 = 0; var5 < (9); var5++) {
         if (var5 != var1 && var3.getStack(var5).getItem() == Items.TOTEM_OF_UNDYING) {
            return var5;
         }
      }

      return var2 && var1 >= 0 && var3.getStack(var1).getItem() == Items.TOTEM_OF_UNDYING ? var1 : -1;
   }

   private static int toHandlerSlot(int var0) {
      return var0 < (9) ? (36) + var0 : var0;
   }

   private void selectTotemSlot() {
      int var1 = this.totemSlot.getIntValue() - (1);
      PlayerInventory var2 = this.mc.player.getInventory();
      if (var2.getStack(var1).getItem() == Items.TOTEM_OF_UNDYING) {
         var2.setSelectedSlot(var1);
      }
   }

   public static enum TotemMode {
      Always,
      OnPop;
   }
}
