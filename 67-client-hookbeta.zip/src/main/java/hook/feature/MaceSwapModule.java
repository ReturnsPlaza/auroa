package hook.feature;

import hook.event.EventListener;
import hook.event.events.AttackEvent;
import hook.event.events.TickEvent;
import hook.module.Category;
import hook.module.Module;
import hook.module.setting.BooleanSetting;
import hook.module.setting.NumberSetting;
import hook.utils.EnchantmentUtil;
import hook.utils.EncryptedString;
import hook.utils.InventoryUtil;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;

public final class MaceSwapModule extends Module {
   private final BooleanSetting enableWindBurst;
   private final BooleanSetting enableBreach;
   private final BooleanSetting onlySword;
   private final BooleanSetting onlyAxe;
   private final BooleanSetting switchBack;
   private final NumberSetting switchDelay;
   private boolean isSwitching;
   private int previousSlot;
   private int currentSwitchDelay;

   public MaceSwapModule() {
      super(EncryptedString.of("Mace Swap"), EncryptedString.of("Switches to a mace when attacking."), -1, Category.COMBAT);
      this.enableWindBurst = new BooleanSetting(EncryptedString.of("Wind Burst"), true);
      this.enableBreach = new BooleanSetting(EncryptedString.of("Breach"), true);
      this.onlySword = new BooleanSetting(EncryptedString.of("Only Sword"), false);
      this.onlyAxe = new BooleanSetting(EncryptedString.of("Only Axe"), false);
      this.switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
      this.switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
      this.addSettings(enableWindBurst, enableBreach, onlySword, onlyAxe, switchBack, switchDelay);
   }

   @Override
   public void onEnable() {
      resetState();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.currentScreen != null || mc.player == null || !isSwitching) {
         return;
      }
      if (switchBack.getValue()) {
         performSwitchBack();
      } else {
         resetState();
      }
   }

   @EventListener
   public void onAttack(AttackEvent event) {
      if (mc.player == null || !isValidWeapon()) {
         return;
      }
      if (previousSlot == -1) {
         previousSlot = mc.player.getInventory().getSelectedSlot();
      }

      boolean useWindBurst = enableWindBurst.getValue();
      boolean useBreach = enableBreach.getValue();
      if (useWindBurst != useBreach) {
         if (enableWindBurst.getValue()) {
            InventoryUtil.swapStack(stack -> EnchantmentUtil.hasEnchantment(stack, Enchantments.WIND_BURST));
         }
         if (enableBreach.getValue()) {
            InventoryUtil.swapStack(stack -> EnchantmentUtil.hasEnchantment(stack, Enchantments.BREACH));
         }
      } else {
         InventoryUtil.swap(Items.MACE);
      }
      isSwitching = true;
   }

   private boolean isValidWeapon() {
      Item item = mc.player.getMainHandStack().getItem();
      if (onlySword.getValue() && onlyAxe.getValue()) {
         return item.getRegistryEntry().isIn(ItemTags.SWORDS) || item instanceof AxeItem;
      }
      if (onlySword.getValue() && !item.getRegistryEntry().isIn(ItemTags.SWORDS)) {
         return false;
      }
      return !onlyAxe.getValue() || item instanceof AxeItem;
   }

   private void performSwitchBack() {
      if (currentSwitchDelay < switchDelay.getIntValue()) {
         currentSwitchDelay++;
      } else {
         InventoryUtil.swap(previousSlot);
         resetState();
      }
   }

   private void resetState() {
      previousSlot = -1;
      currentSwitchDelay = 0;
      isSwitching = false;
   }
}
