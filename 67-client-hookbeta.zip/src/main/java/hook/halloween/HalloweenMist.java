package hook.halloween;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.gl.UniformType;
import net.minecraft.world.LightType;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.Heightmap.Type;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

public final class HalloweenMist {
   private static final int CELL = 7;
   private static final int RANGE = 6;
   private static final float FAR = 40.0F;
   private static final int UBO_SIZE = 96;
   public static final RenderPipeline PIPELINE = RenderPipeline.builder(new Snippet[0])
      .withLocation(Identifier.of("hook", "pipeline/hw_mist"))
      .withVertexShader(HalloweenShaders.MIST)
      .withFragmentShader(HalloweenShaders.MIST)
      .withUniform("Projection", UniformType.UNIFORM_BUFFER)
      .withUniform("Fog", UniformType.UNIFORM_BUFFER)
      .withUniform("MistData", UniformType.UNIFORM_BUFFER)
      .withSampler("Sampler0")
      .withSampler("DepthSampler")
      .withBlend(BlendFunction.TRANSLUCENT)
      .withDepthWrite(false)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withCull(false)
      .withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, DrawMode.QUADS)
      .build();
   private static GpuTexture puff;
   private static GpuTextureView puffView;
   private static GpuBuffer ubo;
   private static ByteBuffer data;
   private static float fade;
   private static long lastNanos;

   private HalloweenMist() {
   }

   private static float hash(int var0, int var1, int var2) {
      int var3 = var0 * 73856093 ^ var1 * 19349663 ^ var2 * 83492791;
      var3 = (var3 ^ var3 >>> 13) * 1274126177;
      return (float)((var3 ^ var3 >>> 16) & 65535) / 65535.0F;
   }

   public static void draw(Camera var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      ClientWorld var2 = var1.world;
      long var3 = System.nanoTime();
      float var5 = lastNanos == 0L ? 0.016F : Math.min(0.1F, (float)(var3 - lastNanos) / 1.0E9F);
      lastNanos = var3;
      float var6 = HalloweenAtmosphere.fogAmount() * HalloweenAtmosphere.outdoor() * HalloweenAtmosphere.nightness();
      fade = fade + (var6 - fade) * (1.0F - (float)Math.exp((double)(-var5 / 0.9F)));
      if (!(fade < 0.004F) && var2 != null && var0 != null && HalloweenSky.hasMatrices()) {
         if (HalloweenShaders.ready(PIPELINE)) {
            try {
               ensure();
               Vec3d var7 = var0.getCameraPos();
               Matrix4f var8 = HalloweenSky.view();
               Matrix4f var9 = new Matrix4f(HalloweenSky.projection()).mul(var8);
               FrustumIntersection var10 = new FrustumIntersection(var9);
               float var11 = var8.m00();
               float var12 = var8.m10();
               float var13 = var8.m20();
               float var14 = var8.m01();
               float var15 = var8.m11();
               float var16 = var8.m21();
               float var17 = ((float)(var2.getTime() % 240000L) + var1.getRenderTickCounter().getTickProgress(false)) / 20.0F;
               float var18 = 1.0F - 0.55F * HalloweenAtmosphere.darkness();
               int var19 = Math.round(150.0F * var18);
               int var20 = Math.round(142.0F * var18);
               int var21 = Math.round(176.0F * var18);
               int var22 = Math.floorDiv((int)Math.floor(var7.x), 7);
               int var23 = Math.floorDiv((int)Math.floor(var7.z), 7);
               BufferBuilder var24 = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               int var25 = 0;
               Mutable var26 = new Mutable();

               for (int var27 = -6; var27 <= 6; var27++) {
                  for (int var28 = -6; var28 <= 6; var28++) {
                     int var29 = var22 + var27;
                     int var30 = var23 + var28;

                     for (int var31 = 0; var31 < 2; var31++) {
                        float var32 = hash(var29, var30, var31);
                        if (!(var32 < 0.18F)) {
                           float var33 = (var32 * 7.0F + var17 * (0.035F + 0.02F * var32)) % 1.0F;
                           float var34 = (float)Math.sin(Math.PI * (double)var33);
                           double var35 = (double)((float)(var29 * 7) + hash(var29, var30, 9 + var31) * 7.0F) + (double)(var33 * 7.0F) * 0.9;
                           double var37 = (double)((float)(var30 * 7) + hash(var29, var30, 17 + var31) * 7.0F) + (double)(var33 * 7.0F) * 0.35;
                           int var39 = (int)Math.floor(var35);
                           int var40 = (int)Math.floor(var37);
                           if (var2.isChunkLoaded(var39 >> 4, var40 >> 4)) {
                              int var41 = var2.getTopY(Type.MOTION_BLOCKING, var39, var40);
                              double var42 = (double)var41 + 0.55 + (double)var31 * 0.9 + (double)hash(var29, var30, 31 + var31) * 0.8;
                              double var44 = var42 - var7.y;
                              if (!(var44 > 22.0) && !(var44 < -26.0)) {
                                 float var46 = 3.2F + var32 * 3.4F + (float)var31 * 1.2F;
                                 float var47 = (float)(var35 - var7.x);
                                 float var48 = (float)var44;
                                 float var49 = (float)(var37 - var7.z);
                                 float var50 = (float)Math.sqrt((double)(var47 * var47 + var49 * var49));
                                 float var51 = 1.0F - smooth((var50 - 28.0F) / 12.0F);
                                 if (!(var51 <= 0.0F) && var10.testSphere(var47, var48, var49, var46 * 1.2F)) {
                                    var26.set(var39, var41, var40);
                                    float var52 = (float)var2.getLightLevel(LightType.BLOCK, var26) / 15.0F;
                                    float var53 = (0.1F + 0.1F * var32) * fade * var34 * var51 * (1.0F - 0.65F * var52);
                                    if (!(var53 < 0.003F)) {
                                       int var54 = Math.min(255, Math.round(var53 * 255.0F));
                                       float var55 = var31 == 0 ? 0.0F : 1.0F;
                                       float var56 = 1.0F - var55;
                                       var24.vertex(
                                             var47 - var11 * var46 - var14 * var46,
                                             var48 - var12 * var46 - var15 * var46,
                                             var49 - var13 * var46 - var16 * var46
                                          )
                                          .texture(var55, 1.0F)
                                          .color(var19, var20, var21, var54);
                                       var24.vertex(
                                             var47 + var11 * var46 - var14 * var46,
                                             var48 + var12 * var46 - var15 * var46,
                                             var49 + var13 * var46 - var16 * var46
                                          )
                                          .texture(var56, 1.0F)
                                          .color(var19, var20, var21, var54);
                                       var24.vertex(
                                             var47 + var11 * var46 + var14 * var46,
                                             var48 + var12 * var46 + var15 * var46,
                                             var49 + var13 * var46 + var16 * var46
                                          )
                                          .texture(var56, 0.0F)
                                          .color(var19, var20, var21, var54);
                                       var24.vertex(
                                             var47 - var11 * var46 + var14 * var46,
                                             var48 - var12 * var46 + var15 * var46,
                                             var49 - var13 * var46 + var16 * var46
                                          )
                                          .texture(var55, 0.0F)
                                          .color(var19, var20, var21, var54);
                                       var25++;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               BuiltBuffer var62 = var24.endNullable();
               if (var62 == null || var25 == 0) {
                  if (var62 != null) {
                     var62.close();
                  }

                  return;
               }

               BuiltBuffer var63 = var62;

               try {
                  MinecraftClient var64 = MinecraftClient.getInstance();
                  Framebuffer var65 = var64.getFramebuffer();
                  Matrix4f var66 = HalloweenSky.projection();
                  float var67 = var66.m32() / (var66.m22() - 1.0F);
                  float var68 = var66.m32() / (var66.m22() + 1.0F);
                  data.clear();
                  var8.get(0, data);
                  HalloweenSky.put4(data, 64, var67, var68, 1.6F, 0.0F);
                  HalloweenSky.put4(data, 80, (float)var65.textureWidth, (float)var65.textureHeight, 0.0F, 0.0F);
                  data.position(0);
                  data.limit(96);
                  CommandEncoder var69 = RenderSystem.getDevice().createCommandEncoder();
                  var69.writeToBuffer(ubo.slice(), data);
                  GpuBuffer var70 = PIPELINE.getVertexFormat().uploadImmediateVertexBuffer(var62.getBuffer());
                  ShapeIndexBuffer var36 = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
                  GpuBuffer var71 = var36.getIndexBuffer(var62.getDrawParameters().indexCount());
                  GpuTextureView var38 = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : var65.getColorAttachmentView();
                  RenderPass var72 = var69.createRenderPass(() -> "Hook Halloween mist", var38, OptionalInt.empty());

                  try {
                     var72.setPipeline(PIPELINE);
                     RenderSystem.bindDefaultUniforms(var72);
                     var72.setUniform("MistData", ubo);
                     var72.bindTexture("Sampler0", puffView, RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
                     var72.bindTexture("DepthSampler", var65.getDepthAttachmentView(), RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
                     var72.setVertexBuffer(0, var70);
                     var72.setIndexBuffer(var71, var36.getIndexType());
                     var72.drawIndexed(0, 0, var62.getDrawParameters().indexCount(), 1);
                  } catch (Throwable var59) {
                     if (var72 != null) {
                        try {
                           var72.close();
                        } catch (Throwable var58) {
                           var59.addSuppressed(var58);
                        }
                     }

                     throw var59;
                  }

                  if (var72 != null) {
                     var72.close();
                  }
               } catch (Throwable var60) {
                  if (var62 != null) {
                     try {
                        var63.close();
                     } catch (Throwable var57) {
                        var60.addSuppressed(var57);
                     }
                  }

                  throw var60;
               }

               if (var62 != null) {
                  var62.close();
               }
            } catch (Throwable var61) {
               System.err.println("Hook: Halloween mist skipped: " + var61);
            }
         }
      }
   }

   private static float smooth(float var0) {
      var0 = Math.max(0.0F, Math.min(1.0F, var0));
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   private static void ensure() {
      if (puff == null) {
         GpuDevice var0 = RenderSystem.getDevice();
         byte var1 = 96;
         puff = var0.createTexture(() -> "Hook mist puff", 5, TextureFormat.RGBA8, var1, var1, 1, 1);
         NativeImage var2 = new NativeImage(var1, var1, false);

         try {
            for (int var3 = 0; var3 < var1; var3++) {
               for (int var4 = 0; var4 < var1; var4++) {
                  float var5 = ((float)var4 + 0.5F) / (float)var1 * 2.0F - 1.0F;
                  float var6 = ((float)var3 + 0.5F) / (float)var1 * 2.0F - 1.0F;
                  float var7 = (float)Math.sqrt((double)(var5 * var5 + var6 * var6));
                  float var8 = Math.max(0.0F, 1.0F - var7);
                  var8 = var8 * var8 * (3.0F - 2.0F * var8);
                  float var9 = 0.0F;
                  float var10 = 0.5F;
                  float var11 = 2.5F;

                  for (int var12 = 0; var12 < 4; var12++) {
                     var9 += var10 * valueNoise(var5 * var11 + (float)var12 * 3.1F, var6 * var11 - (float)var12 * 1.7F);
                     var10 *= 0.5F;
                     var11 *= 2.1F;
                  }

                  float var17 = Math.max(0.0F, Math.min(1.0F, var8 * (0.55F + 0.75F * var9)));
                  int var13 = Math.round(var17 * 255.0F);
                  var2.setColorArgb(var4, var3, var13 << 24 | var13 << 16 | var13 << 8 | var13);
               }
            }

            var0.createCommandEncoder().writeToTexture(puff, var2);
         } catch (Throwable var15) {
            try {
               var2.close();
            } catch (Throwable var14) {
               var15.addSuppressed(var14);
            }

            throw var15;
         }

         var2.close();
         puffView = var0.createTextureView(puff);
         ubo = var0.createBuffer(() -> "Hook Halloween mist", 136, 96L);
         data = BufferUtils.createByteBuffer(96);
      }
   }

   private static float valueNoise(float var0, float var1) {
      int var2 = (int)Math.floor((double)var0);
      int var3 = (int)Math.floor((double)var1);
      float var4 = var0 - (float)var2;
      float var5 = var1 - (float)var3;
      var4 = var4 * var4 * (3.0F - 2.0F * var4);
      var5 = var5 * var5 * (3.0F - 2.0F * var5);
      float var6 = hash(var2, var3, 5);
      float var7 = hash(var2 + 1, var3, 5);
      float var8 = hash(var2, var3 + 1, 5);
      float var9 = hash(var2 + 1, var3 + 1, 5);
      return var6 + (var7 - var6) * var4 + (var8 - var6) * var5 + (var6 - var7 - var8 + var9) * var4 * var5;
   }

   public static void release() {
      for (AutoCloseable var3 : new AutoCloseable[]{puffView, puff, ubo}) {
         if (var3 != null) {
            try {
               var3.close();
            } catch (Throwable var5) {
            }
         }
      }

      puffView = null;
      puff = null;
      ubo = null;
      data = null;
      fade = 0.0F;
   }
}
