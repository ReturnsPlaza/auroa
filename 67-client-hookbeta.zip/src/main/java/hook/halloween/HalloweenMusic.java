package hook.halloween;

import it.unimi.dsi.fastutil.floats.FloatConsumer;
import java.io.BufferedInputStream;
import java.io.InputStream;
import net.minecraft.client.sound.OggAudioStream;
import hook.feature.UiAudio;

public final class HalloweenMusic {
   static final int SR = 44100;
   private static final float MENU_FADE_IN = 1.8F;
   private static final float MENU_FADE_OUT = 5.0F;
   private static final float EVENT_FADE_IN = 2.6F;
   private static final float EVENT_HOLD = 56.0F;
   private static final float EVENT_FADE_OUT = 5.5F;
   static final HalloweenMusic.Track MENU = new HalloweenMusic.Track("/assets/hook/music/halloween_menu.ogg", true);
   static final HalloweenMusic.Track EVENT = new HalloweenMusic.Track("/assets/hook/music/halloween_event.ogg", false);
   private static volatile boolean menuWanted;
   private static volatile float menuVolume = 0.35F;
   private static volatile float eventVolume = 0.6F;
   private static volatile boolean eventRequested;
   private static volatile boolean eventStopRequested;
   private static volatile boolean beatEnabled = true;
   private static final int BEATS = 32;
   private static final long[] beatFrame = new long[32];
   private static final float[] beatStrength = new float[32];
   private static volatile int beatHead;

   private HalloweenMusic() {
   }

   public static void setMenuWanted(boolean var0, float var1) {
      menuVolume = Math.max(0.0F, Math.min(1.0F, var1));
      if (var0 != menuWanted) {
         menuWanted = var0;
      }

      if (var0 || MENU.playing) {
         UiAudio.wake();
      }
   }

   public static void setEventVolume(float var0) {
      eventVolume = Math.max(0.0F, Math.min(1.0F, var0));
   }

   public static void playEvent(float var0) {
      setEventVolume(var0);
      if (!EVENT.playing || EVENT.stopping) {
         eventRequested = true;
         UiAudio.wake();
      }
   }

   public static void stopEvent() {
      if (EVENT.playing) {
         eventStopRequested = true;
         UiAudio.wake();
      }
   }

   public static boolean eventPlaying() {
      return EVENT.playing || eventRequested;
   }

   public static boolean menuPlaying() {
      return MENU.playing;
   }

   public static boolean active() {
      return MENU.playing || EVENT.playing || menuWanted || eventRequested;
   }

   public static boolean replacesAmbience() {
      return menuWanted || MENU.playing && MENU.level > 0.02F;
   }

   public static void setBeatEnabled(boolean var0) {
      beatEnabled = var0;
   }

   public static float beat() {
      if (MENU.playing && beatEnabled) {
         long var0 = UiAudio.heardFrame();
         float var2 = 0.0F;
         int var3 = beatHead;

         for (int var4 = 0; var4 < 32; var4++) {
            int var5 = (var3 - 1 - var4 + 32) % 32;
            float var6 = beatStrength[var5];
            if (!(var6 <= 0.0F)) {
               float var7 = (float)(var0 - beatFrame[var5]) / 44100.0F;
               if (!(var7 < 0.0F)) {
                  if (var7 > 1.2F) {
                     break;
                  }

                  float var8 = Math.min(1.0F, var7 / 0.035F);
                  var8 = var8 * var8 * (3.0F - 2.0F * var8);
                  var2 = Math.max(var2, var6 * var8 * (float)Math.exp((double)(-var7 / 0.22F)));
               }
            }
         }

         return var2 * smoothLevel(MENU.level);
      } else {
         return 0.0F;
      }
   }

   private static float smoothLevel(float var0) {
      var0 = Math.max(0.0F, Math.min(1.0F, var0));
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   public static void mix(float[] var0, int var1, float var2, long var3) {
      HalloweenMusic.Track var5 = MENU;
      boolean var6 = menuWanted && !EVENT.playing;
      if (var6 && !var5.playing) {
         var5.resume();
      }

      if (var5.playing) {
         var5.target = var6 ? 1.0F : 0.0F;
         var5.rateUp = 1.2597631E-5F;
         var5.rateDown = 1.0F / (44100.0F * (EVENT.playing ? 2.0F : 5.0F));
         var5.mix(var0, var1, menuVolume * var2, true, var3);
         if (!var6 && var5.level <= 0.0F) {
            var5.pause();
         }
      }

      HalloweenMusic.Track var7 = EVENT;
      if (eventRequested) {
         eventRequested = false;
         if (!var7.playing) {
            var7.open();
         }

         var7.stopping = false;
         var7.target = 1.0F;
      }

      if (eventStopRequested) {
         eventStopRequested = false;
         if (var7.playing) {
            var7.stopping = true;
         }
      }

      if (var7.playing) {
         float var8 = (float)var7.frames / 44100.0F;
         if (var8 >= 58.6F) {
            var7.stopping = true;
         }

         var7.target = var7.stopping ? 0.0F : 1.0F;
         var7.rateUp = 8.721438E-6F;
         var7.rateDown = 1.0F / (44100.0F * (var8 >= 56.0F ? 5.5F : 2.4F));
         var7.mix(var0, var1, eventVolume * var2, false, var3);
         if (var7.stopping && var7.level <= 0.0F || var7.ended) {
            var7.close();
         }
      }
   }

   static void recordBeat(long var0, float var2) {
      int var3 = beatHead;
      beatFrame[var3] = var0;
      beatStrength[var3] = var2;
      beatHead = (var3 + 1) % 32;
   }

   public static void closeAll() {
      MENU.close();
      EVENT.close();
      menuWanted = false;
      eventRequested = false;
      eventStopRequested = false;
   }

   static final class Track implements FloatConsumer {
      final String path;
      final boolean loop;
      volatile boolean playing;
      volatile boolean stopping;
      volatile float level;
      boolean ended;
      float target;
      float rateUp;
      float rateDown;
      long frames;
      private OggAudioStream stream;
      private float[] buf = new float[8192];
      private int len;
      private int pos;
      private float gain = -1.0F;
      private float lp1;
      private float lp2;
      private float energySlow = 1.0E-4F;
      private float energyBlock;
      private int energyCount;
      private long lastBeat = -44100L;

      Track(String var1, boolean var2) {
         this.path = var1;
         this.loop = var2;
      }

      void resume() {
         if (this.stream != null && !this.ended) {
            this.playing = true;
            this.stopping = false;
         } else {
            this.open();
         }
      }

      void pause() {
         this.playing = false;
         this.stopping = false;
         this.level = 0.0F;
      }

      void open() {
         this.closeStream();

         try {
            InputStream var1 = HalloweenMusic.class.getResourceAsStream(this.path);
            if (var1 == null) {
               System.err.println("Hook: missing " + this.path);
               return;
            }

            this.stream = new OggAudioStream(new BufferedInputStream(var1, 32768));
            this.playing = true;
            this.stopping = false;
            this.ended = false;
            this.level = 0.0F;
            this.frames = 0L;
            this.len = 0;
            this.pos = 0;
            this.gain = -1.0F;
         } catch (Throwable var2) {
            System.err.println("Hook: could not open " + this.path + ": " + var2);
            this.closeStream();
            this.playing = false;
         }
      }

      void close() {
         this.closeStream();
         this.playing = false;
         this.stopping = false;
         this.level = 0.0F;
         this.len = 0;
         this.pos = 0;
      }

      private void closeStream() {
         if (this.stream != null) {
            try {
               this.stream.close();
            } catch (Throwable var2) {
            }

            this.stream = null;
         }
      }

      public void accept(float var1) {
         if (this.len == this.buf.length) {
            float[] var2 = new float[this.buf.length * 2];
            System.arraycopy(this.buf, 0, var2, 0, this.len);
            this.buf = var2;
         }

         this.buf[this.len++] = var1;
      }

      private boolean ensure() {
         while (this.pos + 1 >= this.len) {
            if (this.stream == null) {
               return false;
            }

            this.len = 0;
            this.pos = 0;

            try {
               if (!this.stream.read(this)) {
                  if (!this.loop) {
                     this.ended = true;
                     return false;
                  }

                  this.closeStream();
                  InputStream var1 = HalloweenMusic.class.getResourceAsStream(this.path);
                  if (var1 == null) {
                     return false;
                  }

                  this.stream = new OggAudioStream(new BufferedInputStream(var1, 32768));
               }
            } catch (Throwable var2) {
               System.err.println("Hook: music decode failed: " + var2);
               this.ended = true;
               this.closeStream();
               return false;
            }
         }

         return true;
      }

      void mix(float[] var1, int var2, float var3, boolean var4, long var5) {
         if (this.gain < 0.0F) {
            this.gain = var3;
         }

         for (int var7 = 0; var7 < var2; var7++) {
            if (this.target <= 0.0F && this.level <= 0.0F) {
               return;
            }

            if (!this.ensure()) {
               this.level = 0.0F;
               return;
            }

            float var8 = this.buf[this.pos++];
            float var9 = this.buf[this.pos++];
            this.frames++;
            this.level = this.target > this.level ? Math.min(this.target, this.level + this.rateUp) : Math.max(this.target, this.level - this.rateDown);
            this.gain = this.gain + (var3 - this.gain) * 2.0E-4F;
            float var10 = HalloweenMusic.smoothLevel(this.level) * this.gain;
            var1[var7 * 2] = var1[var7 * 2] + var8 * var10;
            var1[var7 * 2 + 1] = var1[var7 * 2 + 1] + var9 * var10;
            if (var4) {
               float var11 = (var8 + var9) * 0.5F;
               this.lp1 = this.lp1 + 0.017F * (var11 - this.lp1);
               this.lp2 = this.lp2 + 0.017F * (this.lp1 - this.lp2);
               this.energyBlock = this.energyBlock + this.lp2 * this.lp2;
               this.energyCount++;
               if (this.energyCount == 256) {
                  float var12 = this.energyBlock / 256.0F;
                  this.energyBlock = 0.0F;
                  this.energyCount = 0;
                  long var13 = var5 + (long)var7;
                  float var15 = var12 / (this.energySlow + 1.0E-7F);
                  this.energySlow = this.energySlow + (var12 - this.energySlow) * 0.0083F;
                  if (var15 > 1.55F && (float)(var13 - this.lastBeat) > 10584.0F && var12 > 2.0E-5F) {
                     this.lastBeat = var13;
                     float var16 = Math.min(1.0F, (var15 - 1.55F) / 1.6F + 0.35F);
                     HalloweenMusic.recordBeat(var13, var16);
                  }
               }
            }
         }
      }
   }
}
