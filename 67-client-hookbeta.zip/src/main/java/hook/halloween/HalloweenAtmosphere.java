package hook.halloween;

import net.minecraft.world.World;
import net.minecraft.world.LightType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.dimension.DimensionType.Skybox;
import net.minecraft.world.Heightmap.Type;
import org.joml.Vector3f;
import org.joml.Vector4f;
import hook.feature.HalloweenModule;

public final class HalloweenAtmosphere {
   private static final double NIGHT = 15200.0;
   private static final int NONE = 0;
   private static final int TO_NIGHT = 1;
   private static final int HOLD = 2;
   private static final int TO_REAL = 3;
   private static boolean wanted;
   private static float raw;
   private static int mode = 0;
   private static double from;
   private static double delta;
   private static double progress;
   private static double duration = 1.0;
   private static double vis;
   private static float outdoor = 1.0F;
   private static float under;
   private static boolean underValid;
   private static float lit;
   private static final Mutable PROBE = new Mutable();
   private static final int[] PROBES = new int[]{0, 0, 0, 0, 2, 0, 0, 6, 0, 3, 1, 0, -3, 1, 0, 0, 1, 3, 0, 1, -3};
   private static final int[] COLUMNS = new int[]{0, 0, 4, 0, -4, 0, 0, 4, 0, -4};
   private static float moonAngle;
   private static boolean moonValid;
   private static World world;

   private HalloweenAtmosphere() {
   }

   public static void setWanted(boolean var0) {
      wanted = var0;
      if (!var0 && (mode == 1 || mode == 2)) {
         beginToReal();
      }
   }

   public static float strength() {
      float var0 = Math.max(0.0F, Math.min(1.0F, raw));
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   public static float darkness() {
      return strength() * (float)(HalloweenModule.darkness.getValue() / 100.0) * (0.35F + 0.65F * nightness());
   }

   public static float nightness() {
      double var0 = mode != 0 ? mod(vis) : (world != null ? mod((double)world.getLevelProperties().getTimeOfDay()) : 18000.0);
      if (var0 >= 12000.0 && var0 < 13800.0) {
         return (float)smooth((var0 - 12000.0) / 1800.0);
      } else if (var0 >= 13800.0 && var0 < 22200.0) {
         return 1.0F;
      } else {
         return var0 >= 22200.0 ? (float)smooth((24000.0 - var0) / 1800.0) : 0.0F;
      }
   }

   private static double mod(double var0) {
      double var2 = var0 % 24000.0;
      return var2 < 0.0 ? var2 + 24000.0 : var2;
   }

   private static double smooth(double var0) {
      var0 = Math.max(0.0, Math.min(1.0, var0));
      return var0 * var0 * var0 * (var0 * (var0 * 6.0 - 15.0) + 10.0);
   }

   private static boolean skyWorld(ClientWorld var0) {
      try {
         return var0.getDimension().skybox() == Skybox.OVERWORLD && var0.getDimension().hasSkyLight();
      } catch (Throwable var2) {
         return false;
      }
   }

   public static void frame(float var0, MinecraftClient var1) {
      ClientWorld var2 = var1.world;
      if (var2 != world) {
         world = var2;
         mode = 0;
         raw = 0.0F;
         outdoor = 1.0F;
         under = 0.0F;
         underValid = false;
         lit = 0.0F;
         moonValid = false;
      }

      if (var2 != null) {
         float var3 = wanted ? 1.0F : 0.0F;
         float var4 = var0 / 3.2F;
         raw = raw < var3 ? Math.min(var3, raw + var4) : Math.max(var3, raw - var4);
         boolean var5 = skyWorld(var2);
         double var6 = (double)var2.getLevelProperties().getTimeOfDay();
         if (wanted && var5 && (mode == 0 || mode == 3)) {
            beginToNight(var6);
         }

         if (!var5 && mode != 0) {
            mode = 0;
         }

         switch (mode) {
            case 1:
               progress = progress + (double)var0 / duration;
               vis = from + delta * smooth(progress);
               if (progress >= 1.0) {
                  mode = 2;
                  vis = from + delta;
               }
               break;
            case 3:
               double var8 = mod(var6 - mod(from));
               if (var8 > 21000.0) {
                  var8 -= 24000.0;
               }

               progress = progress + (double)var0 / duration;
               vis = from + var8 * smooth(progress);
               if (progress >= 1.0) {
                  mode = 0;
               }
         }

         Camera var12 = var1.gameRenderer.getCamera();
         if (var12 != null && var12.isReady()) {
            Vec3d var9 = var12.getCameraPos();
            float var10 = var5 ? measureUnder(var2, var9) : 0.0F;
            if (!underValid) {
               under = var10;
               underValid = true;
            } else {
               under = under + (var10 - under) * (1.0F - (float)Math.exp((double)(-var0 / 1.4F)));
            }

            outdoor = 1.0F - under;
            int var11 = var2.getLightLevel(LightType.BLOCK, BlockPos.ofFloored(var9));
            lit = lit + ((float)var11 / 15.0F - lit) * (1.0F - (float)Math.exp((double)(-var0 / 0.9F)));
         }
      }
   }

   private static float measureUnder(ClientWorld var0, Vec3d var1) {
      int var2 = MathHelper.floor(var1.x);
      int var3 = MathHelper.floor(var1.y);
      int var4 = MathHelper.floor(var1.z);
      float var5 = 0.0F;
      float var6 = 0.0F;

      for (byte var7 = 0; var7 < PROBES.length; var7 += 3) {
         PROBE.set(var2 + PROBES[var7], var3 + PROBES[var7 + 1], var4 + PROBES[var7 + 2]);
         int var8 = var0.getLightLevel(LightType.SKY, PROBE);
         var5 += (float)var8;
         var6 = Math.max(var6, (float)var8);
      }

      float var11 = (0.6F * var5 / (float)(PROBES.length / 3) + 0.4F * var6) / 15.0F;
      float var12 = 1.0F - (float)smooth((double)((var11 - 0.3F) / 0.56F));
      float var9 = 0.0F;

      for (byte var10 = 0; var10 < COLUMNS.length; var10 += 2) {
         var9 += (float)var0.getTopY(Type.MOTION_BLOCKING_NO_LEAVES, var2 + COLUMNS[var10], var4 + COLUMNS[var10 + 1]);
      }

      var9 /= (float)(COLUMNS.length / 2);
      float var14 = Math.max(0.0F, Math.min(1.0F, (var9 - (float)var1.y - 1.0F) / 12.0F));
      return var12 * (0.6F + 0.4F * var14);
   }

   private static void beginToNight(double var0) {
      double var2 = mode == 3 ? vis : var0;
      double var4 = mod(var2);
      double var6;
      if (var4 >= 12500.0) {
         var6 = 15200.0 - var4;
         if (var6 < -11000.0) {
            var6 += 24000.0;
         }
      } else {
         var6 = mod(15200.0 - var4);
      }

      double var8 = 0.0;
      if (var4 < 11000.0) {
         long var10 = (long)Math.floor((var2 + var6) / 24000.0);
         var8 = (double)(-Math.floorMod(var10, 8L)) * 24000.0;
      }

      from = var2 + var8;
      delta = var6;
      progress = 0.0;
      duration = Math.max(2.6, Math.min(8.5, 2.6 + Math.abs(var6) / 13000.0 * 6.0));
      vis = from;
      mode = 1;
   }

   private static void beginToReal() {
      if (world == null) {
         mode = 0;
      } else {
         double var0 = (double)world.getLevelProperties().getTimeOfDay();
         double var2 = mod(var0 - mod(vis));
         from = vis;
         progress = 0.0;
         duration = Math.max(2.6, Math.min(7.0, 2.6 + Math.abs(var2 > 21000.0 ? var2 - 24000.0 : var2) / 13000.0 * 5.0));
         mode = 3;
      }
   }

   public static long timeOfDay(World var0, long var1) {
      return mode != 0 && var0 == world ? (long)Math.floor(vis) : var1;
   }

   public static float lightmap(int var0, float var1) {
      float var2 = strength();
      if (var2 <= 0.0F) {
         return var1;
      } else {
         float var3 = darkness();
         float var4 = under;

         return switch (var0) {
            case 1 -> var1 * (1.0F - 0.66F * var3);
            case 2 -> var1 * (1.0F - 0.3F * var3 * (1.0F - 0.6F * var4));
            case 3 -> var1 * (1.0F - var2) + var2 * ambientFloor(var4);
            default -> var1;
            case 5 -> var1 + (1.0F - var1) * 0.4F * var3 * (1.0F - var4);
            case 6 -> var1 * (1.0F - var2);
         };
      }
   }

   private static float ambientFloor(float var0) {
      float var1 = (float)(HalloweenModule.darkness.getValue() / 100.0);
      float var2 = 0.066F;
      float var3 = 0.19F - 0.045F * var1;
      float var4 = var2 + (var3 - var2) * var0;
      return Math.max(0.0F, ((var4 - 0.03F) / 0.96F - 0.03F) / 0.97F);
   }

   public static Vector3f skyLight(Vector3f var0) {
      float var1 = strength();
      if (var1 > 0.0F) {
         var0.mul(1.0F + -0.19999999F * var1, 1.0F + -0.24000001F * var1, 1.0F + 0.059999943F * var1);
      }

      return var0;
   }

   public static float fogAmount() {
      float var0 = strength();
      if (var0 <= 0.0F) {
         return 0.0F;
      } else {
         float var1 = (float)(HalloweenModule.fogDensity.getValue() / 100.0);
         return var0 * (float)Math.pow((double)var1, 0.8) * (0.18F + 0.82F * outdoor) * (0.4F + 0.6F * nightness());
      }
   }

   private static float nearEnd() {
      float var0 = (float)(HalloweenModule.fogDensity.getValue() / 100.0);
      return (150.0F + -126.0F * var0) * (1.0F + 0.6F * lit);
   }

   public static void fog(float[] var0, Vector4f var1) {
      float var2 = fogAmount();
      if (!(var2 <= 0.0F)) {
         float var3 = nearEnd();
         var0[0] = lerp(var0[0], Math.min(var0[0], var3 * 0.03F), var2);
         var0[1] = lerp(var0[1], Math.min(var0[1], var3), var2);
         var0[4] = lerp(var0[4], Math.min(var0[4], var3 * 1.45F), var2);
         var0[5] = lerp(var0[5], Math.min(var0[5], var3 * 2.2F), var2);
         float var4 = var2 * 0.9F;
         var1.x = lerp(var1.x, 0.08F, var4);
         var1.y = lerp(var1.y, 0.066F, var4);
         var1.z = lerp(var1.z, 0.108F, var4);
      }
   }

   private static float lerp(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   public static int skyColor(int var0) {
      return mixRgb(var0, 1510692, strength() * 0.78F * nightness());
   }

   public static int sunset(int var0) {
      return var0 & 0xFF000000 | mixRgb(var0, 16735778, strength() * 0.8F) & 16777215;
   }

   public static int clouds(int var0) {
      float var1 = strength() * (0.3F + 0.7F * nightness());
      int var2 = Math.round((float)(var0 >>> 24) * (1.0F - 0.6F * var1));
      return var2 << 24 | mixRgb(var0, 2761270, var1 * 0.85F) & 16777215;
   }

   public static float stars(float var0) {
      return var0 * (1.0F + 0.35F * strength());
   }

   private static int mixRgb(int var0, int var1, float var2) {
      var2 = Math.max(0.0F, Math.min(1.0F, var2));
      int var3 = Math.round((float)(var0 >> 16 & 0xFF) + (float)((var1 >> 16 & 0xFF) - (var0 >> 16 & 0xFF)) * var2);
      int var4 = Math.round((float)(var0 >> 8 & 0xFF) + (float)((var1 >> 8 & 0xFF) - (var0 >> 8 & 0xFF)) * var2);
      int var5 = Math.round((float)(var0 & 0xFF) + (float)((var1 & 0xFF) - (var0 & 0xFF)) * var2);
      return var0 & 0xFF000000 | var3 << 16 | var4 << 8 | var5;
   }

   public static void moonAngle(float var0) {
      moonAngle = var0;
      moonValid = true;
   }

   public static Vector4f moonDir() {
      if (!moonValid) {
         return new Vector4f(0.0F, 1.0F, 0.0F, 0.0F);
      } else {
         float var0 = -((float)Math.sin((double)moonAngle));
         float var1 = (float)Math.cos((double)moonAngle);
         return new Vector4f(var0, var1, 0.0F, Math.max(0.0F, Math.min(1.0F, (var1 + 0.08F) / 0.25F)));
      }
   }

   public static float outdoor() {
      return outdoor;
   }

   public static float under() {
      return under;
   }

   public static float lit() {
      return lit;
   }

   public static boolean overridingTime() {
      return mode != 0;
   }
}
