package hook.halloween;

import net.minecraft.client.util.Window;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import hook.feature.UiIcon;
import hook.feature.MinecraftUiRenderer;
import hook.feature.UiRenderer;

public final class CinematicOverlay {
   private static boolean barsWanted;
   private static float bars;
   private static boolean hudWanted = true;
   private static boolean hudShown = true;
   private static float dip = -1.0F;
   private static float vignette;
   private static float notice;
   private static String noticeText = "";

   private CinematicOverlay() {
   }

   public static void cinematic(boolean var0) {
      barsWanted = var0;
      if (hudWanted == var0) {
         hudWanted = !var0;
         if (dip < 0.0F) {
            dip = 0.0F;
         }
      }
   }

   public static void reset() {
      barsWanted = false;
      bars = 0.0F;
      hudWanted = true;
      hudShown = true;
      dip = -1.0F;
      vignette = 0.0F;
   }

   public static void notice(String var0) {
      noticeText = var0;
      notice = 2.2F;
   }

   public static boolean hideHud() {
      return !hudShown;
   }

   public static boolean visible() {
      return bars > 0.001F || dip >= 0.0F || notice > 0.0F || vignette > 0.001F;
   }

   public static void frame(float var0) {
      float var1 = barsWanted ? 1.0F : 0.0F;
      bars = bars < var1 ? Math.min(var1, bars + var0 / 0.85F) : Math.max(var1, bars - var0 / 0.75F);
      vignette = vignette < var1 ? Math.min(var1, vignette + var0 / 1.4F) : Math.max(var1, vignette - var0 / 0.9F);
      if (dip >= 0.0F) {
         dip += var0 / 0.7F;
         if (dip >= 0.5F && hudShown != hudWanted) {
            hudShown = hudWanted;
         }

         if (dip >= 1.0F) {
            dip = -1.0F;
            hudShown = hudWanted;
         }
      }

      if (notice > 0.0F) {
         notice -= var0;
      }
   }

   private static float smooth(float var0) {
      var0 = Math.max(0.0F, Math.min(1.0F, var0));
      return var0 * var0 * var0 * (var0 * (var0 * 6.0F - 15.0F) + 10.0F);
   }

   public static void render(DrawContext var0) {
      if (visible()) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         Window var2 = var1.getWindow();
         int var3 = var2.getFramebufferWidth();
         int var4 = var2.getFramebufferHeight();
         float var5 = (float)var2.getScaleFactor();
         var0.getMatrices().pushMatrix();
         var0.getMatrices().scale(1.0F / var5, 1.0F / var5);

         try {
            MinecraftUiRenderer var6 = new MinecraftUiRenderer(var0, var5);
            float var7 = smooth(vignette);
            if (var7 > 0.001F) {
               float var8 = (float)Math.max(var3, var4);
               var6.glow(0.0F, 0.0F, var8 * 0.55F, UiRenderer.argb(0.42F * var7, 0, 0, 0));
               var6.glow((float)var3, 0.0F, var8 * 0.55F, UiRenderer.argb(0.42F * var7, 0, 0, 0));
               var6.glow(0.0F, (float)var4, var8 * 0.55F, UiRenderer.argb(0.42F * var7, 0, 0, 0));
               var6.glow((float)var3, (float)var4, var8 * 0.55F, UiRenderer.argb(0.42F * var7, 0, 0, 0));
            }

            float var20 = smooth(bars);
            if (var20 > 0.001F) {
               float var9 = (float)var4 * 0.105F * var20;
               float var10 = (float)var4 * 0.02F;
               var6.rect(0.0F, 0.0F, (float)var3, var9, UiRenderer.argb(0.97F, 3, 2, 5));
               var6.gradient(0.0F, var9, (float)var3, var10, UiRenderer.argb(0.55F * var20, 3, 2, 5), UiRenderer.argb(0.0F, 3, 2, 5));
               var6.rect(0.0F, (float)var4 - var9, (float)var3, var9, UiRenderer.argb(0.97F, 3, 2, 5));
               var6.gradient(
                  0.0F, (float)var4 - var9 - var10, (float)var3, var10, UiRenderer.argb(0.0F, 3, 2, 5), UiRenderer.argb(0.55F * var20, 3, 2, 5)
               );
            }

            if (dip >= 0.0F) {
               float var21 = (float)Math.sin(Math.PI * (double)Math.min(1.0F, dip));
               var6.rect(0.0F, 0.0F, (float)var3, (float)var4, UiRenderer.argb(0.72F * var21 * var21, 2, 1, 4));
            }

            if (notice > 0.0F) {
               float var22 = Math.min(1.0F, notice / 0.4F) * Math.min(1.0F, (2.2F - notice) / 0.25F);
               float var23 = (float)var4 / 1080.0F;
               float var11 = 15.0F * var23;
               float var12 = var6.textWidth(noticeText, var11, 0);
               float var13 = var12 + 64.0F * var23;
               float var14 = 40.0F * var23;
               float var15 = ((float)var3 - var13) / 2.0F;
               float var16 = (float)var4 * 0.13F + (1.0F - var22) * 8.0F * var23;
               var6.pushAlpha(var22);
               var6.shadow(var15, var16, var13, var14, var14 / 2.0F, 16.0F * var23, UiRenderer.argb(0.45F, 0, 0, 0));
               var6.round(var15, var16, var13, var14, var14 / 2.0F, UiRenderer.argb(0.86F, 24, 16, 28));
               var6.outline(var15, var16, var13, var14, var14 / 2.0F, Math.max(1.0F, var23), UiRenderer.argb(0.5F, 255, 150, 70));
               var6.icon(
                  UiIcon.MONITOR, var15 + 18.0F * var23, var16 + (var14 - 18.0F * var23) / 2.0F, 18.0F * var23, UiRenderer.argb(0.9F, 255, 170, 90)
               );
               var6.text(noticeText, var15 + 46.0F * var23, var16 + (var14 - var11) / 2.0F - var23, var11, 0, UiRenderer.argb(1.0F, 240, 234, 232));
               var6.popAlpha();
            }
         } finally {
            var0.getMatrices().popMatrix();
         }
      }
   }
}
