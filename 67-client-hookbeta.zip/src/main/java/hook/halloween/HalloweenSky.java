package hook.halloween;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalInt;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.BufferUtils;

public final class HalloweenSky {
   private static final int UBO_SIZE = 144;
   public static final RenderPipeline PIPELINE = RenderPipeline.builder(new Snippet[0])
      .withLocation(Identifier.of("hook", "pipeline/hw_sky"))
      .withVertexShader(HalloweenShaders.SKY)
      .withFragmentShader(HalloweenShaders.SKY)
      .withUniform("SkyData", UniformType.UNIFORM_BUFFER)
      .withBlend(BlendFunction.TRANSLUCENT)
      .withDepthWrite(false)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withCull(false)
      .withVertexFormat(VertexFormats.EMPTY, DrawMode.TRIANGLES)
      .build();
   private static final Matrix4f VIEW = new Matrix4f();
   private static final Matrix4f PROJ = new Matrix4f();
   private static boolean haveMatrices;
   private static GpuBuffer ubo;
   private static ByteBuffer data;

   private HalloweenSky() {
   }

   public static void capture(Matrix4f var0, Matrix4f var1) {
      VIEW.set(var0);
      PROJ.set(var1);
      haveMatrices = true;
   }

   public static Matrix4f projection() {
      return PROJ;
   }

   public static Matrix4f view() {
      return VIEW;
   }

   public static boolean hasMatrices() {
      return haveMatrices;
   }

   public static void draw() {
      float var0 = HalloweenAtmosphere.strength() * HalloweenAtmosphere.nightness();
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (!(var0 <= 0.004F) && haveMatrices && var1.world != null && HalloweenShaders.ready(PIPELINE)) {
         try {
            if (ubo == null) {
               ubo = RenderSystem.getDevice().createBuffer(() -> "Hook Halloween sky", 136, 144L);
               data = BufferUtils.createByteBuffer(144);
            }

            Matrix4f var2 = new Matrix4f(PROJ).mul(VIEW).invert();
            Vector4f var3 = HalloweenAtmosphere.moonDir();
            float var4 = 1.0F - var1.world.getRainGradient(1.0F);
            float var5 = ((float)(var1.world.getTime() % 240000L) + var1.getRenderTickCounter().getTickProgress(false)) / 20.0F;
            data.clear();
            var2.get(0, data);
            put4(data, 64, var3.x, var3.y, var3.z, var3.w * var4);
            put4(data, 80, var0 * 0.94F, var5, 0.0F, 0.0F);
            put4(data, 96, 0.03F, 0.015F, 0.05F, 1.0F);
            put4(data, 112, 0.135F, 0.066F, 0.165F, 1.0F);
            put4(data, 128, 0.32F, 0.11F, 0.035F, 0.55F);
            data.position(0);
            data.limit(144);
            CommandEncoder var6 = RenderSystem.getDevice().createCommandEncoder();
            var6.writeToBuffer(ubo.slice(), data);
            GpuTextureView var7 = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : var1.getFramebuffer().getColorAttachmentView();
            RenderPass var8 = var6.createRenderPass(() -> "Hook Halloween sky", var7, OptionalInt.empty());

            try {
               var8.setPipeline(PIPELINE);
               var8.setUniform("SkyData", ubo);
               var8.draw(0, 3);
            } catch (Throwable var12) {
               if (var8 != null) {
                  try {
                     var8.close();
                  } catch (Throwable var11) {
                     var12.addSuppressed(var11);
                  }
               }

               throw var12;
            }

            if (var8 != null) {
               var8.close();
            }
         } catch (Throwable var13) {
            System.err.println("Hook: Halloween sky skipped: " + var13);
         }
      }
   }

   static void put4(ByteBuffer var0, int var1, float var2, float var3, float var4, float var5) {
      var0.putFloat(var1, var2);
      var0.putFloat(var1 + 4, var3);
      var0.putFloat(var1 + 8, var4);
      var0.putFloat(var1 + 12, var5);
   }

   public static void release() {
      if (ubo != null) {
         ubo.close();
         ubo = null;
      }

      data = null;
   }
}
