package hook.utils;

import hook.Hook;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;
import hook.feature.FontManager;
import hook.feature.MinecraftUiRenderer;

public final class TextRenderer {
   private static final float SIZE = 17.0F;
   private static final int WEIGHT = 1;

   private TextRenderer() {
   }

   private static float guiScale() {
      try {
         return (float)Hook.mc.getWindow().getScaleFactor();
      } catch (Throwable var1) {
         return 1.0F;
      }
   }

   public static void drawString(CharSequence var0, DrawContext var1, int var2, int var3, int var4) {
      RenderUtils.setContext(var1);
      if (FontManager.available()) {
         new MinecraftUiRenderer(var1, guiScale()).text(var0.toString(), (float)var2, (float)var3, 17.0F, 1, var4);
      } else {
         drawLargeString(var0, var1, var2, var3, var4);
      }
   }

   public static int getWidth(CharSequence var0) {
      String var1 = var0.toString();
      return FontManager.available() ? Math.round(FontManager.width(var1, 17.0F, 1)) : Hook.mc.textRenderer.getWidth(var1) * 2;
   }

   public static void drawCenteredString(CharSequence var0, DrawContext var1, int var2, int var3, int var4) {
      if (FontManager.available()) {
         drawString(var0, var1, var2 - getWidth(var0) / 2, var3, var4);
      } else {
         drawCenteredMinecraftText(var0, var1, var2, var3, var4);
      }
   }

   public static void drawLargeString(CharSequence var0, DrawContext var1, int var2, int var3, int var4) {
      Matrix3x2fStack var5 = var1.getMatrices();
      var5.pushMatrix();
      var5.scale(2.0F, 2.0F);
      var1.drawText(Hook.mc.textRenderer, var0.toString(), var2 / 2, var3 / 2, var4, false);
      var5.popMatrix();
   }

   public static void drawCenteredMinecraftText(CharSequence var0, DrawContext var1, int var2, int var3, int var4) {
      Matrix3x2fStack var5 = var1.getMatrices();
      var5.pushMatrix();
      var5.scale(2.0F, 2.0F);
      var1.drawText(Hook.mc.textRenderer, var0.toString(), var2 / 2 - Hook.mc.textRenderer.getWidth(var0.toString()) / 2, var3 / 2, var4, false);
      var5.popMatrix();
   }
}
