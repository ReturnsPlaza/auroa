package hook.itemfx.mesh;

public final class ToolModel {
   public static final int SWORD = 0;
   public static final int PICKAXE = 1;
   public static final int AXE = 2;
   public static final int SHOVEL = 3;
   public static final int HOE = 4;
   public static final int TYPES = 5;
   public static final int WOOD = 0;
   public static final int STONE = 1;
   public static final int COPPER = 2;
   public static final int IRON = 3;
   public static final int GOLD = 4;
   public static final int DIAMOND = 5;
   public static final int NETHERITE = 6;
   public static final int TIERS = 7;
   public static final int R_TOOL_HEAD = 6;
   private static final float[] AXE_BIT = new float[]{
      -0.03F,
      0.975F,
      -0.17F,
      0.992F,
      -0.3F,
      1.062F,
      -0.338F,
      1.03F,
      -0.362F,
      0.96F,
      -0.37F,
      0.88F,
      -0.36F,
      0.8F,
      -0.33F,
      0.735F,
      -0.3F,
      0.7F,
      -0.17F,
      0.795F,
      -0.03F,
      0.83F
   };
   private static final float[] SPADE = new float[]{
      -0.15F,
      0.825F,
      -0.156F,
      1.04F,
      -0.122F,
      1.118F,
      -0.055F,
      1.16F,
      0.0F,
      1.168F,
      0.055F,
      1.16F,
      0.122F,
      1.118F,
      0.156F,
      1.04F,
      0.15F,
      0.825F,
      0.09F,
      0.785F,
      0.0F,
      0.77F,
      -0.09F,
      0.785F
   };
   private static final float[] HOE_BLADE = new float[]{-0.196F, 1.0F, -0.33F, 1.004F, -0.346F, 0.8F, -0.318F, 0.758F, -0.222F, 0.812F};
   private static final int ARC = 30;
   private final int type;
   private final int tier;
   private final float[] arc = new float[93];

   private ToolModel(int var1, int var2) {
      this.type = var1;
      this.tier = var2;

      for (int var3 = 0; var3 <= 30; var3++) {
         float var4 = -0.465F + 0.93F * (float)var3 / 30.0F;
         float var5 = Math.abs(var4);
         this.arc[var3 * 3] = var4;
         this.arc[var3 * 3 + 1] = 0.938F - 0.5F * var4 * var4 - 0.35F * var4 * var4 * var4 * var4;
         float var6 = (float)Math.pow((double)Math.max(0.0F, 1.0F - (float)Math.pow((double)(var5 / 0.47F), 1.7F)), 0.62F);
         this.arc[var3 * 3 + 2] = 0.05F * var6 + 0.0035F;
      }
   }

   public static MeshData build(int var0, int var1) {
      ToolModel var2 = new ToolModel(var0, var1);
      float var3 = var0 == 0 ? 1.24F : (var0 == 3 ? 1.19F : 1.09F);
      float var4 = var0 == 1 ? 0.5F : (var0 == 0 ? 0.27F : (var0 == 3 ? 0.19F : 0.4F));
      MeshData var5 = SurfaceNets.build(var2::field, var2::paint, -var4, -0.04F, -0.075F, var4, var3, 0.075F, 0.006666667F, 0.05F);
      float var6 = 0.70710677F;
      float var7 = var0 == 0 ? 1.235F : var3 - 0.02F;
      float var8 = -var7 * var6 * 0.5F;

      for (int var9 = 0; var9 < var5.vertexCount; var9++) {
         float var10 = var5.pos[var9 * 3];
         float var11 = var5.pos[var9 * 3 + 1];
         var5.pos[var9 * 3] = var6 * var10 + var6 * var11 + var8 - 0.012F;
         var5.pos[var9 * 3 + 1] = -var6 * var10 + var6 * var11 + var8 - 0.012F;
         float var12 = var5.nrm[var9 * 3];
         float var13 = var5.nrm[var9 * 3 + 1];
         var5.nrm[var9 * 3] = var6 * var12 + var6 * var13;
         var5.nrm[var9 * 3 + 1] = -var6 * var12 + var6 * var13;
      }

      float var14 = 0.0F;

      for (int var15 = 0; var15 < var5.vertexCount; var15++) {
         var14 = Math.max(var14, Math.max(Math.abs(var5.pos[var15 * 3]), Math.abs(var5.pos[var15 * 3 + 1])));
      }

      if (var14 > 0.475F) {
         float var16 = 0.475F / var14;

         for (int var17 = 0; var17 < var5.vertexCount * 3; var17++) {
            var5.pos[var17] = var5.pos[var17] * var16;
         }
      }

      return var5;
   }

   private float handleTop() {
      return switch (this.type) {
         case 0 -> 0.27F;
         case 3 -> 0.8F;
         default -> 0.952F;
      };
   }

   private float haft(float var1, float var2, float var3) {
      float var4 = this.handleTop();
      if (this.type == 0) {
         return Sd.capsule(var1, var2, var3, 0.0F, 0.06F, 0.0F, 0.0F, var4, 0.0F, 0.03F);
      } else {
         float var5 = 0.029F + 0.003F * (float)Math.sin(Math.PI * (double)Sd.clamp(var2 / var4, 0.0F, 1.0F));
         return Sd.capsule(var1, var2, var3, 0.0F, 0.02F, 0.0F, 0.0F, var4, 0.0F, var5);
      }
   }

   private float grip(float var1, float var2, float var3) {
      return this.type == 0
         ? Sd.capsule(var1, var2, var3, 0.0F, 0.065F, 0.0F, 0.0F, 0.262F, 0.0F, 0.035F)
         : Sd.capsule(var1, var2, var3, 0.0F, 0.07F, 0.0F, 0.0F, 0.39F, 0.0F, 0.0355F);
   }

   private float fittings(float var1, float var2, float var3) {
      if (this.type == 0) {
         float var9 = Sd.ellipsoid(var1, var2 - 0.034F, var3, 0.05F, 0.044F, 0.04F);
         var9 = Sd.smin(var9, Sd.roundCone(var1, var2, var3, 0.0F, 0.01F, 0.0F, 0.0F, -0.022F, 0.0F, 0.016F, 0.004F), 0.008F);
         float var11 = Math.abs(var1);
         float var6 = Sd.box(var1, var2 - 0.3F, var3, 0.05F, 0.028F, 0.034F, 0.014F);
         var6 = Sd.smin(var6, Sd.roundCone(var11, var2, var3, 0.03F, 0.298F, 0.0F, 0.195F, 0.318F, 0.0F, 0.024F, 0.017F), 0.012F);
         var6 = Sd.smin(var6, Sd.roundCone(var11, var2, var3, 0.195F, 0.318F, 0.0F, 0.232F, 0.362F, 0.0F, 0.017F, 0.008F), 0.008F);
         return Math.min(var9, var6);
      } else {
         float var4 = Sd.ellipsoid(var1, var2 - 0.018F, var3, 0.04F, 0.032F, 0.04F);
         var4 = Math.min(var4, Sd.torus(var1, var2 - 0.045F, var3, 0.032F, 0.0075F));
         float var5 = this.handleTop() - (this.type == 3 ? 0.03F : 0.115F);
         var4 = Math.min(var4, Sd.torus(var1, var2 - var5, var3, 0.033F, 0.0085F));
         return Math.min(var4, Sd.torus(var1, var2 - 0.4F, var3, 0.037F, 0.006F));
      }
   }

   private float headShape(float var1, float var2, float var3) {
      return switch (this.type) {
         case 1 -> this.pick(var1, var2, var3);
         case 2 -> axe(var1, var2, var3);
         case 3 -> shovel(var1, var2, var3);
         case 4 -> hoe(var1, var2, var3);
         default -> blade(var1, var2, var3);
      };
   }

   private float head(float var1, float var2, float var3) {
      float var4 = this.headShape(var1, var2, var3);
      if (this.tier == 1 && var4 < 0.02F) {
         var4 += 0.0075F * (Sd.fbm(var1 * 22.0F, var2 * 22.0F, var3 * 22.0F, 3) - 0.5F);
      }

      return var4;
   }

   private float pick(float var1, float var2, float var3) {
      if (var2 < 0.7F) {
         return var2 < 0.6F ? 0.2F : 0.7F - var2 + 0.05F;
      } else {
         float var4 = Sd.box(var1, var2 - 0.936F, var3, 0.05F, 0.074F, 0.046F, 0.02F);

         for (int var5 = 0; var5 < 30; var5++) {
            float[] var6 = this.arc;
            float var7 = Sd.roundCone(
                  var1,
                  var2,
                  var3 / 0.74F,
                  var6[var5 * 3],
                  var6[var5 * 3 + 1],
                  0.0F,
                  var6[var5 * 3 + 3],
                  var6[var5 * 3 + 4],
                  0.0F,
                  var6[var5 * 3 + 2],
                  var6[var5 * 3 + 5]
               )
               * 0.74F;
            var4 = Sd.smin(var4, var7, 0.018F);
         }

         return var4;
      }
   }

   private static float axe(float var0, float var1, float var2) {
      if (var1 < 0.66F) {
         return 0.7F - var1;
      } else {
         float var3 = Sd.box(var0, var1 - 0.905F, var2, 0.042F, 0.086F, 0.046F, 0.016F);
         float var4 = Sd.box(var0 - 0.066F, var1 - 0.905F, var2, 0.032F, 0.058F, 0.041F, 0.016F);
         float var5 = Sd.smoothstep(-0.03F, -0.365F, var0);
         float var6 = Sd.mix(0.043F, 0.0035F, (float)Math.pow((double)var5, 0.85F));
         float var7 = Math.max(Sd.polygon(var0, var1, AXE_BIT), Math.abs(var2) - var6);
         return Sd.smin(Sd.smin(var3, var4, 0.012F), var7, 0.018F);
      }
   }

   private static float shovel(float var0, float var1, float var2) {
      if (var1 < 0.62F) {
         return 0.66F - var1;
      } else {
         float var3 = Sd.roundCone(var0, var1, var2 / 0.8F, 0.0F, 0.68F, 0.0F, 0.0F, 0.8F, 0.0F, 0.034F, 0.05F) * 0.8F;
         float var4 = 0.065F * (var0 / 0.156F) * (var0 / 0.156F) - 0.025F + 0.03F * Sd.smoothstep(1.0F, 1.17F, var1);
         float var5 = Math.max(Sd.polygon(var0, var1, SPADE), (Math.abs(var2 - var4) - 0.0115F) * 0.62F);
         return Sd.smin(var3, var5, 0.03F);
      }
   }

   private static float hoe(float var0, float var1, float var2) {
      if (var1 < 0.7F) {
         return 0.74F - var1;
      } else {
         float var3 = Sd.box(var0, var1 - 0.935F, var2, 0.04F, 0.062F, 0.045F, 0.015F);
         float var4 = Sd.roundCone(var0, var1, var2, -0.03F, 0.958F, 0.0F, -0.215F, 0.975F, 0.0F, 0.03F, 0.021F);
         float var5 = Math.max(Sd.polygon(var0, var1, HOE_BLADE), Math.abs(var2) - Sd.mix(0.016F, 0.004F, Sd.smoothstep(0.93F, 0.76F, var1)));
         return Sd.smin(Sd.smin(var3, var4, 0.014F), var5, 0.016F);
      }
   }

   private static float bladeWidth(float var0) {
      float var1 = Sd.mix(0.08F, 0.06F, Sd.clamp((var0 - 0.33F) / 0.7F, 0.0F, 1.0F));
      float var2 = Sd.smoothstep(1.225F, 1.02F, var0);
      return var1 * (float)Math.sqrt((double)var2);
   }

   private static float blade(float var0, float var1, float var2) {
      if (var1 < 0.28F) {
         return 0.31F - var1;
      } else {
         float var3 = bladeWidth(var1);
         float var4 = Math.abs(var0);
         float var5 = Math.max(var4 - var3, var1 - 1.228F);
         float var6 = 0.025F * Sd.clamp((1.24F - var1) / 0.25F, 0.25F, 1.0F);
         float var7 = var6 * (float)Math.pow((double)Sd.clamp(1.0F - var4 / Math.max(var3, 1.0E-4F), 0.0F, 1.0F), 0.85F) + 0.0016F;
         float var8 = Math.max(Math.max(var5, Math.abs(var2) - var7), 0.32F - var1);
         float var9 = Math.max(Math.max(var4 - 0.0115F, var6 - 0.0072F - Math.abs(var2)), Math.max(0.36F - var1, var1 - 0.9F));
         return Sd.ssub(var8, var9, 0.004F);
      }
   }

   private float field(float var1, float var2, float var3) {
      float var4 = Sd.smin(this.haft(var1, var2, var3), this.grip(var1, var2, var3), 0.006F);
      var4 = Sd.smin(var4, this.fittings(var1, var2, var3), 0.006F);
      return Sd.smin(var4, this.head(var1, var2, var3), 0.008F);
   }

   private float edge(float var1, float var2, float var3) {
      return switch (this.type) {
         case 1 -> {
            float var4 = 1.0F;

            for (int var5 = 0; var5 <= 30; var5++) {
               var4 = Math.min(var4, Sd.len(var1 - this.arc[var5 * 3], var2 - this.arc[var5 * 3 + 1]) - this.arc[var5 * 3 + 2]);
            }

            float var6 = Sd.smoothstep(0.25F, 0.45F, Math.abs(var1));
            yield var6 * (1.0F - Sd.smoothstep(-0.004F, 0.02F, -var4));
         }
         case 2 -> Sd.smoothstep(-0.3F, -0.36F, var1);
         case 3 -> Sd.smoothstep(1.1F, 1.165F, var2) + (1.0F - Sd.smoothstep(0.0F, 0.02F, -Sd.polygon(var1, var2, SPADE))) * Sd.smoothstep(1.0F, 1.12F, var2);
         case 4 -> Sd.smoothstep(0.8F, 0.765F, var2) * Sd.smoothstep(-0.22F, -0.3F, var1);
         default -> 1.0F - Sd.smoothstep(0.004F, 0.02F, bladeWidth(var2) - Math.abs(var1));
      };
   }

   private void headMaterial(SurfaceNets.Surface var1) {
      switch (this.tier) {
         case 0:
            var1.mat = 9;
            var1.rgb = Mat.rgb(0.7F, 0.52F, 0.31F);
            var1.p1 = 0.6F;
            break;
         case 1:
            var1.mat = 11;
            var1.rgb = Mat.rgb(0.5F, 0.5F, 0.52F);
            var1.p1 = 0.8F;
            break;
         case 2:
            var1.mat = 14;
            var1.rgb = Mat.rgb(0.95F, 0.58F, 0.42F);
            var1.p1 = 0.3F;
            break;
         case 3:
            var1.mat = 14;
            var1.rgb = Mat.rgb(0.76F, 0.77F, 0.8F);
            var1.p1 = 0.18F;
            break;
         case 4:
            var1.mat = 14;
            var1.rgb = Mat.rgb(1.0F, 0.78F, 0.34F);
            var1.p1 = 0.12F;
            break;
         case 5:
            var1.mat = 12;
            var1.rgb = Mat.rgb(0.32F, 0.94F, 0.88F);
            var1.p1 = 0.05F;
            break;
         default:
            var1.mat = 14;
            var1.rgb = Mat.rgb(0.25F, 0.215F, 0.24F);
            var1.p1 = 0.26F;
      }
   }

   private void fittingMaterial(SurfaceNets.Surface var1) {
      var1.mat = 1;
      switch (this.tier) {
         case 0:
         case 1:
            var1.rgb = Mat.rgb(0.42F, 0.42F, 0.45F);
            var1.p1 = 0.45F;
            break;
         case 2:
            var1.rgb = Mat.rgb(0.93F, 0.6F, 0.44F);
            var1.p1 = 0.35F;
            break;
         case 3:
            var1.rgb = Mat.rgb(0.62F, 0.63F, 0.66F);
            var1.p1 = 0.25F;
            break;
         case 4:
         case 5:
            var1.rgb = Mat.rgb(1.0F, 0.77F, 0.36F);
            var1.p1 = 0.18F;
            break;
         default:
            var1.rgb = Mat.rgb(0.34F, 0.29F, 0.31F);
            var1.p1 = 0.3F;
      }
   }

   private void paint(float var1, float var2, float var3, float var4, float var5, float var6, SurfaceNets.Surface var7) {
      float var8 = Math.abs(this.haft(var1, var2, var3));
      float var9 = Math.abs(this.grip(var1, var2, var3));
      float var10 = Math.abs(this.fittings(var1, var2, var3));
      float var11 = Math.abs(this.head(var1, var2, var3));
      float var12 = Math.min(Math.min(var8, var9), Math.min(var10, var11));
      var7.u = (float)(Math.atan2((double)var3, (double)var1) / (Math.PI * 2) + 0.5);
      var7.v = var2;
      if (var12 == var11) {
         this.headMaterial(var7);
         var7.p2 = Sd.clamp(this.edge(var1, var2, var3), 0.0F, 1.0F);
         var7.region = 6;
         var7.u = var1 * 4.0F;
      } else if (var12 == var10) {
         this.fittingMaterial(var7);
      } else if (var12 == var9) {
         var7.mat = 10;
         var7.rgb = this.tier == 6 ? Mat.rgb(0.1F, 0.07F, 0.08F) : Mat.rgb(0.26F, 0.14F, 0.075F);
         var7.p1 = 0.75F;
      } else {
         var7.mat = 9;
         var7.rgb = this.tier == 6 ? Mat.rgb(0.14F, 0.09F, 0.075F) : Mat.rgb(0.4F, 0.245F, 0.13F);
         var7.p1 = 0.55F;
      }
   }
}
