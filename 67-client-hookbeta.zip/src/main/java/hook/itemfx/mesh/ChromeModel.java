package hook.itemfx.mesh;

import java.util.Arrays;
import java.util.HashSet;

public final class ChromeModel {
   private static final TotemShape SHAPE = new TotemShape(0.08F, 0.045F, 0.0F, 0.0F);
   private static final float FACE_Z = 0.112F;
   private static final float EYE_X = 0.052F;
   private static final float EYE_Y = 0.305F;

   private ChromeModel() {
   }

   public static MeshData build() {
      return SurfaceNets.build(ChromeModel::field, ChromeModel::paint, -0.47F, -0.49F, -0.18F, 0.47F, 0.47F, 0.18F, 0.008333334F, 0.07F);
   }

   static float face(float var0, float var1, float var2) {
      if (!(var2 < 0.05F) && !(var1 < 0.17F) && !(var1 > 0.38F)) {
         float var3 = Sd.box(var0, var1 - 0.346F, var2 - 0.112F + 0.004F, 0.1F, 0.012F, 0.014F, 0.011F);
         float var4 = Sd.box(var0, var1 - 0.262F, var2 - 0.112F, 0.015F, 0.032F, 0.014F, 0.011F);
         return Math.min(var3, var4);
      } else {
         return 1.0F;
      }
   }

   static float hollows(float var0, float var1, float var2) {
      if (!(var2 < 0.05F) && !(var1 < 0.17F) && !(var1 > 0.38F)) {
         float var3 = Sd.ellipsoid(Math.abs(var0) - 0.052F, var1 - 0.305F, var2 - 0.112F - 0.004F, 0.036F, 0.026F, 0.03F);
         float var4 = Sd.box(var0, var1 - 0.205F, var2 - 0.112F - 0.004F, 0.06F, 0.009F, 0.022F, 0.008F);
         return Math.min(var3, var4);
      } else {
         return 1.0F;
      }
   }

   static float eyes(float var0, float var1, float var2) {
      return Sd.ellipsoid(Math.abs(var0) - 0.052F, var1 - 0.305F, var2 - 0.094F, 0.026F, 0.018F, 0.014F);
   }

   static float body(float var0, float var1, float var2) {
      float var3 = SHAPE.body(var0, var1, var2);
      var3 = Sd.smin(var3, SHAPE.belt(var0, var1, var2), 0.02F);
      var3 = Sd.smin(var3, face(var0, var1, var2), 0.014F);
      var3 = Sd.ssub(var3, hollows(var0, var1, var2), 0.012F);
      if (var3 < 0.05F) {
         float var4 = faceMask(var0, var1, var2);
         var3 -= 0.02F * (1.0F - 0.85F * var4) * (Sd.fbm(var0 * 5.5F + 3.1F, var1 * 4.0F, var2 * 5.5F, 2) - 0.5F);
      }

      return var3;
   }

   public static float field(float var0, float var1, float var2) {
      return Math.min(body(var0, var1, var2), eyes(var0, var1, var2));
   }

   public static float faceMask(float var0, float var1, float var2) {
      return Sd.smoothstep(0.05F, 0.09F, var2)
         * (1.0F - Sd.smoothstep(0.112F, 0.14F, Math.abs(var0)))
         * Sd.smoothstep(0.165F, 0.19F, var1)
         * (1.0F - Sd.smoothstep(0.392F, 0.42F, var1));
   }

   public static void paint(float var0, float var1, float var2, float var3, float var4, float var5, SurfaceNets.Surface var6) {
      float var7 = Math.abs(eyes(var0, var1, var2));
      float var8 = Math.abs(body(var0, var1, var2));
      var6.u = (float)(Math.atan2((double)var2, (double)var0) / (Math.PI * 2) + 0.5);
      var6.v = var1;
      if (var7 < var8 && var7 < 0.008F) {
         var6.mat = 4;
         var6.rgb = Mat.rgb(0.1F, 0.95F, 0.42F);
         var6.p1 = 0.8F;
      } else {
         var6.mat = 2;
         var6.rgb = Mat.rgb(0.92F, 0.93F, 0.95F);
         var6.p1 = 1.0F - 0.8F * faceMask(var0, var1, var2);
         var6.region = 5;
      }
   }

   public static float[] dripAnchors(MeshData var0) {
      float var1 = 0.035F;
      HashSet var2 = new HashSet();
      float[] var3 = new float[288];
      int var4 = 0;

      for (int var5 = 0; var5 < var0.vertexCount && var4 < 96; var5++) {
         float var6 = var0.nrm[var5 * 3 + 1];
         if (!(var6 > -0.8F) && var0.p1[var5] >= 900 && var0.mat[var5] == 2) {
            float var7 = var0.pos[var5 * 3];
            float var8 = var0.pos[var5 * 3 + 1];
            float var9 = var0.pos[var5 * 3 + 2];
            if (!(var9 < -0.07F)) {
               long var10 = (long)Math.floor((double)(var7 / var1)) * 1000003L
                  + (long)Math.floor((double)(var8 / var1)) * 1009L
                  + (long)Math.floor((double)(var9 / var1));
               if (var2.add(var10)) {
                  var3[var4 * 3] = var7;
                  var3[var4 * 3 + 1] = var8;
                  var3[var4 * 3 + 2] = var9;
                  var4++;
               }
            }
         }
      }

      return Arrays.copyOf(var3, var4 * 3);
   }
}
