package hook.itemfx;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import com.mojang.blaze3d.vertex.VertexFormat.IndexType;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;
import hook.itemfx.mesh.ChromeModel;
import hook.itemfx.mesh.MeshData;
import hook.itemfx.mesh.SpookyModel;
import hook.itemfx.mesh.SpriteModels;
import hook.itemfx.mesh.ToolModel;
import hook.mixin.RenderLayerAccessor;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gl.ScissorState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue.Custom;
import net.minecraft.client.util.math.MatrixStack.Entry;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

public final class ItemFxRenderer {
   static final int DESIGN_SPOOKY = 1;
   static final int DESIGN_CHROME = 2;
   static final int DESIGN_TOOL = 3;
   static final int DESIGN_SPOOKY_PX = 4;
   static final int DESIGN_CHROME_PX = 5;
   static final int DESIGN_GHOST = 6;
   static final int CTX_WORLD = 0;
   static final int CTX_HAND = 1;
   static final int CTX_GUI = 2;
   static final int CTX_FLOATING = 3;
   private static final int MAX = 128;
   private static final int CHUNK = 32;
   private static final int INSTANCE_SIZE = 272;
   private static final int DRIPS_SIZE = 784;
   private static final VertexFormat FORMAT = VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL;
   private static final RenderPipeline MESH_PIPE = base("pipeline/fx_item", ItemFxShaders.MESH, FORMAT)
      .withUniform("Lighting", UniformType.UNIFORM_BUFFER)
      .withSampler("Sampler2")
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline DRIP_PIPE = base("pipeline/fx_drip", ItemFxShaders.DRIP, VertexFormats.POSITION)
      .withUniform("Lighting", UniformType.UNIFORM_BUFFER)
      .withUniform("ItemFxDrips", UniformType.UNIFORM_BUFFER)
      .withSampler("Sampler2")
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline GLOW_PIPE = base("pipeline/fx_glow", ItemFxShaders.GLOW, VertexFormats.POSITION)
      .withBlend(new BlendFunction(SourceFactor.ONE, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE))
      .withDepthWrite(false)
      .build();
   private static final RenderPipeline SMOKE_PIPE = base("pipeline/fx_smoke", ItemFxShaders.SMOKE, VertexFormats.POSITION)
      .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
      .withDepthWrite(false)
      .build();
   private static final BlendFunction ADD = new BlendFunction(SourceFactor.ONE, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE);
   private static final RenderPipeline SPRITE_PIPE = base("pipeline/fx_sprite", ItemFxShaders.SPRITE, FORMAT)
      .withUniform("Lighting", UniformType.UNIFORM_BUFFER)
      .withSampler("Sampler0")
      .withSampler("Sampler2")
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline GHOST_BACK_PIPE = base("pipeline/fx_ghost_back", ItemFxShaders.GHOST_BACK, FORMAT)
      .withSampler("Sampler0")
      .withSampler("Sampler2")
      .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline GHOST_FRONT_PIPE = base("pipeline/fx_ghost_front", ItemFxShaders.GHOST_FRONT, FORMAT)
      .withSampler("Sampler0")
      .withSampler("Sampler2")
      .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline HALO_PIPE = base("pipeline/fx_halo", ItemFxShaders.HALO, FORMAT)
      .withSampler("Sampler0")
      .withBlend(ADD)
      .withDepthWrite(false)
      .build();
   private static final RenderPipeline SKULL_PIPE = base("pipeline/fx_skull", ItemFxShaders.SKULL, VertexFormats.POSITION)
      .withSampler("Sampler0")
      .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
      .withDepthWrite(true)
      .build();
   private static final RenderPipeline MARKER_PIPE = RenderPipeline.builder(new Snippet[0])
      .withLocation(Identifier.of("hook", "pipeline/fx_marker"))
      .withVertexShader(ItemFxShaders.MESH)
      .withFragmentShader(ItemFxShaders.MESH)
      .withVertexFormat(FORMAT, DrawMode.QUADS)
      .build();
   private static RenderLayer layer;
   private static boolean layerFailed;
   private static final Matrix4f[] POSE = new Matrix4f[128];
   private static final Matrix3f[] NRM = new Matrix3f[128];
   private static final int[] FX = new int[128];
   private static final int[] CTX = new int[128];
   private static final int[] LIGHT = new int[128];
   private static final float[] ACT = new float[128];
   private static final boolean[] GLINT = new boolean[128];
   private static int pending;
   private static final ItemFxRenderer.Command[] COMMANDS = new ItemFxRenderer.Command[512];
   private static int nextCommand;
   private static final Map<Integer, ItemFxRenderer.GpuMeshes> MESHES = new HashMap<>();
   private static final Map<Integer, CompletableFuture<ItemFxRenderer.Built>> BUILDS = new HashMap<>();
   private static final Map<Integer, float[]> ANCHORS = new HashMap<>();
   private static final ExecutorService BUILDER = Executors.newSingleThreadExecutor(var0x -> {
      Thread var1x = new Thread(var0x, "Hook item models");
      var1x.setDaemon(true);
      var1x.setPriority(1);
      return var1x;
   });
   private static GpuTexture atlas;
   private static GpuTextureView atlasView;
   private static GpuBuffer quadVbo;
   private static GpuBuffer quadIbo;
   private static GpuBuffer dripVbo;
   private static GpuBuffer dripIbo;
   private static int dripIndices;
   private static GpuBuffer ubo;
   private static GpuBuffer dripUbo;
   private static int stride;
   private static ByteBuffer data;
   private static ByteBuffer dripData;
   private static long dripFrame = -1L;
   private static boolean failed;
   private static final Matrix4f TMP = new Matrix4f();
   private static final Matrix4f ANIM = new Matrix4f();
   private static final Matrix4f MV = new Matrix4f();
   private static final Matrix4f NM = new Matrix4f();
   private static final Matrix3f TMP3 = new Matrix3f();
   private static final Matrix3f ANIM3 = new Matrix3f();

   private ItemFxRenderer() {
   }

   private static Builder base(String var0, Identifier var1, VertexFormat var2) {
      return RenderPipeline.builder(new Snippet[0])
         .withLocation(Identifier.of("hook", var0))
         .withVertexShader(var1)
         .withFragmentShader(var1)
         .withUniform("Projection", UniformType.UNIFORM_BUFFER)
         .withUniform("Fog", UniformType.UNIFORM_BUFFER)
         .withUniform("ItemFx", UniformType.UNIFORM_BUFFER)
         .withCull(false)
         .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
         .withVertexFormat(var2, DrawMode.TRIANGLES);
   }

   static RenderLayer layer() {
      if (layer == null && !layerFailed) {
         try {
            layer = RenderLayerAccessor.hook$create("hook_item_fx", RenderSetup.builder(MARKER_PIPE).build());
         } catch (Throwable var1) {
            layerFailed = true;
            System.err.println("Hook: item fx layer unavailable: " + var1);
         }
      }

      return layer;
   }

   public static boolean isMarker(Object var0) {
      return var0 != null && var0 == layer;
   }

   static int meshKey(int var0, int var1, int var2) {
      return switch (var0) {
         case 3 -> 100 + var1 * 10 + var2;
         case 4 -> 201;
         case 5 -> 202;
         case 6 -> 203;
         default -> var0;
      };
   }

   private static ItemFxRenderer.Built buildModel(int var0) {
      if (var0 == 1) {
         MeshData var4 = SpookyModel.build();
         return new ItemFxRenderer.Built(var4, var4.indices.length, null);
      } else if (var0 == 2) {
         MeshData var3 = ChromeModel.build();
         return new ItemFxRenderer.Built(var3, var3.indices.length, ChromeModel.dripAnchors(var3));
      } else if (var0 > 200) {
         SpriteModels.Model var2 = SpriteModels.build(var0 == 201 ? 1 : (var0 == 202 ? 2 : 3));
         return new ItemFxRenderer.Built(var2.mesh, var2.mainIndices, var0 == 202 ? var2.anchors : null);
      } else {
         MeshData var1 = ToolModel.build((var0 - 100) / 10, (var0 - 100) % 10);
         return new ItemFxRenderer.Built(var1, var1.indices.length, null);
      }
   }

   static float[] anchors(int var0) {
      return ANCHORS.get(var0);
   }

   static boolean ready(int var0) {
      if (failed) {
         return false;
      } else if (MESHES.containsKey(var0)) {
         return true;
      } else {
         CompletableFuture var1 = BUILDS.computeIfAbsent(var0, var0x -> CompletableFuture.supplyAsync(() -> buildModel(var0x), BUILDER));
         if (!var1.isDone()) {
            return false;
         } else {
            try {
               ItemFxRenderer.Built var2 = (ItemFxRenderer.Built)var1.join();
               MESHES.put(var0, upload(var2.mesh(), var2.main(), var0));
               if (var2.anchors() != null) {
                  ANCHORS.put(var0, var2.anchors());
               }

               BUILDS.remove(var0);
               return true;
            } catch (Throwable var3) {
               System.err.println("Hook: item model " + var0 + " failed: " + var3);
               failed = true;
               return false;
            }
         }
      }
   }

   static boolean prepare(int var0) {
      if (failed || layer() == null) {
         return false;
      } else if (!ready(var0) || !ItemFxShaders.ready(GLOW_PIPE) || !ItemFxShaders.ready(SMOKE_PIPE)) {
         return false;
      } else if (var0 > 200) {
         boolean var1 = ItemFxShaders.ready(HALO_PIPE) && ensureAtlas();
         return var0 == 203
            ? var1 && ItemFxShaders.ready(GHOST_BACK_PIPE) && ItemFxShaders.ready(GHOST_FRONT_PIPE) && ItemFxShaders.ready(SKULL_PIPE)
            : var1 && ItemFxShaders.ready(SPRITE_PIPE) && (var0 != 202 || ItemFxShaders.ready(DRIP_PIPE));
      } else {
         return ItemFxShaders.ready(MESH_PIPE) && (var0 != 2 || ItemFxShaders.ready(DRIP_PIPE));
      }
   }

   private static boolean ensureAtlas() {
      if (atlasView != null) {
         return true;
      } else {
         try {
            GpuDevice var0 = RenderSystem.getDevice();

            BufferedImage var1;
            try (InputStream var2 = ItemFxRenderer.class.getResourceAsStream("/assets/hook/itemfx/atlas.png")) {
               var1 = ImageIO.read(var2);
            }

            int var12 = var1.getWidth();
            int var3 = var1.getHeight();
            atlas = var0.createTexture(() -> "Hook item atlas", 5, TextureFormat.RGBA8, var12, var3, 1, 1);
            NativeImage var4 = new NativeImage(var12, var3, false);

            try {
               for (int var5 = 0; var5 < var3; var5++) {
                  for (int var6 = 0; var6 < var12; var6++) {
                     var4.setColorArgb(var6, var5, var1.getRGB(var6, var5));
                  }
               }

               var0.createCommandEncoder().writeToTexture(atlas, var4);
            } catch (Throwable var10) {
               try {
                  var4.close();
               } catch (Throwable var7) {
                  var10.addSuppressed(var7);
               }

               throw var10;
            }

            var4.close();
            atlasView = var0.createTextureView(atlas);
            return true;
         } catch (Throwable var11) {
            System.err.println("Hook: item atlas failed: " + var11);
            failed = true;
            return false;
         }
      }
   }

   private static ItemFxRenderer.GpuMeshes upload(MeshData var0, int var1, int var2) {
      GpuDevice var3 = RenderSystem.getDevice();
      int var4 = FORMAT.getVertexSize();
      int var5 = FORMAT.getOffset(VertexFormatElement.POSITION);
      int var6 = FORMAT.getOffset(VertexFormatElement.COLOR);
      int var7 = FORMAT.getOffset(VertexFormatElement.UV0);
      int var8 = FORMAT.getOffset(VertexFormatElement.UV1);
      int var9 = FORMAT.getOffset(VertexFormatElement.UV2);
      int var10 = FORMAT.getOffset(VertexFormatElement.NORMAL);
      ByteBuffer var11 = BufferUtils.createByteBuffer(var4 * var0.vertexCount).order(ByteOrder.nativeOrder());

      for (int var12 = 0; var12 < var0.vertexCount; var12++) {
         int var13 = var12 * var4;
         var11.putFloat(var13 + var5, var0.pos[var12 * 3]);
         var11.putFloat(var13 + var5 + 4, var0.pos[var12 * 3 + 1]);
         var11.putFloat(var13 + var5 + 8, var0.pos[var12 * 3 + 2]);
         int var14 = var0.rgba[var12];
         var11.put(var13 + var6, (byte)(var14 >> 16));
         var11.put(var13 + var6 + 1, (byte)(var14 >> 8));
         var11.put(var13 + var6 + 2, (byte)var14);
         var11.put(var13 + var6 + 3, (byte)(var14 >>> 24));
         var11.putFloat(var13 + var7, var0.uv[var12 * 2]);
         var11.putFloat(var13 + var7 + 4, var0.uv[var12 * 2 + 1]);
         var11.putShort(var13 + var8, var0.mat[var12]);
         var11.putShort(var13 + var8 + 2, var0.region[var12]);
         var11.putShort(var13 + var9, var0.p1[var12]);
         var11.putShort(var13 + var9 + 2, var0.p2[var12]);
         var11.put(var13 + var10, (byte)Math.round(var0.nrm[var12 * 3] * 127.0F));
         var11.put(var13 + var10 + 1, (byte)Math.round(var0.nrm[var12 * 3 + 1] * 127.0F));
         var11.put(var13 + var10 + 2, (byte)Math.round(var0.nrm[var12 * 3 + 2] * 127.0F));
      }

      var11.position(0);
      var11.limit(var4 * var0.vertexCount);
      GpuBuffer var18 = var3.createBuffer(() -> "Hook item model " + var2, 32, var11);
      ByteBuffer var19 = BufferUtils.createByteBuffer(var0.indices.length * 4).order(ByteOrder.nativeOrder());

      for (int var17 : var0.indices) {
         var19.putInt(var17);
      }

      var19.flip();
      GpuBuffer var21 = var3.createBuffer(() -> "Hook item model indices " + var2, 64, var19);
      return new ItemFxRenderer.GpuMeshes(var18, var21, var0.indices.length, var1);
   }

   private static void ensureStatic() {
      if (ubo == null) {
         GpuDevice var0 = RenderSystem.getDevice();
         int var1 = Math.max(16, var0.getUniformOffsetAlignment());
         stride = (272 + var1 - 1) / var1 * var1;
         ubo = var0.createBuffer(() -> "Hook item fx instances", 136, (long)stride * 32L);
         dripUbo = var0.createBuffer(() -> "Hook item fx drips", 136, 784L);
         data = BufferUtils.createByteBuffer(stride * 32).order(ByteOrder.nativeOrder());
         dripData = BufferUtils.createByteBuffer(784).order(ByteOrder.nativeOrder());
         ByteBuffer var2 = BufferUtils.createByteBuffer(48).order(ByteOrder.nativeOrder());
         float[] var3 = new float[]{-1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F};

         for (int var4 = 0; var4 < 4; var4++) {
            var2.putFloat(var3[var4 * 2]);
            var2.putFloat(var3[var4 * 2 + 1]);
            var2.putFloat(0.0F);
         }

         var2.flip();
         quadVbo = var0.createBuffer(() -> "Hook fx quad", 32, var2);
         ByteBuffer var15 = BufferUtils.createByteBuffer(24).order(ByteOrder.nativeOrder());

         for (int var8 : new int[]{0, 1, 2, 0, 2, 3}) {
            var15.putInt(var8);
         }

         var15.flip();
         quadIbo = var0.createBuffer(() -> "Hook fx quad indices", 64, var15);
         byte var16 = 16;
         byte var17 = 26;
         ByteBuffer var18 = BufferUtils.createByteBuffer((var16 + 1) * (var17 + 1) * 12).order(ByteOrder.nativeOrder());

         for (int var19 = 0; var19 <= var17; var19++) {
            for (int var9 = 0; var9 <= var16; var9++) {
               var18.putFloat((float)var9 / (float)var16);
               float var10 = (float)var19 / (float)var17;
               var18.putFloat(var10);
               var18.putFloat(0.0F);
            }
         }

         var18.flip();
         dripVbo = var0.createBuffer(() -> "Hook drip", 32, var18);
         ByteBuffer var20 = BufferUtils.createByteBuffer(var16 * var17 * 6 * 4).order(ByteOrder.nativeOrder());

         for (int var21 = 0; var21 < var17; var21++) {
            for (int var22 = 0; var22 < var16; var22++) {
               int var11 = var21 * (var16 + 1) + var22;
               int var12 = var11 + 1;
               int var13 = var11 + var16 + 1;
               int var14 = var13 + 1;
               var20.putInt(var11);
               var20.putInt(var13);
               var20.putInt(var12);
               var20.putInt(var12);
               var20.putInt(var13);
               var20.putInt(var14);
            }
         }

         var20.flip();
         dripIndices = var16 * var17 * 6;
         dripIbo = var0.createBuffer(() -> "Hook drip indices", 64, var20);
      }
   }

   static void submit(OrderedRenderCommandQueue var0, MatrixStack var1, int var2, int var3, int var4, boolean var5, float var6) {
      ItemFxRenderer.Command var7 = COMMANDS[nextCommand];
      nextCommand = (nextCommand + 1) % COMMANDS.length;
      var7.fx = var2;
      var7.ctx = var3;
      var7.light = var4;
      var7.glint = var5;
      var7.act = var6;
      var0.submitCustom(var1, layer, var7);
   }

   public static void flush(BuiltBuffer var0) {
      try {
         var0.close();
      } catch (Throwable var4) {
      }

      int var1 = pending;
      pending = 0;
      if (var1 != 0 && !failed) {
         try {
            draw(var1);
         } catch (Throwable var3) {
            failed = true;
            System.err.println("Hook: custom item rendering disabled after an error: " + var3);
            var3.printStackTrace();
         }
      }
   }

   private static void draw(int var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      Framebuffer var2 = var1.getFramebuffer();
      GpuTextureView var3 = RenderSystem.outputColorTextureOverride != null ? RenderSystem.outputColorTextureOverride : var2.getColorAttachmentView();
      GpuTextureView var4 = RenderSystem.outputDepthTextureOverride != null
         ? RenderSystem.outputDepthTextureOverride
         : (var2.useDepthAttachment ? var2.getDepthAttachmentView() : null);
      if (var3 != null && ItemFxShaders.ready(GLOW_PIPE) && ItemFxShaders.ready(SMOKE_PIPE)) {
         ensureStatic();
         CommandEncoder var5 = RenderSystem.getDevice().createCommandEncoder();
         MV.set(RenderSystem.getModelViewMatrix());
         boolean var6 = ItemFxShaders.ready(DRIP_PIPE);
         long var7 = ItemFx.frameIndex();
         if (var7 != dripFrame) {
            dripFrame = var7;
            dripData.clear();
            Drips.write(dripData, 0);
            dripData.position(0);
            dripData.limit(784);
            var5.writeToBuffer(dripUbo.slice(), dripData);
         }

         int var9 = Math.round(dripData.getFloat(0));
         GpuTextureView var10 = var1.gameRenderer.getLightmapTextureManager().getGlTextureView();
         GpuSampler var11 = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
         ScissorState var12 = RenderSystem.getScissorStateForRenderTypeDraws();
         GpuSampler var13 = RenderSystem.getSamplerCache()
            .get(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.NEAREST, FilterMode.NEAREST, false);
         GpuSampler var14 = RenderSystem.getSamplerCache()
            .get(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);

         for (byte var15 = 0; var15 < var0; var15 += 32) {
            int var16 = Math.min(32, var0 - var15);
            data.clear();

            for (int var17 = 0; var17 < var16; var17++) {
               writeInstance(var15 + var17, var17 * stride);
            }

            data.position(0);
            data.limit(var16 * stride);
            var5.writeToBuffer(ubo.slice(0L, (long)var16 * (long)stride), data);
            RenderPass var25 = var5.createRenderPass(() -> "Hook items", var3, OptionalInt.empty(), var4, OptionalDouble.empty());

            try {
               if (var12.isEnabled()) {
                  var25.enableScissor(var12.getX(), var12.getY(), var12.getWidth(), var12.getHeight());
               }

               boolean var18 = false;

               for (int var19 = 0; var19 < var16; var19++) {
                  int var20 = FX[var15 + var19];
                  int var21 = ItemFx.design(var20);
                  ItemFxRenderer.GpuMeshes var22 = MESHES.get(meshKey(var21, ItemFx.type(var20), ItemFx.tier(var20)));
                  if (var22 != null && var21 <= 3) {
                     if (!var18) {
                        var25.setPipeline(MESH_PIPE);
                        RenderSystem.bindDefaultUniforms(var25);
                        var25.bindTexture("Sampler2", var10, var11);
                        var18 = true;
                     }

                     var25.setUniform("ItemFx", ubo.slice((long)var19 * (long)stride, 272L));
                     var25.setVertexBuffer(0, var22.vbo);
                     var25.setIndexBuffer(var22.ibo, IndexType.INT);
                     var25.drawIndexed(0, 0, var22.count, 1);
                  }
               }

               var18 = false;

               for (int var29 = 0; var29 < var16; var29++) {
                  int var33 = FX[var15 + var29];
                  int var37 = ItemFx.design(var33);
                  ItemFxRenderer.GpuMeshes var41 = MESHES.get(meshKey(var37, ItemFx.type(var33), ItemFx.tier(var33)));
                  if (var41 != null && (var37 == 4 || var37 == 5)) {
                     if (!var18) {
                        var25.setPipeline(SPRITE_PIPE);
                        RenderSystem.bindDefaultUniforms(var25);
                        var25.bindTexture("Sampler0", atlasView, var13);
                        var25.bindTexture("Sampler2", var10, var11);
                        var18 = true;
                     }

                     var25.setUniform("ItemFx", ubo.slice((long)var29 * (long)stride, 272L));
                     var25.setVertexBuffer(0, var41.vbo);
                     var25.setIndexBuffer(var41.ibo, IndexType.INT);
                     var25.drawIndexed(0, 0, var41.main, 1);
                  }
               }

               if (var6) {
                  var18 = false;

                  for (int var30 = 0; var30 < var16; var30++) {
                     int var34 = FX[var15 + var30];
                     if (ItemFx.design(var34) == 2 || ItemFx.design(var34) == 5) {
                        int var38 = (ItemFx.animations(var34) ? var9 : 0) + (ACT[var15 + var30] >= 0.0F && ItemFx.popFx(var34) ? 18 : 0);
                        if (var38 > 0) {
                           if (!var18) {
                              var25.setPipeline(DRIP_PIPE);
                              RenderSystem.bindDefaultUniforms(var25);
                              var25.bindTexture("Sampler2", var10, var11);
                              var25.setUniform("ItemFxDrips", dripUbo);
                              var25.setVertexBuffer(0, dripVbo);
                              var25.setIndexBuffer(dripIbo, IndexType.INT);
                              var18 = true;
                           }

                           var25.setUniform("ItemFx", ubo.slice((long)var30 * (long)stride, 272L));
                           var25.drawIndexed(0, 0, dripIndices, var38);
                        }
                     }
                  }
               }

               for (int var31 = 0; var31 < var16; var31++) {
                  int var35 = FX[var15 + var31];
                  if (ItemFx.design(var35) == 6) {
                     ItemFxRenderer.GpuMeshes var39 = MESHES.get(meshKey(6, 0, 0));
                     if (var39 != null) {
                        var25.setPipeline(GHOST_BACK_PIPE);
                        RenderSystem.bindDefaultUniforms(var25);
                        var25.bindTexture("Sampler0", atlasView, var13);
                        var25.bindTexture("Sampler2", var10, var11);
                        var25.setUniform("ItemFx", ubo.slice((long)var31 * (long)stride, 272L));
                        var25.setVertexBuffer(0, var39.vbo);
                        var25.setIndexBuffer(var39.ibo, IndexType.INT);
                        var25.drawIndexed(0, 0, var39.main, 1);
                        if (ItemFx.particles(var35)) {
                           var25.setPipeline(SKULL_PIPE);
                           RenderSystem.bindDefaultUniforms(var25);
                           var25.bindTexture("Sampler0", atlasView, var13);
                           var25.setVertexBuffer(0, quadVbo);
                           var25.setIndexBuffer(quadIbo, IndexType.INT);
                           var25.drawIndexed(0, 0, 6, 5);
                        }

                        var25.setPipeline(GHOST_FRONT_PIPE);
                        RenderSystem.bindDefaultUniforms(var25);
                        var25.bindTexture("Sampler0", atlasView, var13);
                        var25.bindTexture("Sampler2", var10, var11);
                        var25.setVertexBuffer(0, var39.vbo);
                        var25.setIndexBuffer(var39.ibo, IndexType.INT);
                        var25.drawIndexed(0, 0, var39.main, 1);
                     }
                  }
               }

               var18 = false;

               for (int var32 = 0; var32 < var16; var32++) {
                  int var36 = FX[var15 + var32];
                  int var40 = ItemFx.design(var36);
                  if (var40 >= 4) {
                     ItemFxRenderer.GpuMeshes var42 = MESHES.get(meshKey(var40, ItemFx.type(var36), ItemFx.tier(var36)));
                     if (var42 != null && var42.count > var42.main) {
                        if (!var18) {
                           var25.setPipeline(HALO_PIPE);
                           RenderSystem.bindDefaultUniforms(var25);
                           var25.bindTexture("Sampler0", atlasView, var14);
                           var18 = true;
                        }

                        var25.setUniform("ItemFx", ubo.slice((long)var32 * (long)stride, 272L));
                        var25.setVertexBuffer(0, var42.vbo);
                        var25.setIndexBuffer(var42.ibo, IndexType.INT);
                        var25.drawIndexed(0, var42.main, var42.count - var42.main, 1);
                     }
                  }
               }

               particles(var25, var15, var16, true);
               particles(var25, var15, var16, false);
            } catch (Throwable var24) {
               if (var25 != null) {
                  try {
                     var25.close();
                  } catch (Throwable var23) {
                     var24.addSuppressed(var23);
                  }
               }

               throw var24;
            }

            if (var25 != null) {
               var25.close();
            }
         }
      }
   }

   private static void particles(RenderPass var0, int var1, int var2, boolean var3) {
      boolean var4 = false;

      for (int var5 = 0; var5 < var2; var5++) {
         int var6 = FX[var1 + var5];
         int var7 = var3 ? ItemFx.glowCount(var6, ACT[var1 + var5]) : ItemFx.smokeCount(var6, ACT[var1 + var5]);
         if (var7 > 0) {
            if (!var4) {
               var0.setPipeline(var3 ? GLOW_PIPE : SMOKE_PIPE);
               RenderSystem.bindDefaultUniforms(var0);
               var0.setVertexBuffer(0, quadVbo);
               var0.setIndexBuffer(quadIbo, IndexType.INT);
               var4 = true;
            }

            var0.setUniform("ItemFx", ubo.slice((long)var5 * (long)stride, 272L));
            var0.drawIndexed(0, 0, 6, var7);
         }
      }
   }

   private static void writeInstance(int var0, int var1) {
      int var2 = FX[var0];
      int var3 = ItemFx.design(var2);
      int var4 = CTX[var0];
      float var5 = ACT[var0];
      float var6 = ItemFx.time();
      ItemFx.anim(ANIM, var2, var4, var5, var6);
      TMP.set(POSE[var0]).mul(ANIM);
      TMP3.set(NRM[var0]).mul(ANIM.get3x3(ANIM3));
      NM.identity().set(TMP3);
      ByteBuffer var7 = data;
      MV.get(var1, var7);
      TMP.get(var1 + 64, var7);
      NM.get(var1 + 128, var7);
      int var8 = LIGHT[var0];
      boolean var9 = var4 == 2 || var4 == 3;
      put4(var7, var1 + 192, var6, var5, (float)var3, (float)var4);
      put4(var7, var1 + 208, (float)((var8 & 65535) >> 4), (float)(var8 >>> 16 >> 4), var9 ? 0.0F : 1.0F, GLINT[var0] ? 1.0F : 0.0F);
      float var10 = (float)Math.sqrt((double)(TMP.m00() * TMP.m00() + TMP.m01() * TMP.m01() + TMP.m02() * TMP.m02()));
      put4(var7, var1 + 224, 0.0F, var4 == 2 ? -1.0F : 1.0F, 0.0F, var10);
      put4(var7, var1 + 240, (float)ItemFx.tier(var2), ItemFx.shaderStyle(var2), (float)ItemFx.type(var2), ItemFx.animations(var2) ? 1.0F : 0.0F);
      put4(
         var7,
         var1 + 256,
         ItemFx.particles(var2) ? 1.0F : 0.0F,
         ItemFx.intensity(var2),
         var3 == 3 ? 0.17F * (float)ItemFx.type(var2) + 0.05F * (float)ItemFx.tier(var2) : 0.37F,
         ItemFx.tint(var2)
      );
   }

   private static void put4(ByteBuffer var0, int var1, float var2, float var3, float var4, float var5) {
      var0.putFloat(var1, var2);
      var0.putFloat(var1 + 4, var3);
      var0.putFloat(var1 + 8, var4);
      var0.putFloat(var1 + 12, var5);
   }

   public static void releaseModels() {
      for (ItemFxRenderer.GpuMeshes var1 : MESHES.values()) {
         try {
            var1.close();
         } catch (Throwable var3) {
         }
      }

      MESHES.clear();
      pending = 0;
      if (atlasView != null) {
         atlasView.close();
         atlas.close();
         atlasView = null;
         atlas = null;
      }
   }

   static {
      for (int var0 = 0; var0 < 128; var0++) {
         POSE[var0] = new Matrix4f();
         NRM[var0] = new Matrix3f();
      }

      for (int var1 = 0; var1 < COMMANDS.length; var1++) {
         COMMANDS[var1] = new ItemFxRenderer.Command();
      }
   }

   private static record Built(MeshData mesh, int main, float[] anchors) {
   }

   private static final class Command implements Custom {
      int fx;
      int ctx;
      int light;
      boolean glint;
      float act;

      public void render(Entry var1, VertexConsumer var2) {
         if (ItemFxRenderer.pending < 128) {
            int var3 = ItemFxRenderer.pending++;
            ItemFxRenderer.POSE[var3].set(var1.getPositionMatrix());
            ItemFxRenderer.NRM[var3].set(var1.getNormalMatrix());
            ItemFxRenderer.FX[var3] = this.fx;
            ItemFxRenderer.CTX[var3] = this.ctx;
            ItemFxRenderer.LIGHT[var3] = this.light;
            ItemFxRenderer.GLINT[var3] = this.glint;
            ItemFxRenderer.ACT[var3] = this.act;
         }

         for (int var4 = 0; var4 < 4; var4++) {
            var2.vertex(0.0F, 0.0F, 0.0F, 0, 0.0F, 0.0F, 0, 0, 0.0F, 1.0F, 0.0F);
         }
      }
   }

   private static record GpuMeshes(GpuBuffer vbo, GpuBuffer ibo, int count, int main) implements AutoCloseable {
      @Override
      public void close() {
         this.vbo.close();
         this.ibo.close();
      }
   }
}
