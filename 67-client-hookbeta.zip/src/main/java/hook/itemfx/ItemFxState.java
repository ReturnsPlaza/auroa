package hook.itemfx;

import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;

public interface ItemFxState {
   int hook$fx();

   void hook$setFx(int var1);

   LayerRenderState hook$layer0();
}
