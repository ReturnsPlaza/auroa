package hook;

import java.io.File;
import hook.manager.EventManager;
import hook.manager.SettingsManager;
import hook.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import hook.feature.HookClickGuiScreen;

public final class Hook {
   public SettingsManager settingsManager;
   public ModuleManager MODULE_MANAGER;
   public EventManager EVENT_BUS;
   public static MinecraftClient mc;
   public String version;
   public static Hook INSTANCE;
   public boolean shouldPreventClose;
   public HookClickGuiScreen GUI;
   public Screen screen;
   public long modified;
   public File jar;

   public Hook() {
      try {
         INSTANCE = this;
         this.version = " b1.3";
         this.screen = null;
         this.EVENT_BUS = new EventManager();
         this.MODULE_MANAGER = new ModuleManager();
         this.GUI = new HookClickGuiScreen();
         this.settingsManager = new SettingsManager();
         this.getSettingsManager().loadProfile();
         this.jar = new File(Hook.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.modified = this.jar.lastModified();
         this.shouldPreventClose = false;
         mc = MinecraftClient.getInstance();
      } catch (Throwable var2) {
         var2.printStackTrace(System.err);
      }
   }

   public SettingsManager getSettingsManager() {
      return this.settingsManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }

   public void resetModifiedDate() {
      this.jar.setLastModified(this.modified);
   }
}
