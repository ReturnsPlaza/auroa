package meteordevelopment.meteorclient.events.game;

/** Fired when the player leaves a world/server (Meteor compatibility layer). */
public class GameLeftEvent {
}
