package meteordevelopment.meteorclient.events.game;

import net.minecraft.text.Text;

/** Fired for every system chat message (Meteor compatibility layer). */
public class ReceiveMessageEvent {
    public Text message;

    public ReceiveMessageEvent(Text message) {
        this.message = message;
    }

    public Text getMessage() {
        return message;
    }
}
