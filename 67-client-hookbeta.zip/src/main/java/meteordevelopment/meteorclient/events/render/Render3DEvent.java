package meteordevelopment.meteorclient.events.render;

import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import hook.utils.RenderUtils;

/**
 * 3D render event (Meteor compatibility layer). Boxes are drawn immediately through Hook Client's
 * RenderUtils, each with its own camera-transformed matrix stack so the shared event state is
 * never mutated.
 */
public class Render3DEvent {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public final Renderer renderer = new Renderer();

    public Render3DEvent() {
    }

    public static final class Renderer {
        public void box(BlockPos pos, Color color1, Color color2, ShapeMode shapeMode, double lineWidth) {
            box(new Box(pos), color1, color2, shapeMode, lineWidth);
        }

        public void box(Box box, Color color1, Color color2, ShapeMode shapeMode, double lineWidth) {
            if (mc == null || mc.world == null || color1 == null) return;

            MatrixStack matrices = new MatrixStack();
            RenderUtils.applyCameraTransform(matrices, RenderUtils.getCamera());

            if (shapeMode == ShapeMode.Both || shapeMode == ShapeMode.Sides) {
                RenderUtils.renderFilledBox(matrices,
                        (float) box.minX, (float) box.minY, (float) box.minZ,
                        (float) box.maxX, (float) box.maxY, (float) box.maxZ,
                        color1.toAwt());
            }

            if (shapeMode == ShapeMode.Both || shapeMode == ShapeMode.Lines) {
                Color lineColor = color2 != null ? color2 : color1;
                float width = lineWidth <= 0 ? 1.5f : (float) lineWidth;
                List<RenderUtils.ColoredLine> lines = new ArrayList<>();
                RenderUtils.addBoxOutline(lines,
                        box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ,
                        lineColor.toAwt(), width);
                RenderUtils.renderLines(matrices, lines);
            }
        }
    }
}
