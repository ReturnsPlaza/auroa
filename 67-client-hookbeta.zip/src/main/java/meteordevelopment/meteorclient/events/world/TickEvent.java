package meteordevelopment.meteorclient.events.world;

/** Client tick events (Meteor compatibility layer). The bridge posts {@link Pre} once per tick. */
public class TickEvent {
    public static class Pre extends TickEvent {
    }

    public static class Post extends TickEvent {
    }
}
