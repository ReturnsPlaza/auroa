package meteordevelopment.meteorclient.renderer;

/** Box drawing mode (Meteor compatibility layer). */
public enum ShapeMode {
    Both,
    Sides,
    Lines
}
