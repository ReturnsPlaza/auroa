package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

/** Double setting rendered by Hook Client's GUI as a number slider with two decimals. */
public class DoubleSetting extends hook.module.setting.NumberSetting implements Setting<Double> {
    private Consumer<Double> onChanged;

    public DoubleSetting(String name, double min, double max, double defaultValue) {
        super(name, min, max, defaultValue, 0.01);
    }

    @Override
    public Double get() {
        return getValue();
    }

    @Override
    public void set(Double value) {
        if (value != null) getValue(value);
    }

    @Override
    public void getValue(double value) {
        super.getValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private double defaultValue;
        private double min = Double.NaN;
        private double max = Double.NaN;
        private Consumer<Double> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(double defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder range(double min, double max) {
            this.min = min;
            this.max = max;
            return this;
        }

        public Builder sliderRange(double min, double max) {
            if (Double.isNaN(this.min)) {
                this.min = min;
                this.max = max;
            }
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Double> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public DoubleSetting build() {
            double lo = Double.isNaN(min) ? Math.min(0, defaultValue) : min;
            double hi = Double.isNaN(max) ? Math.max(1000, defaultValue) : max;
            DoubleSetting setting = new DoubleSetting(name, lo, hi, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
