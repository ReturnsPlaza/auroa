package meteordevelopment.meteorclient.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Block list setting rendered as an editable comma-separated list of block ids. */
public class BlockListSetting extends hook.module.setting.StringSetting implements Setting<List<Block>> {
    private Consumer<List<Block>> onChanged;

    public BlockListSetting(String name, Block... defaultValues) {
        super(name, idsOf(defaultValues));
    }

    @Override
    public List<Block> get() {
        List<Block> result = new ArrayList<>();
        String value = getValue();
        if (value == null || value.isEmpty()) return result;

        for (String part : value.split(",")) {
            Identifier id = Identifier.tryParse(part.trim());
            if (id == null || !Registries.BLOCK.containsId(id)) continue;
            Block block = Registries.BLOCK.get(id);
            if (block != null) result.add(block);
        }
        return result;
    }

    @Override
    public void set(List<Block> value) {
        if (value != null) setValue(idsOf(value.toArray(new Block[0])));
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    private static String idsOf(Block... blocks) {
        StringBuilder builder = new StringBuilder();
        for (Block block : blocks) {
            Identifier id = Registries.BLOCK.getId(block);
            if (id == null) continue;
            if (builder.length() > 0) builder.append(", ");
            builder.append(id);
        }
        return builder.toString();
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private Block[] defaultValues = new Block[0];
        private Consumer<List<Block>> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(Block... defaultValues) {
            this.defaultValues = defaultValues;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<List<Block>> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public BlockListSetting build() {
            BlockListSetting setting = new BlockListSetting(name, defaultValues);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
