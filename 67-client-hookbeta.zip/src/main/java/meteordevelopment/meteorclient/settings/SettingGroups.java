package meteordevelopment.meteorclient.settings;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds every setting of a module. Additions are mirrored into the Hook Client module's own setting
 * list, which is what the ClickGUI renders and the config system persists.
 */
public final class SettingGroups {
    private final hook.module.Module owner;
    private final List<Setting<?>> all = new ArrayList<>();

    public SettingGroups(hook.module.Module owner) {
        this.owner = owner;
    }

    public SettingGroup getDefaultGroup() {
        return new SettingGroup(this, "general");
    }

    public SettingGroup createGroup(String name) {
        return new SettingGroup(this, name);
    }

    void register(Setting<?> setting) {
        all.add(setting);
        if (setting instanceof hook.module.setting.Setting base) {
            owner.addSetting(base);
        }
    }

    @SuppressWarnings("unchecked")
    public <T> Setting<T> get(String name, Class<T> type) {
        for (Setting<?> setting : all) {
            if (!(setting instanceof hook.module.setting.Setting base)) continue;
            if (!name.contentEquals(base.getName())) continue;

            Object value = setting.get();
            if (value != null && type.isInstance(value)) return (Setting<T>) setting;
        }
        return null;
    }
}
