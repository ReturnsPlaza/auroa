package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

/** Boolean setting rendered by Hook Client's GUI as a toggle. */
public class BoolSetting extends hook.module.setting.BooleanSetting implements Setting<Boolean> {
    private Consumer<Boolean> onChanged;

    public BoolSetting(String name, boolean defaultValue) {
        super(name, defaultValue);
    }

    @Override
    public Boolean get() {
        return getValue();
    }

    @Override
    public void set(Boolean value) {
        if (value != null) setValue(value);
    }

    @Override
    public void setValue(boolean value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(getValue());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private boolean defaultValue;
        private Consumer<Boolean> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(boolean defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Boolean> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public BoolSetting build() {
            BoolSetting setting = new BoolSetting(name, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
