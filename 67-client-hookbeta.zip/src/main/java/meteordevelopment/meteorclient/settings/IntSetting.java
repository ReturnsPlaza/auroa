package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

/** Integer setting rendered by Hook Client's GUI as a number slider. */
public class IntSetting extends hook.module.setting.NumberSetting implements Setting<Integer> {
    private Consumer<Integer> onChanged;

    public IntSetting(String name, double min, double max, int defaultValue) {
        super(name, min, max, defaultValue, 1.0);
    }

    @Override
    public Integer get() {
        return (int) getValue();
    }

    @Override
    public void set(Integer value) {
        if (value != null) getValue(value.doubleValue());
    }

    @Override
    public void getValue(double value) {
        super.getValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private double defaultValue;
        private double min = Double.NaN;
        private double max = Double.NaN;
        private Consumer<Integer> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(int defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder range(double min, double max) {
            this.min = min;
            this.max = max;
            return this;
        }

        public Builder sliderRange(double min, double max) {
            if (Double.isNaN(this.min)) {
                this.min = min;
                this.max = max;
            }
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Integer> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public IntSetting build() {
            double lo = Double.isNaN(min) ? Math.min(0, defaultValue) : min;
            double hi = Double.isNaN(max) ? Math.max(1000, defaultValue) : max;
            IntSetting setting = new IntSetting(name, lo, hi, (int) defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
