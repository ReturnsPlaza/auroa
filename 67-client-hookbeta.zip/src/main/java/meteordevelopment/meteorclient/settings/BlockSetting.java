package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;

/**
 * Single-block setting rendered with Hook Client's item picker (a block's item). The stored value is
 * the block item; {@link #get()} converts it back to a block.
 */
public class BlockSetting extends hook.module.setting.ItemSetting implements Setting<Block> {
    private Consumer<Block> onChanged;

    public BlockSetting(String name, Block defaultValue) {
        super(name, defaultValue == null ? Blocks.AIR.asItem() : defaultValue.asItem());
    }

    @Override
    public Block get() {
        Item item = getItem();
        if (item instanceof BlockItem blockItem) return blockItem.getBlock();
        return Blocks.AIR;
    }

    @Override
    public void set(Block value) {
        if (value != null) setItem(value.asItem());
    }

    @Override
    public void setItem(Item item) {
        super.setItem(item);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private Block defaultValue = Blocks.AIR;
        private Consumer<Block> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(Block defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Block> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public BlockSetting build() {
            BlockSetting setting = new BlockSetting(name, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
