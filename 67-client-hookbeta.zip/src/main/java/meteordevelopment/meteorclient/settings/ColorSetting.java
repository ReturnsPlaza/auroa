package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

/** Colour setting rendered by Hook Client's colour picker (ARGB int under the hood). */
public class ColorSetting extends hook.module.setting.RgbSetting implements Setting<SettingColor> {
    private Consumer<SettingColor> onChanged;

    public ColorSetting(String name, SettingColor defaultValue) {
        super(name, toArgb(defaultValue));
    }

    @Override
    public SettingColor get() {
        return new SettingColor(getArgb());
    }

    @Override
    public void set(SettingColor value) {
        if (value != null) setArgb(toArgb(value));
    }

    @Override
    public void setArgb(int argb) {
        super.setArgb(argb);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    private static int toArgb(SettingColor color) {
        return (color.a << 24) | (color.r << 16) | (color.g << 8) | color.b;
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private SettingColor defaultValue = new SettingColor(255, 255, 255, 255);
        private Consumer<SettingColor> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(SettingColor defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<SettingColor> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public ColorSetting build() {
            ColorSetting setting = new ColorSetting(name, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
