package meteordevelopment.meteorclient.settings;

/**
 * Typed setting accessor (Meteor compatibility layer). Concrete settings also extend Hook Client's
 * {@code hook.module.setting.Setting} subclasses so the ClickGUI can render and persist them.
 */
public interface Setting<T> {
    T get();

    void set(T value);
}
