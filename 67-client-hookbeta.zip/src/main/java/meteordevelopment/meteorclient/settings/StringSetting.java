package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

/** Free-text setting rendered by Hook Client's GUI as a text field. */
public class StringSetting extends hook.module.setting.StringSetting implements Setting<String> {
    private Consumer<String> onChanged;

    public StringSetting(String name, String defaultValue) {
        super(name, defaultValue == null ? "" : defaultValue);
    }

    @Override
    public String get() {
        String value = getValue();
        return value == null ? "" : value;
    }

    @Override
    public void set(String value) {
        if (value != null) setValue(value);
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private String defaultValue = "";
        private Consumer<String> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(String defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder placeholder(String placeholder) {
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<String> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public StringSetting build() {
            StringSetting setting = new StringSetting(name, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
