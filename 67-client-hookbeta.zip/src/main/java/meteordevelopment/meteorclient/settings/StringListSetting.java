package meteordevelopment.meteorclient.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** List-of-strings setting rendered as an editable comma-separated text field. */
public class StringListSetting extends hook.module.setting.StringSetting implements Setting<List<String>> {
    private Consumer<List<String>> onChanged;

    public StringListSetting(String name, String... defaultValues) {
        super(name, join(defaultValues));
    }

    @Override
    public List<String> get() {
        String value = getValue();
        List<String> result = new ArrayList<>();
        if (value == null || value.isEmpty()) return result;

        for (String part : value.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) result.add(trimmed);
        }
        return result;
    }

    @Override
    public void set(List<String> value) {
        if (value != null) setValue(join(value.toArray(new String[0])));
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    private static String join(String[] values) {
        StringBuilder builder = new StringBuilder();
        for (String value : values) {
            if (value == null || value.isEmpty()) continue;
            if (builder.length() > 0) builder.append(", ");
            builder.append(value);
        }
        return builder.toString();
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private String[] defaultValues = new String[0];
        private Consumer<List<String>> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(String... defaultValues) {
            this.defaultValues = defaultValues;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<List<String>> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public StringListSetting build() {
            StringListSetting setting = new StringListSetting(name, defaultValues);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
