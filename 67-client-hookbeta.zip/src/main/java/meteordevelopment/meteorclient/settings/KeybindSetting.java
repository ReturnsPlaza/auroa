package meteordevelopment.meteorclient.settings;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.utils.misc.Keybind;

/**
 * Keybind setting backed by Hook Client's BindSetting. The action is fired by the event bridge when
 * the key is pressed in-game (not while a screen is open).
 */
public class KeybindSetting extends hook.module.setting.BindSetting implements Setting<Keybind> {
    static final List<KeybindSetting> ALL = new CopyOnWriteArrayList<>();

    private Runnable action;
    private Consumer<Keybind> onChanged;

    public KeybindSetting(String name, Keybind defaultValue, Runnable action) {
        super(name, defaultValue == null ? Keybind.NONE : defaultValue.getKey(), false);
        this.action = action;
        ALL.add(this);
    }

    @Override
    public Keybind get() {
        return new Keybind(getValue());
    }

    @Override
    public void set(Keybind value) {
        if (value != null) setValue(value.getKey());
    }

    @Override
    public void setValue(int key) {
        super.setValue(key);
        fire();
    }

    /** Invoked by the bridge when this keybind's key goes down in-game. */
    public void runAction() {
        if (action != null) action.run();
    }

    /** Called by the bridge for every in-game key press; runs every matching keybind action. */
    public static void handleKeyPress(int key) {
        if (key < 0) return;
        for (KeybindSetting setting : ALL) {
            if (setting.getValue() == key && setting.action != null) {
                try {
                    setting.action.run();
                } catch (Throwable t) {
                    System.err.println("Hook: keybind action failed");
                    t.printStackTrace(System.err);
                }
            }
        }
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private Keybind defaultValue = Keybind.none();
        private Runnable action;
        private Consumer<Keybind> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(Keybind defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder action(Runnable action) {
            this.action = action;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Keybind> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public KeybindSetting build() {
            KeybindSetting setting = new KeybindSetting(name, defaultValue, action);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
