package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;

/** Enum setting rendered by Hook Client's GUI as a cycling mode selector. */
public class EnumSetting<T extends Enum<T>> extends hook.module.setting.ModeSetting<T> implements Setting<T> {
    private Consumer<T> onChanged;

    public EnumSetting(String name, T defaultValue, Class<T> type) {
        super(name, defaultValue, type);
    }

    @SuppressWarnings("unchecked")
    @Override
    public T get() {
        return (T) getValue();
    }

    @Override
    public void set(T value) {
        if (value != null) setMode(value);
    }

    @Override
    public void setMode(Enum<T> value) {
        super.setMode(value);
        fire();
    }

    @Override
    public void setModeIndex(int index) {
        super.setModeIndex(index);
        fire();
    }

    @Override
    public void cycleUp() {
        super.cycleUp();
        fire();
    }

    @Override
    public void cycleDown() {
        super.cycleDown();
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    public static class Builder<T extends Enum<T>> {
        private String name = "";
        private String description = "";
        private T defaultValue;
        private Consumer<T> onChanged;

        public Builder<T> name(String name) {
            this.name = name;
            return this;
        }

        public Builder<T> description(String description) {
            this.description = description;
            return this;
        }

        public Builder<T> defaultValue(T defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder<T> visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder<T> onChanged(Consumer<T> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public EnumSetting<T> build() {
            if (defaultValue == null) {
                throw new IllegalStateException("EnumSetting '" + name + "' built without a default value");
            }
            @SuppressWarnings("unchecked")
            Class<T> type = (Class<T>) defaultValue.getDeclaringClass();
            EnumSetting<T> setting = new EnumSetting<>(name, defaultValue, type);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
