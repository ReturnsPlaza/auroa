package meteordevelopment.meteorclient.settings;

import java.util.function.Consumer;
import net.minecraft.util.math.BlockPos;

/** Block-position setting rendered as an editable {@code "x, y, z"} text field. */
public class BlockPosSetting extends hook.module.setting.StringSetting implements Setting<BlockPos> {
    private final BlockPos defaultValue;
    private Consumer<BlockPos> onChanged;

    public BlockPosSetting(String name, BlockPos defaultValue) {
        super(name, format(defaultValue));
        this.defaultValue = defaultValue == null ? BlockPos.ORIGIN : defaultValue;
    }

    @Override
    public BlockPos get() {
        String value = getValue();
        if (value == null) return defaultValue;

        String[] parts = value.split(",");
        if (parts.length != 3) return defaultValue;
        try {
            int x = Integer.parseInt(parts[0].trim());
            int y = Integer.parseInt(parts[1].trim());
            int z = Integer.parseInt(parts[2].trim());
            return new BlockPos(x, y, z);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    @Override
    public void set(BlockPos value) {
        if (value != null) setValue(format(value));
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    private static String format(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private BlockPos defaultValue = BlockPos.ORIGIN;
        private Consumer<BlockPos> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(BlockPos defaultValue) {
            this.defaultValue = defaultValue;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<BlockPos> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public BlockPosSetting build() {
            BlockPosSetting setting = new BlockPosSetting(name, defaultValue);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
