package meteordevelopment.meteorclient.settings;

/**
 * Logical group of settings. Hook Client's GUI shows a flat list; grouping only organises lookup
 * and mirrors each addition into the Hook Client module so it renders and persists.
 */
public final class SettingGroup {
    private final SettingGroups owner;
    private final String name;

    SettingGroup(SettingGroups owner, String name) {
        this.owner = owner;
        this.name = name;
    }

    public String name() {
        return name;
    }

    public <T> Setting<T> add(Setting<T> setting) {
        owner.register(setting);
        return setting;
    }
}
