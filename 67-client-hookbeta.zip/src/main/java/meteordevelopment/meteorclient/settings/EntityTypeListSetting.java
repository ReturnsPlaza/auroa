package meteordevelopment.meteorclient.settings;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Entity-type list setting rendered as an editable comma-separated list of type ids. */
public class EntityTypeListSetting extends hook.module.setting.StringSetting
        implements Setting<java.util.Set<EntityType<?>>> {
    private Consumer<Set<EntityType<?>>> onChanged;

    public EntityTypeListSetting(String name, EntityType<?>... defaultValues) {
        super(name, idsOf(defaultValues));
    }

    @Override
    public Set<EntityType<?>> get() {
        Set<EntityType<?>> result = new LinkedHashSet<>();
        String value = getValue();
        if (value == null || value.isEmpty()) return result;

        for (String part : value.split(",")) {
            Identifier id = Identifier.tryParse(part.trim());
            if (id == null || !Registries.ENTITY_TYPE.containsId(id)) continue;
            EntityType<?> type = Registries.ENTITY_TYPE.get(id);
            if (type != null) result.add(type);
        }
        return result;
    }

    @Override
    public void set(Set<EntityType<?>> value) {
        if (value != null) setValue(idsOf(value.toArray(new EntityType<?>[0])));
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        fire();
    }

    private void fire() {
        if (onChanged != null) onChanged.accept(get());
    }

    private static String idsOf(EntityType<?>... types) {
        StringBuilder builder = new StringBuilder();
        for (EntityType<?> type : types) {
            Identifier id = Registries.ENTITY_TYPE.getId(type);
            if (id == null) continue;
            if (builder.length() > 0) builder.append(", ");
            builder.append(id);
        }
        return builder.toString();
    }

    public static class Builder {
        private String name = "";
        private String description = "";
        private EntityType<?>[] defaultValues = new EntityType<?>[0];
        private Consumer<Set<EntityType<?>>> onChanged;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder defaultValue(EntityType<?>... defaultValues) {
            this.defaultValues = defaultValues;
            return this;
        }

        public Builder visible(java.util.function.Supplier<Boolean> visible) {
            return this;
        }

        public Builder onChanged(Consumer<Set<EntityType<?>>> onChanged) {
            this.onChanged = onChanged;
            return this;
        }

        public EntityTypeListSetting build() {
            EntityTypeListSetting setting = new EntityTypeListSetting(name, defaultValues);
            setting.onChanged = onChanged;
            if (!description.isEmpty()) setting.setDescription(description);
            return setting;
        }
    }
}
