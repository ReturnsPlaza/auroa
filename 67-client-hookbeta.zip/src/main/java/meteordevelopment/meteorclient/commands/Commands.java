package meteordevelopment.meteorclient.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

/**
 * Registry and dispatcher for dot commands. Hook Client has no command framework, so the event bridge
 * feeds outgoing chat here and cancels the packet when a registered command consumed it.
 */
public final class Commands {
    private static final List<Command> COMMANDS = new ArrayList<>();

    private Commands() {
    }

    public static void add(Command command) {
        COMMANDS.add(command);
    }

    /** @return true when {@code message} was a registered dot command and must not be sent */
    public static boolean dispatch(String message) {
        if (message == null || !message.startsWith(".")) return false;

        String body = message.substring(1).trim();
        if (body.isEmpty()) return false;

        String[] parts = body.split("\\s+", 2);
        Command command = find(parts[0]);
        if (command == null) return false;

        try {
            LiteralArgumentBuilder<CommandSource> root = LiteralArgumentBuilder.literal(command.name);
            command.build(root);

            CommandDispatcher<CommandSource> dispatcher = new CommandDispatcher<>();
            dispatcher.register(root);

            String normalized = command.name + (parts.length > 1 ? " " + parts[1] : "");
            dispatcher.execute(normalized, noopSource());
        } catch (CommandSyntaxException e) {
            CommandChat.send(Text.literal("§7[§bHook§7] §c" + e.getRawMessage().getString()));
        } catch (Throwable t) {
            CommandChat.send(Text.literal("§7[§bHook§7] §cCommand failed: " + t));
            t.printStackTrace(System.err);
        }
        return true;
    }

    private static Command find(String token) {
        for (Command command : COMMANDS) {
            if (command.name.equalsIgnoreCase(token)) return command;
            if (command.alias != null && command.alias.equalsIgnoreCase(token)) return command;
        }
        return null;
    }

    /**
     * Command feedback goes through chat directly; the source itself is never used for output.
     * Built as a dynamic proxy so it stays valid regardless of which abstract methods the
     * current mappings declare on {@link CommandSource}.
     */
    private static CommandSource noopSource() {
        return (CommandSource) Proxy.newProxyInstance(
            Commands.class.getClassLoader(),
            new Class<?>[]{CommandSource.class},
            (proxy, method, args) -> {
                Class<?> type = method.getReturnType();
                if (type == boolean.class) return false;
                if (type == int.class) return 0;
                if (type == long.class) return 0L;
                if (type == float.class) return 0.0F;
                if (type == double.class) return 0.0;
                return null;
            });
    }
}
