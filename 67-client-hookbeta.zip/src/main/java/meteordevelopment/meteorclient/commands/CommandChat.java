package meteordevelopment.meteorclient.commands;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** Chat output helper for the command layer (main-thread safe). */
final class CommandChat {
    private CommandChat() {
    }

    static void send(Text message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null) return;

        if (mc.isOnThread()) {
            mc.inGameHud.getChatHud().addMessage(message);
        } else {
            mc.execute(() -> mc.inGameHud.getChatHud().addMessage(message));
        }
    }
}
