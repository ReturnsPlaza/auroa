package meteordevelopment.meteorclient.commands;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

/** Base class for {@code .hook} style commands (Meteor compatibility layer). */
public abstract class Command {
    public static final int SINGLE_SUCCESS = 1;

    public final String name;
    public final String description;
    public final String alias;

    protected Command(String name, String description, String alias) {
        this.name = name;
        this.description = description;
        this.alias = alias;
    }

    public abstract void build(LiteralArgumentBuilder<CommandSource> builder);

    protected LiteralArgumentBuilder<CommandSource> literal(String name) {
        return LiteralArgumentBuilder.literal(name);
    }

    protected <T> RequiredArgumentBuilder<CommandSource, T> argument(String name, ArgumentType<T> type) {
        return RequiredArgumentBuilder.argument(name, type);
    }

    protected void info(String format, Object... args) {
        chat("§f", format, args);
    }

    protected void warning(String format, Object... args) {
        chat("§e", format, args);
    }

    protected void error(String format, Object... args) {
        chat("§c", format, args);
    }

    private void chat(String color, String format, Object... args) {
        String message;
        try {
            message = args.length == 0 ? format : String.format(format, args);
        } catch (RuntimeException e) {
            message = format;
        }

        CommandChat.send(Text.literal("§7[§bHook§7] " + color + message));
    }
}
