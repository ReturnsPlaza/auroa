package meteordevelopment.meteorclient.addons;

/** Base class for addons (Meteor compatibility layer). Hook Client calls {@link #onInitialize()} itself. */
public abstract class MeteorAddon {
    public void onRegisterCategories() {
    }

    public abstract void onInitialize();

    public String getPackage() {
        return "";
    }
}
