package meteordevelopment.meteorclient.systems.modules;

import java.util.Optional;

/**
 * Module registry (Meteor compatibility layer). Delegates to the client's ModuleManager; instances
 * are registered by the Hook Client bootstrap after it has been created.
 */
public final class Modules {
    private static Modules instance;

    private Modules() {
    }

    public static Modules get() {
        if (instance == null) instance = new Modules();
        return instance;
    }

    public void add(Module module) {
        hook.Hook.INSTANCE.getModuleManager().a(module);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        return (T) hook.Hook.INSTANCE.getModuleManager().getModuleByClass(type);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> Optional<T> getOptional(Class<T> type) {
        return Optional.ofNullable((T) hook.Hook.INSTANCE.getModuleManager().getModuleByClass(type));
    }

    public static void registerCategory(Category category) {
        // Hook Client derives categories from the module instances; nothing to register.
    }
}
