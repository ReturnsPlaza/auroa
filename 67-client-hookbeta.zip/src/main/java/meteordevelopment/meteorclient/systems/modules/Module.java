package meteordevelopment.meteorclient.systems.modules;

import meteordevelopment.meteorclient.settings.SettingGroups;
import meteordevelopment.orbit.EventBus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Module base class (Meteor compatibility layer). Extends Hook Client's Module so instances show up in
 * the ClickGUI, persist through Hook Client's config and toggle through Hook Client's keybind/GUI system;
 * {@code onEnable}/{@code onDisable} wire the meteor-style event subscription around
 * {@link #onActivate()}/{@link #onDeactivate()}.
 */
public abstract class Module extends hook.module.Module {
    /** Exact module id, e.g. {@code auto-area-miner}. */
    public final String name;
    /** Display name, e.g. {@code Auto Area Miner}. */
    public final String title;

    public SettingGroups settings;

    public Module(Category category, String name, String description) {
        super(formatName(name), description, -1,
                category == null ? hook.module.Category.AUTOMATION : category.hook());
        this.name = name;
        this.title = formatName(name);
        this.settings = new SettingGroups(this);
    }

    // Lifecycle ---------------------------------------------------------------------------

    @Override
    public void onEnable() {
        EventBus.get().subscribe(this);
        super.onEnable();
        onActivate();
    }

    @Override
    public void onDisable() {
        EventBus.get().unsubscribe(this);
        super.onDisable();
        onDeactivate();
    }

    public void onActivate() {
    }

    public void onDeactivate() {
    }

    public boolean isActive() {
        return isEnabled();
    }

    public void activate() {
        toggle(true);
    }

    public void enable() {
        toggle(true);
    }

    public void disable() {
        toggle(false);
    }

    /**
     * Hook's config loader re-enables persisted modules through {@code setEnabled}, which fires
     * no lifecycle on the base class. Mirror the activate/deactivate contract so a reloaded module
     * is never "enabled but dead". ({@code toggle()} assigns the field directly, so the two paths
     * cannot double-fire.)
     */
    @Override
    public void setEnabled(boolean enabled) {
        boolean was = isEnabled();
        super.setEnabled(enabled);
        if (enabled == was) return;

        if (enabled) {
            EventBus.get().subscribe(this);
            super.onEnable();
            onActivate();
        } else {
            EventBus.get().unsubscribe(this);
            super.onDisable();
            onDeactivate();
        }
    }

    /** Short status line for HUDs and lists; modules override it. */
    public String getInfoString() {
        return null;
    }

    // Chat output -------------------------------------------------------------------------

    public void info(String format, Object... args) {
        chat("§f", format, args);
    }

    public void warning(String format, Object... args) {
        chat("§e", format, args);
    }

    public void error(String format, Object... args) {
        chat("§c", format, args);
    }

    private void chat(String color, String format, Object... args) {
        String message;
        try {
            message = args == null || args.length == 0 ? format : String.format(format, args);
        } catch (RuntimeException e) {
            message = format;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null) return;

        Text text = Text.literal("§7[§b" + title + "§7] " + color + message);
        if (mc.isOnThread()) {
            mc.inGameHud.getChatHud().addMessage(text);
        } else {
            mc.execute(() -> mc.inGameHud.getChatHud().addMessage(text));
        }
    }

    private static String formatName(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        StringBuilder builder = new StringBuilder(raw.length() + 8);
        for (String word : raw.split("[-_]+")) {
            if (word.isEmpty()) continue;
            if (builder.length() > 0) builder.append(' ');
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return builder.toString();
    }
}
