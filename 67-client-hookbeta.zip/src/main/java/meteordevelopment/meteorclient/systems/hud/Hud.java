package meteordevelopment.meteorclient.systems.hud;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;

/** HUD registry (Meteor compatibility layer); the bridge renders registered elements. */
public class Hud {
    private static final Hud INSTANCE = new Hud();

    private final List<HudElementInfo<?>> infos = new ArrayList<>();
    private final Map<HudElementInfo<?>, HudElement> elements = new IdentityHashMap<>();

    public static Hud get() {
        return INSTANCE;
    }

    public void register(HudElementInfo<?> info) {
        if (!infos.contains(info)) infos.add(info);
    }

    /** Renders all registered elements stacked from the top-left corner. */
    public void render(DrawContext context) {
        if (infos.isEmpty()) return;

        HudRenderer renderer = new HudRenderer();
        renderer.begin(context);

        double y = 4;
        for (HudElementInfo<?> info : infos) {
            HudElement element = elements.get(info);
            if (element == null) {
                element = info.create();
                elements.put(info, element);
            }

            element.x = 4;
            element.y = y;
            element.render(renderer);
            y += Math.max(element.height, 0) + 2;
        }
    }
}
