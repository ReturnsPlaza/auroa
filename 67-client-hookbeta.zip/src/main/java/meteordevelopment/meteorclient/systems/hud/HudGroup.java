package meteordevelopment.meteorclient.systems.hud;

/** HUD element group (Meteor compatibility layer). */
public class HudGroup {
    public final String name;

    public HudGroup(String name) {
        this.name = name;
    }
}
