package meteordevelopment.meteorclient.systems.hud;

import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Text renderer handed to HUD elements (Meteor compatibility layer). */
public class HudRenderer {
    private DrawContext context;

    void begin(DrawContext context) {
        this.context = context;
    }

    public void text(String text, double x, double y, Color color, boolean shadow) {
        if (context == null || text == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        context.drawText(mc.textRenderer, Text.literal(text), (int) x, (int) y, color.getRGB(), shadow);
    }

    public double textWidth(String text, boolean bold) {
        if (text == null) return 0;
        return MinecraftClient.getInstance().textRenderer.getWidth(text);
    }

    public double textHeight(boolean bold) {
        return MinecraftClient.getInstance().textRenderer.fontHeight;
    }
}
