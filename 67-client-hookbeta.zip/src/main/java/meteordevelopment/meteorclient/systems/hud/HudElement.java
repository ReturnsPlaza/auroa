package meteordevelopment.meteorclient.systems.hud;

/** Base class for HUD elements (Meteor compatibility layer). */
public abstract class HudElement {
    public double x;
    public double y;
    public double width;
    public double height;

    protected HudElement(HudElementInfo<?> info) {
    }

    public abstract void render(HudRenderer renderer);

    protected void setSize(double width, double height) {
        this.width = width;
        this.height = height;
    }
}
