package meteordevelopment.meteorclient.systems.hud;

import java.util.function.Supplier;

/** Registration record for a HUD element (Meteor compatibility layer). */
public class HudElementInfo<T extends HudElement> {
    public final HudGroup group;
    public final String name;
    public final String description;
    private final Supplier<T> factory;

    public HudElementInfo(HudGroup group, String name, String description, Supplier<T> factory) {
        this.group = group;
        this.name = name;
        this.description = description;
        this.factory = factory;
    }

    public T create() {
        return factory.get();
    }
}
