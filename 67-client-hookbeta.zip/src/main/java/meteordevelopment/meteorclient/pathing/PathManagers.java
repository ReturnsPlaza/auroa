package meteordevelopment.meteorclient.pathing;

import net.minecraft.util.math.BlockPos;

/**
 * Hook Client ships no pathfinding, so this returns a manager named {@code "none"}. The Hook navigator
 * checks for exactly that name and falls back to its own key-input walker.
 */
public final class PathManagers {
    private static final IPathManager NONE = new IPathManager() {
        @Override
        public String getName() {
            return "none";
        }

        @Override
        public void moveTo(BlockPos target) {
        }

        @Override
        public boolean isPathing() {
            return false;
        }

        @Override
        public void stop() {
        }
    };

    private PathManagers() {
    }

    public static IPathManager get() {
        return NONE;
    }
}
