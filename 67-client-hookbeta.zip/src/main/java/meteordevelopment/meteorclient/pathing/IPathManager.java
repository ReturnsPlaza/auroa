package meteordevelopment.meteorclient.pathing;

import net.minecraft.util.math.BlockPos;

/** Path manager surface used by the navigator (Meteor compatibility layer). */
public interface IPathManager {
    String getName();

    void moveTo(BlockPos target);

    boolean isPathing();

    void stop();
}
