package meteordevelopment.meteorclient.utils.world;

import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Block interaction helpers (Meteor compatibility layer), implemented on top of the vanilla
 * client interaction manager: break progresses one block at a time exactly like holding down
 * the attack key, place clicks an adjacent support face after selecting the item.
 */
public final class BlockUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static BlockPos breakingPos;

    private BlockUtils() {
    }

    /** True when the block can be mined at all (hardness 0 or better, so bedrock is out). */
    public static boolean canBreak(BlockPos pos, BlockState state) {
        if (mc.world == null || pos == null || state == null || state.isAir()) return false;
        return state.getHardness(mc.world, pos) >= 0;
    }

    /**
     * Advances breaking of {@code pos} by one tick: starts the break when it is not running yet,
     * continues it otherwise.
     *
     * @return true when the block is being (or was just) broken
     */
    public static boolean breakBlock(BlockPos pos, boolean swing) {
        if (mc.player == null || mc.interactionManager == null || mc.world == null || pos == null) return false;

        BlockState state = mc.world.getBlockState(pos);
        if (!canBreak(pos, state)) return false;

        Direction side = facing(pos);
        boolean continuing = mc.interactionManager.isBreakingBlock() && pos.equals(breakingPos);
        boolean working = continuing
                ? mc.interactionManager.updateBlockBreakingProgress(pos, side)
                : mc.interactionManager.attackBlock(pos, side);
        breakingPos = pos;

        if (swing) mc.player.swingHand(Hand.MAIN_HAND);
        return working || continuing;
    }

    /**
     * Direction from {@code pos} to a solid neighbour that can be clicked to place against,
     * or {@code null} when the block has no placement support yet.
     */
    public static Direction getPlaceSide(BlockPos pos) {
        if (mc.world == null || pos == null) return null;

        for (Direction direction : Direction.values()) {
            if (!mc.world.getBlockState(pos.offset(direction)).isReplaceable()) {
                return direction;
            }
        }
        return null;
    }

    /** True when the position is replaceable, i.e. something could be placed there. */
    public static boolean canPlace(BlockPos pos) {
        if (mc.world == null || pos == null) return false;
        return mc.world.getBlockState(pos).isReplaceable();
    }

    /**
     * Places the block held in {@code item}'s hotbar slot at {@code pos} by clicking the support
     * face returned by {@link #getPlaceSide(BlockPos)}. The block appears once the server
     * confirms; callers verify the world state themselves.
     *
     * @param rotate look at the clicked face first
     * @param priority unused; kept for call-site compatibility
     * @param swing swing the hand when the interaction was accepted
     * @param checkSpace unused; callers already checked the target
     * @param altInteract unused; kept for call-site compatibility
     */
    public static boolean place(BlockPos pos, FindItemResult item, boolean rotate, int priority,
            boolean swing, boolean checkSpace, boolean altInteract) {
        if (mc.player == null || mc.interactionManager == null || mc.world == null || pos == null) return false;
        if (item == null || !item.found() || !item.isHotbar()) return false;

        if (mc.player.getInventory().getSelectedSlot() != item.slot()) {
            mc.player.getInventory().setSelectedSlot(item.slot());
        }

        Direction side = getPlaceSide(pos);
        if (side == null) return false;

        BlockPos support = pos.offset(side);
        Direction face = side.getOpposite();
        Vec3d hit = new Vec3d(
                support.getX() + 0.5 + face.getOffsetX() * 0.5,
                support.getY() + 0.5 + face.getOffsetY() * 0.5,
                support.getZ() + 0.5 + face.getOffsetZ() * 0.5);

        if (rotate) {
            Rotations.rotate(Rotations.getYaw(hit), Rotations.getPitch(hit));
        }

        BlockHitResult hitResult = new BlockHitResult(hit, face, support, false);
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
        if (result.isAccepted() && swing) {
            mc.player.swingHand(Hand.MAIN_HAND);
        }
        return result.isAccepted();
    }

    /** Dominant axis from the eye towards the block, used as the digging/placing face. */
    private static Direction facing(BlockPos pos) {
        Vec3d delta = Vec3d.ofCenter(pos).subtract(mc.player.getEyePos());
        double ax = Math.abs(delta.x);
        double ay = Math.abs(delta.y);
        double az = Math.abs(delta.z);

        if (ax >= ay && ax >= az) return delta.x > 0 ? Direction.EAST : Direction.WEST;
        if (ay >= az) return delta.y > 0 ? Direction.UP : Direction.DOWN;
        return delta.z > 0 ? Direction.SOUTH : Direction.NORTH;
    }
}
