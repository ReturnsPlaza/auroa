package meteordevelopment.meteorclient.utils.player;

import net.minecraft.client.MinecraftClient;

/** Chat helpers (Meteor compatibility layer). */
public final class ChatUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private ChatUtils() {
    }

    /** Sends a chat message as the player (commands start with {@code /}). */
    public static void sendPlayerMsg(String message) {
        if (mc.player == null || mc.getNetworkHandler() == null || message == null) return;
        mc.getNetworkHandler().sendChatMessage(message);
    }
}
