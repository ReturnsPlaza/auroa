package meteordevelopment.meteorclient.utils.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Rotation helpers (Meteor compatibility layer). Hook Client has no queued rotation system, so the
 * look direction is applied straight to the player: vanilla then sends a normal look packet on
 * the next movement update, before the action packets that follow it in the same tick.
 */
public final class Rotations {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Rotations() {
    }

    public static double getYaw(Vec3d target) {
        if (mc.player == null || target == null) return 0;
        Vec3d eyes = mc.player.getEyePos();
        return Math.toDegrees(Math.atan2(target.z - eyes.z, target.x - eyes.x)) - 90.0;
    }

    public static double getPitch(Vec3d target) {
        if (mc.player == null || target == null) return 0;
        Vec3d eyes = mc.player.getEyePos();
        double dx = target.x - eyes.x;
        double dy = target.y - eyes.y;
        double dz = target.z - eyes.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return -Math.toDegrees(Math.atan2(dy, horizontal));
    }

    public static void rotate(double yaw, double pitch) {
        if (mc.player == null) return;
        mc.player.setYaw((float) yaw);
        mc.player.setPitch((float) Math.max(-90, Math.min(90, pitch)));
    }
}
