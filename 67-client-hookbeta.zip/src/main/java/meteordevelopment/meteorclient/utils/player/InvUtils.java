package meteordevelopment.meteorclient.utils.player;

import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Inventory helpers (Meteor compatibility layer), backed by vanilla inventory access. */
public final class InvUtils {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private InvUtils() {
    }

    /** First matching stack in the hotbar and main inventory (slots 0-35). */
    public static FindItemResult find(Predicate<ItemStack> filter) {
        return scan(0, PlayerInventory.MAIN_SIZE, filter);
    }

    /** First matching stack in the hotbar (slots 0-8). */
    public static FindItemResult findInHotbar(Predicate<ItemStack> filter) {
        return scan(0, 9, filter);
    }

    /**
     * Fastest tool for mining {@code state}: highest mining speed, preferring suitable tools on
     * ties. Returns an empty result when the inventory holds nothing better than the bare hand.
     */
    public static FindItemResult findFastestTool(BlockState state) {
        if (mc.player == null || state == null) return new FindItemResult(-1, 0);

        PlayerInventory inventory = mc.player.getInventory();
        int bestSlot = -1;
        float bestSpeed = 1.0f;
        boolean bestSuitable = false;

        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isEmpty()) continue;

            float speed = stack.getMiningSpeedMultiplier(state);
            boolean suitable = stack.isSuitableFor(state);
            if (speed <= 1.0f && !suitable) continue;

            boolean better = speed > bestSpeed
                    || (speed == bestSpeed && suitable && !bestSuitable);
            if (better) {
                bestSpeed = speed;
                bestSuitable = suitable;
                bestSlot = slot;
            }
        }

        if (bestSlot < 0) return new FindItemResult(-1, 0);
        return new FindItemResult(bestSlot, inventory.getStack(bestSlot).getCount());
    }

    /** Selects the given hotbar slot (0-8). The {@code swapBack} flag is not used. */
    public static boolean swap(int slot, boolean swapBack) {
        if (mc.player == null || slot < 0 || slot > 8) return false;
        mc.player.getInventory().setSelectedSlot(slot);
        return true;
    }

    /** Fluent inventory move: {@code InvUtils.move().from(slot).toHotbar(hotbarSlot)}. */
    public static MoveItem move() {
        return new MoveItem();
    }

    private static FindItemResult scan(int from, int to, Predicate<ItemStack> filter) {
        if (mc.player == null) return new FindItemResult(-1, 0);

        PlayerInventory inventory = mc.player.getInventory();
        for (int slot = from; slot < to; slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (!stack.isEmpty() && filter.test(stack)) {
                return new FindItemResult(slot, stack.getCount());
            }
        }
        return new FindItemResult(-1, 0);
    }

    public static final class MoveItem {
        private int from = -1;

        private MoveItem() {
        }

        public MoveItem from(int slot) {
            this.from = slot;
            return this;
        }

        public MoveItem from(FindItemResult result) {
            this.from = result == null ? -1 : result.slot();
            return this;
        }

        /** Swaps the source slot with the given hotbar slot (0-8) through the screen handler. */
        public void toHotbar(int hotbarSlot) {
            if (mc.player == null || mc.interactionManager == null) return;
            if (from < 0 || from >= PlayerInventory.MAIN_SIZE) return;
            if (hotbarSlot < 0 || hotbarSlot > 8 || from == hotbarSlot) return;

            mc.interactionManager.clickSlot(
                    mc.player.currentScreenHandler.syncId, from, hotbarSlot, SlotActionType.SWAP, mc.player);
        }
    }
}
