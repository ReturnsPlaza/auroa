package meteordevelopment.meteorclient.utils.player;

/**
 * Result of an inventory lookup (Meteor compatibility layer). {@code slot} is a raw
 * {@code PlayerInventory} index: hotbar 0-8, main inventory 9-35, {@code -1} when nothing matched.
 */
public class FindItemResult {
    private final int slot;
    private final int count;

    public FindItemResult(int slot, int count) {
        this.slot = slot;
        this.count = count;
    }

    public boolean found() {
        return slot >= 0;
    }

    public boolean empty() {
        return !found();
    }

    public int slot() {
        return slot;
    }

    public int count() {
        return count;
    }

    public boolean isHotbar() {
        return slot >= 0 && slot < 9;
    }

    public int hotbar() {
        return isHotbar() ? slot : -1;
    }
}
