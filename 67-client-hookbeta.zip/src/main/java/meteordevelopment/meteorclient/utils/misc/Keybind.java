package meteordevelopment.meteorclient.utils.misc;

/** Keybind value (Meteor compatibility layer). {@code -1} means "not set". */
public class Keybind {
    public static final int NONE = -1;

    private int key;

    public Keybind() {
        this(NONE);
    }

    public Keybind(int key) {
        this.key = key;
    }

    public static Keybind none() {
        return new Keybind(NONE);
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isSet() {
        return key != NONE;
    }

    public String toStr() {
        return isSet() ? String.valueOf(key) : "None";
    }
}
