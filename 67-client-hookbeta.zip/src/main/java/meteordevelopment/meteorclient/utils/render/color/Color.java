package meteordevelopment.meteorclient.utils.render.color;

/** RGBA colour (Meteor compatibility layer). Components are 0-255. */
public class Color {
    public int r;
    public int g;
    public int b;
    public int a;

    public static final Color WHITE = new Color(255, 255, 255);

    public Color(int r, int g, int b) {
        this(r, g, b, 255);
    }

    public Color(int r, int g, int b, int a) {
        this.r = clamp(r);
        this.g = clamp(g);
        this.b = clamp(b);
        this.a = clamp(a);
    }

    public int getRGB() {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public int getAlpha() {
        return a;
    }

    public java.awt.Color toAwt() {
        return new java.awt.Color(r, g, b, a);
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
