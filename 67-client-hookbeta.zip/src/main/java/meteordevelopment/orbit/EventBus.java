package meteordevelopment.orbit;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Minimal replacement for Meteor's orbit bus. Modules subscribe while active; events are plain
 * objects dispatched to {@code @EventHandler} methods by exact parameter type.
 */
public final class EventBus {
    private static final EventBus INSTANCE = new EventBus();

    private final Map<Class<?>, List<Entry>> handlers = new ConcurrentHashMap<>();

    public static EventBus get() {
        return INSTANCE;
    }

    public void subscribe(Object subscriber) {
        for (Method method : subscriber.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(EventHandler.class)) continue;
            if (method.getParameterCount() != 1) continue;
            method.setAccessible(true);
            handlers.computeIfAbsent(method.getParameterTypes()[0], key -> new CopyOnWriteArrayList<>())
                    .add(new Entry(subscriber, method));
        }
    }

    public void unsubscribe(Object subscriber) {
        for (List<Entry> entries : handlers.values()) {
            entries.removeIf(entry -> entry.instance == subscriber);
        }
    }

    public void post(Object event) {
        List<Entry> entries = handlers.get(event.getClass());
        if (entries == null) return;

        for (Entry entry : entries) {
            try {
                entry.method.invoke(entry.instance, event);
            } catch (Throwable t) {
                System.err.println("Hook: handler failed for " + event.getClass().getSimpleName());
                t.printStackTrace(System.err);
            }
        }
    }

    private record Entry(Object instance, Method method) {
    }
}
